function Param = param_powDyn()
% PARAM_STIRREDTANKREACTOR_TRAJ1 - parameters for the stirred-tank reactor
%                                  benchmark
%
% Syntax:
%       Param = PARAM_STIRREDTANKREACTOR_TRAJ1()
%
% Description:
%       Parameters for the stirred-tank reactor benchmark. The parameters 
%       include input constraints, disturbances as well as the parameters 
%       of the motion primitive like initial set, goal state, etc..
%
% Output Arguments:
%
%       -Param:             a structure containing following options
%
%           -.R0:           initial set (class: interval)
%           -.xf:           goal state
%           -.U:            set of admissible control inputs (class:
%                           interval)
%           -.W:            set of uncertain disturbances (class: interval)
%
% See Also:
%       stirredTankReactor
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information plfunction Param = param_powDyn()
% PARAM_STIRREDTANKREACTOR - parameters for the stirred-tank reactor
%                            benchmark
%
% Syntax:
%       Param = PARAM_POWDYN()
%
% Description:
%       Parameters for the IEEE-14 bus benchmark. The parameters 
%       include input constraints, disturbances as well as the parameters 
%       of the motion primitive like initial set, goal state, etc..
%
% Output Arguments:
%
%       -Param:             a structure containing following options
%
%           -.R0:           initial set (class: interval)
%           -.xf:           goal state
%           -.U:            set of admissible control inputs (class:
%                           interval)
%           -.W:            set of uncertain disturbances (class: interval)
%
% See Also:
%       IEEE 14 Bus
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information please visit <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
%
% More Toolbox Info by searching <a href="matlab:docsearch aroc">AROC</a> in the Matlab Documentation
%
%------------------------------------------------------------------
% Authors:      Ashish Kothyari
% Website:      <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
% Work Adress:  Technische Universitaet Muenchen
% Copyright (c) 2020 Chair of Robotics, Artificial Intelligence and
%               Embedded Systems, TU Muenchen
%------------------------------------------------------------------
    
    % final state
    qq = 0.05*ones(5,1);
    ee = 0.1*ones(14,1);
    Param.xf = [qq;zeros(5,1);ee;0.038];
    
    % set of admissible control inputs
    u1 = zeros(5,1);
    u2 = 10*ones(5,1);
    Param.U = interval(u1,u2);
    
    % set of uncertain disturbances
    w1 = zeros(14,1);
    w2 = 0.1*ones(14,1);
    %width = [0.1;1];
    Param.W = interval(w1,w2);

end




