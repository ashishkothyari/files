function Opts = settings_reachsetOptContr_car()
% SETTINGS_REACHSETOPTCONTR_CAR - algorithm settings for the car benchmark 
%
% Syntax:
%       Opts = SETTINGS_REACHSETOPTCONTR_CAR()
%
% Description:
%       Algorithm settings and parameter for the Reachset Optimal Control 
%       algorithm for the car benchmark
%
% Output Arguments:
%
%       -Opts:              a structure containing following options
%
% See Also:
%       reachsetOptimalControl, car
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information please visit <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
%
% More Toolbox Info by searching <a href="matlab:docsearch aroc">AROC</a> in the Matlab Documentation
%
%------------------------------------------------------------------
% Authors:      Niklas Kochdumper
% Website:      <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
% Work Adress:  Technische Universitaet Muenchen
% Copyright (c) 2019 Chair of Robotics, Artificial Intelligence and
%               Embedded Systems, TU Muenchen
%------------------------------------------------------------------
    
    % number of center trajectory and intermediate time steps
    Opts.Nc = 10;
    Opts.Ninter = 4;
    
    % weighting matrices for the cost function (center trajectory)
    Opts.Q = 10*eye(4);             
    Opts.R = 1/10*eye(2); 
    

end