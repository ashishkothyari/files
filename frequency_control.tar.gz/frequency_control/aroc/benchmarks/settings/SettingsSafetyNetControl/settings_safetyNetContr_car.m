function Opts = settings_safetyNetContr_car()
% SETTINGS_SAFETYNETCONTR_CAR - algorithm settings for the car benchmark 
%
% Syntax:
%       Opts = SETTINGS_SAFETYNETCONTR_CAR()
%
% Description:
%       Algorithm settings and parameter for the Safety Net Control
%       Algorithm for the car benchmark (maneuver: turn right)
%
% Output Arguments:
%
%       -Opts:              a structure containing following options
%
%           -.N:            number of time-steps
%                           [{10} / positive integer]
%           -.Ninter:       number of intermediate time steps
%                           [{4} / positive integer]
%           -.Q:            state weighting matrix for the cost function
%                           (reference trajectory)
%           -.R:            input weighting matrix for the cost function
%                           (reference trajectory)
%           -.reachSteps:   number of reachability steps in one time step
%                           [{10} / positive integer]
%           -.order:        maximum zonotope order of backward reach. sets
%                           [{3} / positive integer]
%           -.iter:         number of iterations for optimization
%                           [{1} / positive integer]
%           -.fracInpCent:  maximum portion of the input set that is used 
%                           for the reference trajectory       
%                           [{0.5} / scalar between 0 and 1]
%           -.controller:   comfort controller applied during online exec.
%                           [{'LQR'} or 'MPC']
%           -.contrOpts:    struct with confort controller settings
%
% See Also:
%       safetyNetControl, car
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information please visit <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
%
% More Toolbox Info by searching <a href="matlab:docsearch aroc">AROC</a> in the Matlab Documentation
%
%------------------------------------------------------------------
% Authors:      Niklas Kochdumper
% Website:      <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
% Work Adress:  Technische Universitaet Muenchen
% Copyright (c) 2019 Chair of Robotics, Artificial Intelligence and
%               Embedded Systems, TU Muenchen
%------------------------------------------------------------------    
    
    % max. portion of input set that can be used for reference trajectory
    Opts.fracInpCent = 0.5;
    
    % number of center trajectory and intermediate time steps
    Opts.N = 10;
    Opts.Ninter = 4;
    
    % weighting matrices for the cost function (reference trajectory)
    Opts.Q = 10*eye(4);             
    Opts.R = 1/10*eye(2); 
    
    % additional settings 
    Opts.reachSteps = 5;
    Opts.order = 3;
    Opts.iter = 1;
    
    % settings for the comfort controller that is applied online
    Opts.controller = {'LQR','LQR','LQR','LQR','LQR','LQR'};
    
    Q = diag([0.2 10 31.2 1]);
    contrOpts1.R = diag([50,170]); contrOpts1.Q = Q;
    contrOpts2.R = diag([50,185]); contrOpts2.Q = Q;
    contrOpts3.R = diag([50,200]); contrOpts3.Q = Q;
    contrOpts4.R = diag([60,170]); contrOpts4.Q = Q;
    contrOpts5.R = diag([60,185]); contrOpts5.Q = Q;
    contrOpts6.R = diag([60,200]); contrOpts6.Q = Q;

    Opts.contrOpts = {contrOpts1,contrOpts2,contrOpts3,contrOpts4, ...
                      contrOpts5,contrOpts6};

end