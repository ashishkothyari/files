function folders = excludedFolders()
% Folders that are excluded from the documentation

    folders{1} = 'documentation';
    folders{2} = 'manual';
    folders{3} = 'examples';
    folders{4} = 'unitTests';
    folders{5} = fullfile('algorithms','convexInterpolationControl','acado');
    folders{6} = fullfile('algorithms','safetyNetControl','acado');
    folders{7} = fullfile('algorithms','reachsetMPC','acado');
    folders{8} = fullfile('algorithms','generatorSpaceControl','acado');
    folders{9} = fullfile('algorithms','reachsetOptimalControl','acado');
    folders{10} = fullfile('algorithms','optimizationBasedControl','acado');
    folders{11} = fullfile('benchmarks','automaton','commonroad');

end