% Benchmark Parameter -----------------------------------------------------

% initial set
x0 = [20;0;0;0];
width = [0.2; 0.02; 0.2; 0.2];
Param.R0 = interval(x0-width,x0+width);             
    
% goal state and final time
Param.xf = [20; -0.2; 19.87; -1.99];              
Param.tFinal = 1;                                     
    
% set of admissible control inputs
width = [9.81;0.4];
Param.U = interval(-width,width);                   
    
% set of uncertain disturbances
width = [0.5;0.02];
Param.W = interval(-width,width);                                        


% Algorithm Settings ------------------------------------------------------

% number of time steps
Opts.N = 10;  

% number of reachability analysis time steps
Opts.reachSteps = 12;
Opts.reachStepsFin = 100;
    
% parameters for optimization
Opts.maxIter = 10;
Opts.bound = 10000;

% weighting matrices for reference trajectory
Opts.refTraj.Q = 10*eye(4);             
Opts.refTraj.R = 1/10*eye(2);


% Control Algorithm -------------------------------------------------------

% construct controller for motion primitive
[objContr,res] = optimizationBasedControl('car',Param,Opts);

% simulation 
[res,~,~] = simulateRandom(objContr,res,10,0.5,0.6,2);


% Visualization -----------------------------------------------------------

% visualization (velocity and orientation)
figure; hold on; box on
plotReach(res,[1,2],[.7 .7 .7],'Unify',true,'Order',3);
plotReachTimePoint(res,[1,2],'b');
plot(Param.R0,[1,2],'w','Filled',true);
plotSimulation(res,[1,2],'k');
xlim([19.7,20.3]);
xlabel('$v~[m/s]$','interpreter','latex','fontsize',12); 
ylabel('$\phi~[rad]$','interpreter','latex','fontsize',12);
set(gcf, 'Units', 'centimeters', 'OuterPosition', [0, 0, 10, 10]);

% visualization (position)
figure; hold on; box on
plotReach(res,[3,4],[.7 .7 .7],'Unify',true,'Order',3);
plotReachTimePoint(res,[3,4],'b');
plot(Param.R0,[3,4],'w','Filled',true);
plotSimulation(res,[3,4],'k');
xlim([-2,22]);
xlabel('$x~[m]$','interpreter','latex','fontsize',12);
ylabel('$y~[m]$','interpreter','latex','fontsize',12);
set(gcf, 'Units', 'centimeters', 'OuterPosition', [0, 0, 10, 10]);