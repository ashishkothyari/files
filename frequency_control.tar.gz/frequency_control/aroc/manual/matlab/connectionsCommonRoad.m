
% load CommonRoad file
[statObs,dynObs,x0,goalSet,lanelets] = commonroad2cora('DEU_Ffb-1_2_S-1', 'verbose', false);
 
% plot the traffic scenario
figure; hold on; axis equal; box on;
for i = 1:length(lanelets)
   plot(lanelets{i},[1,2],'FaceColor',[.7 .7 .7],'Filled',true);
end
plot(goalSet{3}.set,[1,2],'r','EdgeColor','none','FaceAlpha',0.5,'Filled',true);
plot(x0.x,x0.y,'.g','MarkerSize',20);
for i = 1:length(dynObs)
   plot(dynObs{i}.set,[1,2],'b','EdgeColor','none','Filled',true);
end
xlim([0,140]);
ylim([-40,40]);
xlabel('$x$','fontsize',15,'fontweight','bold','Interpreter','latex');
ylabel('$y$','fontsize',15,'fontweight','bold','Interpreter','latex');
set(gcf, 'Units', 'centimeters', 'OuterPosition', [0, 0, 15, 10]);