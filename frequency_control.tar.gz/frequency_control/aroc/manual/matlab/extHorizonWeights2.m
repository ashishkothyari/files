%% Weight Functions 

names = {'fall','fallLinear','fallEqDiff'};
decayFunc = cell(length(names),1);
index = 10;

for i = 1:length(names)
   Opts.extHorizon.decay = names{i};
   decayFunc{i} = decayFunctions(index,Opts);
end


%% Plotting

colors = {[0 0.4470 0.7410];[0.8500 0.3250 0.0980];[0.9290 0.6940 0.1250]};

figure; hold on;
handles = [];

for i = 1:length(decayFunc)
    % plot dotted lines
    x = zeros(2*index,1);
    y = zeros(2*index,1);
    decay = decayFunc{i};
    
    counter = 1;
    for j = 1:index
       x(counter) = j-0.5;
       x(counter+1) = j+0.5;
       y(counter) = decay(j);
       y(counter+1) = decay(j);
       counter = counter + 2;
    end
    
    plot(x,y,'--','LineWidth',2,'Color',colors{i});
    
    % plot solid line
    x = zeros(2,1);
    y = zeros(2,1);
    
    for j = 1:index
       x(1) = j-0.5;
       x(2) = j+0.5;
       y(1) = decay(j);
       y(2) = decay(j);
       handle = plot(x,y,'LineWidth',4,'Color',colors{i});
    end
    
    handles = [handles,handle];
end

l = legend(handles,names{:});
set(l,'fontsize',11);
grid on; box on
xlim([0.5,index+0.5]);
ylim([0,1.1]);
xlabel('$i$','fontsize',15,'fontweight','bold','Interpreter','latex');
ylabel('$w(i)$','fontsize',15,'fontweight','bold','Interpreter','latex');
set(gcf, 'Units', 'centimeters', 'OuterPosition', [0, 0, 10, 10]);
