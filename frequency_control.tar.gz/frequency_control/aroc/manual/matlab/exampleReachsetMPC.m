% Benchmark Parameter -----------------------------------------------------

% initial set
x0 = [-0.3;-30];
Param.R0 = interval(x0);             
    
% goal state
Param.xf = [0;0];                                                
    
% set of admissible control inputs
Param.U = interval(-20,70);                  
    
% set of uncertain disturbances
width = [0.1;2];
Param.W = interval(-width,width);                                        


% Algorithm Settings ------------------------------------------------------

% tightend set of admissible control inputs
Opts.U_ = interval(-18,68);
    
% number of time steps and optimization horizon
Opts.N = 5;
Opts.tOpt = 9;
    
% weighting matrices for the optmial control problem
Opts.Q = diag([100,1]);             
Opts.R = 0.9; 
    
% weigthing matrices for the tracking controller
Opts.Qlqr = diag([1;1]);
Opts.Rlqr = 100;
    
% terminal region
A = [-1.0000 0;1.0000 0;30.0000 -1.0000;66.6526 -4.8603;-66.6526 4.8603];
b = [0.3000;0.0620;11.8400;65.0000;15.0000];
Opts.termReg = mptPolytope(A,b);
    
% additional settings
Opts.tComp = 0.54;
Opts.alpha = 0.1;
Opts.maxIter = 50;
Opts.reachSteps = 1;


% Control Algorithm -------------------------------------------------------

% execute control algorithm
res = reachsetMPC('stirredTankReactor',Param,Opts);


% Visualization -----------------------------------------------------------

figure; hold on; box on
plot(Opts.termReg,[1,2],'FaceColor',[100 182 100]./255,...
     'EdgeColor','none','FaceAlpha',0.8,'Filled',true);
plotReach(res,[1,2],[.75 .75 .75]);
plotReachTimePoint(res,[1,2],'b');
plotSimulation(res,[1,2],'r','LineWidth',1.5);
xlabel('$C_A~[mol/l] $','Interpreter','latex','fontsize',12);
ylabel('$T~[K]$','Interpreter','latex','fontsize',12);
xlim([-0.35,0]);
ylim([-33,-10]);
set(gcf, 'Units', 'centimeters', 'OuterPosition', [0, 0, 15, 10]);