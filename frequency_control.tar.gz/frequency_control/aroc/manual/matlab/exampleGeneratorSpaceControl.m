% Benchmark Parameter -----------------------------------------------------

% initial set
x0 = [0;0];
width = [0.2; 0.2];
Param.R0 = interval(x0-width,x0+width);             
    
% goal state and final time
Param.xf = [2;0];              
Param.tFinal = 1;                                     
    
% set of admissible control inputs
Param.U = interval(-14,14);                   
    
% set of uncertain disturbances
width = [0.1;0.1];
Param.W = interval(-width,width);                                         


% Algorithm Settings ------------------------------------------------------

% number of time steps
Opts.N = 10;
Opts.Ninter = 4;

% weighting matrices for optimal control problems
Opts.Q = diag([2,1]);             
Opts.R = 0; 

% weigthing matrice for the reference trajectory
Opts.refTraj.Q = diag([25,25]);
Opts.refTraj.R = 0.0051;


% Control Algorithm -------------------------------------------------------

% construct controller (without extended horizon)
[objContr,res] = generatorSpaceControl('massSpringDamper',Param,Opts);

% construct controller (with extended horizon)
Opts.extHorizon.active = 1;
Opts.extHorizon.horizon = 4;
Opts.extHorizon.decay = 'riseLinear';

[objContrEx,resEx] = generatorSpaceControl('massSpringDamper',Param,Opts);

% simulation 
[res,~,~] = simulateRandom(objContr,res,10,0.5,0.6,2);
[resEx,~,~] = simulateRandom(objContrEx,resEx,10,0.5,0.6,2);


% Visualization -----------------------------------------------------------

% visualization (without extended horizon)
figure; hold on; box on
plotReach(res,[1,2],[.7 .7 .7],'Unify',true,'Order',3);
plotReachTimePoint(res,[1,2],'b');
plot(Param.R0,[1,2],'w','Filled',true);
plotSimulation(res,[1,2],'k');
xlabel('$x~[m]$','Interpreter','latex','fontsize',12);
ylabel('$\dot x~[\frac{m}{s}]$','Interpreter','latex','fontsize',12);
set(gcf, 'Units', 'centimeters', 'OuterPosition', [0, 0, 10, 10]);

% visualization (with extended horizon)
figure; hold on; box on
plotReach(resEx,[1,2],[.7 .7 .7],'Unify',true,'Order',3);
plotReachTimePoint(resEx,[1,2],'r');
plot(Param.R0,[1,2],'w','Filled',true);
plotSimulation(resEx,[1,2],'k');
xlabel('$x~[m]$','Interpreter','latex','fontsize',12);
ylabel('$\dot x~[\frac{m}{s}]$','Interpreter','latex','fontsize',12);
set(gcf, 'Units', 'centimeters', 'OuterPosition', [0, 0, 10, 10]);