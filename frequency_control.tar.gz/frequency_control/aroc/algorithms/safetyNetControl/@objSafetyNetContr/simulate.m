function [res,t,x,u,flag] = simulate(obj,res,x0,w)
% SIMULATE - simulate a trajectory of a nonlinear system controlled with 
%            the Safety Net Controller
%
% Syntax:
%       [res,t,x,u,flag] = SIMULATE(obj,res,x0,w)
%
% Description:
%       Simulate a trajectory of a nonlinear closed-loop system controlled
%       with the Safety Net Controler for a given initial point and given 
%       specific disturbance values over time.
%
% Input Arguments:
%
%       -obj:   object of class objConvInterContr storing the control law
%               computed in the offline-phase
%       -res:   existing results object to which the simulation results
%               should be added
%       -x0:    initial point for the simulation
%       -w:     matrix storing the values for the disturbances over time
%               (dimension: [nw,timeSteps])
%
% Output Arguments:
%
%       -res:   results object storing the simulation data
%       -t:     vector storing the time points for the simulated states
%       -x:     matrix storing the simulated trajectory 
%               (dimension: [|t|,nx])
%       -u:     matrix storing the applied control input 
%               (dimension: [|t|,nu])
%       -flag:  vector storing a flag that specifies which controller was
%               active (1: comfort controller, 0: safety net controller)
%
% See Also:
%       safetyNetControl, simulateRandom
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information please visit <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
%
% More Toolbox Info by searching <a href="matlab:docsearch aroc">AROC</a> in the Matlab Documentation
%
%------------------------------------------------------------------
% Authors:      Moritz Klischat, Niklas Kochdumper
% Website:      <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
% Work Adress:  Technische Universitaet Muenchen
% Copyright (c) 2019 Chair of Robotics, Artificial Intelligence and
%               Embedded Systems, TU Muenchen
%------------------------------------------------------------------    


    % check if the number of specified disturbance vectors is correct
    if size(w,2) > 1
        Nw = size(w,2)/(obj.N * obj.Ninter);
        if Nw < 1 || floor(Nw) ~= Nw
           error('Number of disturbance vectors has to be a multiple of ''N*Ninter''!'); 
        end
    end
    
    % initialize comfort controllers
    for i = 1:length(obj.comfContr)
       init(obj.comfContr{i}); 
    end
    
    % initialization
    x_ = x0;
    x = []; u = []; t = []; flag = [];
    counter = 1;
    
    % loop over all time steps
    for i = 1:obj.N
        
        wTemp = w(:,counter:counter+obj.Ninter-1);
        comfFeas = 0;
        
        % loop over all parallel comfort controller
        for j = 1:length(obj.comfContr)
        
            % compute the reachable set of the comfort controller
            [conSat,R,Param] = reachSet(obj.comfContr{j},x_,i);

            % check if the input constraints are satisfied and the reachable 
            % set of the comfort controller is located inside the reachable
            % set of the safety net controller
            if conSat == 1 && in(obj.reachSet{i+1},R)
                % comfort controller feasible -> execute comfort controller
                [tTemp,xTemp,uTemp] = simulate(obj.comfContr{j},x_,wTemp,Param,i);
                fTemp = ones(size(tTemp));
                comfFeas = 1;
                break;
            end
        end
        
        % no comfort controller feasible -> execute safety net controller
        if ~comfFeas
            [tTemp,xTemp,uTemp] = simulateSafetyNet(obj,x_,wTemp,i);
            fTemp = zeros(size(tTemp));
        end
        
        % store the simulation results
        x_ = xTemp(end,:)'; x = [x;xTemp]; u = [u;uTemp]; 
        flag = [flag;fTemp];
        if isempty(t)
            t = [t;tTemp];
        else
            t = [t;t(end)+tTemp];
        end
        counter = counter + obj.Ninter;
    end

    % store simulation in results object
    if isempty(res)
        sim{1}.t = t; sim{1}.x = x; sim{1}.u = u; sim{1}.flag = flag;
        res = results([],[],[],sim);
    else
        sim = res.simulation;

        if isempty(sim)
           sim{1}.t = t; sim{1}.x = x; sim{1}.u = u; sim{1}.flag = flag;
        else
           sim{end+1}.t = t; sim{end}.x = x; 
           sim{end}.u = u; sim{end}.flag = flag;
        end

        res = results(res.reachSet,res.reachSetTimePoint,res.refTraj,sim);
    end
end

% Auxiliary Functions -----------------------------------------------------

function [t,x,u] = simulateSafetyNet(obj,x0,w,iter)
% simulate the trajecoty for the safety net controller for one time step

    U = obj.Usub{iter};
    H = obj.H{iter};
    x_ = x0;
    Nw = size(w,2);
    nu = dim(U{1});
    timeStep = obj.tFinal/(obj.N*obj.Ninter*Nw);
    x = []; t = []; u = [];

    % solve linear program to obtain the value for the factors alpha
    alpha = getFactorValues(obj,x0,iter);

    % loop over all intermediate time steps
    for i = 1:obj.Ninter
       
        % compute control input
        cu = center(U{i});
        Gu = generators(U{i});
        
        ind = (obj.Ninter-i)*nu;
        H_ = H(ind+1:ind+nu,:);
        
        u_ = cu + Gu*H_*alpha;
        
        % simulate the system
        for k = 1:Nw
            [tTemp,xTemp] = ode45(@(t,x)obj.dynamics(x,u_,w(:,k)),[0 timeStep],x_);

            x_ = xTemp(end,:)';
            x = [x;xTemp]; u = [u;ones(size(xTemp,1),1)*u_'];
            if isempty(t)
                t = [t;tTemp];
            else
                t = [t;t(end)+tTemp];
            end
        end
    end
end


function alpha = getFactorValues(obj,x0,iter)
% compute the values for the factors alpha by solving the linear program
%
%   min \sum_i |\alpha_i|   s.t. c+G*\alpha = x0, -1 < \alpha_i < 1
%   
% To handle the absolute value in the objective function we transform this
% to the following equivalent optimization problem with slack variables y:
%
%  min \sum_ y1_i + y2_i    s.t. c+G*\alpha = x0, -1 < \alpha_i < 1
%                                alpha_i = y1_i - y2_i, y1_i > 0, y2_i > 0
%
% We use the state vector x = [\alpha;y1_1; ...;y1_n;y2_1;...;y2_n],

    % get object properties
    c = center(obj.reachSet{iter});
    G = generators(obj.reachSet{iter});
    
    n = size(G,2);
    
    % objective function \sum_ y1_i + y2_i 
    f = [zeros(n,1);ones(2*n,1)];
    
    % constraints -1 < \alpha_i < 1 and y1_i > 0, y2_i > 0
    lb = [-ones(n,1);zeros(2*n,1)];
    ub = ones(3*n,1);
    
    % constraint c+G*\alpha = x0
    Aeq1 = [G,zeros(size(G,1),2*n)];
    beq1 = x0 - c;
    
    % constraint alpha_i = y1_i - y2_i
    Aeq2 = [-eye(n),-eye(n),eye(n)];
    beq2 = zeros(n,1);
    
    Aeq = [Aeq1;Aeq2];
    beq = [beq1;beq2];
    
    % solve linear program
    options = optimoptions('linprog','Algorithm','interior-point', ...
                           'MaxIterations',10000,'display','off');

    [xOpt,~,exitflag] = linprog(f',[],[],Aeq,beq,lb,ub,options);
    
    if exitflag < 0
       error('Linear programm failed!'); 
    end
    
    % get values for the factors
    alpha = xOpt(1:n);
end