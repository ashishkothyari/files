classdef comfContrMPC
% COMFCONTRMPC - class representing a MPC controller object 
%
% Syntax:
%       obj = CONFCONTRMPC(benchmark,Opts,ContrOpts)
%
% Description:
%       This class represents a MPC (Model Predictive Control) controller
%       object which can be used as a comfort controller during the online
%       phase of the Safety Net Controller.
%
% Input Arguments:
%
%       -benchmark:    name of the considered benchmark model (see
%                      "aroc/benchmarks/...")
%       -Opts:              a structure containing following options
%
%           -.xf:           goal state
%           -.tFinal:       final time after which the goal set should be
%                           reached
%           -.U:            set of admissible control inputs (class:
%                           interval)
%           -.W:            set of uncertain disturbances (class: interval)
%           -.N:            number of time-steps
%                           [{10} / positive integer]
%           -.Ninter:       number of intermediate time steps
%                           [{4} / positive integer]
%           -.reachSteps:   number of reachability steps in one time step
%                           [{10} / positive integer]
%           -.xCenter:      reference trajectory states
%           -.uCetner:      reference trajectory inputs
%
%       -ContrOpts:         a structure with options for comfort controller
%   
%           -.Q:            state weighting matrix for the MPC controller
%           -.R:            input weighting matrix for the MPC controller
%           -.horizon:      optimization horizon for the optimal control
%                           problems
%
% Output Arguments:
%
%       -obj:   resulting object of class comfContrMPC
%
% See Also:
%       safetyNetControl, objSafetyNetContr
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information please visit <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
%
% More Toolbox Info by searching <a href="matlab:docsearch aroc">AROC</a> in the Matlab Documentation
%
%------------------------------------------------------------------
% Authors:      Moritz Klischat, Niklas Kochdumper
% Website:      <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
% Work Adress:  Technische Universitaet Muenchen
% Copyright (c) 2019 Chair of Robotics, Artificial Intelligence and
%               Embedded Systems, TU Muenchen
%------------------------------------------------------------------   
    
properties (SetAccess = protected, GetAccess = public)
    xf = [];            % final state
    tFinal = [];        % final time
    U = [];             % set of admissble control inputs
    W = [];             % set of disturbances
    N = [];             % number of time steps
    Ninter = [];        % number of intermediate time steps
    reachSteps = [];    % number of reachability steps
    xCenter = [];       % reference trajectory states
    uCenter = [];       % reference trajectory inputs
    horizon = [];       % length of the optimization horizon
    OptContrOpts = [];  % settings for solving optimal control problems
    ReachOpts = [];     % reachability options for CORA toolbox
    ReachParams = [];   % reachability parameter for CORA toolbox
    sys = [];           % nonlinSys object with system dynamics
    nx = [];            % number of states
    nu = [];            % number of inputs
    nw = [];            % number of disturbances
    path = [];          % file path to the ACADO files
    benchmark = [];     % name of the bechmark
    funHandle = [];     % function handle to the dynamic function
end
   
methods

    function obj = comfContrMPC(benchmark,Opts,ContrOpts)
    % object constructor
        
        % copy options from input arguments
        obj.benchmark = benchmark;
        
        obj.xf = Opts.xf;
        obj.tFinal = Opts.tFinal;
        obj.U = Opts.U;
        obj.W = Opts.W;
        obj.N = Opts.N;
        obj.Ninter = Opts.Ninter;
        obj.xCenter = Opts.xCenter;
        obj.uCenter = Opts.uCenter;
        obj.reachSteps = Opts.reachSteps;
        
        obj.horizon = ContrOpts.horizon;
        
        % store useful parameters
        obj.nx = length(obj.xf);
        obj.nu = dim(obj.U);
        obj.nw = dim(obj.W);
        
        % set options for reachability analysis with the CORA toolbox
        [params,options] = coraOptions(obj);
        obj.ReachOpts = options;
        obj.ReachParams = params;
        
        % construct the system dynamics of the controlled system
        str = ['funHandle = @(x,u,w)',benchmark,'(x,u,w);'];
        eval(str);
        
        funHanMPC = @(x,w) dynamicsClosedLoopLinear(x,w,obj.nx, ...
                                                      obj.nu,funHandle);
                                           
        obj.sys = nonlinearSys(@(x,w) funHanMPC(x,w),obj.nx+obj.nu,obj.nw);                
        obj.funHandle = funHandle;
        
        % set options for solving optimal control problems
        obj.OptContrOpts = optimalControlOptions(obj,ContrOpts);
    end    
    
    function [params,options] = coraOptions(obj)
    % define the settings for the CORA reachability analysis toolbox

        % set of disturbances and final time for reachability analysis
        params.U = zonotope(obj.W);
        params.tFinal = obj.tFinal/(obj.N*obj.Ninter);   

        % set options for CORA toolbox      
        options.taylorTerms = 20;         
        options.zonotopeOrder = 30;       
        options.intermediateOrder = 20;   

        options.timeStep = params.tFinal/obj.reachSteps;            

        % additional parameters for reachability analysis
        options.alg = 'lin';
        options.tensorOrder = 2;
    end
    
    function Opts = optimalControlOptions(obj,ContrOpts)
    % define the settings for solving optimal control problems
        
        % set options for optimal control problems
        Opts.Nc = obj.N*obj.Ninter;
        Opts.nx = obj.nx;
        Opts.nu = obj.nu;
        Opts.nw = obj.nw;
        Opts.hc = obj.tFinal/Opts.Nc;
        Opts.xf = obj.xf;
        Opts.uMax = supremum(obj.U);
        Opts.uMin = infimum(obj.U);
        Opts.extHorizon.active = 0;
        Opts.extHorizon.horizon = 1;
        Opts.extHorizon.decay = 'uniform';
        
        % check if ACADO toolbox is installed
        if isempty(which('BEGIN_ACADO'))
            Opts.useAcado = 0;
        else
            Opts.useAcado = 1;
        end
        
        % store state and input weightening matrix
        Opts.Q = ContrOpts.Q;
        Opts.R = ContrOpts.R;
    end
end
end