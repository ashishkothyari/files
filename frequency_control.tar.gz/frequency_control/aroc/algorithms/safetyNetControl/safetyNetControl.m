function [objContr,res] = safetyNetControl(benchmark,Param,Opts,varargin)
% SAFETYNETCONTROL - Implementation of the safety net controller based on
%                    backward rechable set computation
%
% Syntax:
%       [objContr,res] = SAFETYNETCONTROL(benchmark,Param,Opts)
%       [objContr,res] = SAFETYNETCONTROL(benchmark,Param,Opts,Post)
%
% Description:
%       Offline-phase computations for the Safety Net Control Algorithm 
%       Algorithm. 
%
% Input Arguments:
%
%       -benchmark:    name of the considered benchmark model (see
%                      "aroc/benchmarks/...")
%       -Param:             a structure containing the benchmark parameters
%
%           -.R0:           initial set of states (class: interval)
%           -.xf:           goal state
%           -.tFinal:       final time after which the goal state should be
%                           reached
%           -.U:            set of admissible control inputs (class:
%                           interval)
%           -.W:            set of uncertain disturbances (class: interval)
%
%       -Opts:              a structure containing the algorithm settings
%
%           -.N:            number of time-steps
%                           [{10} / positive integer]
%           -.Ninter:       number of intermediate time steps
%                           [{4} / positive integer]
%           -.Q:            state weighting matrix for the cost function
%                           (reference trajectory)
%           -.R:            input weighting matrix for the cost function
%                           (reference trajectory)
%           -.reachSteps:   number of reachability steps in one time step
%                           [{10} / positive integer]
%           -.order:        maximum zonotope order of backward reach. sets
%                           [{3} / positive integer]
%           -.iter:         number of iterations for optimization
%                           [{1} / positive integer]
%           -.fracInpCent:  maximum portion of the input set that is used 
%                           for the reference trajectory       
%                           [{0.5} / scalar between 0 and 1]
%           -.controller:   comfort controller applied during online exec.
%                           [{'LQR'} or 'MPC']
%           -.contrOpts:    struct with confort controller settings
%
%           -.refTraj.x:    user provided reference trajectory
%                           (dimension: [nx,N*Ninter + 1])
%           -.refTraj.u     inputs for the user provided reference
%                           trajectory (dimension: [nu,N*Ninter])
%
%       -Post:      function handle to the postprocessing function that is
%                   used to compute the occupancy set
%
% Output Arguments:
%
%       -objContr:  resulting controller storing the data computed during
%                   the offline phase (class: objSafteyNetContr)
%       -res:       results object storing the computed reachable set and
%                   the center trajectory
%
% See Also:
%       objSafetyNetContr
%
% References:
%       * *[1] Schuermann et al. (2019)*, Formal Safety Net Control Using
%              Backward Reachability Analysis
%
%------------------------------------------------------------------
% This file is part of <a href="matlab:docsearch aroc">AROC</a>, a Toolbox for Automatic Reachset-
% Optimal Controller Synthesis developed at the Chair of Robotics, 
% Artificial Intelligence and Embedded Systems, 
% Technische Universitaet Muenchen. 
%
% For updates and further information please visit <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
%
% More Toolbox Info by searching <a href="matlab:docsearch aroc">AROC</a> in the Matlab Documentation
%
%------------------------------------------------------------------
% Authors:      Moritz Klischat, Niklas Kochdumper
% Website:      <a href="http://aroc.in.tum.de">aroc.in.tum.de</a>
% Work Adress:  Technische Universitaet Muenchen
% Copyright (c) 2019 Chair of Robotics, Artificial Intelligence and
%               Embedded Systems, TU Muenchen
%------------------------------------------------------------------


%% Parse Input Arguments

% Default values
Def = defaultSettings();

% Parse Options
Opts = parseOpts(Opts,Def);


%% Initialization

[sys,Opts] = initialization(benchmark,Param,Opts);

% cell-array storing the time point reach. set at each ref. traj. time step
zono = cell(Opts.N+1,1);
zono{end} = zonotope(Opts.Xf);
R0 = zono{end};

% cell-array storing the time interval reachable set
Rcont = cell(Opts.N,1);

% matrix storing the generator-to-input assignments
H = cell(Opts.N,1);


%% Reference Trajectory

% compute center trajectory
dyn = Opts.funHandle;
[xCenter,uCenter] = centerTrajectory(dyn,Opts);
    
% compute the adapted input sets shifted by the center trajectory
[U,xCenter,uCenter] = subsetsInput(xCenter,uCenter,Opts);


%% Algorithm 

% loop backward over all center-trajectory time steps
for i = Opts.N:-1:1
    
    fprintf('Iteration: %i\n\n',Opts.N-i+1);
    Opts.tStart = (i-1)*Opts.timeStep;
    
    % backward reachable set for linearized dynamics (Sec. V.C. in [1])
    [Rtemp,H{i}] = linearBackwardReach(R0,xCenter{i},uCenter{i},U{i},Opts);
    
    % scale the initial set to obtain the backward reachable set for the
    % nonlinear dynamics (Sec. V.E in [1])
    [zono{i},Rcont{i}] = scaleInitialSet(sys,Rtemp,H{i},zono{i+1},U{i},Opts);
                                         
    % reduce the order of the zonotope
    R0 = orderReduction(zono{i},Opts.order);
end


%% Assign output values

% construct reachSet object
reachSet = Rcont{1};
for i = 2:length(Rcont)
   reachSet = add(reachSet,Rcont{i}); 
end

% construct comfort controller
Opts.xCenter = xCenter;
Opts.uCenter = uCenter;
listComf = cell(length(Opts.controller),1);

for i = 1:length(Opts.controller)
    str = ['objComf = comfContr',Opts.controller{i},'(''',benchmark, ...
            ''',Opts,Opts.contrOpts{i});'];
    eval(str);
    listComf{i} = objComf;
end

% create results object
res = results(reachSet,zono,xCenter,[]);

% compute the occupancy set
occSet = [];

if nargin > 3
   post = varargin{1};
   occSet = compOccupancySet(reachSet,post,Opts);
end

% create controller object
contrLaw.comfContr = listComf;
contrLaw.reachSet = zono;
contrLaw.H = H;
contrLaw.N = Opts.N;
contrLaw.Ninter = Opts.Ninter;
contrLaw.Rinit = Param.R0;
contrLaw.Usub = U;

Param.R0 = zono{1};

objContr = objSafetyNetContr(Opts.funHandle,zono{end},contrLaw,Param,occSet);

end

% Auxiliary Functions -----------------------------------------------------

function [sys,Opts] = initialization(benchmark,Param,Opts)
    
    % copy benchmark parameter to options
    Opts.W = Param.W;
    Opts.U = Param.U;
    Opts.tFinal = Param.tFinal;
    Opts.R0 = Param.R0;
    Opts.Xf = Param.R0 - center(Param.R0) + Param.xf;

    % time steps size
    Opts.Nc = Opts.N*Opts.Ninter;            % center trajectory time steps
    Opts.timeStep = Opts.tFinal/Opts.N;      % time step size
    Opts.hc = Opts.tFinal/Opts.Nc;           % size center traj. time step
    Opts.dt = Opts.hc;                       % size intermediate time step
    
    % final and initial state
    Opts.xf = center(Opts.Xf);
    Opts.x0 = center(Param.R0);
    
    % store important paramters in the Opts-struct
    Opts.nx = length(Opts.Xf);
    Opts.nu = length(Opts.U);
    Opts.nw = length(Opts.W);
    
    Opts.uMinTotal = infimum(Opts.U);
    Opts.uMaxTotal = supremum(Opts.U);
    
    % compute the tightend input constraints for the reference trajectory
    Utemp = enlarge(Opts.U,Opts.fracInpCent);
    Opts.uMin = infimum(Utemp);
    Opts.uMax = supremum(Utemp);
    
    Opts.nGen = Opts.order * Opts.nx + Opts.nu*Opts.Ninter;
    
    % convert control law parameters to cell
    if ~iscell(Opts.controller)
       Opts.controller = {Opts.controller};
       Opts.contrOpts = {Opts.contrOpts};
    end
    
    % function handle to dynamic file
    str = ['Opts.funHandle = @(x,u,w)',benchmark,'(x,u,w);'];
    eval(str);
    
    % generate function handles for linearized dynamics
    x = sym('x',[Opts.nx,1]); 
    u = sym('u',[Opts.nu,1]);
    w = sym(zeros(Opts.nw,1));
    
    f = Opts.funHandle(x,u,w);
    
    A = jacobian(f,x);
    B = jacobian(f,u);
    
    Opts.linDyn.A = matlabFunction(A,'Vars',{x,u});
    Opts.linDyn.B = matlabFunction(B,'Vars',{x,u});

    % set options for reachability analysis with the CORA toolbox
    Opts = coraOptions(Opts);
    
    % generate ACADO files
    if isempty(which('BEGIN_ACADO'))
        Opts.useAcado = 0;
        Opts.extHorizon.active = 0;
        Opts.extHorizon.horizon = 1;
        Opts.extHorizon.decay = 'uniform';
    else
        Opts.useAcado = 1;

        w = warning();
        warning('off','all');

        [path,~,~] = fileparts(mfilename('fullpath'));
        rmpath(genpath(fullfile(path,'acado')));

        Opts_ = Opts;
        Opts_.extHorizon.active = 0;
        Opts_.extHorizon.horizon = 1;
        Opts_.extHorizon.decay = 'uniform';
        
        acadoConvertDynamics(path,Opts_,benchmark);
        writeAcadoFiles(path,benchmark,Opts_);

        warning(w);
    end    
    
    % generate system dynamics
    nExtended = Opts.nx + Opts.nu + Opts.nGen;
    
    funHan = @(x,w) dynamicsClosedLoopLinear(x,w,Opts.nx, ...
                                               Opts.nu,Opts.funHandle);
                                           
    sys = nonlinearSys(@(x,w) funHan(x,w),nExtended,Opts.nw);
end

function Def = defaultSettings()
% default values for the algorithm settings

    Def.N = 10;
    Def.Ninter = 4;
    Def.fracInpCent = 0.5;
    Def.reachSteps = 10;
    Def.order = 3;
    Def.iter = 1;
    Def.controller = 'LQR';
end

function Opts = coraOptions(Opts)
% define the settings for the CORA reachability analysis toolbox
    
    % set of disturbances for reachability analysis
    params.U = zonotope(Opts.W);

    % set options for CORA toolbox
    options.tFinal = Opts.hc;         % duration of reachability analysis
    options.taylorTerms = 20;         % number of taylor terms for reachable sets
    options.zonotopeOrder = 30;       % zonotope order in reachability analysis
    options.intermediateOrder = 20;   % intermediate zonotope order used in reachability analysis
    
    options.timeStep = Opts.hc ...
        / Opts.reachSteps;            % length of each time step in reachability analysis

    % additional parameters for reachability analysis
    options.alg = 'poly';
   
    options.errorOrder = 5;
    options.tensorOrder = 3;
    
    % store reachability options
    Opts.ReachOpts = options;
    Opts.ReachParams = params;
end