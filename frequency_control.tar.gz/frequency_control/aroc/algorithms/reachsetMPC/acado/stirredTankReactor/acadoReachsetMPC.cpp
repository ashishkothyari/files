/*
*    This file is part of ACADO Toolkit.
*
*    ACADO Toolkit -- A Toolkit for Automatic Control and Dynamic Optimization.
*    Copyright (C) 2008-2009 by Boris Houska and Hans Joachim Ferreau, K.U.Leuven.
*    Developed within the Optimization in Engineering Center (OPTEC) under
*    supervision of Moritz Diehl. All rights reserved.
*
*    ACADO Toolkit is free software; you can redistribute it and/or
*    modify it under the terms of the GNU Lesser General Public
*    License as published by the Free Software Foundation; either
*    version 3 of the License, or (at your option) any later version.
*
*    ACADO Toolkit is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*    Lesser General Public License for more details.
*
*    You should have received a copy of the GNU Lesser General Public
*    License along with ACADO Toolkit; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*
*/


/**
*    Author David Ariens, Rien Quirynen
*    Date 2009-2013
*    http://www.acadotoolkit.org/matlab 
*/

#include <acado_optimal_control.hpp>
#include <acado_toolkit.hpp>
#include <acado/utils/matlab_acado_utils.hpp>

USING_NAMESPACE_ACADO

#include <mex.h>


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] ) 
 { 
 
    MatlabConsoleStreamBuf mybuf;
    RedirectStream redirect(std::cout, mybuf);
    clearAllStaticCounters( ); 
 
    mexPrintf("\nACADO Toolkit for Matlab - Developed by David Ariens and Rien Quirynen, 2009-2013 \n"); 
    mexPrintf("Support available at http://www.acadotoolkit.org/matlab \n \n"); 

    if (nrhs != 31){ 
      mexErrMsgTxt("This problem expects 31 right hand side argument(s) since you have defined 31 MexInput(s)");
    } 
 
    TIME autotime;
    DifferentialState x1;
    DifferentialState x2;
    DifferentialState x3;
    DifferentialState x4;
    DifferentialState x5;
    DifferentialState x6;
    DifferentialState x7;
    DifferentialState x8;
    DifferentialState x9;
    DifferentialState x10;
    DifferentialState x11;
    DifferentialState x12;
    DifferentialState x13;
    DifferentialState x14;
    DifferentialState x15;
    DifferentialState x16;
    DifferentialState x17;
    DifferentialState x18;
    DifferentialState x19;
    DifferentialState x20;
    DifferentialState x21;
    DifferentialState x22;
    DifferentialState inputcost;
    Parameter p1; 
    Parameter p2; 
    Parameter p3; 
    Parameter p4; 
    Parameter p5; 
    Parameter p6; 
    Parameter p7; 
    Parameter p8; 
    Parameter p9; 
    Parameter p10; 
    Parameter p11; 
    Parameter p12; 
    Parameter p13; 
    Parameter p14; 
    Parameter p15; 
    Parameter p16; 
    Parameter p17; 
    Parameter p18; 
    Parameter p19; 
    Parameter p20; 
    Parameter ps1; 
    Parameter ps2; 
    Parameter ps3; 
    Parameter ps4; 
    Parameter ps5; 
    Parameter ps6; 
    Parameter ps7; 
    Parameter ps8; 
    Parameter ps9; 
    Parameter ps10; 
    Parameter ps11; 
    Control u1;
    Control u2;
    Control u3;
    Control u4;
    Control u5;
    Control u6;
    Control u7;
    Control u8;
    Control u9;
    Control u10;
    Control u11;
    double *mexinput0_temp = NULL; 
    if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) || !(mxGetM(prhs[0])==1 && mxGetN(prhs[0])==1) ) { 
      mexErrMsgTxt("Input 0 must be a noncomplex scalar double.");
    } 
    mexinput0_temp = mxGetPr(prhs[0]); 
    double mexinput0 = *mexinput0_temp; 

    double *mexinput1_temp = NULL; 
    if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) ) { 
      mexErrMsgTxt("Input 1 must be a noncomplex scalar double.");
    } 
    mexinput1_temp = mxGetPr(prhs[1]); 
    double mexinput1 = *mexinput1_temp; 

    double *mexinput2_temp = NULL; 
    if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) ) { 
      mexErrMsgTxt("Input 2 must be a noncomplex scalar double.");
    } 
    mexinput2_temp = mxGetPr(prhs[2]); 
    double mexinput2 = *mexinput2_temp; 

    double *mexinput3_temp = NULL; 
    if( !mxIsDouble(prhs[3]) || mxIsComplex(prhs[3]) || !(mxGetM(prhs[3])==1 && mxGetN(prhs[3])==1) ) { 
      mexErrMsgTxt("Input 3 must be a noncomplex scalar double.");
    } 
    mexinput3_temp = mxGetPr(prhs[3]); 
    double mexinput3 = *mexinput3_temp; 

    double *mexinput4_temp = NULL; 
    if( !mxIsDouble(prhs[4]) || mxIsComplex(prhs[4]) || !(mxGetM(prhs[4])==1 && mxGetN(prhs[4])==1) ) { 
      mexErrMsgTxt("Input 4 must be a noncomplex scalar double.");
    } 
    mexinput4_temp = mxGetPr(prhs[4]); 
    double mexinput4 = *mexinput4_temp; 

    double *mexinput5_temp = NULL; 
    if( !mxIsDouble(prhs[5]) || mxIsComplex(prhs[5]) || !(mxGetM(prhs[5])==1 && mxGetN(prhs[5])==1) ) { 
      mexErrMsgTxt("Input 5 must be a noncomplex scalar double.");
    } 
    mexinput5_temp = mxGetPr(prhs[5]); 
    double mexinput5 = *mexinput5_temp; 

    double *mexinput6_temp = NULL; 
    if( !mxIsDouble(prhs[6]) || mxIsComplex(prhs[6]) || !(mxGetM(prhs[6])==1 && mxGetN(prhs[6])==1) ) { 
      mexErrMsgTxt("Input 6 must be a noncomplex scalar double.");
    } 
    mexinput6_temp = mxGetPr(prhs[6]); 
    double mexinput6 = *mexinput6_temp; 

    double *mexinput7_temp = NULL; 
    if( !mxIsDouble(prhs[7]) || mxIsComplex(prhs[7]) || !(mxGetM(prhs[7])==1 && mxGetN(prhs[7])==1) ) { 
      mexErrMsgTxt("Input 7 must be a noncomplex scalar double.");
    } 
    mexinput7_temp = mxGetPr(prhs[7]); 
    double mexinput7 = *mexinput7_temp; 

    double *mexinput8_temp = NULL; 
    if( !mxIsDouble(prhs[8]) || mxIsComplex(prhs[8]) || !(mxGetM(prhs[8])==1 && mxGetN(prhs[8])==1) ) { 
      mexErrMsgTxt("Input 8 must be a noncomplex scalar double.");
    } 
    mexinput8_temp = mxGetPr(prhs[8]); 
    double mexinput8 = *mexinput8_temp; 

    double *mexinput9_temp = NULL; 
    if( !mxIsDouble(prhs[9]) || mxIsComplex(prhs[9]) || !(mxGetM(prhs[9])==1 && mxGetN(prhs[9])==1) ) { 
      mexErrMsgTxt("Input 9 must be a noncomplex scalar double.");
    } 
    mexinput9_temp = mxGetPr(prhs[9]); 
    double mexinput9 = *mexinput9_temp; 

    double *mexinput10_temp = NULL; 
    if( !mxIsDouble(prhs[10]) || mxIsComplex(prhs[10]) || !(mxGetM(prhs[10])==1 && mxGetN(prhs[10])==1) ) { 
      mexErrMsgTxt("Input 10 must be a noncomplex scalar double.");
    } 
    mexinput10_temp = mxGetPr(prhs[10]); 
    double mexinput10 = *mexinput10_temp; 

    double *mexinput11_temp = NULL; 
    if( !mxIsDouble(prhs[11]) || mxIsComplex(prhs[11]) || !(mxGetM(prhs[11])==1 && mxGetN(prhs[11])==1) ) { 
      mexErrMsgTxt("Input 11 must be a noncomplex scalar double.");
    } 
    mexinput11_temp = mxGetPr(prhs[11]); 
    double mexinput11 = *mexinput11_temp; 

    double *mexinput12_temp = NULL; 
    if( !mxIsDouble(prhs[12]) || mxIsComplex(prhs[12]) || !(mxGetM(prhs[12])==1 && mxGetN(prhs[12])==1) ) { 
      mexErrMsgTxt("Input 12 must be a noncomplex scalar double.");
    } 
    mexinput12_temp = mxGetPr(prhs[12]); 
    double mexinput12 = *mexinput12_temp; 

    double *mexinput13_temp = NULL; 
    if( !mxIsDouble(prhs[13]) || mxIsComplex(prhs[13]) || !(mxGetM(prhs[13])==1 && mxGetN(prhs[13])==1) ) { 
      mexErrMsgTxt("Input 13 must be a noncomplex scalar double.");
    } 
    mexinput13_temp = mxGetPr(prhs[13]); 
    double mexinput13 = *mexinput13_temp; 

    double *mexinput14_temp = NULL; 
    if( !mxIsDouble(prhs[14]) || mxIsComplex(prhs[14]) || !(mxGetM(prhs[14])==1 && mxGetN(prhs[14])==1) ) { 
      mexErrMsgTxt("Input 14 must be a noncomplex scalar double.");
    } 
    mexinput14_temp = mxGetPr(prhs[14]); 
    double mexinput14 = *mexinput14_temp; 

    double *mexinput15_temp = NULL; 
    if( !mxIsDouble(prhs[15]) || mxIsComplex(prhs[15]) || !(mxGetM(prhs[15])==1 && mxGetN(prhs[15])==1) ) { 
      mexErrMsgTxt("Input 15 must be a noncomplex scalar double.");
    } 
    mexinput15_temp = mxGetPr(prhs[15]); 
    double mexinput15 = *mexinput15_temp; 

    double *mexinput16_temp = NULL; 
    if( !mxIsDouble(prhs[16]) || mxIsComplex(prhs[16]) || !(mxGetM(prhs[16])==1 && mxGetN(prhs[16])==1) ) { 
      mexErrMsgTxt("Input 16 must be a noncomplex scalar double.");
    } 
    mexinput16_temp = mxGetPr(prhs[16]); 
    double mexinput16 = *mexinput16_temp; 

    double *mexinput17_temp = NULL; 
    if( !mxIsDouble(prhs[17]) || mxIsComplex(prhs[17]) || !(mxGetM(prhs[17])==1 && mxGetN(prhs[17])==1) ) { 
      mexErrMsgTxt("Input 17 must be a noncomplex scalar double.");
    } 
    mexinput17_temp = mxGetPr(prhs[17]); 
    double mexinput17 = *mexinput17_temp; 

    double *mexinput18_temp = NULL; 
    if( !mxIsDouble(prhs[18]) || mxIsComplex(prhs[18]) || !(mxGetM(prhs[18])==1 && mxGetN(prhs[18])==1) ) { 
      mexErrMsgTxt("Input 18 must be a noncomplex scalar double.");
    } 
    mexinput18_temp = mxGetPr(prhs[18]); 
    double mexinput18 = *mexinput18_temp; 

    double *mexinput19_temp = NULL; 
    if( !mxIsDouble(prhs[19]) || mxIsComplex(prhs[19]) || !(mxGetM(prhs[19])==1 && mxGetN(prhs[19])==1) ) { 
      mexErrMsgTxt("Input 19 must be a noncomplex scalar double.");
    } 
    mexinput19_temp = mxGetPr(prhs[19]); 
    double mexinput19 = *mexinput19_temp; 

    double *mexinput20_temp = NULL; 
    if( !mxIsDouble(prhs[20]) || mxIsComplex(prhs[20]) || !(mxGetM(prhs[20])==1 && mxGetN(prhs[20])==1) ) { 
      mexErrMsgTxt("Input 20 must be a noncomplex scalar double.");
    } 
    mexinput20_temp = mxGetPr(prhs[20]); 
    double mexinput20 = *mexinput20_temp; 

    double *mexinput21_temp = NULL; 
    if( !mxIsDouble(prhs[21]) || mxIsComplex(prhs[21]) || !(mxGetM(prhs[21])==1 && mxGetN(prhs[21])==1) ) { 
      mexErrMsgTxt("Input 21 must be a noncomplex scalar double.");
    } 
    mexinput21_temp = mxGetPr(prhs[21]); 
    double mexinput21 = *mexinput21_temp; 

    double *mexinput22_temp = NULL; 
    if( !mxIsDouble(prhs[22]) || mxIsComplex(prhs[22]) || !(mxGetM(prhs[22])==1 && mxGetN(prhs[22])==1) ) { 
      mexErrMsgTxt("Input 22 must be a noncomplex scalar double.");
    } 
    mexinput22_temp = mxGetPr(prhs[22]); 
    double mexinput22 = *mexinput22_temp; 

    double *mexinput23_temp = NULL; 
    if( !mxIsDouble(prhs[23]) || mxIsComplex(prhs[23]) || !(mxGetM(prhs[23])==1 && mxGetN(prhs[23])==1) ) { 
      mexErrMsgTxt("Input 23 must be a noncomplex scalar double.");
    } 
    mexinput23_temp = mxGetPr(prhs[23]); 
    double mexinput23 = *mexinput23_temp; 

    double *mexinput24_temp = NULL; 
    if( !mxIsDouble(prhs[24]) || mxIsComplex(prhs[24]) || !(mxGetM(prhs[24])==1 && mxGetN(prhs[24])==1) ) { 
      mexErrMsgTxt("Input 24 must be a noncomplex scalar double.");
    } 
    mexinput24_temp = mxGetPr(prhs[24]); 
    double mexinput24 = *mexinput24_temp; 

    double *mexinput25_temp = NULL; 
    if( !mxIsDouble(prhs[25]) || mxIsComplex(prhs[25]) || !(mxGetM(prhs[25])==1 && mxGetN(prhs[25])==1) ) { 
      mexErrMsgTxt("Input 25 must be a noncomplex scalar double.");
    } 
    mexinput25_temp = mxGetPr(prhs[25]); 
    double mexinput25 = *mexinput25_temp; 

    double *mexinput26_temp = NULL; 
    if( !mxIsDouble(prhs[26]) || mxIsComplex(prhs[26]) || !(mxGetM(prhs[26])==1 && mxGetN(prhs[26])==1) ) { 
      mexErrMsgTxt("Input 26 must be a noncomplex scalar double.");
    } 
    mexinput26_temp = mxGetPr(prhs[26]); 
    double mexinput26 = *mexinput26_temp; 

    double *mexinput27_temp = NULL; 
    if( !mxIsDouble(prhs[27]) || mxIsComplex(prhs[27]) || !(mxGetM(prhs[27])==1 && mxGetN(prhs[27])==1) ) { 
      mexErrMsgTxt("Input 27 must be a noncomplex scalar double.");
    } 
    mexinput27_temp = mxGetPr(prhs[27]); 
    double mexinput27 = *mexinput27_temp; 

    double *mexinput28_temp = NULL; 
    if( !mxIsDouble(prhs[28]) || mxIsComplex(prhs[28]) || !(mxGetM(prhs[28])==1 && mxGetN(prhs[28])==1) ) { 
      mexErrMsgTxt("Input 28 must be a noncomplex scalar double.");
    } 
    mexinput28_temp = mxGetPr(prhs[28]); 
    double mexinput28 = *mexinput28_temp; 

    double *mexinput29_temp = NULL; 
    if( !mxIsDouble(prhs[29]) || mxIsComplex(prhs[29]) || !(mxGetM(prhs[29])==1 && mxGetN(prhs[29])==1) ) { 
      mexErrMsgTxt("Input 29 must be a noncomplex scalar double.");
    } 
    mexinput29_temp = mxGetPr(prhs[29]); 
    double mexinput29 = *mexinput29_temp; 

    double *mexinput30_temp = NULL; 
    if( !mxIsDouble(prhs[30]) || mxIsComplex(prhs[30]) || !(mxGetM(prhs[30])==1 && mxGetN(prhs[30])==1) ) { 
      mexErrMsgTxt("Input 30 must be a noncomplex scalar double.");
    } 
    mexinput30_temp = mxGetPr(prhs[30]); 
    double mexinput30 = *mexinput30_temp; 

    DifferentialEquation acadodata_f1;
    acadodata_f1 << dot(x1) == (-(5.00000000000000000000e-01+x1)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x2))-1/6.00000000000000000000e+01*x1+8.33333333333333321769e-03);
    acadodata_f1 << dot(x2) == ((5.00000000000000000000e-01+x1)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x2))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x2+2.50000000000000000000e+01/7.17000000000000000000e+02*u1);
    acadodata_f1 << dot(x3) == (-(5.00000000000000000000e-01+x3)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x4))-1/6.00000000000000000000e+01*x3+8.33333333333333321769e-03);
    acadodata_f1 << dot(x4) == ((5.00000000000000000000e-01+x3)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x4))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x4+2.50000000000000000000e+01/7.17000000000000000000e+02*u2);
    acadodata_f1 << dot(x5) == (-(5.00000000000000000000e-01+x5)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x6))-1/6.00000000000000000000e+01*x5+8.33333333333333321769e-03);
    acadodata_f1 << dot(x6) == ((5.00000000000000000000e-01+x5)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x6))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x6+2.50000000000000000000e+01/7.17000000000000000000e+02*u3);
    acadodata_f1 << dot(x7) == (-(5.00000000000000000000e-01+x7)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x8))-1/6.00000000000000000000e+01*x7+8.33333333333333321769e-03);
    acadodata_f1 << dot(x8) == ((5.00000000000000000000e-01+x7)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x8))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x8+2.50000000000000000000e+01/7.17000000000000000000e+02*u4);
    acadodata_f1 << dot(x9) == (-(5.00000000000000000000e-01+x9)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x10))-1/6.00000000000000000000e+01*x9+8.33333333333333321769e-03);
    acadodata_f1 << dot(x10) == ((5.00000000000000000000e-01+x9)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x10))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x10+2.50000000000000000000e+01/7.17000000000000000000e+02*u5);
    acadodata_f1 << dot(x11) == (-(5.00000000000000000000e-01+x11)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x12))-1/6.00000000000000000000e+01*x11+8.33333333333333321769e-03);
    acadodata_f1 << dot(x12) == ((5.00000000000000000000e-01+x11)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x12))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x12+2.50000000000000000000e+01/7.17000000000000000000e+02*u6);
    acadodata_f1 << dot(x13) == (-(5.00000000000000000000e-01+x13)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x14))-1/6.00000000000000000000e+01*x13+8.33333333333333321769e-03);
    acadodata_f1 << dot(x14) == ((5.00000000000000000000e-01+x13)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x14))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x14+2.50000000000000000000e+01/7.17000000000000000000e+02*u7);
    acadodata_f1 << dot(x15) == (-(5.00000000000000000000e-01+x15)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x16))-1/6.00000000000000000000e+01*x15+8.33333333333333321769e-03);
    acadodata_f1 << dot(x16) == ((5.00000000000000000000e-01+x15)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x16))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x16+2.50000000000000000000e+01/7.17000000000000000000e+02*u8);
    acadodata_f1 << dot(x17) == (-(5.00000000000000000000e-01+x17)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x18))-1/6.00000000000000000000e+01*x17+8.33333333333333321769e-03);
    acadodata_f1 << dot(x18) == ((5.00000000000000000000e-01+x17)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x18))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x18+2.50000000000000000000e+01/7.17000000000000000000e+02*u9);
    acadodata_f1 << dot(x19) == (-(5.00000000000000000000e-01+x19)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x20))-1/6.00000000000000000000e+01*x19+8.33333333333333321769e-03);
    acadodata_f1 << dot(x20) == ((5.00000000000000000000e-01+x19)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x20))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x20+2.50000000000000000000e+01/7.17000000000000000000e+02*u10);
    acadodata_f1 << dot(x21) == (-(5.00000000000000000000e-01+x21)*1.20000000000000000000e+09*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x22))-1/6.00000000000000000000e+01*x21+8.33333333333333321769e-03);
    acadodata_f1 << dot(x22) == ((5.00000000000000000000e-01+x21)/3.27680000000000000000e+04*8.22627615062761500000e+15*exp((-8.75000000000000000000e+03)/(3.50000000000000000000e+02+x22))-1.74337517433751743035e+00-1/1.43400000000000000000e+04*7.39000000000000000000e+02*x22+2.50000000000000000000e+01/7.17000000000000000000e+02*u11);
    acadodata_f1 << dot(inputcost) == (mexinput8*u1*u1+mexinput8*u10*u10+mexinput8*u11*u11+mexinput8*u2*u2+mexinput8*u3*u3+mexinput8*u4*u4+mexinput8*u5*u5+mexinput8*u6*u6+mexinput8*u7*u7+mexinput8*u8*u8+mexinput8*u9*u9);

    OCP ocp1(0, mexinput10, mexinput9);
    ocp1.minimizeMayerTerm((((-mexinput2+x21)*mexinput4+(-mexinput3+x22)*mexinput6)*(-mexinput2+x21)+((-mexinput2+x21)*mexinput5+(-mexinput3+x22)*mexinput7)*(-mexinput3+x22)+9.99999999999999954748e-07*ps1+9.99999999999999954748e-07*ps10+9.99999999999999954748e-07*ps11+9.99999999999999954748e-07*ps2+9.99999999999999954748e-07*ps3+9.99999999999999954748e-07*ps4+9.99999999999999954748e-07*ps5+9.99999999999999954748e-07*ps6+9.99999999999999954748e-07*ps7+9.99999999999999954748e-07*ps8+9.99999999999999954748e-07*ps9+inputcost));
    ocp1.subjectTo(acadodata_f1);
    ocp1.subjectTo(AT_START, x1 == mexinput0);
    ocp1.subjectTo(AT_START, x2 == mexinput1);
    ocp1.subjectTo(AT_END, (-p1+x1) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p2+x2) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p1+x3) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p2+x4) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p3+x3) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p4+x4) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p3+x5) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p4+x6) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p5+x5) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p6+x6) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p5+x7) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p6+x8) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p7+x7) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p8+x8) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p7+x9) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p8+x10) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p9+x9) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p10+x10) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p9+x11) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p10+x12) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p11+x11) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p12+x12) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p11+x13) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p12+x14) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p13+x13) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p14+x14) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p13+x15) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p14+x16) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p15+x15) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p16+x16) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p15+x17) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p16+x18) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p17+x17) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p18+x18) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p17+x19) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p18+x20) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p19+x19) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-p20+x20) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p19+x21) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-p20+x22) == 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, inputcost == 0.00000000000000000000e+00);
    ocp1.subjectTo(mexinput12 <= u1 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u2 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u3 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u4 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u5 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u6 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u7 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u8 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u9 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u10 <= mexinput11);
    ocp1.subjectTo(mexinput12 <= u11 <= mexinput11);
    ocp1.subjectTo(AT_START, ((mexinput13*x1+mexinput14*x2-mexinput23*mexinput28)/mexinput23/mexinput28-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x1+mexinput16*x2-mexinput24*mexinput28)/mexinput24/mexinput28-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x1+mexinput18*x2-mexinput25*mexinput28)/mexinput25/mexinput28-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x1+mexinput20*x2-mexinput26*mexinput28)/mexinput26/mexinput28-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x1+mexinput22*x2-mexinput27*mexinput28)/mexinput27/mexinput28-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps1 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x3+mexinput14*x4-mexinput23*mexinput28)/mexinput23/mexinput28-ps2) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x3+mexinput16*x4-mexinput24*mexinput28)/mexinput24/mexinput28-ps2) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x3+mexinput18*x4-mexinput25*mexinput28)/mexinput25/mexinput28-ps2) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x3+mexinput20*x4-mexinput26*mexinput28)/mexinput26/mexinput28-ps2) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x3+mexinput22*x4-mexinput27*mexinput28)/mexinput27/mexinput28-ps2) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps2 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x5+mexinput14*x6-mexinput23*mexinput28)/mexinput23/mexinput28-ps3) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x5+mexinput16*x6-mexinput24*mexinput28)/mexinput24/mexinput28-ps3) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x5+mexinput18*x6-mexinput25*mexinput28)/mexinput25/mexinput28-ps3) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x5+mexinput20*x6-mexinput26*mexinput28)/mexinput26/mexinput28-ps3) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x5+mexinput22*x6-mexinput27*mexinput28)/mexinput27/mexinput28-ps3) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps3 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x7+mexinput14*x8-mexinput23*mexinput28)/mexinput23/mexinput28-ps4) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x7+mexinput16*x8-mexinput24*mexinput28)/mexinput24/mexinput28-ps4) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x7+mexinput18*x8-mexinput25*mexinput28)/mexinput25/mexinput28-ps4) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x7+mexinput20*x8-mexinput26*mexinput28)/mexinput26/mexinput28-ps4) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x7+mexinput22*x8-mexinput27*mexinput28)/mexinput27/mexinput28-ps4) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps4 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x9+mexinput14*x10-mexinput23*mexinput28)/mexinput23/mexinput28-ps5) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x9+mexinput16*x10-mexinput24*mexinput28)/mexinput24/mexinput28-ps5) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x9+mexinput18*x10-mexinput25*mexinput28)/mexinput25/mexinput28-ps5) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x9+mexinput20*x10-mexinput26*mexinput28)/mexinput26/mexinput28-ps5) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x9+mexinput22*x10-mexinput27*mexinput28)/mexinput27/mexinput28-ps5) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps5 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x11+mexinput14*x12-mexinput23*mexinput28)/mexinput23/mexinput28-ps6) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x11+mexinput16*x12-mexinput24*mexinput28)/mexinput24/mexinput28-ps6) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x11+mexinput18*x12-mexinput25*mexinput28)/mexinput25/mexinput28-ps6) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x11+mexinput20*x12-mexinput26*mexinput28)/mexinput26/mexinput28-ps6) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x11+mexinput22*x12-mexinput27*mexinput28)/mexinput27/mexinput28-ps6) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps6 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x13+mexinput14*x14-mexinput23*mexinput28)/mexinput23/mexinput28-ps7) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x13+mexinput16*x14-mexinput24*mexinput28)/mexinput24/mexinput28-ps7) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x13+mexinput18*x14-mexinput25*mexinput28)/mexinput25/mexinput28-ps7) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x13+mexinput20*x14-mexinput26*mexinput28)/mexinput26/mexinput28-ps7) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x13+mexinput22*x14-mexinput27*mexinput28)/mexinput27/mexinput28-ps7) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps7 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x15+mexinput14*x16-mexinput23*mexinput28)/mexinput23/mexinput28-ps8) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x15+mexinput16*x16-mexinput24*mexinput28)/mexinput24/mexinput28-ps8) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x15+mexinput18*x16-mexinput25*mexinput28)/mexinput25/mexinput28-ps8) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x15+mexinput20*x16-mexinput26*mexinput28)/mexinput26/mexinput28-ps8) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x15+mexinput22*x16-mexinput27*mexinput28)/mexinput27/mexinput28-ps8) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps8 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x17+mexinput14*x18-mexinput23*mexinput28)/mexinput23/mexinput28-ps9) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x17+mexinput16*x18-mexinput24*mexinput28)/mexinput24/mexinput28-ps9) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x17+mexinput18*x18-mexinput25*mexinput28)/mexinput25/mexinput28-ps9) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x17+mexinput20*x18-mexinput26*mexinput28)/mexinput26/mexinput28-ps9) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x17+mexinput22*x18-mexinput27*mexinput28)/mexinput27/mexinput28-ps9) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps9 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x19+mexinput14*x20-mexinput23*mexinput28)/mexinput23/mexinput28-ps10) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x19+mexinput16*x20-mexinput24*mexinput28)/mexinput24/mexinput28-ps10) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x19+mexinput18*x20-mexinput25*mexinput28)/mexinput25/mexinput28-ps10) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x19+mexinput20*x20-mexinput26*mexinput28)/mexinput26/mexinput28-ps10) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x19+mexinput22*x20-mexinput27*mexinput28)/mexinput27/mexinput28-ps10) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps10 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput13*x21+mexinput14*x22-mexinput23*mexinput28)/mexinput23/mexinput28-ps11) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput15*x21+mexinput16*x22-mexinput24*mexinput28)/mexinput24/mexinput28-ps11) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput17*x21+mexinput18*x22-mexinput25*mexinput28)/mexinput25/mexinput28-ps11) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput19*x21+mexinput20*x22-mexinput26*mexinput28)/mexinput26/mexinput28-ps11) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput21*x21+mexinput22*x22-mexinput27*mexinput28)/mexinput27/mexinput28-ps11) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps11 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput13*x21+mexinput14*x22-mexinput23*mexinput28)/mexinput23/mexinput28 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput15*x21+mexinput16*x22-mexinput24*mexinput28)/mexinput24/mexinput28 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput17*x21+mexinput18*x22-mexinput25*mexinput28)/mexinput25/mexinput28 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput19*x21+mexinput20*x22-mexinput26*mexinput28)/mexinput26/mexinput28 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput21*x21+mexinput22*x22-mexinput27*mexinput28)/mexinput27/mexinput28 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-mexinput29+ps1+ps10+ps11+ps2+ps3+ps4+ps5+ps6+ps7+ps8+ps9) <= (-mexinput30));


    OptimizationAlgorithm algo1(ocp1);
    algo1.set( HESSIAN_APPROXIMATION, EXACT_HESSIAN );
    algo1.set( KKT_TOLERANCE, 1.000000E-12 );
    algo1.set( INTEGRATOR_TOLERANCE, 1.000000E-06 );
    algo1.set( INTEGRATOR_TYPE, INT_RK45 );
    algo1.set( DISCRETIZATION_TYPE, MULTIPLE_SHOOTING );
    algo1.set( ABSOLUTE_TOLERANCE, 1.000000E-06 );
    algo1.set( MAX_NUM_ITERATIONS, 12 );
    returnValue returnvalue = algo1.solve();

    VariablesGrid out_states; 
    VariablesGrid out_parameters; 
    VariablesGrid out_controls; 
    VariablesGrid out_disturbances; 
    VariablesGrid out_algstates; 
    algo1.getDifferentialStates(out_states);
    algo1.getControls(out_controls);
    algo1.getParameters(out_parameters);
    const char* outputFieldNames[] = {"STATES", "CONTROLS", "PARAMETERS", "DISTURBANCES", "ALGEBRAICSTATES", "CONVERGENCE_ACHIEVED"}; 
    plhs[0] = mxCreateStructMatrix( 1,1,6,outputFieldNames ); 
    mxArray *OutS = NULL;
    double  *outS = NULL;
    OutS = mxCreateDoubleMatrix( out_states.getNumPoints(),1+out_states.getNumValues(),mxREAL ); 
    outS = mxGetPr( OutS );
    for( int i=0; i<out_states.getNumPoints(); ++i ){ 
      outS[0*out_states.getNumPoints() + i] = out_states.getTime(i); 
      for( int j=0; j<out_states.getNumValues(); ++j ){ 
        outS[(1+j)*out_states.getNumPoints() + i] = out_states(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"STATES",OutS );
    mxArray *OutC = NULL;
    double  *outC = NULL;
    OutC = mxCreateDoubleMatrix( out_controls.getNumPoints(),1+out_controls.getNumValues(),mxREAL ); 
    outC = mxGetPr( OutC );
    for( int i=0; i<out_controls.getNumPoints(); ++i ){ 
      outC[0*out_controls.getNumPoints() + i] = out_controls.getTime(i); 
      for( int j=0; j<out_controls.getNumValues(); ++j ){ 
        outC[(1+j)*out_controls.getNumPoints() + i] = out_controls(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"CONTROLS",OutC );
    mxArray *OutP = NULL;
    double  *outP = NULL;
    OutP = mxCreateDoubleMatrix( out_parameters.getNumPoints(),1+out_parameters.getNumValues(),mxREAL ); 
    outP = mxGetPr( OutP );
    for( int i=0; i<out_parameters.getNumPoints(); ++i ){ 
      outP[0*out_parameters.getNumPoints() + i] = out_parameters.getTime(i); 
      for( int j=0; j<out_parameters.getNumValues(); ++j ){ 
        outP[(1+j)*out_parameters.getNumPoints() + i] = out_parameters(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"PARAMETERS",OutP );
    mxArray *OutW = NULL;
    double  *outW = NULL;
    OutW = mxCreateDoubleMatrix( out_disturbances.getNumPoints(),1+out_disturbances.getNumValues(),mxREAL ); 
    outW = mxGetPr( OutW );
    for( int i=0; i<out_disturbances.getNumPoints(); ++i ){ 
      outW[0*out_disturbances.getNumPoints() + i] = out_disturbances.getTime(i); 
      for( int j=0; j<out_disturbances.getNumValues(); ++j ){ 
        outW[(1+j)*out_disturbances.getNumPoints() + i] = out_disturbances(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"DISTURBANCES",OutW );
    mxArray *OutZ = NULL;
    double  *outZ = NULL;
    OutZ = mxCreateDoubleMatrix( out_algstates.getNumPoints(),1+out_algstates.getNumValues(),mxREAL ); 
    outZ = mxGetPr( OutZ );
    for( int i=0; i<out_algstates.getNumPoints(); ++i ){ 
      outZ[0*out_algstates.getNumPoints() + i] = out_algstates.getTime(i); 
      for( int j=0; j<out_algstates.getNumValues(); ++j ){ 
        outZ[(1+j)*out_algstates.getNumPoints() + i] = out_algstates(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"ALGEBRAICSTATES",OutZ );
    mxArray *OutConv = NULL;
    if ( returnvalue == SUCCESSFUL_RETURN ) { OutConv = mxCreateDoubleScalar( 1 ); }else{ OutConv = mxCreateDoubleScalar( 0 ); } 
    mxSetField( plhs[0],0,"CONVERGENCE_ACHIEVED",OutConv );


    clearAllStaticCounters( ); 
 
} 

