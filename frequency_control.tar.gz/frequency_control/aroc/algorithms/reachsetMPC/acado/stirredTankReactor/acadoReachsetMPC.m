%% Begin ACADO Initialization

BEGIN_ACADO;

% Problem name
acadoSet('problemname', 'acadoReachsetMPC');


%% Initialize variables

% States
DifferentialState	x1;
DifferentialState	x2;

DifferentialState	x3;
DifferentialState	x4;

DifferentialState	x5;
DifferentialState	x6;

DifferentialState	x7;
DifferentialState	x8;

DifferentialState	x9;
DifferentialState	x10;

DifferentialState	x11;
DifferentialState	x12;

DifferentialState	x13;
DifferentialState	x14;

DifferentialState	x15;
DifferentialState	x16;

DifferentialState	x17;
DifferentialState	x18;

DifferentialState	x19;
DifferentialState	x20;

DifferentialState	x21;
DifferentialState	x22;

DifferentialState	inputcost;

% Parameters (needed to couple differential states in constraints)
Parameter	p1;
Parameter	p2;

Parameter	p3;
Parameter	p4;

Parameter	p5;
Parameter	p6;

Parameter	p7;
Parameter	p8;

Parameter	p9;
Parameter	p10;

Parameter	p11;
Parameter	p12;

Parameter	p13;
Parameter	p14;

Parameter	p15;
Parameter	p16;

Parameter	p17;
Parameter	p18;

Parameter	p19;
Parameter	p20;


% Parameters (for computing maximal distance to set)
Parameter	ps1;
Parameter	ps2;
Parameter	ps3;
Parameter	ps4;
Parameter	ps5;
Parameter	ps6;
Parameter	ps7;
Parameter	ps8;
Parameter	ps9;
Parameter	ps10;
Parameter	ps11;

% Control inputs
Control	u1;

Control	u2;

Control	u3;

Control	u4;

Control	u5;

Control	u6;

Control	u7;

Control	u8;

Control	u9;

Control	u10;

Control	u11;


%% Parse inputs to the MEX-file

% Input 1: x0
x01 = acado.MexInput;
x02 = acado.MexInput;

x0 = [x01;x02];

% Input 2: xf
xf1 = acado.MexInput;
xf2 = acado.MexInput;

xf = [xf1;xf2];

% Input 3: Q
Q11 = acado.MexInput;
Q12 = acado.MexInput;

Q21 = acado.MexInput;
Q22 = acado.MexInput;

Q = [Q11,Q12; ...
	Q21,Q22];

% Input 4: R
R11 = acado.MexInput;

R = [R11];

% Input 5: multiple shooting steps
Nc = acado.MexInput;

% Input 6: optimization termination time T
t_end = acado.MexInput;

% Input 7: u_max
u_max1 = acado.MexInput;

u_max = [u_max1];

% Input 8: u_min
u_min1 = acado.MexInput;

u_min = [u_min1];

% Input 9: polytope parameter D
D11 = acado.MexInput;
D12 = acado.MexInput;
D21 = acado.MexInput;
D22 = acado.MexInput;
D31 = acado.MexInput;
D32 = acado.MexInput;
D41 = acado.MexInput;
D42 = acado.MexInput;
D51 = acado.MexInput;
D52 = acado.MexInput;
D = [D11,D12; ...
	D21,D22; ...
	D31,D32; ...
	D41,D42; ...
	D51,D52];

% Input 10: polytope parameter e
e1 = acado.MexInput;
e2 = acado.MexInput;
e3 = acado.MexInput;
e4 = acado.MexInput;
e5 = acado.MexInput;

e = [e1;e2;e3;e4;e5];

% Input 11: scaling factor (polytope)
alphaPoly = acado.MexInput;


% Input 12: Previous value of the cost function
J = acado.MexInput;


% Input 13: contraction rate
alpha = acado.MexInput;



%% Differential Equation

% Set the differential equation object for continous time in ACADO
f = acado.DifferentialEquation();

% System Dynamics
f.add(dot(x1) == 1/120 - 1200000000*exp(-8750/(x2 + 350))*(x1 + 1/2) - x1/60);
f.add(dot(x2) == (25*u1)/717 - (739*x2)/14340 + (8226276150627615*exp(-8750/(x2 + 350))*(x1 + 1/2))/32768 - 1250/717);



f.add(dot(x3) == 1/120 - 1200000000*exp(-8750/(x4 + 350))*(x3 + 1/2) - x3/60);
f.add(dot(x4) == (25*u2)/717 - (739*x4)/14340 + (8226276150627615*exp(-8750/(x4 + 350))*(x3 + 1/2))/32768 - 1250/717);



f.add(dot(x5) == 1/120 - 1200000000*exp(-8750/(x6 + 350))*(x5 + 1/2) - x5/60);
f.add(dot(x6) == (25*u3)/717 - (739*x6)/14340 + (8226276150627615*exp(-8750/(x6 + 350))*(x5 + 1/2))/32768 - 1250/717);



f.add(dot(x7) == 1/120 - 1200000000*exp(-8750/(x8 + 350))*(x7 + 1/2) - x7/60);
f.add(dot(x8) == (25*u4)/717 - (739*x8)/14340 + (8226276150627615*exp(-8750/(x8 + 350))*(x7 + 1/2))/32768 - 1250/717);



f.add(dot(x9) == 1/120 - 1200000000*exp(-8750/(x10 + 350))*(x9 + 1/2) - x9/60);
f.add(dot(x10) == (25*u5)/717 - (739*x10)/14340 + (8226276150627615*exp(-8750/(x10 + 350))*(x9 + 1/2))/32768 - 1250/717);



f.add(dot(x11) == 1/120 - 1200000000*exp(-8750/(x12 + 350))*(x11 + 1/2) - x11/60);
f.add(dot(x12) == (25*u6)/717 - (739*x12)/14340 + (8226276150627615*exp(-8750/(x12 + 350))*(x11 + 1/2))/32768 - 1250/717);



f.add(dot(x13) == 1/120 - 1200000000*exp(-8750/(x14 + 350))*(x13 + 1/2) - x13/60);
f.add(dot(x14) == (25*u7)/717 - (739*x14)/14340 + (8226276150627615*exp(-8750/(x14 + 350))*(x13 + 1/2))/32768 - 1250/717);



f.add(dot(x15) == 1/120 - 1200000000*exp(-8750/(x16 + 350))*(x15 + 1/2) - x15/60);
f.add(dot(x16) == (25*u8)/717 - (739*x16)/14340 + (8226276150627615*exp(-8750/(x16 + 350))*(x15 + 1/2))/32768 - 1250/717);



f.add(dot(x17) == 1/120 - 1200000000*exp(-8750/(x18 + 350))*(x17 + 1/2) - x17/60);
f.add(dot(x18) == (25*u9)/717 - (739*x18)/14340 + (8226276150627615*exp(-8750/(x18 + 350))*(x17 + 1/2))/32768 - 1250/717);



f.add(dot(x19) == 1/120 - 1200000000*exp(-8750/(x20 + 350))*(x19 + 1/2) - x19/60);
f.add(dot(x20) == (25*u10)/717 - (739*x20)/14340 + (8226276150627615*exp(-8750/(x20 + 350))*(x19 + 1/2))/32768 - 1250/717);



f.add(dot(x21) == 1/120 - 1200000000*exp(-8750/(x22 + 350))*(x21 + 1/2) - x21/60);
f.add(dot(x22) == (25*u11)/717 - (739*x22)/14340 + (8226276150627615*exp(-8750/(x22 + 350))*(x21 + 1/2))/32768 - 1250/717);



% Forming control vectors u

u_1 = [u1];
u_2 = [u2];
u_3 = [u3];
u_4 = [u4];
u_5 = [u5];
u_6 = [u6];
u_7 = [u7];
u_8 = [u8];
u_9 = [u9];
u_10 = [u10];
u_11 = [u11];

% Integration of control input costs
f.add(dot(inputcost) ==		u_1' * R * u_1 ...
					+ u_2' * R * u_2 ...
					+ u_3' * R * u_3 ...
					+ u_4' * R * u_4 ...
					+ u_5' * R * u_5 ...
					+ u_6' * R * u_6 ...
					+ u_7' * R * u_7 ...
					+ u_8' * R * u_8 ...
					+ u_9' * R * u_9 ...
					+ u_10' * R * u_10 ...
					+ u_11' * R * u_11);


%% Optimal Control Problem

% Parameters
start_time = 0;		% Set up start time of optimization
end_time = t_end;	% Set up termination time of optimization
grid_points = Nc;	% Set up gridpoints of optimization

% Set up the Optimal Control Problem (OCP) for ACADO
ocp = acado.OCP(start_time, end_time, grid_points);

% Forming state vectors x
x_1 =[x1;x2];
x_2 =[x3;x4];
x_3 =[x5;x6];
x_4 =[x7;x8];
x_5 =[x9;x10];
x_6 =[x11;x12];
x_7 =[x13;x14];
x_8 =[x15;x16];
x_9 =[x17;x18];
x_10 =[x19;x20];
x_11 =[x21;x22];

% Define objective function
objective = (x_11-xf)'*Q*(x_11-xf);
objective = objective + 1e-6 * ps1;
objective = objective + 1e-6 * ps2;
objective = objective + 1e-6 * ps3;
objective = objective + 1e-6 * ps4;
objective = objective + 1e-6 * ps5;
objective = objective + 1e-6 * ps6;
objective = objective + 1e-6 * ps7;
objective = objective + 1e-6 * ps8;
objective = objective + 1e-6 * ps9;
objective = objective + 1e-6 * ps10;
objective = objective + 1e-6 * ps11;

% Min(x,u) integral 0-T(inputcost) + Quadratic Distance Cost 
ocp.minimizeMayerTerm(inputcost + objective);


%% Polytope

% Scale the polytope
e = alphaPoly * e;

% Compute distances of points from hyperplanes
temp1 = (D*x_1 - e)./e;
temp2 = (D*x_2 - e)./e;
temp3 = (D*x_3 - e)./e;
temp4 = (D*x_4 - e)./e;
temp5 = (D*x_5 - e)./e;
temp6 = (D*x_6 - e)./e;
temp7 = (D*x_7 - e)./e;
temp8 = (D*x_8 - e)./e;
temp9 = (D*x_9 - e)./e;
temp10 = (D*x_10 - e)./e;
temp11 = (D*x_11 - e)./e;



%% Constraints

% Optimize with respect to your differential equation
ocp.subjectTo( f );

% Initial point
ocp.subjectTo( 'AT_START', x1 ==  x0(1) );
ocp.subjectTo( 'AT_START', x2 ==  x0(2) );

% Coupled boundary conditions 1 -> 2
ocp.subjectTo( 'AT_END', x1 - p1 ==  0 );
ocp.subjectTo( 'AT_END', x2 - p2 ==  0 );

ocp.subjectTo( 'AT_START', x3 - p1 ==  0 );
ocp.subjectTo( 'AT_START', x4 - p2 ==  0 );

% Coupled boundary conditions 2 -> 3
ocp.subjectTo( 'AT_END', x3 - p3 ==  0 );
ocp.subjectTo( 'AT_END', x4 - p4 ==  0 );

ocp.subjectTo( 'AT_START', x5 - p3 ==  0 );
ocp.subjectTo( 'AT_START', x6 - p4 ==  0 );

% Coupled boundary conditions 3 -> 4
ocp.subjectTo( 'AT_END', x5 - p5 ==  0 );
ocp.subjectTo( 'AT_END', x6 - p6 ==  0 );

ocp.subjectTo( 'AT_START', x7 - p5 ==  0 );
ocp.subjectTo( 'AT_START', x8 - p6 ==  0 );

% Coupled boundary conditions 4 -> 5
ocp.subjectTo( 'AT_END', x7 - p7 ==  0 );
ocp.subjectTo( 'AT_END', x8 - p8 ==  0 );

ocp.subjectTo( 'AT_START', x9 - p7 ==  0 );
ocp.subjectTo( 'AT_START', x10 - p8 ==  0 );

% Coupled boundary conditions 5 -> 6
ocp.subjectTo( 'AT_END', x9 - p9 ==  0 );
ocp.subjectTo( 'AT_END', x10 - p10 ==  0 );

ocp.subjectTo( 'AT_START', x11 - p9 ==  0 );
ocp.subjectTo( 'AT_START', x12 - p10 ==  0 );

% Coupled boundary conditions 6 -> 7
ocp.subjectTo( 'AT_END', x11 - p11 ==  0 );
ocp.subjectTo( 'AT_END', x12 - p12 ==  0 );

ocp.subjectTo( 'AT_START', x13 - p11 ==  0 );
ocp.subjectTo( 'AT_START', x14 - p12 ==  0 );

% Coupled boundary conditions 7 -> 8
ocp.subjectTo( 'AT_END', x13 - p13 ==  0 );
ocp.subjectTo( 'AT_END', x14 - p14 ==  0 );

ocp.subjectTo( 'AT_START', x15 - p13 ==  0 );
ocp.subjectTo( 'AT_START', x16 - p14 ==  0 );

% Coupled boundary conditions 8 -> 9
ocp.subjectTo( 'AT_END', x15 - p15 ==  0 );
ocp.subjectTo( 'AT_END', x16 - p16 ==  0 );

ocp.subjectTo( 'AT_START', x17 - p15 ==  0 );
ocp.subjectTo( 'AT_START', x18 - p16 ==  0 );

% Coupled boundary conditions 9 -> 10
ocp.subjectTo( 'AT_END', x17 - p17 ==  0 );
ocp.subjectTo( 'AT_END', x18 - p18 ==  0 );

ocp.subjectTo( 'AT_START', x19 - p17 ==  0 );
ocp.subjectTo( 'AT_START', x20 - p18 ==  0 );

% Coupled boundary conditions 10 -> 11
ocp.subjectTo( 'AT_END', x19 - p19 ==  0 );
ocp.subjectTo( 'AT_END', x20 - p20 ==  0 );

ocp.subjectTo( 'AT_START', x21 - p19 ==  0 );
ocp.subjectTo( 'AT_START', x22 - p20 ==  0 );

% Initial value for input costs L(0) = 0
ocp.subjectTo( 'AT_START', inputcost ==  0.0 );

% Input constraints
ocp.subjectTo( u_min(1) <= u1 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u2 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u3 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u4 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u5 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u6 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u7 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u8 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u9 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u10 <= u_max(1) );

ocp.subjectTo( u_min(1) <= u11 <= u_max(1) );

% Distance computaion constraints
ocp.subjectTo('AT_START', temp1(1) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(2) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(3) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(4) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(5) - ps1 <= 0 );
ocp.subjectTo('AT_START', ps1 >= 0 );

ocp.subjectTo('AT_START', temp2(1) - ps2 <= 0 );
ocp.subjectTo('AT_START', temp2(2) - ps2 <= 0 );
ocp.subjectTo('AT_START', temp2(3) - ps2 <= 0 );
ocp.subjectTo('AT_START', temp2(4) - ps2 <= 0 );
ocp.subjectTo('AT_START', temp2(5) - ps2 <= 0 );
ocp.subjectTo('AT_START', ps2 >= 0 );

ocp.subjectTo('AT_START', temp3(1) - ps3 <= 0 );
ocp.subjectTo('AT_START', temp3(2) - ps3 <= 0 );
ocp.subjectTo('AT_START', temp3(3) - ps3 <= 0 );
ocp.subjectTo('AT_START', temp3(4) - ps3 <= 0 );
ocp.subjectTo('AT_START', temp3(5) - ps3 <= 0 );
ocp.subjectTo('AT_START', ps3 >= 0 );

ocp.subjectTo('AT_START', temp4(1) - ps4 <= 0 );
ocp.subjectTo('AT_START', temp4(2) - ps4 <= 0 );
ocp.subjectTo('AT_START', temp4(3) - ps4 <= 0 );
ocp.subjectTo('AT_START', temp4(4) - ps4 <= 0 );
ocp.subjectTo('AT_START', temp4(5) - ps4 <= 0 );
ocp.subjectTo('AT_START', ps4 >= 0 );

ocp.subjectTo('AT_START', temp5(1) - ps5 <= 0 );
ocp.subjectTo('AT_START', temp5(2) - ps5 <= 0 );
ocp.subjectTo('AT_START', temp5(3) - ps5 <= 0 );
ocp.subjectTo('AT_START', temp5(4) - ps5 <= 0 );
ocp.subjectTo('AT_START', temp5(5) - ps5 <= 0 );
ocp.subjectTo('AT_START', ps5 >= 0 );

ocp.subjectTo('AT_START', temp6(1) - ps6 <= 0 );
ocp.subjectTo('AT_START', temp6(2) - ps6 <= 0 );
ocp.subjectTo('AT_START', temp6(3) - ps6 <= 0 );
ocp.subjectTo('AT_START', temp6(4) - ps6 <= 0 );
ocp.subjectTo('AT_START', temp6(5) - ps6 <= 0 );
ocp.subjectTo('AT_START', ps6 >= 0 );

ocp.subjectTo('AT_START', temp7(1) - ps7 <= 0 );
ocp.subjectTo('AT_START', temp7(2) - ps7 <= 0 );
ocp.subjectTo('AT_START', temp7(3) - ps7 <= 0 );
ocp.subjectTo('AT_START', temp7(4) - ps7 <= 0 );
ocp.subjectTo('AT_START', temp7(5) - ps7 <= 0 );
ocp.subjectTo('AT_START', ps7 >= 0 );

ocp.subjectTo('AT_START', temp8(1) - ps8 <= 0 );
ocp.subjectTo('AT_START', temp8(2) - ps8 <= 0 );
ocp.subjectTo('AT_START', temp8(3) - ps8 <= 0 );
ocp.subjectTo('AT_START', temp8(4) - ps8 <= 0 );
ocp.subjectTo('AT_START', temp8(5) - ps8 <= 0 );
ocp.subjectTo('AT_START', ps8 >= 0 );

ocp.subjectTo('AT_START', temp9(1) - ps9 <= 0 );
ocp.subjectTo('AT_START', temp9(2) - ps9 <= 0 );
ocp.subjectTo('AT_START', temp9(3) - ps9 <= 0 );
ocp.subjectTo('AT_START', temp9(4) - ps9 <= 0 );
ocp.subjectTo('AT_START', temp9(5) - ps9 <= 0 );
ocp.subjectTo('AT_START', ps9 >= 0 );

ocp.subjectTo('AT_START', temp10(1) - ps10 <= 0 );
ocp.subjectTo('AT_START', temp10(2) - ps10 <= 0 );
ocp.subjectTo('AT_START', temp10(3) - ps10 <= 0 );
ocp.subjectTo('AT_START', temp10(4) - ps10 <= 0 );
ocp.subjectTo('AT_START', temp10(5) - ps10 <= 0 );
ocp.subjectTo('AT_START', ps10 >= 0 );

ocp.subjectTo('AT_START', temp11(1) - ps11 <= 0 );
ocp.subjectTo('AT_START', temp11(2) - ps11 <= 0 );
ocp.subjectTo('AT_START', temp11(3) - ps11 <= 0 );
ocp.subjectTo('AT_START', temp11(4) - ps11 <= 0 );
ocp.subjectTo('AT_START', temp11(5) - ps11 <= 0 );
ocp.subjectTo('AT_START', ps11 >= 0 );

% Distance computaion constraints
ocp.subjectTo('AT_END', temp11(1) <= 0 );
ocp.subjectTo('AT_END', temp11(2) <= 0 );
ocp.subjectTo('AT_END', temp11(3) <= 0 );
ocp.subjectTo('AT_END', temp11(4) <= 0 );
ocp.subjectTo('AT_END', temp11(5) <= 0 );

% Contraction constraint
sumNew = ps1 + ps2 + ps3 + ps4 + ps5 + ps6 + ps7 + ps8 + ps9 + ps10 + ps11;
ocp.subjectTo('AT_START', sumNew - J <= -alpha );


%% Optimization Algorithm 

% Set up the optimization algorithm, link it to the OCP
algo =acado.OptimizationAlgorithm(ocp); 

% Set options for optimization
algo.set( 'HESSIAN_APPROXIMATION', 'EXACT_HESSIAN' );
algo.set( 'KKT_TOLERANCE', 1e-12 );
algo.set( 'INTEGRATOR_TOLERANCE', 1e-6 ); 
algo.set( 'INTEGRATOR_TYPE', 'INT_RK45' );
algo.set( 'DISCRETIZATION_TYPE', 'MULTIPLE_SHOOTING');
algo.set( 'ABSOLUTE_TOLERANCE', 1e-6 );
algo.set( 'MAX_NUM_ITERATIONS', 12 );
END_ACADO;