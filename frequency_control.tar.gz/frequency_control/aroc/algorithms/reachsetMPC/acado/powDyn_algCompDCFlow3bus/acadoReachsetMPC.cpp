/*
*    This file is part of ACADO Toolkit.
*
*    ACADO Toolkit -- A Toolkit for Automatic Control and Dynamic Optimization.
*    Copyright (C) 2008-2009 by Boris Houska and Hans Joachim Ferreau, K.U.Leuven.
*    Developed within the Optimization in Engineering Center (OPTEC) under
*    supervision of Moritz Diehl. All rights reserved.
*
*    ACADO Toolkit is free software; you can redistribute it and/or
*    modify it under the terms of the GNU Lesser General Public
*    License as published by the Free Software Foundation; either
*    version 3 of the License, or (at your option) any later version.
*
*    ACADO Toolkit is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*    Lesser General Public License for more details.
*
*    You should have received a copy of the GNU Lesser General Public
*    License along with ACADO Toolkit; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*
*/


/**
*    Author David Ariens, Rien Quirynen
*    Date 2009-2013
*    http://www.acadotoolkit.org/matlab 
*/

#include <acado_optimal_control.hpp>
#include <acado_toolkit.hpp>
#include <acado/utils/matlab_acado_utils.hpp>

USING_NAMESPACE_ACADO

#include <mex.h>


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] ) 
 { 
 
    MatlabConsoleStreamBuf mybuf;
    RedirectStream redirect(std::cout, mybuf);
    clearAllStaticCounters( ); 
 
    mexPrintf("\nACADO Toolkit for Matlab - Developed by David Ariens and Rien Quirynen, 2009-2013 \n"); 
    mexPrintf("Support available at http://www.acadotoolkit.org/matlab \n \n"); 

    if (nrhs != 360){ 
      mexErrMsgTxt("This problem expects 360 right hand side argument(s) since you have defined 360 MexInput(s)");
    } 
 
    TIME autotime;
    DifferentialState x1;
    DifferentialState x2;
    DifferentialState x3;
    DifferentialState x4;
    DifferentialState x5;
    DifferentialState x6;
    DifferentialState x7;
    DifferentialState x8;
    DifferentialState x9;
    DifferentialState x10;
    DifferentialState inputcost;
    Parameter ps1; 
    Control u1;
    Control u2;
    Control u3;
    double *mexinput0_temp = NULL; 
    if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) || !(mxGetM(prhs[0])==1 && mxGetN(prhs[0])==1) ) { 
      mexErrMsgTxt("Input 0 must be a noncomplex scalar double.");
    } 
    mexinput0_temp = mxGetPr(prhs[0]); 
    double mexinput0 = *mexinput0_temp; 

    double *mexinput1_temp = NULL; 
    if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) ) { 
      mexErrMsgTxt("Input 1 must be a noncomplex scalar double.");
    } 
    mexinput1_temp = mxGetPr(prhs[1]); 
    double mexinput1 = *mexinput1_temp; 

    double *mexinput2_temp = NULL; 
    if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) ) { 
      mexErrMsgTxt("Input 2 must be a noncomplex scalar double.");
    } 
    mexinput2_temp = mxGetPr(prhs[2]); 
    double mexinput2 = *mexinput2_temp; 

    double *mexinput3_temp = NULL; 
    if( !mxIsDouble(prhs[3]) || mxIsComplex(prhs[3]) || !(mxGetM(prhs[3])==1 && mxGetN(prhs[3])==1) ) { 
      mexErrMsgTxt("Input 3 must be a noncomplex scalar double.");
    } 
    mexinput3_temp = mxGetPr(prhs[3]); 
    double mexinput3 = *mexinput3_temp; 

    double *mexinput4_temp = NULL; 
    if( !mxIsDouble(prhs[4]) || mxIsComplex(prhs[4]) || !(mxGetM(prhs[4])==1 && mxGetN(prhs[4])==1) ) { 
      mexErrMsgTxt("Input 4 must be a noncomplex scalar double.");
    } 
    mexinput4_temp = mxGetPr(prhs[4]); 
    double mexinput4 = *mexinput4_temp; 

    double *mexinput5_temp = NULL; 
    if( !mxIsDouble(prhs[5]) || mxIsComplex(prhs[5]) || !(mxGetM(prhs[5])==1 && mxGetN(prhs[5])==1) ) { 
      mexErrMsgTxt("Input 5 must be a noncomplex scalar double.");
    } 
    mexinput5_temp = mxGetPr(prhs[5]); 
    double mexinput5 = *mexinput5_temp; 

    double *mexinput6_temp = NULL; 
    if( !mxIsDouble(prhs[6]) || mxIsComplex(prhs[6]) || !(mxGetM(prhs[6])==1 && mxGetN(prhs[6])==1) ) { 
      mexErrMsgTxt("Input 6 must be a noncomplex scalar double.");
    } 
    mexinput6_temp = mxGetPr(prhs[6]); 
    double mexinput6 = *mexinput6_temp; 

    double *mexinput7_temp = NULL; 
    if( !mxIsDouble(prhs[7]) || mxIsComplex(prhs[7]) || !(mxGetM(prhs[7])==1 && mxGetN(prhs[7])==1) ) { 
      mexErrMsgTxt("Input 7 must be a noncomplex scalar double.");
    } 
    mexinput7_temp = mxGetPr(prhs[7]); 
    double mexinput7 = *mexinput7_temp; 

    double *mexinput8_temp = NULL; 
    if( !mxIsDouble(prhs[8]) || mxIsComplex(prhs[8]) || !(mxGetM(prhs[8])==1 && mxGetN(prhs[8])==1) ) { 
      mexErrMsgTxt("Input 8 must be a noncomplex scalar double.");
    } 
    mexinput8_temp = mxGetPr(prhs[8]); 
    double mexinput8 = *mexinput8_temp; 

    double *mexinput9_temp = NULL; 
    if( !mxIsDouble(prhs[9]) || mxIsComplex(prhs[9]) || !(mxGetM(prhs[9])==1 && mxGetN(prhs[9])==1) ) { 
      mexErrMsgTxt("Input 9 must be a noncomplex scalar double.");
    } 
    mexinput9_temp = mxGetPr(prhs[9]); 
    double mexinput9 = *mexinput9_temp; 

    double *mexinput10_temp = NULL; 
    if( !mxIsDouble(prhs[10]) || mxIsComplex(prhs[10]) || !(mxGetM(prhs[10])==1 && mxGetN(prhs[10])==1) ) { 
      mexErrMsgTxt("Input 10 must be a noncomplex scalar double.");
    } 
    mexinput10_temp = mxGetPr(prhs[10]); 
    double mexinput10 = *mexinput10_temp; 

    double *mexinput11_temp = NULL; 
    if( !mxIsDouble(prhs[11]) || mxIsComplex(prhs[11]) || !(mxGetM(prhs[11])==1 && mxGetN(prhs[11])==1) ) { 
      mexErrMsgTxt("Input 11 must be a noncomplex scalar double.");
    } 
    mexinput11_temp = mxGetPr(prhs[11]); 
    double mexinput11 = *mexinput11_temp; 

    double *mexinput12_temp = NULL; 
    if( !mxIsDouble(prhs[12]) || mxIsComplex(prhs[12]) || !(mxGetM(prhs[12])==1 && mxGetN(prhs[12])==1) ) { 
      mexErrMsgTxt("Input 12 must be a noncomplex scalar double.");
    } 
    mexinput12_temp = mxGetPr(prhs[12]); 
    double mexinput12 = *mexinput12_temp; 

    double *mexinput13_temp = NULL; 
    if( !mxIsDouble(prhs[13]) || mxIsComplex(prhs[13]) || !(mxGetM(prhs[13])==1 && mxGetN(prhs[13])==1) ) { 
      mexErrMsgTxt("Input 13 must be a noncomplex scalar double.");
    } 
    mexinput13_temp = mxGetPr(prhs[13]); 
    double mexinput13 = *mexinput13_temp; 

    double *mexinput14_temp = NULL; 
    if( !mxIsDouble(prhs[14]) || mxIsComplex(prhs[14]) || !(mxGetM(prhs[14])==1 && mxGetN(prhs[14])==1) ) { 
      mexErrMsgTxt("Input 14 must be a noncomplex scalar double.");
    } 
    mexinput14_temp = mxGetPr(prhs[14]); 
    double mexinput14 = *mexinput14_temp; 

    double *mexinput15_temp = NULL; 
    if( !mxIsDouble(prhs[15]) || mxIsComplex(prhs[15]) || !(mxGetM(prhs[15])==1 && mxGetN(prhs[15])==1) ) { 
      mexErrMsgTxt("Input 15 must be a noncomplex scalar double.");
    } 
    mexinput15_temp = mxGetPr(prhs[15]); 
    double mexinput15 = *mexinput15_temp; 

    double *mexinput16_temp = NULL; 
    if( !mxIsDouble(prhs[16]) || mxIsComplex(prhs[16]) || !(mxGetM(prhs[16])==1 && mxGetN(prhs[16])==1) ) { 
      mexErrMsgTxt("Input 16 must be a noncomplex scalar double.");
    } 
    mexinput16_temp = mxGetPr(prhs[16]); 
    double mexinput16 = *mexinput16_temp; 

    double *mexinput17_temp = NULL; 
    if( !mxIsDouble(prhs[17]) || mxIsComplex(prhs[17]) || !(mxGetM(prhs[17])==1 && mxGetN(prhs[17])==1) ) { 
      mexErrMsgTxt("Input 17 must be a noncomplex scalar double.");
    } 
    mexinput17_temp = mxGetPr(prhs[17]); 
    double mexinput17 = *mexinput17_temp; 

    double *mexinput18_temp = NULL; 
    if( !mxIsDouble(prhs[18]) || mxIsComplex(prhs[18]) || !(mxGetM(prhs[18])==1 && mxGetN(prhs[18])==1) ) { 
      mexErrMsgTxt("Input 18 must be a noncomplex scalar double.");
    } 
    mexinput18_temp = mxGetPr(prhs[18]); 
    double mexinput18 = *mexinput18_temp; 

    double *mexinput19_temp = NULL; 
    if( !mxIsDouble(prhs[19]) || mxIsComplex(prhs[19]) || !(mxGetM(prhs[19])==1 && mxGetN(prhs[19])==1) ) { 
      mexErrMsgTxt("Input 19 must be a noncomplex scalar double.");
    } 
    mexinput19_temp = mxGetPr(prhs[19]); 
    double mexinput19 = *mexinput19_temp; 

    double *mexinput20_temp = NULL; 
    if( !mxIsDouble(prhs[20]) || mxIsComplex(prhs[20]) || !(mxGetM(prhs[20])==1 && mxGetN(prhs[20])==1) ) { 
      mexErrMsgTxt("Input 20 must be a noncomplex scalar double.");
    } 
    mexinput20_temp = mxGetPr(prhs[20]); 
    double mexinput20 = *mexinput20_temp; 

    double *mexinput21_temp = NULL; 
    if( !mxIsDouble(prhs[21]) || mxIsComplex(prhs[21]) || !(mxGetM(prhs[21])==1 && mxGetN(prhs[21])==1) ) { 
      mexErrMsgTxt("Input 21 must be a noncomplex scalar double.");
    } 
    mexinput21_temp = mxGetPr(prhs[21]); 
    double mexinput21 = *mexinput21_temp; 

    double *mexinput22_temp = NULL; 
    if( !mxIsDouble(prhs[22]) || mxIsComplex(prhs[22]) || !(mxGetM(prhs[22])==1 && mxGetN(prhs[22])==1) ) { 
      mexErrMsgTxt("Input 22 must be a noncomplex scalar double.");
    } 
    mexinput22_temp = mxGetPr(prhs[22]); 
    double mexinput22 = *mexinput22_temp; 

    double *mexinput23_temp = NULL; 
    if( !mxIsDouble(prhs[23]) || mxIsComplex(prhs[23]) || !(mxGetM(prhs[23])==1 && mxGetN(prhs[23])==1) ) { 
      mexErrMsgTxt("Input 23 must be a noncomplex scalar double.");
    } 
    mexinput23_temp = mxGetPr(prhs[23]); 
    double mexinput23 = *mexinput23_temp; 

    double *mexinput24_temp = NULL; 
    if( !mxIsDouble(prhs[24]) || mxIsComplex(prhs[24]) || !(mxGetM(prhs[24])==1 && mxGetN(prhs[24])==1) ) { 
      mexErrMsgTxt("Input 24 must be a noncomplex scalar double.");
    } 
    mexinput24_temp = mxGetPr(prhs[24]); 
    double mexinput24 = *mexinput24_temp; 

    double *mexinput25_temp = NULL; 
    if( !mxIsDouble(prhs[25]) || mxIsComplex(prhs[25]) || !(mxGetM(prhs[25])==1 && mxGetN(prhs[25])==1) ) { 
      mexErrMsgTxt("Input 25 must be a noncomplex scalar double.");
    } 
    mexinput25_temp = mxGetPr(prhs[25]); 
    double mexinput25 = *mexinput25_temp; 

    double *mexinput26_temp = NULL; 
    if( !mxIsDouble(prhs[26]) || mxIsComplex(prhs[26]) || !(mxGetM(prhs[26])==1 && mxGetN(prhs[26])==1) ) { 
      mexErrMsgTxt("Input 26 must be a noncomplex scalar double.");
    } 
    mexinput26_temp = mxGetPr(prhs[26]); 
    double mexinput26 = *mexinput26_temp; 

    double *mexinput27_temp = NULL; 
    if( !mxIsDouble(prhs[27]) || mxIsComplex(prhs[27]) || !(mxGetM(prhs[27])==1 && mxGetN(prhs[27])==1) ) { 
      mexErrMsgTxt("Input 27 must be a noncomplex scalar double.");
    } 
    mexinput27_temp = mxGetPr(prhs[27]); 
    double mexinput27 = *mexinput27_temp; 

    double *mexinput28_temp = NULL; 
    if( !mxIsDouble(prhs[28]) || mxIsComplex(prhs[28]) || !(mxGetM(prhs[28])==1 && mxGetN(prhs[28])==1) ) { 
      mexErrMsgTxt("Input 28 must be a noncomplex scalar double.");
    } 
    mexinput28_temp = mxGetPr(prhs[28]); 
    double mexinput28 = *mexinput28_temp; 

    double *mexinput29_temp = NULL; 
    if( !mxIsDouble(prhs[29]) || mxIsComplex(prhs[29]) || !(mxGetM(prhs[29])==1 && mxGetN(prhs[29])==1) ) { 
      mexErrMsgTxt("Input 29 must be a noncomplex scalar double.");
    } 
    mexinput29_temp = mxGetPr(prhs[29]); 
    double mexinput29 = *mexinput29_temp; 

    double *mexinput30_temp = NULL; 
    if( !mxIsDouble(prhs[30]) || mxIsComplex(prhs[30]) || !(mxGetM(prhs[30])==1 && mxGetN(prhs[30])==1) ) { 
      mexErrMsgTxt("Input 30 must be a noncomplex scalar double.");
    } 
    mexinput30_temp = mxGetPr(prhs[30]); 
    double mexinput30 = *mexinput30_temp; 

    double *mexinput31_temp = NULL; 
    if( !mxIsDouble(prhs[31]) || mxIsComplex(prhs[31]) || !(mxGetM(prhs[31])==1 && mxGetN(prhs[31])==1) ) { 
      mexErrMsgTxt("Input 31 must be a noncomplex scalar double.");
    } 
    mexinput31_temp = mxGetPr(prhs[31]); 
    double mexinput31 = *mexinput31_temp; 

    double *mexinput32_temp = NULL; 
    if( !mxIsDouble(prhs[32]) || mxIsComplex(prhs[32]) || !(mxGetM(prhs[32])==1 && mxGetN(prhs[32])==1) ) { 
      mexErrMsgTxt("Input 32 must be a noncomplex scalar double.");
    } 
    mexinput32_temp = mxGetPr(prhs[32]); 
    double mexinput32 = *mexinput32_temp; 

    double *mexinput33_temp = NULL; 
    if( !mxIsDouble(prhs[33]) || mxIsComplex(prhs[33]) || !(mxGetM(prhs[33])==1 && mxGetN(prhs[33])==1) ) { 
      mexErrMsgTxt("Input 33 must be a noncomplex scalar double.");
    } 
    mexinput33_temp = mxGetPr(prhs[33]); 
    double mexinput33 = *mexinput33_temp; 

    double *mexinput34_temp = NULL; 
    if( !mxIsDouble(prhs[34]) || mxIsComplex(prhs[34]) || !(mxGetM(prhs[34])==1 && mxGetN(prhs[34])==1) ) { 
      mexErrMsgTxt("Input 34 must be a noncomplex scalar double.");
    } 
    mexinput34_temp = mxGetPr(prhs[34]); 
    double mexinput34 = *mexinput34_temp; 

    double *mexinput35_temp = NULL; 
    if( !mxIsDouble(prhs[35]) || mxIsComplex(prhs[35]) || !(mxGetM(prhs[35])==1 && mxGetN(prhs[35])==1) ) { 
      mexErrMsgTxt("Input 35 must be a noncomplex scalar double.");
    } 
    mexinput35_temp = mxGetPr(prhs[35]); 
    double mexinput35 = *mexinput35_temp; 

    double *mexinput36_temp = NULL; 
    if( !mxIsDouble(prhs[36]) || mxIsComplex(prhs[36]) || !(mxGetM(prhs[36])==1 && mxGetN(prhs[36])==1) ) { 
      mexErrMsgTxt("Input 36 must be a noncomplex scalar double.");
    } 
    mexinput36_temp = mxGetPr(prhs[36]); 
    double mexinput36 = *mexinput36_temp; 

    double *mexinput37_temp = NULL; 
    if( !mxIsDouble(prhs[37]) || mxIsComplex(prhs[37]) || !(mxGetM(prhs[37])==1 && mxGetN(prhs[37])==1) ) { 
      mexErrMsgTxt("Input 37 must be a noncomplex scalar double.");
    } 
    mexinput37_temp = mxGetPr(prhs[37]); 
    double mexinput37 = *mexinput37_temp; 

    double *mexinput38_temp = NULL; 
    if( !mxIsDouble(prhs[38]) || mxIsComplex(prhs[38]) || !(mxGetM(prhs[38])==1 && mxGetN(prhs[38])==1) ) { 
      mexErrMsgTxt("Input 38 must be a noncomplex scalar double.");
    } 
    mexinput38_temp = mxGetPr(prhs[38]); 
    double mexinput38 = *mexinput38_temp; 

    double *mexinput39_temp = NULL; 
    if( !mxIsDouble(prhs[39]) || mxIsComplex(prhs[39]) || !(mxGetM(prhs[39])==1 && mxGetN(prhs[39])==1) ) { 
      mexErrMsgTxt("Input 39 must be a noncomplex scalar double.");
    } 
    mexinput39_temp = mxGetPr(prhs[39]); 
    double mexinput39 = *mexinput39_temp; 

    double *mexinput40_temp = NULL; 
    if( !mxIsDouble(prhs[40]) || mxIsComplex(prhs[40]) || !(mxGetM(prhs[40])==1 && mxGetN(prhs[40])==1) ) { 
      mexErrMsgTxt("Input 40 must be a noncomplex scalar double.");
    } 
    mexinput40_temp = mxGetPr(prhs[40]); 
    double mexinput40 = *mexinput40_temp; 

    double *mexinput41_temp = NULL; 
    if( !mxIsDouble(prhs[41]) || mxIsComplex(prhs[41]) || !(mxGetM(prhs[41])==1 && mxGetN(prhs[41])==1) ) { 
      mexErrMsgTxt("Input 41 must be a noncomplex scalar double.");
    } 
    mexinput41_temp = mxGetPr(prhs[41]); 
    double mexinput41 = *mexinput41_temp; 

    double *mexinput42_temp = NULL; 
    if( !mxIsDouble(prhs[42]) || mxIsComplex(prhs[42]) || !(mxGetM(prhs[42])==1 && mxGetN(prhs[42])==1) ) { 
      mexErrMsgTxt("Input 42 must be a noncomplex scalar double.");
    } 
    mexinput42_temp = mxGetPr(prhs[42]); 
    double mexinput42 = *mexinput42_temp; 

    double *mexinput43_temp = NULL; 
    if( !mxIsDouble(prhs[43]) || mxIsComplex(prhs[43]) || !(mxGetM(prhs[43])==1 && mxGetN(prhs[43])==1) ) { 
      mexErrMsgTxt("Input 43 must be a noncomplex scalar double.");
    } 
    mexinput43_temp = mxGetPr(prhs[43]); 
    double mexinput43 = *mexinput43_temp; 

    double *mexinput44_temp = NULL; 
    if( !mxIsDouble(prhs[44]) || mxIsComplex(prhs[44]) || !(mxGetM(prhs[44])==1 && mxGetN(prhs[44])==1) ) { 
      mexErrMsgTxt("Input 44 must be a noncomplex scalar double.");
    } 
    mexinput44_temp = mxGetPr(prhs[44]); 
    double mexinput44 = *mexinput44_temp; 

    double *mexinput45_temp = NULL; 
    if( !mxIsDouble(prhs[45]) || mxIsComplex(prhs[45]) || !(mxGetM(prhs[45])==1 && mxGetN(prhs[45])==1) ) { 
      mexErrMsgTxt("Input 45 must be a noncomplex scalar double.");
    } 
    mexinput45_temp = mxGetPr(prhs[45]); 
    double mexinput45 = *mexinput45_temp; 

    double *mexinput46_temp = NULL; 
    if( !mxIsDouble(prhs[46]) || mxIsComplex(prhs[46]) || !(mxGetM(prhs[46])==1 && mxGetN(prhs[46])==1) ) { 
      mexErrMsgTxt("Input 46 must be a noncomplex scalar double.");
    } 
    mexinput46_temp = mxGetPr(prhs[46]); 
    double mexinput46 = *mexinput46_temp; 

    double *mexinput47_temp = NULL; 
    if( !mxIsDouble(prhs[47]) || mxIsComplex(prhs[47]) || !(mxGetM(prhs[47])==1 && mxGetN(prhs[47])==1) ) { 
      mexErrMsgTxt("Input 47 must be a noncomplex scalar double.");
    } 
    mexinput47_temp = mxGetPr(prhs[47]); 
    double mexinput47 = *mexinput47_temp; 

    double *mexinput48_temp = NULL; 
    if( !mxIsDouble(prhs[48]) || mxIsComplex(prhs[48]) || !(mxGetM(prhs[48])==1 && mxGetN(prhs[48])==1) ) { 
      mexErrMsgTxt("Input 48 must be a noncomplex scalar double.");
    } 
    mexinput48_temp = mxGetPr(prhs[48]); 
    double mexinput48 = *mexinput48_temp; 

    double *mexinput49_temp = NULL; 
    if( !mxIsDouble(prhs[49]) || mxIsComplex(prhs[49]) || !(mxGetM(prhs[49])==1 && mxGetN(prhs[49])==1) ) { 
      mexErrMsgTxt("Input 49 must be a noncomplex scalar double.");
    } 
    mexinput49_temp = mxGetPr(prhs[49]); 
    double mexinput49 = *mexinput49_temp; 

    double *mexinput50_temp = NULL; 
    if( !mxIsDouble(prhs[50]) || mxIsComplex(prhs[50]) || !(mxGetM(prhs[50])==1 && mxGetN(prhs[50])==1) ) { 
      mexErrMsgTxt("Input 50 must be a noncomplex scalar double.");
    } 
    mexinput50_temp = mxGetPr(prhs[50]); 
    double mexinput50 = *mexinput50_temp; 

    double *mexinput51_temp = NULL; 
    if( !mxIsDouble(prhs[51]) || mxIsComplex(prhs[51]) || !(mxGetM(prhs[51])==1 && mxGetN(prhs[51])==1) ) { 
      mexErrMsgTxt("Input 51 must be a noncomplex scalar double.");
    } 
    mexinput51_temp = mxGetPr(prhs[51]); 
    double mexinput51 = *mexinput51_temp; 

    double *mexinput52_temp = NULL; 
    if( !mxIsDouble(prhs[52]) || mxIsComplex(prhs[52]) || !(mxGetM(prhs[52])==1 && mxGetN(prhs[52])==1) ) { 
      mexErrMsgTxt("Input 52 must be a noncomplex scalar double.");
    } 
    mexinput52_temp = mxGetPr(prhs[52]); 
    double mexinput52 = *mexinput52_temp; 

    double *mexinput53_temp = NULL; 
    if( !mxIsDouble(prhs[53]) || mxIsComplex(prhs[53]) || !(mxGetM(prhs[53])==1 && mxGetN(prhs[53])==1) ) { 
      mexErrMsgTxt("Input 53 must be a noncomplex scalar double.");
    } 
    mexinput53_temp = mxGetPr(prhs[53]); 
    double mexinput53 = *mexinput53_temp; 

    double *mexinput54_temp = NULL; 
    if( !mxIsDouble(prhs[54]) || mxIsComplex(prhs[54]) || !(mxGetM(prhs[54])==1 && mxGetN(prhs[54])==1) ) { 
      mexErrMsgTxt("Input 54 must be a noncomplex scalar double.");
    } 
    mexinput54_temp = mxGetPr(prhs[54]); 
    double mexinput54 = *mexinput54_temp; 

    double *mexinput55_temp = NULL; 
    if( !mxIsDouble(prhs[55]) || mxIsComplex(prhs[55]) || !(mxGetM(prhs[55])==1 && mxGetN(prhs[55])==1) ) { 
      mexErrMsgTxt("Input 55 must be a noncomplex scalar double.");
    } 
    mexinput55_temp = mxGetPr(prhs[55]); 
    double mexinput55 = *mexinput55_temp; 

    double *mexinput56_temp = NULL; 
    if( !mxIsDouble(prhs[56]) || mxIsComplex(prhs[56]) || !(mxGetM(prhs[56])==1 && mxGetN(prhs[56])==1) ) { 
      mexErrMsgTxt("Input 56 must be a noncomplex scalar double.");
    } 
    mexinput56_temp = mxGetPr(prhs[56]); 
    double mexinput56 = *mexinput56_temp; 

    double *mexinput57_temp = NULL; 
    if( !mxIsDouble(prhs[57]) || mxIsComplex(prhs[57]) || !(mxGetM(prhs[57])==1 && mxGetN(prhs[57])==1) ) { 
      mexErrMsgTxt("Input 57 must be a noncomplex scalar double.");
    } 
    mexinput57_temp = mxGetPr(prhs[57]); 
    double mexinput57 = *mexinput57_temp; 

    double *mexinput58_temp = NULL; 
    if( !mxIsDouble(prhs[58]) || mxIsComplex(prhs[58]) || !(mxGetM(prhs[58])==1 && mxGetN(prhs[58])==1) ) { 
      mexErrMsgTxt("Input 58 must be a noncomplex scalar double.");
    } 
    mexinput58_temp = mxGetPr(prhs[58]); 
    double mexinput58 = *mexinput58_temp; 

    double *mexinput59_temp = NULL; 
    if( !mxIsDouble(prhs[59]) || mxIsComplex(prhs[59]) || !(mxGetM(prhs[59])==1 && mxGetN(prhs[59])==1) ) { 
      mexErrMsgTxt("Input 59 must be a noncomplex scalar double.");
    } 
    mexinput59_temp = mxGetPr(prhs[59]); 
    double mexinput59 = *mexinput59_temp; 

    double *mexinput60_temp = NULL; 
    if( !mxIsDouble(prhs[60]) || mxIsComplex(prhs[60]) || !(mxGetM(prhs[60])==1 && mxGetN(prhs[60])==1) ) { 
      mexErrMsgTxt("Input 60 must be a noncomplex scalar double.");
    } 
    mexinput60_temp = mxGetPr(prhs[60]); 
    double mexinput60 = *mexinput60_temp; 

    double *mexinput61_temp = NULL; 
    if( !mxIsDouble(prhs[61]) || mxIsComplex(prhs[61]) || !(mxGetM(prhs[61])==1 && mxGetN(prhs[61])==1) ) { 
      mexErrMsgTxt("Input 61 must be a noncomplex scalar double.");
    } 
    mexinput61_temp = mxGetPr(prhs[61]); 
    double mexinput61 = *mexinput61_temp; 

    double *mexinput62_temp = NULL; 
    if( !mxIsDouble(prhs[62]) || mxIsComplex(prhs[62]) || !(mxGetM(prhs[62])==1 && mxGetN(prhs[62])==1) ) { 
      mexErrMsgTxt("Input 62 must be a noncomplex scalar double.");
    } 
    mexinput62_temp = mxGetPr(prhs[62]); 
    double mexinput62 = *mexinput62_temp; 

    double *mexinput63_temp = NULL; 
    if( !mxIsDouble(prhs[63]) || mxIsComplex(prhs[63]) || !(mxGetM(prhs[63])==1 && mxGetN(prhs[63])==1) ) { 
      mexErrMsgTxt("Input 63 must be a noncomplex scalar double.");
    } 
    mexinput63_temp = mxGetPr(prhs[63]); 
    double mexinput63 = *mexinput63_temp; 

    double *mexinput64_temp = NULL; 
    if( !mxIsDouble(prhs[64]) || mxIsComplex(prhs[64]) || !(mxGetM(prhs[64])==1 && mxGetN(prhs[64])==1) ) { 
      mexErrMsgTxt("Input 64 must be a noncomplex scalar double.");
    } 
    mexinput64_temp = mxGetPr(prhs[64]); 
    double mexinput64 = *mexinput64_temp; 

    double *mexinput65_temp = NULL; 
    if( !mxIsDouble(prhs[65]) || mxIsComplex(prhs[65]) || !(mxGetM(prhs[65])==1 && mxGetN(prhs[65])==1) ) { 
      mexErrMsgTxt("Input 65 must be a noncomplex scalar double.");
    } 
    mexinput65_temp = mxGetPr(prhs[65]); 
    double mexinput65 = *mexinput65_temp; 

    double *mexinput66_temp = NULL; 
    if( !mxIsDouble(prhs[66]) || mxIsComplex(prhs[66]) || !(mxGetM(prhs[66])==1 && mxGetN(prhs[66])==1) ) { 
      mexErrMsgTxt("Input 66 must be a noncomplex scalar double.");
    } 
    mexinput66_temp = mxGetPr(prhs[66]); 
    double mexinput66 = *mexinput66_temp; 

    double *mexinput67_temp = NULL; 
    if( !mxIsDouble(prhs[67]) || mxIsComplex(prhs[67]) || !(mxGetM(prhs[67])==1 && mxGetN(prhs[67])==1) ) { 
      mexErrMsgTxt("Input 67 must be a noncomplex scalar double.");
    } 
    mexinput67_temp = mxGetPr(prhs[67]); 
    double mexinput67 = *mexinput67_temp; 

    double *mexinput68_temp = NULL; 
    if( !mxIsDouble(prhs[68]) || mxIsComplex(prhs[68]) || !(mxGetM(prhs[68])==1 && mxGetN(prhs[68])==1) ) { 
      mexErrMsgTxt("Input 68 must be a noncomplex scalar double.");
    } 
    mexinput68_temp = mxGetPr(prhs[68]); 
    double mexinput68 = *mexinput68_temp; 

    double *mexinput69_temp = NULL; 
    if( !mxIsDouble(prhs[69]) || mxIsComplex(prhs[69]) || !(mxGetM(prhs[69])==1 && mxGetN(prhs[69])==1) ) { 
      mexErrMsgTxt("Input 69 must be a noncomplex scalar double.");
    } 
    mexinput69_temp = mxGetPr(prhs[69]); 
    double mexinput69 = *mexinput69_temp; 

    double *mexinput70_temp = NULL; 
    if( !mxIsDouble(prhs[70]) || mxIsComplex(prhs[70]) || !(mxGetM(prhs[70])==1 && mxGetN(prhs[70])==1) ) { 
      mexErrMsgTxt("Input 70 must be a noncomplex scalar double.");
    } 
    mexinput70_temp = mxGetPr(prhs[70]); 
    double mexinput70 = *mexinput70_temp; 

    double *mexinput71_temp = NULL; 
    if( !mxIsDouble(prhs[71]) || mxIsComplex(prhs[71]) || !(mxGetM(prhs[71])==1 && mxGetN(prhs[71])==1) ) { 
      mexErrMsgTxt("Input 71 must be a noncomplex scalar double.");
    } 
    mexinput71_temp = mxGetPr(prhs[71]); 
    double mexinput71 = *mexinput71_temp; 

    double *mexinput72_temp = NULL; 
    if( !mxIsDouble(prhs[72]) || mxIsComplex(prhs[72]) || !(mxGetM(prhs[72])==1 && mxGetN(prhs[72])==1) ) { 
      mexErrMsgTxt("Input 72 must be a noncomplex scalar double.");
    } 
    mexinput72_temp = mxGetPr(prhs[72]); 
    double mexinput72 = *mexinput72_temp; 

    double *mexinput73_temp = NULL; 
    if( !mxIsDouble(prhs[73]) || mxIsComplex(prhs[73]) || !(mxGetM(prhs[73])==1 && mxGetN(prhs[73])==1) ) { 
      mexErrMsgTxt("Input 73 must be a noncomplex scalar double.");
    } 
    mexinput73_temp = mxGetPr(prhs[73]); 
    double mexinput73 = *mexinput73_temp; 

    double *mexinput74_temp = NULL; 
    if( !mxIsDouble(prhs[74]) || mxIsComplex(prhs[74]) || !(mxGetM(prhs[74])==1 && mxGetN(prhs[74])==1) ) { 
      mexErrMsgTxt("Input 74 must be a noncomplex scalar double.");
    } 
    mexinput74_temp = mxGetPr(prhs[74]); 
    double mexinput74 = *mexinput74_temp; 

    double *mexinput75_temp = NULL; 
    if( !mxIsDouble(prhs[75]) || mxIsComplex(prhs[75]) || !(mxGetM(prhs[75])==1 && mxGetN(prhs[75])==1) ) { 
      mexErrMsgTxt("Input 75 must be a noncomplex scalar double.");
    } 
    mexinput75_temp = mxGetPr(prhs[75]); 
    double mexinput75 = *mexinput75_temp; 

    double *mexinput76_temp = NULL; 
    if( !mxIsDouble(prhs[76]) || mxIsComplex(prhs[76]) || !(mxGetM(prhs[76])==1 && mxGetN(prhs[76])==1) ) { 
      mexErrMsgTxt("Input 76 must be a noncomplex scalar double.");
    } 
    mexinput76_temp = mxGetPr(prhs[76]); 
    double mexinput76 = *mexinput76_temp; 

    double *mexinput77_temp = NULL; 
    if( !mxIsDouble(prhs[77]) || mxIsComplex(prhs[77]) || !(mxGetM(prhs[77])==1 && mxGetN(prhs[77])==1) ) { 
      mexErrMsgTxt("Input 77 must be a noncomplex scalar double.");
    } 
    mexinput77_temp = mxGetPr(prhs[77]); 
    double mexinput77 = *mexinput77_temp; 

    double *mexinput78_temp = NULL; 
    if( !mxIsDouble(prhs[78]) || mxIsComplex(prhs[78]) || !(mxGetM(prhs[78])==1 && mxGetN(prhs[78])==1) ) { 
      mexErrMsgTxt("Input 78 must be a noncomplex scalar double.");
    } 
    mexinput78_temp = mxGetPr(prhs[78]); 
    double mexinput78 = *mexinput78_temp; 

    double *mexinput79_temp = NULL; 
    if( !mxIsDouble(prhs[79]) || mxIsComplex(prhs[79]) || !(mxGetM(prhs[79])==1 && mxGetN(prhs[79])==1) ) { 
      mexErrMsgTxt("Input 79 must be a noncomplex scalar double.");
    } 
    mexinput79_temp = mxGetPr(prhs[79]); 
    double mexinput79 = *mexinput79_temp; 

    double *mexinput80_temp = NULL; 
    if( !mxIsDouble(prhs[80]) || mxIsComplex(prhs[80]) || !(mxGetM(prhs[80])==1 && mxGetN(prhs[80])==1) ) { 
      mexErrMsgTxt("Input 80 must be a noncomplex scalar double.");
    } 
    mexinput80_temp = mxGetPr(prhs[80]); 
    double mexinput80 = *mexinput80_temp; 

    double *mexinput81_temp = NULL; 
    if( !mxIsDouble(prhs[81]) || mxIsComplex(prhs[81]) || !(mxGetM(prhs[81])==1 && mxGetN(prhs[81])==1) ) { 
      mexErrMsgTxt("Input 81 must be a noncomplex scalar double.");
    } 
    mexinput81_temp = mxGetPr(prhs[81]); 
    double mexinput81 = *mexinput81_temp; 

    double *mexinput82_temp = NULL; 
    if( !mxIsDouble(prhs[82]) || mxIsComplex(prhs[82]) || !(mxGetM(prhs[82])==1 && mxGetN(prhs[82])==1) ) { 
      mexErrMsgTxt("Input 82 must be a noncomplex scalar double.");
    } 
    mexinput82_temp = mxGetPr(prhs[82]); 
    double mexinput82 = *mexinput82_temp; 

    double *mexinput83_temp = NULL; 
    if( !mxIsDouble(prhs[83]) || mxIsComplex(prhs[83]) || !(mxGetM(prhs[83])==1 && mxGetN(prhs[83])==1) ) { 
      mexErrMsgTxt("Input 83 must be a noncomplex scalar double.");
    } 
    mexinput83_temp = mxGetPr(prhs[83]); 
    double mexinput83 = *mexinput83_temp; 

    double *mexinput84_temp = NULL; 
    if( !mxIsDouble(prhs[84]) || mxIsComplex(prhs[84]) || !(mxGetM(prhs[84])==1 && mxGetN(prhs[84])==1) ) { 
      mexErrMsgTxt("Input 84 must be a noncomplex scalar double.");
    } 
    mexinput84_temp = mxGetPr(prhs[84]); 
    double mexinput84 = *mexinput84_temp; 

    double *mexinput85_temp = NULL; 
    if( !mxIsDouble(prhs[85]) || mxIsComplex(prhs[85]) || !(mxGetM(prhs[85])==1 && mxGetN(prhs[85])==1) ) { 
      mexErrMsgTxt("Input 85 must be a noncomplex scalar double.");
    } 
    mexinput85_temp = mxGetPr(prhs[85]); 
    double mexinput85 = *mexinput85_temp; 

    double *mexinput86_temp = NULL; 
    if( !mxIsDouble(prhs[86]) || mxIsComplex(prhs[86]) || !(mxGetM(prhs[86])==1 && mxGetN(prhs[86])==1) ) { 
      mexErrMsgTxt("Input 86 must be a noncomplex scalar double.");
    } 
    mexinput86_temp = mxGetPr(prhs[86]); 
    double mexinput86 = *mexinput86_temp; 

    double *mexinput87_temp = NULL; 
    if( !mxIsDouble(prhs[87]) || mxIsComplex(prhs[87]) || !(mxGetM(prhs[87])==1 && mxGetN(prhs[87])==1) ) { 
      mexErrMsgTxt("Input 87 must be a noncomplex scalar double.");
    } 
    mexinput87_temp = mxGetPr(prhs[87]); 
    double mexinput87 = *mexinput87_temp; 

    double *mexinput88_temp = NULL; 
    if( !mxIsDouble(prhs[88]) || mxIsComplex(prhs[88]) || !(mxGetM(prhs[88])==1 && mxGetN(prhs[88])==1) ) { 
      mexErrMsgTxt("Input 88 must be a noncomplex scalar double.");
    } 
    mexinput88_temp = mxGetPr(prhs[88]); 
    double mexinput88 = *mexinput88_temp; 

    double *mexinput89_temp = NULL; 
    if( !mxIsDouble(prhs[89]) || mxIsComplex(prhs[89]) || !(mxGetM(prhs[89])==1 && mxGetN(prhs[89])==1) ) { 
      mexErrMsgTxt("Input 89 must be a noncomplex scalar double.");
    } 
    mexinput89_temp = mxGetPr(prhs[89]); 
    double mexinput89 = *mexinput89_temp; 

    double *mexinput90_temp = NULL; 
    if( !mxIsDouble(prhs[90]) || mxIsComplex(prhs[90]) || !(mxGetM(prhs[90])==1 && mxGetN(prhs[90])==1) ) { 
      mexErrMsgTxt("Input 90 must be a noncomplex scalar double.");
    } 
    mexinput90_temp = mxGetPr(prhs[90]); 
    double mexinput90 = *mexinput90_temp; 

    double *mexinput91_temp = NULL; 
    if( !mxIsDouble(prhs[91]) || mxIsComplex(prhs[91]) || !(mxGetM(prhs[91])==1 && mxGetN(prhs[91])==1) ) { 
      mexErrMsgTxt("Input 91 must be a noncomplex scalar double.");
    } 
    mexinput91_temp = mxGetPr(prhs[91]); 
    double mexinput91 = *mexinput91_temp; 

    double *mexinput92_temp = NULL; 
    if( !mxIsDouble(prhs[92]) || mxIsComplex(prhs[92]) || !(mxGetM(prhs[92])==1 && mxGetN(prhs[92])==1) ) { 
      mexErrMsgTxt("Input 92 must be a noncomplex scalar double.");
    } 
    mexinput92_temp = mxGetPr(prhs[92]); 
    double mexinput92 = *mexinput92_temp; 

    double *mexinput93_temp = NULL; 
    if( !mxIsDouble(prhs[93]) || mxIsComplex(prhs[93]) || !(mxGetM(prhs[93])==1 && mxGetN(prhs[93])==1) ) { 
      mexErrMsgTxt("Input 93 must be a noncomplex scalar double.");
    } 
    mexinput93_temp = mxGetPr(prhs[93]); 
    double mexinput93 = *mexinput93_temp; 

    double *mexinput94_temp = NULL; 
    if( !mxIsDouble(prhs[94]) || mxIsComplex(prhs[94]) || !(mxGetM(prhs[94])==1 && mxGetN(prhs[94])==1) ) { 
      mexErrMsgTxt("Input 94 must be a noncomplex scalar double.");
    } 
    mexinput94_temp = mxGetPr(prhs[94]); 
    double mexinput94 = *mexinput94_temp; 

    double *mexinput95_temp = NULL; 
    if( !mxIsDouble(prhs[95]) || mxIsComplex(prhs[95]) || !(mxGetM(prhs[95])==1 && mxGetN(prhs[95])==1) ) { 
      mexErrMsgTxt("Input 95 must be a noncomplex scalar double.");
    } 
    mexinput95_temp = mxGetPr(prhs[95]); 
    double mexinput95 = *mexinput95_temp; 

    double *mexinput96_temp = NULL; 
    if( !mxIsDouble(prhs[96]) || mxIsComplex(prhs[96]) || !(mxGetM(prhs[96])==1 && mxGetN(prhs[96])==1) ) { 
      mexErrMsgTxt("Input 96 must be a noncomplex scalar double.");
    } 
    mexinput96_temp = mxGetPr(prhs[96]); 
    double mexinput96 = *mexinput96_temp; 

    double *mexinput97_temp = NULL; 
    if( !mxIsDouble(prhs[97]) || mxIsComplex(prhs[97]) || !(mxGetM(prhs[97])==1 && mxGetN(prhs[97])==1) ) { 
      mexErrMsgTxt("Input 97 must be a noncomplex scalar double.");
    } 
    mexinput97_temp = mxGetPr(prhs[97]); 
    double mexinput97 = *mexinput97_temp; 

    double *mexinput98_temp = NULL; 
    if( !mxIsDouble(prhs[98]) || mxIsComplex(prhs[98]) || !(mxGetM(prhs[98])==1 && mxGetN(prhs[98])==1) ) { 
      mexErrMsgTxt("Input 98 must be a noncomplex scalar double.");
    } 
    mexinput98_temp = mxGetPr(prhs[98]); 
    double mexinput98 = *mexinput98_temp; 

    double *mexinput99_temp = NULL; 
    if( !mxIsDouble(prhs[99]) || mxIsComplex(prhs[99]) || !(mxGetM(prhs[99])==1 && mxGetN(prhs[99])==1) ) { 
      mexErrMsgTxt("Input 99 must be a noncomplex scalar double.");
    } 
    mexinput99_temp = mxGetPr(prhs[99]); 
    double mexinput99 = *mexinput99_temp; 

    double *mexinput100_temp = NULL; 
    if( !mxIsDouble(prhs[100]) || mxIsComplex(prhs[100]) || !(mxGetM(prhs[100])==1 && mxGetN(prhs[100])==1) ) { 
      mexErrMsgTxt("Input 100 must be a noncomplex scalar double.");
    } 
    mexinput100_temp = mxGetPr(prhs[100]); 
    double mexinput100 = *mexinput100_temp; 

    double *mexinput101_temp = NULL; 
    if( !mxIsDouble(prhs[101]) || mxIsComplex(prhs[101]) || !(mxGetM(prhs[101])==1 && mxGetN(prhs[101])==1) ) { 
      mexErrMsgTxt("Input 101 must be a noncomplex scalar double.");
    } 
    mexinput101_temp = mxGetPr(prhs[101]); 
    double mexinput101 = *mexinput101_temp; 

    double *mexinput102_temp = NULL; 
    if( !mxIsDouble(prhs[102]) || mxIsComplex(prhs[102]) || !(mxGetM(prhs[102])==1 && mxGetN(prhs[102])==1) ) { 
      mexErrMsgTxt("Input 102 must be a noncomplex scalar double.");
    } 
    mexinput102_temp = mxGetPr(prhs[102]); 
    double mexinput102 = *mexinput102_temp; 

    double *mexinput103_temp = NULL; 
    if( !mxIsDouble(prhs[103]) || mxIsComplex(prhs[103]) || !(mxGetM(prhs[103])==1 && mxGetN(prhs[103])==1) ) { 
      mexErrMsgTxt("Input 103 must be a noncomplex scalar double.");
    } 
    mexinput103_temp = mxGetPr(prhs[103]); 
    double mexinput103 = *mexinput103_temp; 

    double *mexinput104_temp = NULL; 
    if( !mxIsDouble(prhs[104]) || mxIsComplex(prhs[104]) || !(mxGetM(prhs[104])==1 && mxGetN(prhs[104])==1) ) { 
      mexErrMsgTxt("Input 104 must be a noncomplex scalar double.");
    } 
    mexinput104_temp = mxGetPr(prhs[104]); 
    double mexinput104 = *mexinput104_temp; 

    double *mexinput105_temp = NULL; 
    if( !mxIsDouble(prhs[105]) || mxIsComplex(prhs[105]) || !(mxGetM(prhs[105])==1 && mxGetN(prhs[105])==1) ) { 
      mexErrMsgTxt("Input 105 must be a noncomplex scalar double.");
    } 
    mexinput105_temp = mxGetPr(prhs[105]); 
    double mexinput105 = *mexinput105_temp; 

    double *mexinput106_temp = NULL; 
    if( !mxIsDouble(prhs[106]) || mxIsComplex(prhs[106]) || !(mxGetM(prhs[106])==1 && mxGetN(prhs[106])==1) ) { 
      mexErrMsgTxt("Input 106 must be a noncomplex scalar double.");
    } 
    mexinput106_temp = mxGetPr(prhs[106]); 
    double mexinput106 = *mexinput106_temp; 

    double *mexinput107_temp = NULL; 
    if( !mxIsDouble(prhs[107]) || mxIsComplex(prhs[107]) || !(mxGetM(prhs[107])==1 && mxGetN(prhs[107])==1) ) { 
      mexErrMsgTxt("Input 107 must be a noncomplex scalar double.");
    } 
    mexinput107_temp = mxGetPr(prhs[107]); 
    double mexinput107 = *mexinput107_temp; 

    double *mexinput108_temp = NULL; 
    if( !mxIsDouble(prhs[108]) || mxIsComplex(prhs[108]) || !(mxGetM(prhs[108])==1 && mxGetN(prhs[108])==1) ) { 
      mexErrMsgTxt("Input 108 must be a noncomplex scalar double.");
    } 
    mexinput108_temp = mxGetPr(prhs[108]); 
    double mexinput108 = *mexinput108_temp; 

    double *mexinput109_temp = NULL; 
    if( !mxIsDouble(prhs[109]) || mxIsComplex(prhs[109]) || !(mxGetM(prhs[109])==1 && mxGetN(prhs[109])==1) ) { 
      mexErrMsgTxt("Input 109 must be a noncomplex scalar double.");
    } 
    mexinput109_temp = mxGetPr(prhs[109]); 
    double mexinput109 = *mexinput109_temp; 

    double *mexinput110_temp = NULL; 
    if( !mxIsDouble(prhs[110]) || mxIsComplex(prhs[110]) || !(mxGetM(prhs[110])==1 && mxGetN(prhs[110])==1) ) { 
      mexErrMsgTxt("Input 110 must be a noncomplex scalar double.");
    } 
    mexinput110_temp = mxGetPr(prhs[110]); 
    double mexinput110 = *mexinput110_temp; 

    double *mexinput111_temp = NULL; 
    if( !mxIsDouble(prhs[111]) || mxIsComplex(prhs[111]) || !(mxGetM(prhs[111])==1 && mxGetN(prhs[111])==1) ) { 
      mexErrMsgTxt("Input 111 must be a noncomplex scalar double.");
    } 
    mexinput111_temp = mxGetPr(prhs[111]); 
    double mexinput111 = *mexinput111_temp; 

    double *mexinput112_temp = NULL; 
    if( !mxIsDouble(prhs[112]) || mxIsComplex(prhs[112]) || !(mxGetM(prhs[112])==1 && mxGetN(prhs[112])==1) ) { 
      mexErrMsgTxt("Input 112 must be a noncomplex scalar double.");
    } 
    mexinput112_temp = mxGetPr(prhs[112]); 
    double mexinput112 = *mexinput112_temp; 

    double *mexinput113_temp = NULL; 
    if( !mxIsDouble(prhs[113]) || mxIsComplex(prhs[113]) || !(mxGetM(prhs[113])==1 && mxGetN(prhs[113])==1) ) { 
      mexErrMsgTxt("Input 113 must be a noncomplex scalar double.");
    } 
    mexinput113_temp = mxGetPr(prhs[113]); 
    double mexinput113 = *mexinput113_temp; 

    double *mexinput114_temp = NULL; 
    if( !mxIsDouble(prhs[114]) || mxIsComplex(prhs[114]) || !(mxGetM(prhs[114])==1 && mxGetN(prhs[114])==1) ) { 
      mexErrMsgTxt("Input 114 must be a noncomplex scalar double.");
    } 
    mexinput114_temp = mxGetPr(prhs[114]); 
    double mexinput114 = *mexinput114_temp; 

    double *mexinput115_temp = NULL; 
    if( !mxIsDouble(prhs[115]) || mxIsComplex(prhs[115]) || !(mxGetM(prhs[115])==1 && mxGetN(prhs[115])==1) ) { 
      mexErrMsgTxt("Input 115 must be a noncomplex scalar double.");
    } 
    mexinput115_temp = mxGetPr(prhs[115]); 
    double mexinput115 = *mexinput115_temp; 

    double *mexinput116_temp = NULL; 
    if( !mxIsDouble(prhs[116]) || mxIsComplex(prhs[116]) || !(mxGetM(prhs[116])==1 && mxGetN(prhs[116])==1) ) { 
      mexErrMsgTxt("Input 116 must be a noncomplex scalar double.");
    } 
    mexinput116_temp = mxGetPr(prhs[116]); 
    double mexinput116 = *mexinput116_temp; 

    double *mexinput117_temp = NULL; 
    if( !mxIsDouble(prhs[117]) || mxIsComplex(prhs[117]) || !(mxGetM(prhs[117])==1 && mxGetN(prhs[117])==1) ) { 
      mexErrMsgTxt("Input 117 must be a noncomplex scalar double.");
    } 
    mexinput117_temp = mxGetPr(prhs[117]); 
    double mexinput117 = *mexinput117_temp; 

    double *mexinput118_temp = NULL; 
    if( !mxIsDouble(prhs[118]) || mxIsComplex(prhs[118]) || !(mxGetM(prhs[118])==1 && mxGetN(prhs[118])==1) ) { 
      mexErrMsgTxt("Input 118 must be a noncomplex scalar double.");
    } 
    mexinput118_temp = mxGetPr(prhs[118]); 
    double mexinput118 = *mexinput118_temp; 

    double *mexinput119_temp = NULL; 
    if( !mxIsDouble(prhs[119]) || mxIsComplex(prhs[119]) || !(mxGetM(prhs[119])==1 && mxGetN(prhs[119])==1) ) { 
      mexErrMsgTxt("Input 119 must be a noncomplex scalar double.");
    } 
    mexinput119_temp = mxGetPr(prhs[119]); 
    double mexinput119 = *mexinput119_temp; 

    double *mexinput120_temp = NULL; 
    if( !mxIsDouble(prhs[120]) || mxIsComplex(prhs[120]) || !(mxGetM(prhs[120])==1 && mxGetN(prhs[120])==1) ) { 
      mexErrMsgTxt("Input 120 must be a noncomplex scalar double.");
    } 
    mexinput120_temp = mxGetPr(prhs[120]); 
    double mexinput120 = *mexinput120_temp; 

    double *mexinput121_temp = NULL; 
    if( !mxIsDouble(prhs[121]) || mxIsComplex(prhs[121]) || !(mxGetM(prhs[121])==1 && mxGetN(prhs[121])==1) ) { 
      mexErrMsgTxt("Input 121 must be a noncomplex scalar double.");
    } 
    mexinput121_temp = mxGetPr(prhs[121]); 
    double mexinput121 = *mexinput121_temp; 

    double *mexinput122_temp = NULL; 
    if( !mxIsDouble(prhs[122]) || mxIsComplex(prhs[122]) || !(mxGetM(prhs[122])==1 && mxGetN(prhs[122])==1) ) { 
      mexErrMsgTxt("Input 122 must be a noncomplex scalar double.");
    } 
    mexinput122_temp = mxGetPr(prhs[122]); 
    double mexinput122 = *mexinput122_temp; 

    double *mexinput123_temp = NULL; 
    if( !mxIsDouble(prhs[123]) || mxIsComplex(prhs[123]) || !(mxGetM(prhs[123])==1 && mxGetN(prhs[123])==1) ) { 
      mexErrMsgTxt("Input 123 must be a noncomplex scalar double.");
    } 
    mexinput123_temp = mxGetPr(prhs[123]); 
    double mexinput123 = *mexinput123_temp; 

    double *mexinput124_temp = NULL; 
    if( !mxIsDouble(prhs[124]) || mxIsComplex(prhs[124]) || !(mxGetM(prhs[124])==1 && mxGetN(prhs[124])==1) ) { 
      mexErrMsgTxt("Input 124 must be a noncomplex scalar double.");
    } 
    mexinput124_temp = mxGetPr(prhs[124]); 
    double mexinput124 = *mexinput124_temp; 

    double *mexinput125_temp = NULL; 
    if( !mxIsDouble(prhs[125]) || mxIsComplex(prhs[125]) || !(mxGetM(prhs[125])==1 && mxGetN(prhs[125])==1) ) { 
      mexErrMsgTxt("Input 125 must be a noncomplex scalar double.");
    } 
    mexinput125_temp = mxGetPr(prhs[125]); 
    double mexinput125 = *mexinput125_temp; 

    double *mexinput126_temp = NULL; 
    if( !mxIsDouble(prhs[126]) || mxIsComplex(prhs[126]) || !(mxGetM(prhs[126])==1 && mxGetN(prhs[126])==1) ) { 
      mexErrMsgTxt("Input 126 must be a noncomplex scalar double.");
    } 
    mexinput126_temp = mxGetPr(prhs[126]); 
    double mexinput126 = *mexinput126_temp; 

    double *mexinput127_temp = NULL; 
    if( !mxIsDouble(prhs[127]) || mxIsComplex(prhs[127]) || !(mxGetM(prhs[127])==1 && mxGetN(prhs[127])==1) ) { 
      mexErrMsgTxt("Input 127 must be a noncomplex scalar double.");
    } 
    mexinput127_temp = mxGetPr(prhs[127]); 
    double mexinput127 = *mexinput127_temp; 

    double *mexinput128_temp = NULL; 
    if( !mxIsDouble(prhs[128]) || mxIsComplex(prhs[128]) || !(mxGetM(prhs[128])==1 && mxGetN(prhs[128])==1) ) { 
      mexErrMsgTxt("Input 128 must be a noncomplex scalar double.");
    } 
    mexinput128_temp = mxGetPr(prhs[128]); 
    double mexinput128 = *mexinput128_temp; 

    double *mexinput129_temp = NULL; 
    if( !mxIsDouble(prhs[129]) || mxIsComplex(prhs[129]) || !(mxGetM(prhs[129])==1 && mxGetN(prhs[129])==1) ) { 
      mexErrMsgTxt("Input 129 must be a noncomplex scalar double.");
    } 
    mexinput129_temp = mxGetPr(prhs[129]); 
    double mexinput129 = *mexinput129_temp; 

    double *mexinput130_temp = NULL; 
    if( !mxIsDouble(prhs[130]) || mxIsComplex(prhs[130]) || !(mxGetM(prhs[130])==1 && mxGetN(prhs[130])==1) ) { 
      mexErrMsgTxt("Input 130 must be a noncomplex scalar double.");
    } 
    mexinput130_temp = mxGetPr(prhs[130]); 
    double mexinput130 = *mexinput130_temp; 

    double *mexinput131_temp = NULL; 
    if( !mxIsDouble(prhs[131]) || mxIsComplex(prhs[131]) || !(mxGetM(prhs[131])==1 && mxGetN(prhs[131])==1) ) { 
      mexErrMsgTxt("Input 131 must be a noncomplex scalar double.");
    } 
    mexinput131_temp = mxGetPr(prhs[131]); 
    double mexinput131 = *mexinput131_temp; 

    double *mexinput132_temp = NULL; 
    if( !mxIsDouble(prhs[132]) || mxIsComplex(prhs[132]) || !(mxGetM(prhs[132])==1 && mxGetN(prhs[132])==1) ) { 
      mexErrMsgTxt("Input 132 must be a noncomplex scalar double.");
    } 
    mexinput132_temp = mxGetPr(prhs[132]); 
    double mexinput132 = *mexinput132_temp; 

    double *mexinput133_temp = NULL; 
    if( !mxIsDouble(prhs[133]) || mxIsComplex(prhs[133]) || !(mxGetM(prhs[133])==1 && mxGetN(prhs[133])==1) ) { 
      mexErrMsgTxt("Input 133 must be a noncomplex scalar double.");
    } 
    mexinput133_temp = mxGetPr(prhs[133]); 
    double mexinput133 = *mexinput133_temp; 

    double *mexinput134_temp = NULL; 
    if( !mxIsDouble(prhs[134]) || mxIsComplex(prhs[134]) || !(mxGetM(prhs[134])==1 && mxGetN(prhs[134])==1) ) { 
      mexErrMsgTxt("Input 134 must be a noncomplex scalar double.");
    } 
    mexinput134_temp = mxGetPr(prhs[134]); 
    double mexinput134 = *mexinput134_temp; 

    double *mexinput135_temp = NULL; 
    if( !mxIsDouble(prhs[135]) || mxIsComplex(prhs[135]) || !(mxGetM(prhs[135])==1 && mxGetN(prhs[135])==1) ) { 
      mexErrMsgTxt("Input 135 must be a noncomplex scalar double.");
    } 
    mexinput135_temp = mxGetPr(prhs[135]); 
    double mexinput135 = *mexinput135_temp; 

    double *mexinput136_temp = NULL; 
    if( !mxIsDouble(prhs[136]) || mxIsComplex(prhs[136]) || !(mxGetM(prhs[136])==1 && mxGetN(prhs[136])==1) ) { 
      mexErrMsgTxt("Input 136 must be a noncomplex scalar double.");
    } 
    mexinput136_temp = mxGetPr(prhs[136]); 
    double mexinput136 = *mexinput136_temp; 

    double *mexinput137_temp = NULL; 
    if( !mxIsDouble(prhs[137]) || mxIsComplex(prhs[137]) || !(mxGetM(prhs[137])==1 && mxGetN(prhs[137])==1) ) { 
      mexErrMsgTxt("Input 137 must be a noncomplex scalar double.");
    } 
    mexinput137_temp = mxGetPr(prhs[137]); 
    double mexinput137 = *mexinput137_temp; 

    double *mexinput138_temp = NULL; 
    if( !mxIsDouble(prhs[138]) || mxIsComplex(prhs[138]) || !(mxGetM(prhs[138])==1 && mxGetN(prhs[138])==1) ) { 
      mexErrMsgTxt("Input 138 must be a noncomplex scalar double.");
    } 
    mexinput138_temp = mxGetPr(prhs[138]); 
    double mexinput138 = *mexinput138_temp; 

    double *mexinput139_temp = NULL; 
    if( !mxIsDouble(prhs[139]) || mxIsComplex(prhs[139]) || !(mxGetM(prhs[139])==1 && mxGetN(prhs[139])==1) ) { 
      mexErrMsgTxt("Input 139 must be a noncomplex scalar double.");
    } 
    mexinput139_temp = mxGetPr(prhs[139]); 
    double mexinput139 = *mexinput139_temp; 

    double *mexinput140_temp = NULL; 
    if( !mxIsDouble(prhs[140]) || mxIsComplex(prhs[140]) || !(mxGetM(prhs[140])==1 && mxGetN(prhs[140])==1) ) { 
      mexErrMsgTxt("Input 140 must be a noncomplex scalar double.");
    } 
    mexinput140_temp = mxGetPr(prhs[140]); 
    double mexinput140 = *mexinput140_temp; 

    double *mexinput141_temp = NULL; 
    if( !mxIsDouble(prhs[141]) || mxIsComplex(prhs[141]) || !(mxGetM(prhs[141])==1 && mxGetN(prhs[141])==1) ) { 
      mexErrMsgTxt("Input 141 must be a noncomplex scalar double.");
    } 
    mexinput141_temp = mxGetPr(prhs[141]); 
    double mexinput141 = *mexinput141_temp; 

    double *mexinput142_temp = NULL; 
    if( !mxIsDouble(prhs[142]) || mxIsComplex(prhs[142]) || !(mxGetM(prhs[142])==1 && mxGetN(prhs[142])==1) ) { 
      mexErrMsgTxt("Input 142 must be a noncomplex scalar double.");
    } 
    mexinput142_temp = mxGetPr(prhs[142]); 
    double mexinput142 = *mexinput142_temp; 

    double *mexinput143_temp = NULL; 
    if( !mxIsDouble(prhs[143]) || mxIsComplex(prhs[143]) || !(mxGetM(prhs[143])==1 && mxGetN(prhs[143])==1) ) { 
      mexErrMsgTxt("Input 143 must be a noncomplex scalar double.");
    } 
    mexinput143_temp = mxGetPr(prhs[143]); 
    double mexinput143 = *mexinput143_temp; 

    double *mexinput144_temp = NULL; 
    if( !mxIsDouble(prhs[144]) || mxIsComplex(prhs[144]) || !(mxGetM(prhs[144])==1 && mxGetN(prhs[144])==1) ) { 
      mexErrMsgTxt("Input 144 must be a noncomplex scalar double.");
    } 
    mexinput144_temp = mxGetPr(prhs[144]); 
    double mexinput144 = *mexinput144_temp; 

    double *mexinput145_temp = NULL; 
    if( !mxIsDouble(prhs[145]) || mxIsComplex(prhs[145]) || !(mxGetM(prhs[145])==1 && mxGetN(prhs[145])==1) ) { 
      mexErrMsgTxt("Input 145 must be a noncomplex scalar double.");
    } 
    mexinput145_temp = mxGetPr(prhs[145]); 
    double mexinput145 = *mexinput145_temp; 

    double *mexinput146_temp = NULL; 
    if( !mxIsDouble(prhs[146]) || mxIsComplex(prhs[146]) || !(mxGetM(prhs[146])==1 && mxGetN(prhs[146])==1) ) { 
      mexErrMsgTxt("Input 146 must be a noncomplex scalar double.");
    } 
    mexinput146_temp = mxGetPr(prhs[146]); 
    double mexinput146 = *mexinput146_temp; 

    double *mexinput147_temp = NULL; 
    if( !mxIsDouble(prhs[147]) || mxIsComplex(prhs[147]) || !(mxGetM(prhs[147])==1 && mxGetN(prhs[147])==1) ) { 
      mexErrMsgTxt("Input 147 must be a noncomplex scalar double.");
    } 
    mexinput147_temp = mxGetPr(prhs[147]); 
    double mexinput147 = *mexinput147_temp; 

    double *mexinput148_temp = NULL; 
    if( !mxIsDouble(prhs[148]) || mxIsComplex(prhs[148]) || !(mxGetM(prhs[148])==1 && mxGetN(prhs[148])==1) ) { 
      mexErrMsgTxt("Input 148 must be a noncomplex scalar double.");
    } 
    mexinput148_temp = mxGetPr(prhs[148]); 
    double mexinput148 = *mexinput148_temp; 

    double *mexinput149_temp = NULL; 
    if( !mxIsDouble(prhs[149]) || mxIsComplex(prhs[149]) || !(mxGetM(prhs[149])==1 && mxGetN(prhs[149])==1) ) { 
      mexErrMsgTxt("Input 149 must be a noncomplex scalar double.");
    } 
    mexinput149_temp = mxGetPr(prhs[149]); 
    double mexinput149 = *mexinput149_temp; 

    double *mexinput150_temp = NULL; 
    if( !mxIsDouble(prhs[150]) || mxIsComplex(prhs[150]) || !(mxGetM(prhs[150])==1 && mxGetN(prhs[150])==1) ) { 
      mexErrMsgTxt("Input 150 must be a noncomplex scalar double.");
    } 
    mexinput150_temp = mxGetPr(prhs[150]); 
    double mexinput150 = *mexinput150_temp; 

    double *mexinput151_temp = NULL; 
    if( !mxIsDouble(prhs[151]) || mxIsComplex(prhs[151]) || !(mxGetM(prhs[151])==1 && mxGetN(prhs[151])==1) ) { 
      mexErrMsgTxt("Input 151 must be a noncomplex scalar double.");
    } 
    mexinput151_temp = mxGetPr(prhs[151]); 
    double mexinput151 = *mexinput151_temp; 

    double *mexinput152_temp = NULL; 
    if( !mxIsDouble(prhs[152]) || mxIsComplex(prhs[152]) || !(mxGetM(prhs[152])==1 && mxGetN(prhs[152])==1) ) { 
      mexErrMsgTxt("Input 152 must be a noncomplex scalar double.");
    } 
    mexinput152_temp = mxGetPr(prhs[152]); 
    double mexinput152 = *mexinput152_temp; 

    double *mexinput153_temp = NULL; 
    if( !mxIsDouble(prhs[153]) || mxIsComplex(prhs[153]) || !(mxGetM(prhs[153])==1 && mxGetN(prhs[153])==1) ) { 
      mexErrMsgTxt("Input 153 must be a noncomplex scalar double.");
    } 
    mexinput153_temp = mxGetPr(prhs[153]); 
    double mexinput153 = *mexinput153_temp; 

    double *mexinput154_temp = NULL; 
    if( !mxIsDouble(prhs[154]) || mxIsComplex(prhs[154]) || !(mxGetM(prhs[154])==1 && mxGetN(prhs[154])==1) ) { 
      mexErrMsgTxt("Input 154 must be a noncomplex scalar double.");
    } 
    mexinput154_temp = mxGetPr(prhs[154]); 
    double mexinput154 = *mexinput154_temp; 

    double *mexinput155_temp = NULL; 
    if( !mxIsDouble(prhs[155]) || mxIsComplex(prhs[155]) || !(mxGetM(prhs[155])==1 && mxGetN(prhs[155])==1) ) { 
      mexErrMsgTxt("Input 155 must be a noncomplex scalar double.");
    } 
    mexinput155_temp = mxGetPr(prhs[155]); 
    double mexinput155 = *mexinput155_temp; 

    double *mexinput156_temp = NULL; 
    if( !mxIsDouble(prhs[156]) || mxIsComplex(prhs[156]) || !(mxGetM(prhs[156])==1 && mxGetN(prhs[156])==1) ) { 
      mexErrMsgTxt("Input 156 must be a noncomplex scalar double.");
    } 
    mexinput156_temp = mxGetPr(prhs[156]); 
    double mexinput156 = *mexinput156_temp; 

    double *mexinput157_temp = NULL; 
    if( !mxIsDouble(prhs[157]) || mxIsComplex(prhs[157]) || !(mxGetM(prhs[157])==1 && mxGetN(prhs[157])==1) ) { 
      mexErrMsgTxt("Input 157 must be a noncomplex scalar double.");
    } 
    mexinput157_temp = mxGetPr(prhs[157]); 
    double mexinput157 = *mexinput157_temp; 

    double *mexinput158_temp = NULL; 
    if( !mxIsDouble(prhs[158]) || mxIsComplex(prhs[158]) || !(mxGetM(prhs[158])==1 && mxGetN(prhs[158])==1) ) { 
      mexErrMsgTxt("Input 158 must be a noncomplex scalar double.");
    } 
    mexinput158_temp = mxGetPr(prhs[158]); 
    double mexinput158 = *mexinput158_temp; 

    double *mexinput159_temp = NULL; 
    if( !mxIsDouble(prhs[159]) || mxIsComplex(prhs[159]) || !(mxGetM(prhs[159])==1 && mxGetN(prhs[159])==1) ) { 
      mexErrMsgTxt("Input 159 must be a noncomplex scalar double.");
    } 
    mexinput159_temp = mxGetPr(prhs[159]); 
    double mexinput159 = *mexinput159_temp; 

    double *mexinput160_temp = NULL; 
    if( !mxIsDouble(prhs[160]) || mxIsComplex(prhs[160]) || !(mxGetM(prhs[160])==1 && mxGetN(prhs[160])==1) ) { 
      mexErrMsgTxt("Input 160 must be a noncomplex scalar double.");
    } 
    mexinput160_temp = mxGetPr(prhs[160]); 
    double mexinput160 = *mexinput160_temp; 

    double *mexinput161_temp = NULL; 
    if( !mxIsDouble(prhs[161]) || mxIsComplex(prhs[161]) || !(mxGetM(prhs[161])==1 && mxGetN(prhs[161])==1) ) { 
      mexErrMsgTxt("Input 161 must be a noncomplex scalar double.");
    } 
    mexinput161_temp = mxGetPr(prhs[161]); 
    double mexinput161 = *mexinput161_temp; 

    double *mexinput162_temp = NULL; 
    if( !mxIsDouble(prhs[162]) || mxIsComplex(prhs[162]) || !(mxGetM(prhs[162])==1 && mxGetN(prhs[162])==1) ) { 
      mexErrMsgTxt("Input 162 must be a noncomplex scalar double.");
    } 
    mexinput162_temp = mxGetPr(prhs[162]); 
    double mexinput162 = *mexinput162_temp; 

    double *mexinput163_temp = NULL; 
    if( !mxIsDouble(prhs[163]) || mxIsComplex(prhs[163]) || !(mxGetM(prhs[163])==1 && mxGetN(prhs[163])==1) ) { 
      mexErrMsgTxt("Input 163 must be a noncomplex scalar double.");
    } 
    mexinput163_temp = mxGetPr(prhs[163]); 
    double mexinput163 = *mexinput163_temp; 

    double *mexinput164_temp = NULL; 
    if( !mxIsDouble(prhs[164]) || mxIsComplex(prhs[164]) || !(mxGetM(prhs[164])==1 && mxGetN(prhs[164])==1) ) { 
      mexErrMsgTxt("Input 164 must be a noncomplex scalar double.");
    } 
    mexinput164_temp = mxGetPr(prhs[164]); 
    double mexinput164 = *mexinput164_temp; 

    double *mexinput165_temp = NULL; 
    if( !mxIsDouble(prhs[165]) || mxIsComplex(prhs[165]) || !(mxGetM(prhs[165])==1 && mxGetN(prhs[165])==1) ) { 
      mexErrMsgTxt("Input 165 must be a noncomplex scalar double.");
    } 
    mexinput165_temp = mxGetPr(prhs[165]); 
    double mexinput165 = *mexinput165_temp; 

    double *mexinput166_temp = NULL; 
    if( !mxIsDouble(prhs[166]) || mxIsComplex(prhs[166]) || !(mxGetM(prhs[166])==1 && mxGetN(prhs[166])==1) ) { 
      mexErrMsgTxt("Input 166 must be a noncomplex scalar double.");
    } 
    mexinput166_temp = mxGetPr(prhs[166]); 
    double mexinput166 = *mexinput166_temp; 

    double *mexinput167_temp = NULL; 
    if( !mxIsDouble(prhs[167]) || mxIsComplex(prhs[167]) || !(mxGetM(prhs[167])==1 && mxGetN(prhs[167])==1) ) { 
      mexErrMsgTxt("Input 167 must be a noncomplex scalar double.");
    } 
    mexinput167_temp = mxGetPr(prhs[167]); 
    double mexinput167 = *mexinput167_temp; 

    double *mexinput168_temp = NULL; 
    if( !mxIsDouble(prhs[168]) || mxIsComplex(prhs[168]) || !(mxGetM(prhs[168])==1 && mxGetN(prhs[168])==1) ) { 
      mexErrMsgTxt("Input 168 must be a noncomplex scalar double.");
    } 
    mexinput168_temp = mxGetPr(prhs[168]); 
    double mexinput168 = *mexinput168_temp; 

    double *mexinput169_temp = NULL; 
    if( !mxIsDouble(prhs[169]) || mxIsComplex(prhs[169]) || !(mxGetM(prhs[169])==1 && mxGetN(prhs[169])==1) ) { 
      mexErrMsgTxt("Input 169 must be a noncomplex scalar double.");
    } 
    mexinput169_temp = mxGetPr(prhs[169]); 
    double mexinput169 = *mexinput169_temp; 

    double *mexinput170_temp = NULL; 
    if( !mxIsDouble(prhs[170]) || mxIsComplex(prhs[170]) || !(mxGetM(prhs[170])==1 && mxGetN(prhs[170])==1) ) { 
      mexErrMsgTxt("Input 170 must be a noncomplex scalar double.");
    } 
    mexinput170_temp = mxGetPr(prhs[170]); 
    double mexinput170 = *mexinput170_temp; 

    double *mexinput171_temp = NULL; 
    if( !mxIsDouble(prhs[171]) || mxIsComplex(prhs[171]) || !(mxGetM(prhs[171])==1 && mxGetN(prhs[171])==1) ) { 
      mexErrMsgTxt("Input 171 must be a noncomplex scalar double.");
    } 
    mexinput171_temp = mxGetPr(prhs[171]); 
    double mexinput171 = *mexinput171_temp; 

    double *mexinput172_temp = NULL; 
    if( !mxIsDouble(prhs[172]) || mxIsComplex(prhs[172]) || !(mxGetM(prhs[172])==1 && mxGetN(prhs[172])==1) ) { 
      mexErrMsgTxt("Input 172 must be a noncomplex scalar double.");
    } 
    mexinput172_temp = mxGetPr(prhs[172]); 
    double mexinput172 = *mexinput172_temp; 

    double *mexinput173_temp = NULL; 
    if( !mxIsDouble(prhs[173]) || mxIsComplex(prhs[173]) || !(mxGetM(prhs[173])==1 && mxGetN(prhs[173])==1) ) { 
      mexErrMsgTxt("Input 173 must be a noncomplex scalar double.");
    } 
    mexinput173_temp = mxGetPr(prhs[173]); 
    double mexinput173 = *mexinput173_temp; 

    double *mexinput174_temp = NULL; 
    if( !mxIsDouble(prhs[174]) || mxIsComplex(prhs[174]) || !(mxGetM(prhs[174])==1 && mxGetN(prhs[174])==1) ) { 
      mexErrMsgTxt("Input 174 must be a noncomplex scalar double.");
    } 
    mexinput174_temp = mxGetPr(prhs[174]); 
    double mexinput174 = *mexinput174_temp; 

    double *mexinput175_temp = NULL; 
    if( !mxIsDouble(prhs[175]) || mxIsComplex(prhs[175]) || !(mxGetM(prhs[175])==1 && mxGetN(prhs[175])==1) ) { 
      mexErrMsgTxt("Input 175 must be a noncomplex scalar double.");
    } 
    mexinput175_temp = mxGetPr(prhs[175]); 
    double mexinput175 = *mexinput175_temp; 

    double *mexinput176_temp = NULL; 
    if( !mxIsDouble(prhs[176]) || mxIsComplex(prhs[176]) || !(mxGetM(prhs[176])==1 && mxGetN(prhs[176])==1) ) { 
      mexErrMsgTxt("Input 176 must be a noncomplex scalar double.");
    } 
    mexinput176_temp = mxGetPr(prhs[176]); 
    double mexinput176 = *mexinput176_temp; 

    double *mexinput177_temp = NULL; 
    if( !mxIsDouble(prhs[177]) || mxIsComplex(prhs[177]) || !(mxGetM(prhs[177])==1 && mxGetN(prhs[177])==1) ) { 
      mexErrMsgTxt("Input 177 must be a noncomplex scalar double.");
    } 
    mexinput177_temp = mxGetPr(prhs[177]); 
    double mexinput177 = *mexinput177_temp; 

    double *mexinput178_temp = NULL; 
    if( !mxIsDouble(prhs[178]) || mxIsComplex(prhs[178]) || !(mxGetM(prhs[178])==1 && mxGetN(prhs[178])==1) ) { 
      mexErrMsgTxt("Input 178 must be a noncomplex scalar double.");
    } 
    mexinput178_temp = mxGetPr(prhs[178]); 
    double mexinput178 = *mexinput178_temp; 

    double *mexinput179_temp = NULL; 
    if( !mxIsDouble(prhs[179]) || mxIsComplex(prhs[179]) || !(mxGetM(prhs[179])==1 && mxGetN(prhs[179])==1) ) { 
      mexErrMsgTxt("Input 179 must be a noncomplex scalar double.");
    } 
    mexinput179_temp = mxGetPr(prhs[179]); 
    double mexinput179 = *mexinput179_temp; 

    double *mexinput180_temp = NULL; 
    if( !mxIsDouble(prhs[180]) || mxIsComplex(prhs[180]) || !(mxGetM(prhs[180])==1 && mxGetN(prhs[180])==1) ) { 
      mexErrMsgTxt("Input 180 must be a noncomplex scalar double.");
    } 
    mexinput180_temp = mxGetPr(prhs[180]); 
    double mexinput180 = *mexinput180_temp; 

    double *mexinput181_temp = NULL; 
    if( !mxIsDouble(prhs[181]) || mxIsComplex(prhs[181]) || !(mxGetM(prhs[181])==1 && mxGetN(prhs[181])==1) ) { 
      mexErrMsgTxt("Input 181 must be a noncomplex scalar double.");
    } 
    mexinput181_temp = mxGetPr(prhs[181]); 
    double mexinput181 = *mexinput181_temp; 

    double *mexinput182_temp = NULL; 
    if( !mxIsDouble(prhs[182]) || mxIsComplex(prhs[182]) || !(mxGetM(prhs[182])==1 && mxGetN(prhs[182])==1) ) { 
      mexErrMsgTxt("Input 182 must be a noncomplex scalar double.");
    } 
    mexinput182_temp = mxGetPr(prhs[182]); 
    double mexinput182 = *mexinput182_temp; 

    double *mexinput183_temp = NULL; 
    if( !mxIsDouble(prhs[183]) || mxIsComplex(prhs[183]) || !(mxGetM(prhs[183])==1 && mxGetN(prhs[183])==1) ) { 
      mexErrMsgTxt("Input 183 must be a noncomplex scalar double.");
    } 
    mexinput183_temp = mxGetPr(prhs[183]); 
    double mexinput183 = *mexinput183_temp; 

    double *mexinput184_temp = NULL; 
    if( !mxIsDouble(prhs[184]) || mxIsComplex(prhs[184]) || !(mxGetM(prhs[184])==1 && mxGetN(prhs[184])==1) ) { 
      mexErrMsgTxt("Input 184 must be a noncomplex scalar double.");
    } 
    mexinput184_temp = mxGetPr(prhs[184]); 
    double mexinput184 = *mexinput184_temp; 

    double *mexinput185_temp = NULL; 
    if( !mxIsDouble(prhs[185]) || mxIsComplex(prhs[185]) || !(mxGetM(prhs[185])==1 && mxGetN(prhs[185])==1) ) { 
      mexErrMsgTxt("Input 185 must be a noncomplex scalar double.");
    } 
    mexinput185_temp = mxGetPr(prhs[185]); 
    double mexinput185 = *mexinput185_temp; 

    double *mexinput186_temp = NULL; 
    if( !mxIsDouble(prhs[186]) || mxIsComplex(prhs[186]) || !(mxGetM(prhs[186])==1 && mxGetN(prhs[186])==1) ) { 
      mexErrMsgTxt("Input 186 must be a noncomplex scalar double.");
    } 
    mexinput186_temp = mxGetPr(prhs[186]); 
    double mexinput186 = *mexinput186_temp; 

    double *mexinput187_temp = NULL; 
    if( !mxIsDouble(prhs[187]) || mxIsComplex(prhs[187]) || !(mxGetM(prhs[187])==1 && mxGetN(prhs[187])==1) ) { 
      mexErrMsgTxt("Input 187 must be a noncomplex scalar double.");
    } 
    mexinput187_temp = mxGetPr(prhs[187]); 
    double mexinput187 = *mexinput187_temp; 

    double *mexinput188_temp = NULL; 
    if( !mxIsDouble(prhs[188]) || mxIsComplex(prhs[188]) || !(mxGetM(prhs[188])==1 && mxGetN(prhs[188])==1) ) { 
      mexErrMsgTxt("Input 188 must be a noncomplex scalar double.");
    } 
    mexinput188_temp = mxGetPr(prhs[188]); 
    double mexinput188 = *mexinput188_temp; 

    double *mexinput189_temp = NULL; 
    if( !mxIsDouble(prhs[189]) || mxIsComplex(prhs[189]) || !(mxGetM(prhs[189])==1 && mxGetN(prhs[189])==1) ) { 
      mexErrMsgTxt("Input 189 must be a noncomplex scalar double.");
    } 
    mexinput189_temp = mxGetPr(prhs[189]); 
    double mexinput189 = *mexinput189_temp; 

    double *mexinput190_temp = NULL; 
    if( !mxIsDouble(prhs[190]) || mxIsComplex(prhs[190]) || !(mxGetM(prhs[190])==1 && mxGetN(prhs[190])==1) ) { 
      mexErrMsgTxt("Input 190 must be a noncomplex scalar double.");
    } 
    mexinput190_temp = mxGetPr(prhs[190]); 
    double mexinput190 = *mexinput190_temp; 

    double *mexinput191_temp = NULL; 
    if( !mxIsDouble(prhs[191]) || mxIsComplex(prhs[191]) || !(mxGetM(prhs[191])==1 && mxGetN(prhs[191])==1) ) { 
      mexErrMsgTxt("Input 191 must be a noncomplex scalar double.");
    } 
    mexinput191_temp = mxGetPr(prhs[191]); 
    double mexinput191 = *mexinput191_temp; 

    double *mexinput192_temp = NULL; 
    if( !mxIsDouble(prhs[192]) || mxIsComplex(prhs[192]) || !(mxGetM(prhs[192])==1 && mxGetN(prhs[192])==1) ) { 
      mexErrMsgTxt("Input 192 must be a noncomplex scalar double.");
    } 
    mexinput192_temp = mxGetPr(prhs[192]); 
    double mexinput192 = *mexinput192_temp; 

    double *mexinput193_temp = NULL; 
    if( !mxIsDouble(prhs[193]) || mxIsComplex(prhs[193]) || !(mxGetM(prhs[193])==1 && mxGetN(prhs[193])==1) ) { 
      mexErrMsgTxt("Input 193 must be a noncomplex scalar double.");
    } 
    mexinput193_temp = mxGetPr(prhs[193]); 
    double mexinput193 = *mexinput193_temp; 

    double *mexinput194_temp = NULL; 
    if( !mxIsDouble(prhs[194]) || mxIsComplex(prhs[194]) || !(mxGetM(prhs[194])==1 && mxGetN(prhs[194])==1) ) { 
      mexErrMsgTxt("Input 194 must be a noncomplex scalar double.");
    } 
    mexinput194_temp = mxGetPr(prhs[194]); 
    double mexinput194 = *mexinput194_temp; 

    double *mexinput195_temp = NULL; 
    if( !mxIsDouble(prhs[195]) || mxIsComplex(prhs[195]) || !(mxGetM(prhs[195])==1 && mxGetN(prhs[195])==1) ) { 
      mexErrMsgTxt("Input 195 must be a noncomplex scalar double.");
    } 
    mexinput195_temp = mxGetPr(prhs[195]); 
    double mexinput195 = *mexinput195_temp; 

    double *mexinput196_temp = NULL; 
    if( !mxIsDouble(prhs[196]) || mxIsComplex(prhs[196]) || !(mxGetM(prhs[196])==1 && mxGetN(prhs[196])==1) ) { 
      mexErrMsgTxt("Input 196 must be a noncomplex scalar double.");
    } 
    mexinput196_temp = mxGetPr(prhs[196]); 
    double mexinput196 = *mexinput196_temp; 

    double *mexinput197_temp = NULL; 
    if( !mxIsDouble(prhs[197]) || mxIsComplex(prhs[197]) || !(mxGetM(prhs[197])==1 && mxGetN(prhs[197])==1) ) { 
      mexErrMsgTxt("Input 197 must be a noncomplex scalar double.");
    } 
    mexinput197_temp = mxGetPr(prhs[197]); 
    double mexinput197 = *mexinput197_temp; 

    double *mexinput198_temp = NULL; 
    if( !mxIsDouble(prhs[198]) || mxIsComplex(prhs[198]) || !(mxGetM(prhs[198])==1 && mxGetN(prhs[198])==1) ) { 
      mexErrMsgTxt("Input 198 must be a noncomplex scalar double.");
    } 
    mexinput198_temp = mxGetPr(prhs[198]); 
    double mexinput198 = *mexinput198_temp; 

    double *mexinput199_temp = NULL; 
    if( !mxIsDouble(prhs[199]) || mxIsComplex(prhs[199]) || !(mxGetM(prhs[199])==1 && mxGetN(prhs[199])==1) ) { 
      mexErrMsgTxt("Input 199 must be a noncomplex scalar double.");
    } 
    mexinput199_temp = mxGetPr(prhs[199]); 
    double mexinput199 = *mexinput199_temp; 

    double *mexinput200_temp = NULL; 
    if( !mxIsDouble(prhs[200]) || mxIsComplex(prhs[200]) || !(mxGetM(prhs[200])==1 && mxGetN(prhs[200])==1) ) { 
      mexErrMsgTxt("Input 200 must be a noncomplex scalar double.");
    } 
    mexinput200_temp = mxGetPr(prhs[200]); 
    double mexinput200 = *mexinput200_temp; 

    double *mexinput201_temp = NULL; 
    if( !mxIsDouble(prhs[201]) || mxIsComplex(prhs[201]) || !(mxGetM(prhs[201])==1 && mxGetN(prhs[201])==1) ) { 
      mexErrMsgTxt("Input 201 must be a noncomplex scalar double.");
    } 
    mexinput201_temp = mxGetPr(prhs[201]); 
    double mexinput201 = *mexinput201_temp; 

    double *mexinput202_temp = NULL; 
    if( !mxIsDouble(prhs[202]) || mxIsComplex(prhs[202]) || !(mxGetM(prhs[202])==1 && mxGetN(prhs[202])==1) ) { 
      mexErrMsgTxt("Input 202 must be a noncomplex scalar double.");
    } 
    mexinput202_temp = mxGetPr(prhs[202]); 
    double mexinput202 = *mexinput202_temp; 

    double *mexinput203_temp = NULL; 
    if( !mxIsDouble(prhs[203]) || mxIsComplex(prhs[203]) || !(mxGetM(prhs[203])==1 && mxGetN(prhs[203])==1) ) { 
      mexErrMsgTxt("Input 203 must be a noncomplex scalar double.");
    } 
    mexinput203_temp = mxGetPr(prhs[203]); 
    double mexinput203 = *mexinput203_temp; 

    double *mexinput204_temp = NULL; 
    if( !mxIsDouble(prhs[204]) || mxIsComplex(prhs[204]) || !(mxGetM(prhs[204])==1 && mxGetN(prhs[204])==1) ) { 
      mexErrMsgTxt("Input 204 must be a noncomplex scalar double.");
    } 
    mexinput204_temp = mxGetPr(prhs[204]); 
    double mexinput204 = *mexinput204_temp; 

    double *mexinput205_temp = NULL; 
    if( !mxIsDouble(prhs[205]) || mxIsComplex(prhs[205]) || !(mxGetM(prhs[205])==1 && mxGetN(prhs[205])==1) ) { 
      mexErrMsgTxt("Input 205 must be a noncomplex scalar double.");
    } 
    mexinput205_temp = mxGetPr(prhs[205]); 
    double mexinput205 = *mexinput205_temp; 

    double *mexinput206_temp = NULL; 
    if( !mxIsDouble(prhs[206]) || mxIsComplex(prhs[206]) || !(mxGetM(prhs[206])==1 && mxGetN(prhs[206])==1) ) { 
      mexErrMsgTxt("Input 206 must be a noncomplex scalar double.");
    } 
    mexinput206_temp = mxGetPr(prhs[206]); 
    double mexinput206 = *mexinput206_temp; 

    double *mexinput207_temp = NULL; 
    if( !mxIsDouble(prhs[207]) || mxIsComplex(prhs[207]) || !(mxGetM(prhs[207])==1 && mxGetN(prhs[207])==1) ) { 
      mexErrMsgTxt("Input 207 must be a noncomplex scalar double.");
    } 
    mexinput207_temp = mxGetPr(prhs[207]); 
    double mexinput207 = *mexinput207_temp; 

    double *mexinput208_temp = NULL; 
    if( !mxIsDouble(prhs[208]) || mxIsComplex(prhs[208]) || !(mxGetM(prhs[208])==1 && mxGetN(prhs[208])==1) ) { 
      mexErrMsgTxt("Input 208 must be a noncomplex scalar double.");
    } 
    mexinput208_temp = mxGetPr(prhs[208]); 
    double mexinput208 = *mexinput208_temp; 

    double *mexinput209_temp = NULL; 
    if( !mxIsDouble(prhs[209]) || mxIsComplex(prhs[209]) || !(mxGetM(prhs[209])==1 && mxGetN(prhs[209])==1) ) { 
      mexErrMsgTxt("Input 209 must be a noncomplex scalar double.");
    } 
    mexinput209_temp = mxGetPr(prhs[209]); 
    double mexinput209 = *mexinput209_temp; 

    double *mexinput210_temp = NULL; 
    if( !mxIsDouble(prhs[210]) || mxIsComplex(prhs[210]) || !(mxGetM(prhs[210])==1 && mxGetN(prhs[210])==1) ) { 
      mexErrMsgTxt("Input 210 must be a noncomplex scalar double.");
    } 
    mexinput210_temp = mxGetPr(prhs[210]); 
    double mexinput210 = *mexinput210_temp; 

    double *mexinput211_temp = NULL; 
    if( !mxIsDouble(prhs[211]) || mxIsComplex(prhs[211]) || !(mxGetM(prhs[211])==1 && mxGetN(prhs[211])==1) ) { 
      mexErrMsgTxt("Input 211 must be a noncomplex scalar double.");
    } 
    mexinput211_temp = mxGetPr(prhs[211]); 
    double mexinput211 = *mexinput211_temp; 

    double *mexinput212_temp = NULL; 
    if( !mxIsDouble(prhs[212]) || mxIsComplex(prhs[212]) || !(mxGetM(prhs[212])==1 && mxGetN(prhs[212])==1) ) { 
      mexErrMsgTxt("Input 212 must be a noncomplex scalar double.");
    } 
    mexinput212_temp = mxGetPr(prhs[212]); 
    double mexinput212 = *mexinput212_temp; 

    double *mexinput213_temp = NULL; 
    if( !mxIsDouble(prhs[213]) || mxIsComplex(prhs[213]) || !(mxGetM(prhs[213])==1 && mxGetN(prhs[213])==1) ) { 
      mexErrMsgTxt("Input 213 must be a noncomplex scalar double.");
    } 
    mexinput213_temp = mxGetPr(prhs[213]); 
    double mexinput213 = *mexinput213_temp; 

    double *mexinput214_temp = NULL; 
    if( !mxIsDouble(prhs[214]) || mxIsComplex(prhs[214]) || !(mxGetM(prhs[214])==1 && mxGetN(prhs[214])==1) ) { 
      mexErrMsgTxt("Input 214 must be a noncomplex scalar double.");
    } 
    mexinput214_temp = mxGetPr(prhs[214]); 
    double mexinput214 = *mexinput214_temp; 

    double *mexinput215_temp = NULL; 
    if( !mxIsDouble(prhs[215]) || mxIsComplex(prhs[215]) || !(mxGetM(prhs[215])==1 && mxGetN(prhs[215])==1) ) { 
      mexErrMsgTxt("Input 215 must be a noncomplex scalar double.");
    } 
    mexinput215_temp = mxGetPr(prhs[215]); 
    double mexinput215 = *mexinput215_temp; 

    double *mexinput216_temp = NULL; 
    if( !mxIsDouble(prhs[216]) || mxIsComplex(prhs[216]) || !(mxGetM(prhs[216])==1 && mxGetN(prhs[216])==1) ) { 
      mexErrMsgTxt("Input 216 must be a noncomplex scalar double.");
    } 
    mexinput216_temp = mxGetPr(prhs[216]); 
    double mexinput216 = *mexinput216_temp; 

    double *mexinput217_temp = NULL; 
    if( !mxIsDouble(prhs[217]) || mxIsComplex(prhs[217]) || !(mxGetM(prhs[217])==1 && mxGetN(prhs[217])==1) ) { 
      mexErrMsgTxt("Input 217 must be a noncomplex scalar double.");
    } 
    mexinput217_temp = mxGetPr(prhs[217]); 
    double mexinput217 = *mexinput217_temp; 

    double *mexinput218_temp = NULL; 
    if( !mxIsDouble(prhs[218]) || mxIsComplex(prhs[218]) || !(mxGetM(prhs[218])==1 && mxGetN(prhs[218])==1) ) { 
      mexErrMsgTxt("Input 218 must be a noncomplex scalar double.");
    } 
    mexinput218_temp = mxGetPr(prhs[218]); 
    double mexinput218 = *mexinput218_temp; 

    double *mexinput219_temp = NULL; 
    if( !mxIsDouble(prhs[219]) || mxIsComplex(prhs[219]) || !(mxGetM(prhs[219])==1 && mxGetN(prhs[219])==1) ) { 
      mexErrMsgTxt("Input 219 must be a noncomplex scalar double.");
    } 
    mexinput219_temp = mxGetPr(prhs[219]); 
    double mexinput219 = *mexinput219_temp; 

    double *mexinput220_temp = NULL; 
    if( !mxIsDouble(prhs[220]) || mxIsComplex(prhs[220]) || !(mxGetM(prhs[220])==1 && mxGetN(prhs[220])==1) ) { 
      mexErrMsgTxt("Input 220 must be a noncomplex scalar double.");
    } 
    mexinput220_temp = mxGetPr(prhs[220]); 
    double mexinput220 = *mexinput220_temp; 

    double *mexinput221_temp = NULL; 
    if( !mxIsDouble(prhs[221]) || mxIsComplex(prhs[221]) || !(mxGetM(prhs[221])==1 && mxGetN(prhs[221])==1) ) { 
      mexErrMsgTxt("Input 221 must be a noncomplex scalar double.");
    } 
    mexinput221_temp = mxGetPr(prhs[221]); 
    double mexinput221 = *mexinput221_temp; 

    double *mexinput222_temp = NULL; 
    if( !mxIsDouble(prhs[222]) || mxIsComplex(prhs[222]) || !(mxGetM(prhs[222])==1 && mxGetN(prhs[222])==1) ) { 
      mexErrMsgTxt("Input 222 must be a noncomplex scalar double.");
    } 
    mexinput222_temp = mxGetPr(prhs[222]); 
    double mexinput222 = *mexinput222_temp; 

    double *mexinput223_temp = NULL; 
    if( !mxIsDouble(prhs[223]) || mxIsComplex(prhs[223]) || !(mxGetM(prhs[223])==1 && mxGetN(prhs[223])==1) ) { 
      mexErrMsgTxt("Input 223 must be a noncomplex scalar double.");
    } 
    mexinput223_temp = mxGetPr(prhs[223]); 
    double mexinput223 = *mexinput223_temp; 

    double *mexinput224_temp = NULL; 
    if( !mxIsDouble(prhs[224]) || mxIsComplex(prhs[224]) || !(mxGetM(prhs[224])==1 && mxGetN(prhs[224])==1) ) { 
      mexErrMsgTxt("Input 224 must be a noncomplex scalar double.");
    } 
    mexinput224_temp = mxGetPr(prhs[224]); 
    double mexinput224 = *mexinput224_temp; 

    double *mexinput225_temp = NULL; 
    if( !mxIsDouble(prhs[225]) || mxIsComplex(prhs[225]) || !(mxGetM(prhs[225])==1 && mxGetN(prhs[225])==1) ) { 
      mexErrMsgTxt("Input 225 must be a noncomplex scalar double.");
    } 
    mexinput225_temp = mxGetPr(prhs[225]); 
    double mexinput225 = *mexinput225_temp; 

    double *mexinput226_temp = NULL; 
    if( !mxIsDouble(prhs[226]) || mxIsComplex(prhs[226]) || !(mxGetM(prhs[226])==1 && mxGetN(prhs[226])==1) ) { 
      mexErrMsgTxt("Input 226 must be a noncomplex scalar double.");
    } 
    mexinput226_temp = mxGetPr(prhs[226]); 
    double mexinput226 = *mexinput226_temp; 

    double *mexinput227_temp = NULL; 
    if( !mxIsDouble(prhs[227]) || mxIsComplex(prhs[227]) || !(mxGetM(prhs[227])==1 && mxGetN(prhs[227])==1) ) { 
      mexErrMsgTxt("Input 227 must be a noncomplex scalar double.");
    } 
    mexinput227_temp = mxGetPr(prhs[227]); 
    double mexinput227 = *mexinput227_temp; 

    double *mexinput228_temp = NULL; 
    if( !mxIsDouble(prhs[228]) || mxIsComplex(prhs[228]) || !(mxGetM(prhs[228])==1 && mxGetN(prhs[228])==1) ) { 
      mexErrMsgTxt("Input 228 must be a noncomplex scalar double.");
    } 
    mexinput228_temp = mxGetPr(prhs[228]); 
    double mexinput228 = *mexinput228_temp; 

    double *mexinput229_temp = NULL; 
    if( !mxIsDouble(prhs[229]) || mxIsComplex(prhs[229]) || !(mxGetM(prhs[229])==1 && mxGetN(prhs[229])==1) ) { 
      mexErrMsgTxt("Input 229 must be a noncomplex scalar double.");
    } 
    mexinput229_temp = mxGetPr(prhs[229]); 
    double mexinput229 = *mexinput229_temp; 

    double *mexinput230_temp = NULL; 
    if( !mxIsDouble(prhs[230]) || mxIsComplex(prhs[230]) || !(mxGetM(prhs[230])==1 && mxGetN(prhs[230])==1) ) { 
      mexErrMsgTxt("Input 230 must be a noncomplex scalar double.");
    } 
    mexinput230_temp = mxGetPr(prhs[230]); 
    double mexinput230 = *mexinput230_temp; 

    double *mexinput231_temp = NULL; 
    if( !mxIsDouble(prhs[231]) || mxIsComplex(prhs[231]) || !(mxGetM(prhs[231])==1 && mxGetN(prhs[231])==1) ) { 
      mexErrMsgTxt("Input 231 must be a noncomplex scalar double.");
    } 
    mexinput231_temp = mxGetPr(prhs[231]); 
    double mexinput231 = *mexinput231_temp; 

    double *mexinput232_temp = NULL; 
    if( !mxIsDouble(prhs[232]) || mxIsComplex(prhs[232]) || !(mxGetM(prhs[232])==1 && mxGetN(prhs[232])==1) ) { 
      mexErrMsgTxt("Input 232 must be a noncomplex scalar double.");
    } 
    mexinput232_temp = mxGetPr(prhs[232]); 
    double mexinput232 = *mexinput232_temp; 

    double *mexinput233_temp = NULL; 
    if( !mxIsDouble(prhs[233]) || mxIsComplex(prhs[233]) || !(mxGetM(prhs[233])==1 && mxGetN(prhs[233])==1) ) { 
      mexErrMsgTxt("Input 233 must be a noncomplex scalar double.");
    } 
    mexinput233_temp = mxGetPr(prhs[233]); 
    double mexinput233 = *mexinput233_temp; 

    double *mexinput234_temp = NULL; 
    if( !mxIsDouble(prhs[234]) || mxIsComplex(prhs[234]) || !(mxGetM(prhs[234])==1 && mxGetN(prhs[234])==1) ) { 
      mexErrMsgTxt("Input 234 must be a noncomplex scalar double.");
    } 
    mexinput234_temp = mxGetPr(prhs[234]); 
    double mexinput234 = *mexinput234_temp; 

    double *mexinput235_temp = NULL; 
    if( !mxIsDouble(prhs[235]) || mxIsComplex(prhs[235]) || !(mxGetM(prhs[235])==1 && mxGetN(prhs[235])==1) ) { 
      mexErrMsgTxt("Input 235 must be a noncomplex scalar double.");
    } 
    mexinput235_temp = mxGetPr(prhs[235]); 
    double mexinput235 = *mexinput235_temp; 

    double *mexinput236_temp = NULL; 
    if( !mxIsDouble(prhs[236]) || mxIsComplex(prhs[236]) || !(mxGetM(prhs[236])==1 && mxGetN(prhs[236])==1) ) { 
      mexErrMsgTxt("Input 236 must be a noncomplex scalar double.");
    } 
    mexinput236_temp = mxGetPr(prhs[236]); 
    double mexinput236 = *mexinput236_temp; 

    double *mexinput237_temp = NULL; 
    if( !mxIsDouble(prhs[237]) || mxIsComplex(prhs[237]) || !(mxGetM(prhs[237])==1 && mxGetN(prhs[237])==1) ) { 
      mexErrMsgTxt("Input 237 must be a noncomplex scalar double.");
    } 
    mexinput237_temp = mxGetPr(prhs[237]); 
    double mexinput237 = *mexinput237_temp; 

    double *mexinput238_temp = NULL; 
    if( !mxIsDouble(prhs[238]) || mxIsComplex(prhs[238]) || !(mxGetM(prhs[238])==1 && mxGetN(prhs[238])==1) ) { 
      mexErrMsgTxt("Input 238 must be a noncomplex scalar double.");
    } 
    mexinput238_temp = mxGetPr(prhs[238]); 
    double mexinput238 = *mexinput238_temp; 

    double *mexinput239_temp = NULL; 
    if( !mxIsDouble(prhs[239]) || mxIsComplex(prhs[239]) || !(mxGetM(prhs[239])==1 && mxGetN(prhs[239])==1) ) { 
      mexErrMsgTxt("Input 239 must be a noncomplex scalar double.");
    } 
    mexinput239_temp = mxGetPr(prhs[239]); 
    double mexinput239 = *mexinput239_temp; 

    double *mexinput240_temp = NULL; 
    if( !mxIsDouble(prhs[240]) || mxIsComplex(prhs[240]) || !(mxGetM(prhs[240])==1 && mxGetN(prhs[240])==1) ) { 
      mexErrMsgTxt("Input 240 must be a noncomplex scalar double.");
    } 
    mexinput240_temp = mxGetPr(prhs[240]); 
    double mexinput240 = *mexinput240_temp; 

    double *mexinput241_temp = NULL; 
    if( !mxIsDouble(prhs[241]) || mxIsComplex(prhs[241]) || !(mxGetM(prhs[241])==1 && mxGetN(prhs[241])==1) ) { 
      mexErrMsgTxt("Input 241 must be a noncomplex scalar double.");
    } 
    mexinput241_temp = mxGetPr(prhs[241]); 
    double mexinput241 = *mexinput241_temp; 

    double *mexinput242_temp = NULL; 
    if( !mxIsDouble(prhs[242]) || mxIsComplex(prhs[242]) || !(mxGetM(prhs[242])==1 && mxGetN(prhs[242])==1) ) { 
      mexErrMsgTxt("Input 242 must be a noncomplex scalar double.");
    } 
    mexinput242_temp = mxGetPr(prhs[242]); 
    double mexinput242 = *mexinput242_temp; 

    double *mexinput243_temp = NULL; 
    if( !mxIsDouble(prhs[243]) || mxIsComplex(prhs[243]) || !(mxGetM(prhs[243])==1 && mxGetN(prhs[243])==1) ) { 
      mexErrMsgTxt("Input 243 must be a noncomplex scalar double.");
    } 
    mexinput243_temp = mxGetPr(prhs[243]); 
    double mexinput243 = *mexinput243_temp; 

    double *mexinput244_temp = NULL; 
    if( !mxIsDouble(prhs[244]) || mxIsComplex(prhs[244]) || !(mxGetM(prhs[244])==1 && mxGetN(prhs[244])==1) ) { 
      mexErrMsgTxt("Input 244 must be a noncomplex scalar double.");
    } 
    mexinput244_temp = mxGetPr(prhs[244]); 
    double mexinput244 = *mexinput244_temp; 

    double *mexinput245_temp = NULL; 
    if( !mxIsDouble(prhs[245]) || mxIsComplex(prhs[245]) || !(mxGetM(prhs[245])==1 && mxGetN(prhs[245])==1) ) { 
      mexErrMsgTxt("Input 245 must be a noncomplex scalar double.");
    } 
    mexinput245_temp = mxGetPr(prhs[245]); 
    double mexinput245 = *mexinput245_temp; 

    double *mexinput246_temp = NULL; 
    if( !mxIsDouble(prhs[246]) || mxIsComplex(prhs[246]) || !(mxGetM(prhs[246])==1 && mxGetN(prhs[246])==1) ) { 
      mexErrMsgTxt("Input 246 must be a noncomplex scalar double.");
    } 
    mexinput246_temp = mxGetPr(prhs[246]); 
    double mexinput246 = *mexinput246_temp; 

    double *mexinput247_temp = NULL; 
    if( !mxIsDouble(prhs[247]) || mxIsComplex(prhs[247]) || !(mxGetM(prhs[247])==1 && mxGetN(prhs[247])==1) ) { 
      mexErrMsgTxt("Input 247 must be a noncomplex scalar double.");
    } 
    mexinput247_temp = mxGetPr(prhs[247]); 
    double mexinput247 = *mexinput247_temp; 

    double *mexinput248_temp = NULL; 
    if( !mxIsDouble(prhs[248]) || mxIsComplex(prhs[248]) || !(mxGetM(prhs[248])==1 && mxGetN(prhs[248])==1) ) { 
      mexErrMsgTxt("Input 248 must be a noncomplex scalar double.");
    } 
    mexinput248_temp = mxGetPr(prhs[248]); 
    double mexinput248 = *mexinput248_temp; 

    double *mexinput249_temp = NULL; 
    if( !mxIsDouble(prhs[249]) || mxIsComplex(prhs[249]) || !(mxGetM(prhs[249])==1 && mxGetN(prhs[249])==1) ) { 
      mexErrMsgTxt("Input 249 must be a noncomplex scalar double.");
    } 
    mexinput249_temp = mxGetPr(prhs[249]); 
    double mexinput249 = *mexinput249_temp; 

    double *mexinput250_temp = NULL; 
    if( !mxIsDouble(prhs[250]) || mxIsComplex(prhs[250]) || !(mxGetM(prhs[250])==1 && mxGetN(prhs[250])==1) ) { 
      mexErrMsgTxt("Input 250 must be a noncomplex scalar double.");
    } 
    mexinput250_temp = mxGetPr(prhs[250]); 
    double mexinput250 = *mexinput250_temp; 

    double *mexinput251_temp = NULL; 
    if( !mxIsDouble(prhs[251]) || mxIsComplex(prhs[251]) || !(mxGetM(prhs[251])==1 && mxGetN(prhs[251])==1) ) { 
      mexErrMsgTxt("Input 251 must be a noncomplex scalar double.");
    } 
    mexinput251_temp = mxGetPr(prhs[251]); 
    double mexinput251 = *mexinput251_temp; 

    double *mexinput252_temp = NULL; 
    if( !mxIsDouble(prhs[252]) || mxIsComplex(prhs[252]) || !(mxGetM(prhs[252])==1 && mxGetN(prhs[252])==1) ) { 
      mexErrMsgTxt("Input 252 must be a noncomplex scalar double.");
    } 
    mexinput252_temp = mxGetPr(prhs[252]); 
    double mexinput252 = *mexinput252_temp; 

    double *mexinput253_temp = NULL; 
    if( !mxIsDouble(prhs[253]) || mxIsComplex(prhs[253]) || !(mxGetM(prhs[253])==1 && mxGetN(prhs[253])==1) ) { 
      mexErrMsgTxt("Input 253 must be a noncomplex scalar double.");
    } 
    mexinput253_temp = mxGetPr(prhs[253]); 
    double mexinput253 = *mexinput253_temp; 

    double *mexinput254_temp = NULL; 
    if( !mxIsDouble(prhs[254]) || mxIsComplex(prhs[254]) || !(mxGetM(prhs[254])==1 && mxGetN(prhs[254])==1) ) { 
      mexErrMsgTxt("Input 254 must be a noncomplex scalar double.");
    } 
    mexinput254_temp = mxGetPr(prhs[254]); 
    double mexinput254 = *mexinput254_temp; 

    double *mexinput255_temp = NULL; 
    if( !mxIsDouble(prhs[255]) || mxIsComplex(prhs[255]) || !(mxGetM(prhs[255])==1 && mxGetN(prhs[255])==1) ) { 
      mexErrMsgTxt("Input 255 must be a noncomplex scalar double.");
    } 
    mexinput255_temp = mxGetPr(prhs[255]); 
    double mexinput255 = *mexinput255_temp; 

    double *mexinput256_temp = NULL; 
    if( !mxIsDouble(prhs[256]) || mxIsComplex(prhs[256]) || !(mxGetM(prhs[256])==1 && mxGetN(prhs[256])==1) ) { 
      mexErrMsgTxt("Input 256 must be a noncomplex scalar double.");
    } 
    mexinput256_temp = mxGetPr(prhs[256]); 
    double mexinput256 = *mexinput256_temp; 

    double *mexinput257_temp = NULL; 
    if( !mxIsDouble(prhs[257]) || mxIsComplex(prhs[257]) || !(mxGetM(prhs[257])==1 && mxGetN(prhs[257])==1) ) { 
      mexErrMsgTxt("Input 257 must be a noncomplex scalar double.");
    } 
    mexinput257_temp = mxGetPr(prhs[257]); 
    double mexinput257 = *mexinput257_temp; 

    double *mexinput258_temp = NULL; 
    if( !mxIsDouble(prhs[258]) || mxIsComplex(prhs[258]) || !(mxGetM(prhs[258])==1 && mxGetN(prhs[258])==1) ) { 
      mexErrMsgTxt("Input 258 must be a noncomplex scalar double.");
    } 
    mexinput258_temp = mxGetPr(prhs[258]); 
    double mexinput258 = *mexinput258_temp; 

    double *mexinput259_temp = NULL; 
    if( !mxIsDouble(prhs[259]) || mxIsComplex(prhs[259]) || !(mxGetM(prhs[259])==1 && mxGetN(prhs[259])==1) ) { 
      mexErrMsgTxt("Input 259 must be a noncomplex scalar double.");
    } 
    mexinput259_temp = mxGetPr(prhs[259]); 
    double mexinput259 = *mexinput259_temp; 

    double *mexinput260_temp = NULL; 
    if( !mxIsDouble(prhs[260]) || mxIsComplex(prhs[260]) || !(mxGetM(prhs[260])==1 && mxGetN(prhs[260])==1) ) { 
      mexErrMsgTxt("Input 260 must be a noncomplex scalar double.");
    } 
    mexinput260_temp = mxGetPr(prhs[260]); 
    double mexinput260 = *mexinput260_temp; 

    double *mexinput261_temp = NULL; 
    if( !mxIsDouble(prhs[261]) || mxIsComplex(prhs[261]) || !(mxGetM(prhs[261])==1 && mxGetN(prhs[261])==1) ) { 
      mexErrMsgTxt("Input 261 must be a noncomplex scalar double.");
    } 
    mexinput261_temp = mxGetPr(prhs[261]); 
    double mexinput261 = *mexinput261_temp; 

    double *mexinput262_temp = NULL; 
    if( !mxIsDouble(prhs[262]) || mxIsComplex(prhs[262]) || !(mxGetM(prhs[262])==1 && mxGetN(prhs[262])==1) ) { 
      mexErrMsgTxt("Input 262 must be a noncomplex scalar double.");
    } 
    mexinput262_temp = mxGetPr(prhs[262]); 
    double mexinput262 = *mexinput262_temp; 

    double *mexinput263_temp = NULL; 
    if( !mxIsDouble(prhs[263]) || mxIsComplex(prhs[263]) || !(mxGetM(prhs[263])==1 && mxGetN(prhs[263])==1) ) { 
      mexErrMsgTxt("Input 263 must be a noncomplex scalar double.");
    } 
    mexinput263_temp = mxGetPr(prhs[263]); 
    double mexinput263 = *mexinput263_temp; 

    double *mexinput264_temp = NULL; 
    if( !mxIsDouble(prhs[264]) || mxIsComplex(prhs[264]) || !(mxGetM(prhs[264])==1 && mxGetN(prhs[264])==1) ) { 
      mexErrMsgTxt("Input 264 must be a noncomplex scalar double.");
    } 
    mexinput264_temp = mxGetPr(prhs[264]); 
    double mexinput264 = *mexinput264_temp; 

    double *mexinput265_temp = NULL; 
    if( !mxIsDouble(prhs[265]) || mxIsComplex(prhs[265]) || !(mxGetM(prhs[265])==1 && mxGetN(prhs[265])==1) ) { 
      mexErrMsgTxt("Input 265 must be a noncomplex scalar double.");
    } 
    mexinput265_temp = mxGetPr(prhs[265]); 
    double mexinput265 = *mexinput265_temp; 

    double *mexinput266_temp = NULL; 
    if( !mxIsDouble(prhs[266]) || mxIsComplex(prhs[266]) || !(mxGetM(prhs[266])==1 && mxGetN(prhs[266])==1) ) { 
      mexErrMsgTxt("Input 266 must be a noncomplex scalar double.");
    } 
    mexinput266_temp = mxGetPr(prhs[266]); 
    double mexinput266 = *mexinput266_temp; 

    double *mexinput267_temp = NULL; 
    if( !mxIsDouble(prhs[267]) || mxIsComplex(prhs[267]) || !(mxGetM(prhs[267])==1 && mxGetN(prhs[267])==1) ) { 
      mexErrMsgTxt("Input 267 must be a noncomplex scalar double.");
    } 
    mexinput267_temp = mxGetPr(prhs[267]); 
    double mexinput267 = *mexinput267_temp; 

    double *mexinput268_temp = NULL; 
    if( !mxIsDouble(prhs[268]) || mxIsComplex(prhs[268]) || !(mxGetM(prhs[268])==1 && mxGetN(prhs[268])==1) ) { 
      mexErrMsgTxt("Input 268 must be a noncomplex scalar double.");
    } 
    mexinput268_temp = mxGetPr(prhs[268]); 
    double mexinput268 = *mexinput268_temp; 

    double *mexinput269_temp = NULL; 
    if( !mxIsDouble(prhs[269]) || mxIsComplex(prhs[269]) || !(mxGetM(prhs[269])==1 && mxGetN(prhs[269])==1) ) { 
      mexErrMsgTxt("Input 269 must be a noncomplex scalar double.");
    } 
    mexinput269_temp = mxGetPr(prhs[269]); 
    double mexinput269 = *mexinput269_temp; 

    double *mexinput270_temp = NULL; 
    if( !mxIsDouble(prhs[270]) || mxIsComplex(prhs[270]) || !(mxGetM(prhs[270])==1 && mxGetN(prhs[270])==1) ) { 
      mexErrMsgTxt("Input 270 must be a noncomplex scalar double.");
    } 
    mexinput270_temp = mxGetPr(prhs[270]); 
    double mexinput270 = *mexinput270_temp; 

    double *mexinput271_temp = NULL; 
    if( !mxIsDouble(prhs[271]) || mxIsComplex(prhs[271]) || !(mxGetM(prhs[271])==1 && mxGetN(prhs[271])==1) ) { 
      mexErrMsgTxt("Input 271 must be a noncomplex scalar double.");
    } 
    mexinput271_temp = mxGetPr(prhs[271]); 
    double mexinput271 = *mexinput271_temp; 

    double *mexinput272_temp = NULL; 
    if( !mxIsDouble(prhs[272]) || mxIsComplex(prhs[272]) || !(mxGetM(prhs[272])==1 && mxGetN(prhs[272])==1) ) { 
      mexErrMsgTxt("Input 272 must be a noncomplex scalar double.");
    } 
    mexinput272_temp = mxGetPr(prhs[272]); 
    double mexinput272 = *mexinput272_temp; 

    double *mexinput273_temp = NULL; 
    if( !mxIsDouble(prhs[273]) || mxIsComplex(prhs[273]) || !(mxGetM(prhs[273])==1 && mxGetN(prhs[273])==1) ) { 
      mexErrMsgTxt("Input 273 must be a noncomplex scalar double.");
    } 
    mexinput273_temp = mxGetPr(prhs[273]); 
    double mexinput273 = *mexinput273_temp; 

    double *mexinput274_temp = NULL; 
    if( !mxIsDouble(prhs[274]) || mxIsComplex(prhs[274]) || !(mxGetM(prhs[274])==1 && mxGetN(prhs[274])==1) ) { 
      mexErrMsgTxt("Input 274 must be a noncomplex scalar double.");
    } 
    mexinput274_temp = mxGetPr(prhs[274]); 
    double mexinput274 = *mexinput274_temp; 

    double *mexinput275_temp = NULL; 
    if( !mxIsDouble(prhs[275]) || mxIsComplex(prhs[275]) || !(mxGetM(prhs[275])==1 && mxGetN(prhs[275])==1) ) { 
      mexErrMsgTxt("Input 275 must be a noncomplex scalar double.");
    } 
    mexinput275_temp = mxGetPr(prhs[275]); 
    double mexinput275 = *mexinput275_temp; 

    double *mexinput276_temp = NULL; 
    if( !mxIsDouble(prhs[276]) || mxIsComplex(prhs[276]) || !(mxGetM(prhs[276])==1 && mxGetN(prhs[276])==1) ) { 
      mexErrMsgTxt("Input 276 must be a noncomplex scalar double.");
    } 
    mexinput276_temp = mxGetPr(prhs[276]); 
    double mexinput276 = *mexinput276_temp; 

    double *mexinput277_temp = NULL; 
    if( !mxIsDouble(prhs[277]) || mxIsComplex(prhs[277]) || !(mxGetM(prhs[277])==1 && mxGetN(prhs[277])==1) ) { 
      mexErrMsgTxt("Input 277 must be a noncomplex scalar double.");
    } 
    mexinput277_temp = mxGetPr(prhs[277]); 
    double mexinput277 = *mexinput277_temp; 

    double *mexinput278_temp = NULL; 
    if( !mxIsDouble(prhs[278]) || mxIsComplex(prhs[278]) || !(mxGetM(prhs[278])==1 && mxGetN(prhs[278])==1) ) { 
      mexErrMsgTxt("Input 278 must be a noncomplex scalar double.");
    } 
    mexinput278_temp = mxGetPr(prhs[278]); 
    double mexinput278 = *mexinput278_temp; 

    double *mexinput279_temp = NULL; 
    if( !mxIsDouble(prhs[279]) || mxIsComplex(prhs[279]) || !(mxGetM(prhs[279])==1 && mxGetN(prhs[279])==1) ) { 
      mexErrMsgTxt("Input 279 must be a noncomplex scalar double.");
    } 
    mexinput279_temp = mxGetPr(prhs[279]); 
    double mexinput279 = *mexinput279_temp; 

    double *mexinput280_temp = NULL; 
    if( !mxIsDouble(prhs[280]) || mxIsComplex(prhs[280]) || !(mxGetM(prhs[280])==1 && mxGetN(prhs[280])==1) ) { 
      mexErrMsgTxt("Input 280 must be a noncomplex scalar double.");
    } 
    mexinput280_temp = mxGetPr(prhs[280]); 
    double mexinput280 = *mexinput280_temp; 

    double *mexinput281_temp = NULL; 
    if( !mxIsDouble(prhs[281]) || mxIsComplex(prhs[281]) || !(mxGetM(prhs[281])==1 && mxGetN(prhs[281])==1) ) { 
      mexErrMsgTxt("Input 281 must be a noncomplex scalar double.");
    } 
    mexinput281_temp = mxGetPr(prhs[281]); 
    double mexinput281 = *mexinput281_temp; 

    double *mexinput282_temp = NULL; 
    if( !mxIsDouble(prhs[282]) || mxIsComplex(prhs[282]) || !(mxGetM(prhs[282])==1 && mxGetN(prhs[282])==1) ) { 
      mexErrMsgTxt("Input 282 must be a noncomplex scalar double.");
    } 
    mexinput282_temp = mxGetPr(prhs[282]); 
    double mexinput282 = *mexinput282_temp; 

    double *mexinput283_temp = NULL; 
    if( !mxIsDouble(prhs[283]) || mxIsComplex(prhs[283]) || !(mxGetM(prhs[283])==1 && mxGetN(prhs[283])==1) ) { 
      mexErrMsgTxt("Input 283 must be a noncomplex scalar double.");
    } 
    mexinput283_temp = mxGetPr(prhs[283]); 
    double mexinput283 = *mexinput283_temp; 

    double *mexinput284_temp = NULL; 
    if( !mxIsDouble(prhs[284]) || mxIsComplex(prhs[284]) || !(mxGetM(prhs[284])==1 && mxGetN(prhs[284])==1) ) { 
      mexErrMsgTxt("Input 284 must be a noncomplex scalar double.");
    } 
    mexinput284_temp = mxGetPr(prhs[284]); 
    double mexinput284 = *mexinput284_temp; 

    double *mexinput285_temp = NULL; 
    if( !mxIsDouble(prhs[285]) || mxIsComplex(prhs[285]) || !(mxGetM(prhs[285])==1 && mxGetN(prhs[285])==1) ) { 
      mexErrMsgTxt("Input 285 must be a noncomplex scalar double.");
    } 
    mexinput285_temp = mxGetPr(prhs[285]); 
    double mexinput285 = *mexinput285_temp; 

    double *mexinput286_temp = NULL; 
    if( !mxIsDouble(prhs[286]) || mxIsComplex(prhs[286]) || !(mxGetM(prhs[286])==1 && mxGetN(prhs[286])==1) ) { 
      mexErrMsgTxt("Input 286 must be a noncomplex scalar double.");
    } 
    mexinput286_temp = mxGetPr(prhs[286]); 
    double mexinput286 = *mexinput286_temp; 

    double *mexinput287_temp = NULL; 
    if( !mxIsDouble(prhs[287]) || mxIsComplex(prhs[287]) || !(mxGetM(prhs[287])==1 && mxGetN(prhs[287])==1) ) { 
      mexErrMsgTxt("Input 287 must be a noncomplex scalar double.");
    } 
    mexinput287_temp = mxGetPr(prhs[287]); 
    double mexinput287 = *mexinput287_temp; 

    double *mexinput288_temp = NULL; 
    if( !mxIsDouble(prhs[288]) || mxIsComplex(prhs[288]) || !(mxGetM(prhs[288])==1 && mxGetN(prhs[288])==1) ) { 
      mexErrMsgTxt("Input 288 must be a noncomplex scalar double.");
    } 
    mexinput288_temp = mxGetPr(prhs[288]); 
    double mexinput288 = *mexinput288_temp; 

    double *mexinput289_temp = NULL; 
    if( !mxIsDouble(prhs[289]) || mxIsComplex(prhs[289]) || !(mxGetM(prhs[289])==1 && mxGetN(prhs[289])==1) ) { 
      mexErrMsgTxt("Input 289 must be a noncomplex scalar double.");
    } 
    mexinput289_temp = mxGetPr(prhs[289]); 
    double mexinput289 = *mexinput289_temp; 

    double *mexinput290_temp = NULL; 
    if( !mxIsDouble(prhs[290]) || mxIsComplex(prhs[290]) || !(mxGetM(prhs[290])==1 && mxGetN(prhs[290])==1) ) { 
      mexErrMsgTxt("Input 290 must be a noncomplex scalar double.");
    } 
    mexinput290_temp = mxGetPr(prhs[290]); 
    double mexinput290 = *mexinput290_temp; 

    double *mexinput291_temp = NULL; 
    if( !mxIsDouble(prhs[291]) || mxIsComplex(prhs[291]) || !(mxGetM(prhs[291])==1 && mxGetN(prhs[291])==1) ) { 
      mexErrMsgTxt("Input 291 must be a noncomplex scalar double.");
    } 
    mexinput291_temp = mxGetPr(prhs[291]); 
    double mexinput291 = *mexinput291_temp; 

    double *mexinput292_temp = NULL; 
    if( !mxIsDouble(prhs[292]) || mxIsComplex(prhs[292]) || !(mxGetM(prhs[292])==1 && mxGetN(prhs[292])==1) ) { 
      mexErrMsgTxt("Input 292 must be a noncomplex scalar double.");
    } 
    mexinput292_temp = mxGetPr(prhs[292]); 
    double mexinput292 = *mexinput292_temp; 

    double *mexinput293_temp = NULL; 
    if( !mxIsDouble(prhs[293]) || mxIsComplex(prhs[293]) || !(mxGetM(prhs[293])==1 && mxGetN(prhs[293])==1) ) { 
      mexErrMsgTxt("Input 293 must be a noncomplex scalar double.");
    } 
    mexinput293_temp = mxGetPr(prhs[293]); 
    double mexinput293 = *mexinput293_temp; 

    double *mexinput294_temp = NULL; 
    if( !mxIsDouble(prhs[294]) || mxIsComplex(prhs[294]) || !(mxGetM(prhs[294])==1 && mxGetN(prhs[294])==1) ) { 
      mexErrMsgTxt("Input 294 must be a noncomplex scalar double.");
    } 
    mexinput294_temp = mxGetPr(prhs[294]); 
    double mexinput294 = *mexinput294_temp; 

    double *mexinput295_temp = NULL; 
    if( !mxIsDouble(prhs[295]) || mxIsComplex(prhs[295]) || !(mxGetM(prhs[295])==1 && mxGetN(prhs[295])==1) ) { 
      mexErrMsgTxt("Input 295 must be a noncomplex scalar double.");
    } 
    mexinput295_temp = mxGetPr(prhs[295]); 
    double mexinput295 = *mexinput295_temp; 

    double *mexinput296_temp = NULL; 
    if( !mxIsDouble(prhs[296]) || mxIsComplex(prhs[296]) || !(mxGetM(prhs[296])==1 && mxGetN(prhs[296])==1) ) { 
      mexErrMsgTxt("Input 296 must be a noncomplex scalar double.");
    } 
    mexinput296_temp = mxGetPr(prhs[296]); 
    double mexinput296 = *mexinput296_temp; 

    double *mexinput297_temp = NULL; 
    if( !mxIsDouble(prhs[297]) || mxIsComplex(prhs[297]) || !(mxGetM(prhs[297])==1 && mxGetN(prhs[297])==1) ) { 
      mexErrMsgTxt("Input 297 must be a noncomplex scalar double.");
    } 
    mexinput297_temp = mxGetPr(prhs[297]); 
    double mexinput297 = *mexinput297_temp; 

    double *mexinput298_temp = NULL; 
    if( !mxIsDouble(prhs[298]) || mxIsComplex(prhs[298]) || !(mxGetM(prhs[298])==1 && mxGetN(prhs[298])==1) ) { 
      mexErrMsgTxt("Input 298 must be a noncomplex scalar double.");
    } 
    mexinput298_temp = mxGetPr(prhs[298]); 
    double mexinput298 = *mexinput298_temp; 

    double *mexinput299_temp = NULL; 
    if( !mxIsDouble(prhs[299]) || mxIsComplex(prhs[299]) || !(mxGetM(prhs[299])==1 && mxGetN(prhs[299])==1) ) { 
      mexErrMsgTxt("Input 299 must be a noncomplex scalar double.");
    } 
    mexinput299_temp = mxGetPr(prhs[299]); 
    double mexinput299 = *mexinput299_temp; 

    double *mexinput300_temp = NULL; 
    if( !mxIsDouble(prhs[300]) || mxIsComplex(prhs[300]) || !(mxGetM(prhs[300])==1 && mxGetN(prhs[300])==1) ) { 
      mexErrMsgTxt("Input 300 must be a noncomplex scalar double.");
    } 
    mexinput300_temp = mxGetPr(prhs[300]); 
    double mexinput300 = *mexinput300_temp; 

    double *mexinput301_temp = NULL; 
    if( !mxIsDouble(prhs[301]) || mxIsComplex(prhs[301]) || !(mxGetM(prhs[301])==1 && mxGetN(prhs[301])==1) ) { 
      mexErrMsgTxt("Input 301 must be a noncomplex scalar double.");
    } 
    mexinput301_temp = mxGetPr(prhs[301]); 
    double mexinput301 = *mexinput301_temp; 

    double *mexinput302_temp = NULL; 
    if( !mxIsDouble(prhs[302]) || mxIsComplex(prhs[302]) || !(mxGetM(prhs[302])==1 && mxGetN(prhs[302])==1) ) { 
      mexErrMsgTxt("Input 302 must be a noncomplex scalar double.");
    } 
    mexinput302_temp = mxGetPr(prhs[302]); 
    double mexinput302 = *mexinput302_temp; 

    double *mexinput303_temp = NULL; 
    if( !mxIsDouble(prhs[303]) || mxIsComplex(prhs[303]) || !(mxGetM(prhs[303])==1 && mxGetN(prhs[303])==1) ) { 
      mexErrMsgTxt("Input 303 must be a noncomplex scalar double.");
    } 
    mexinput303_temp = mxGetPr(prhs[303]); 
    double mexinput303 = *mexinput303_temp; 

    double *mexinput304_temp = NULL; 
    if( !mxIsDouble(prhs[304]) || mxIsComplex(prhs[304]) || !(mxGetM(prhs[304])==1 && mxGetN(prhs[304])==1) ) { 
      mexErrMsgTxt("Input 304 must be a noncomplex scalar double.");
    } 
    mexinput304_temp = mxGetPr(prhs[304]); 
    double mexinput304 = *mexinput304_temp; 

    double *mexinput305_temp = NULL; 
    if( !mxIsDouble(prhs[305]) || mxIsComplex(prhs[305]) || !(mxGetM(prhs[305])==1 && mxGetN(prhs[305])==1) ) { 
      mexErrMsgTxt("Input 305 must be a noncomplex scalar double.");
    } 
    mexinput305_temp = mxGetPr(prhs[305]); 
    double mexinput305 = *mexinput305_temp; 

    double *mexinput306_temp = NULL; 
    if( !mxIsDouble(prhs[306]) || mxIsComplex(prhs[306]) || !(mxGetM(prhs[306])==1 && mxGetN(prhs[306])==1) ) { 
      mexErrMsgTxt("Input 306 must be a noncomplex scalar double.");
    } 
    mexinput306_temp = mxGetPr(prhs[306]); 
    double mexinput306 = *mexinput306_temp; 

    double *mexinput307_temp = NULL; 
    if( !mxIsDouble(prhs[307]) || mxIsComplex(prhs[307]) || !(mxGetM(prhs[307])==1 && mxGetN(prhs[307])==1) ) { 
      mexErrMsgTxt("Input 307 must be a noncomplex scalar double.");
    } 
    mexinput307_temp = mxGetPr(prhs[307]); 
    double mexinput307 = *mexinput307_temp; 

    double *mexinput308_temp = NULL; 
    if( !mxIsDouble(prhs[308]) || mxIsComplex(prhs[308]) || !(mxGetM(prhs[308])==1 && mxGetN(prhs[308])==1) ) { 
      mexErrMsgTxt("Input 308 must be a noncomplex scalar double.");
    } 
    mexinput308_temp = mxGetPr(prhs[308]); 
    double mexinput308 = *mexinput308_temp; 

    double *mexinput309_temp = NULL; 
    if( !mxIsDouble(prhs[309]) || mxIsComplex(prhs[309]) || !(mxGetM(prhs[309])==1 && mxGetN(prhs[309])==1) ) { 
      mexErrMsgTxt("Input 309 must be a noncomplex scalar double.");
    } 
    mexinput309_temp = mxGetPr(prhs[309]); 
    double mexinput309 = *mexinput309_temp; 

    double *mexinput310_temp = NULL; 
    if( !mxIsDouble(prhs[310]) || mxIsComplex(prhs[310]) || !(mxGetM(prhs[310])==1 && mxGetN(prhs[310])==1) ) { 
      mexErrMsgTxt("Input 310 must be a noncomplex scalar double.");
    } 
    mexinput310_temp = mxGetPr(prhs[310]); 
    double mexinput310 = *mexinput310_temp; 

    double *mexinput311_temp = NULL; 
    if( !mxIsDouble(prhs[311]) || mxIsComplex(prhs[311]) || !(mxGetM(prhs[311])==1 && mxGetN(prhs[311])==1) ) { 
      mexErrMsgTxt("Input 311 must be a noncomplex scalar double.");
    } 
    mexinput311_temp = mxGetPr(prhs[311]); 
    double mexinput311 = *mexinput311_temp; 

    double *mexinput312_temp = NULL; 
    if( !mxIsDouble(prhs[312]) || mxIsComplex(prhs[312]) || !(mxGetM(prhs[312])==1 && mxGetN(prhs[312])==1) ) { 
      mexErrMsgTxt("Input 312 must be a noncomplex scalar double.");
    } 
    mexinput312_temp = mxGetPr(prhs[312]); 
    double mexinput312 = *mexinput312_temp; 

    double *mexinput313_temp = NULL; 
    if( !mxIsDouble(prhs[313]) || mxIsComplex(prhs[313]) || !(mxGetM(prhs[313])==1 && mxGetN(prhs[313])==1) ) { 
      mexErrMsgTxt("Input 313 must be a noncomplex scalar double.");
    } 
    mexinput313_temp = mxGetPr(prhs[313]); 
    double mexinput313 = *mexinput313_temp; 

    double *mexinput314_temp = NULL; 
    if( !mxIsDouble(prhs[314]) || mxIsComplex(prhs[314]) || !(mxGetM(prhs[314])==1 && mxGetN(prhs[314])==1) ) { 
      mexErrMsgTxt("Input 314 must be a noncomplex scalar double.");
    } 
    mexinput314_temp = mxGetPr(prhs[314]); 
    double mexinput314 = *mexinput314_temp; 

    double *mexinput315_temp = NULL; 
    if( !mxIsDouble(prhs[315]) || mxIsComplex(prhs[315]) || !(mxGetM(prhs[315])==1 && mxGetN(prhs[315])==1) ) { 
      mexErrMsgTxt("Input 315 must be a noncomplex scalar double.");
    } 
    mexinput315_temp = mxGetPr(prhs[315]); 
    double mexinput315 = *mexinput315_temp; 

    double *mexinput316_temp = NULL; 
    if( !mxIsDouble(prhs[316]) || mxIsComplex(prhs[316]) || !(mxGetM(prhs[316])==1 && mxGetN(prhs[316])==1) ) { 
      mexErrMsgTxt("Input 316 must be a noncomplex scalar double.");
    } 
    mexinput316_temp = mxGetPr(prhs[316]); 
    double mexinput316 = *mexinput316_temp; 

    double *mexinput317_temp = NULL; 
    if( !mxIsDouble(prhs[317]) || mxIsComplex(prhs[317]) || !(mxGetM(prhs[317])==1 && mxGetN(prhs[317])==1) ) { 
      mexErrMsgTxt("Input 317 must be a noncomplex scalar double.");
    } 
    mexinput317_temp = mxGetPr(prhs[317]); 
    double mexinput317 = *mexinput317_temp; 

    double *mexinput318_temp = NULL; 
    if( !mxIsDouble(prhs[318]) || mxIsComplex(prhs[318]) || !(mxGetM(prhs[318])==1 && mxGetN(prhs[318])==1) ) { 
      mexErrMsgTxt("Input 318 must be a noncomplex scalar double.");
    } 
    mexinput318_temp = mxGetPr(prhs[318]); 
    double mexinput318 = *mexinput318_temp; 

    double *mexinput319_temp = NULL; 
    if( !mxIsDouble(prhs[319]) || mxIsComplex(prhs[319]) || !(mxGetM(prhs[319])==1 && mxGetN(prhs[319])==1) ) { 
      mexErrMsgTxt("Input 319 must be a noncomplex scalar double.");
    } 
    mexinput319_temp = mxGetPr(prhs[319]); 
    double mexinput319 = *mexinput319_temp; 

    double *mexinput320_temp = NULL; 
    if( !mxIsDouble(prhs[320]) || mxIsComplex(prhs[320]) || !(mxGetM(prhs[320])==1 && mxGetN(prhs[320])==1) ) { 
      mexErrMsgTxt("Input 320 must be a noncomplex scalar double.");
    } 
    mexinput320_temp = mxGetPr(prhs[320]); 
    double mexinput320 = *mexinput320_temp; 

    double *mexinput321_temp = NULL; 
    if( !mxIsDouble(prhs[321]) || mxIsComplex(prhs[321]) || !(mxGetM(prhs[321])==1 && mxGetN(prhs[321])==1) ) { 
      mexErrMsgTxt("Input 321 must be a noncomplex scalar double.");
    } 
    mexinput321_temp = mxGetPr(prhs[321]); 
    double mexinput321 = *mexinput321_temp; 

    double *mexinput322_temp = NULL; 
    if( !mxIsDouble(prhs[322]) || mxIsComplex(prhs[322]) || !(mxGetM(prhs[322])==1 && mxGetN(prhs[322])==1) ) { 
      mexErrMsgTxt("Input 322 must be a noncomplex scalar double.");
    } 
    mexinput322_temp = mxGetPr(prhs[322]); 
    double mexinput322 = *mexinput322_temp; 

    double *mexinput323_temp = NULL; 
    if( !mxIsDouble(prhs[323]) || mxIsComplex(prhs[323]) || !(mxGetM(prhs[323])==1 && mxGetN(prhs[323])==1) ) { 
      mexErrMsgTxt("Input 323 must be a noncomplex scalar double.");
    } 
    mexinput323_temp = mxGetPr(prhs[323]); 
    double mexinput323 = *mexinput323_temp; 

    double *mexinput324_temp = NULL; 
    if( !mxIsDouble(prhs[324]) || mxIsComplex(prhs[324]) || !(mxGetM(prhs[324])==1 && mxGetN(prhs[324])==1) ) { 
      mexErrMsgTxt("Input 324 must be a noncomplex scalar double.");
    } 
    mexinput324_temp = mxGetPr(prhs[324]); 
    double mexinput324 = *mexinput324_temp; 

    double *mexinput325_temp = NULL; 
    if( !mxIsDouble(prhs[325]) || mxIsComplex(prhs[325]) || !(mxGetM(prhs[325])==1 && mxGetN(prhs[325])==1) ) { 
      mexErrMsgTxt("Input 325 must be a noncomplex scalar double.");
    } 
    mexinput325_temp = mxGetPr(prhs[325]); 
    double mexinput325 = *mexinput325_temp; 

    double *mexinput326_temp = NULL; 
    if( !mxIsDouble(prhs[326]) || mxIsComplex(prhs[326]) || !(mxGetM(prhs[326])==1 && mxGetN(prhs[326])==1) ) { 
      mexErrMsgTxt("Input 326 must be a noncomplex scalar double.");
    } 
    mexinput326_temp = mxGetPr(prhs[326]); 
    double mexinput326 = *mexinput326_temp; 

    double *mexinput327_temp = NULL; 
    if( !mxIsDouble(prhs[327]) || mxIsComplex(prhs[327]) || !(mxGetM(prhs[327])==1 && mxGetN(prhs[327])==1) ) { 
      mexErrMsgTxt("Input 327 must be a noncomplex scalar double.");
    } 
    mexinput327_temp = mxGetPr(prhs[327]); 
    double mexinput327 = *mexinput327_temp; 

    double *mexinput328_temp = NULL; 
    if( !mxIsDouble(prhs[328]) || mxIsComplex(prhs[328]) || !(mxGetM(prhs[328])==1 && mxGetN(prhs[328])==1) ) { 
      mexErrMsgTxt("Input 328 must be a noncomplex scalar double.");
    } 
    mexinput328_temp = mxGetPr(prhs[328]); 
    double mexinput328 = *mexinput328_temp; 

    double *mexinput329_temp = NULL; 
    if( !mxIsDouble(prhs[329]) || mxIsComplex(prhs[329]) || !(mxGetM(prhs[329])==1 && mxGetN(prhs[329])==1) ) { 
      mexErrMsgTxt("Input 329 must be a noncomplex scalar double.");
    } 
    mexinput329_temp = mxGetPr(prhs[329]); 
    double mexinput329 = *mexinput329_temp; 

    double *mexinput330_temp = NULL; 
    if( !mxIsDouble(prhs[330]) || mxIsComplex(prhs[330]) || !(mxGetM(prhs[330])==1 && mxGetN(prhs[330])==1) ) { 
      mexErrMsgTxt("Input 330 must be a noncomplex scalar double.");
    } 
    mexinput330_temp = mxGetPr(prhs[330]); 
    double mexinput330 = *mexinput330_temp; 

    double *mexinput331_temp = NULL; 
    if( !mxIsDouble(prhs[331]) || mxIsComplex(prhs[331]) || !(mxGetM(prhs[331])==1 && mxGetN(prhs[331])==1) ) { 
      mexErrMsgTxt("Input 331 must be a noncomplex scalar double.");
    } 
    mexinput331_temp = mxGetPr(prhs[331]); 
    double mexinput331 = *mexinput331_temp; 

    double *mexinput332_temp = NULL; 
    if( !mxIsDouble(prhs[332]) || mxIsComplex(prhs[332]) || !(mxGetM(prhs[332])==1 && mxGetN(prhs[332])==1) ) { 
      mexErrMsgTxt("Input 332 must be a noncomplex scalar double.");
    } 
    mexinput332_temp = mxGetPr(prhs[332]); 
    double mexinput332 = *mexinput332_temp; 

    double *mexinput333_temp = NULL; 
    if( !mxIsDouble(prhs[333]) || mxIsComplex(prhs[333]) || !(mxGetM(prhs[333])==1 && mxGetN(prhs[333])==1) ) { 
      mexErrMsgTxt("Input 333 must be a noncomplex scalar double.");
    } 
    mexinput333_temp = mxGetPr(prhs[333]); 
    double mexinput333 = *mexinput333_temp; 

    double *mexinput334_temp = NULL; 
    if( !mxIsDouble(prhs[334]) || mxIsComplex(prhs[334]) || !(mxGetM(prhs[334])==1 && mxGetN(prhs[334])==1) ) { 
      mexErrMsgTxt("Input 334 must be a noncomplex scalar double.");
    } 
    mexinput334_temp = mxGetPr(prhs[334]); 
    double mexinput334 = *mexinput334_temp; 

    double *mexinput335_temp = NULL; 
    if( !mxIsDouble(prhs[335]) || mxIsComplex(prhs[335]) || !(mxGetM(prhs[335])==1 && mxGetN(prhs[335])==1) ) { 
      mexErrMsgTxt("Input 335 must be a noncomplex scalar double.");
    } 
    mexinput335_temp = mxGetPr(prhs[335]); 
    double mexinput335 = *mexinput335_temp; 

    double *mexinput336_temp = NULL; 
    if( !mxIsDouble(prhs[336]) || mxIsComplex(prhs[336]) || !(mxGetM(prhs[336])==1 && mxGetN(prhs[336])==1) ) { 
      mexErrMsgTxt("Input 336 must be a noncomplex scalar double.");
    } 
    mexinput336_temp = mxGetPr(prhs[336]); 
    double mexinput336 = *mexinput336_temp; 

    double *mexinput337_temp = NULL; 
    if( !mxIsDouble(prhs[337]) || mxIsComplex(prhs[337]) || !(mxGetM(prhs[337])==1 && mxGetN(prhs[337])==1) ) { 
      mexErrMsgTxt("Input 337 must be a noncomplex scalar double.");
    } 
    mexinput337_temp = mxGetPr(prhs[337]); 
    double mexinput337 = *mexinput337_temp; 

    double *mexinput338_temp = NULL; 
    if( !mxIsDouble(prhs[338]) || mxIsComplex(prhs[338]) || !(mxGetM(prhs[338])==1 && mxGetN(prhs[338])==1) ) { 
      mexErrMsgTxt("Input 338 must be a noncomplex scalar double.");
    } 
    mexinput338_temp = mxGetPr(prhs[338]); 
    double mexinput338 = *mexinput338_temp; 

    double *mexinput339_temp = NULL; 
    if( !mxIsDouble(prhs[339]) || mxIsComplex(prhs[339]) || !(mxGetM(prhs[339])==1 && mxGetN(prhs[339])==1) ) { 
      mexErrMsgTxt("Input 339 must be a noncomplex scalar double.");
    } 
    mexinput339_temp = mxGetPr(prhs[339]); 
    double mexinput339 = *mexinput339_temp; 

    double *mexinput340_temp = NULL; 
    if( !mxIsDouble(prhs[340]) || mxIsComplex(prhs[340]) || !(mxGetM(prhs[340])==1 && mxGetN(prhs[340])==1) ) { 
      mexErrMsgTxt("Input 340 must be a noncomplex scalar double.");
    } 
    mexinput340_temp = mxGetPr(prhs[340]); 
    double mexinput340 = *mexinput340_temp; 

    double *mexinput341_temp = NULL; 
    if( !mxIsDouble(prhs[341]) || mxIsComplex(prhs[341]) || !(mxGetM(prhs[341])==1 && mxGetN(prhs[341])==1) ) { 
      mexErrMsgTxt("Input 341 must be a noncomplex scalar double.");
    } 
    mexinput341_temp = mxGetPr(prhs[341]); 
    double mexinput341 = *mexinput341_temp; 

    double *mexinput342_temp = NULL; 
    if( !mxIsDouble(prhs[342]) || mxIsComplex(prhs[342]) || !(mxGetM(prhs[342])==1 && mxGetN(prhs[342])==1) ) { 
      mexErrMsgTxt("Input 342 must be a noncomplex scalar double.");
    } 
    mexinput342_temp = mxGetPr(prhs[342]); 
    double mexinput342 = *mexinput342_temp; 

    double *mexinput343_temp = NULL; 
    if( !mxIsDouble(prhs[343]) || mxIsComplex(prhs[343]) || !(mxGetM(prhs[343])==1 && mxGetN(prhs[343])==1) ) { 
      mexErrMsgTxt("Input 343 must be a noncomplex scalar double.");
    } 
    mexinput343_temp = mxGetPr(prhs[343]); 
    double mexinput343 = *mexinput343_temp; 

    double *mexinput344_temp = NULL; 
    if( !mxIsDouble(prhs[344]) || mxIsComplex(prhs[344]) || !(mxGetM(prhs[344])==1 && mxGetN(prhs[344])==1) ) { 
      mexErrMsgTxt("Input 344 must be a noncomplex scalar double.");
    } 
    mexinput344_temp = mxGetPr(prhs[344]); 
    double mexinput344 = *mexinput344_temp; 

    double *mexinput345_temp = NULL; 
    if( !mxIsDouble(prhs[345]) || mxIsComplex(prhs[345]) || !(mxGetM(prhs[345])==1 && mxGetN(prhs[345])==1) ) { 
      mexErrMsgTxt("Input 345 must be a noncomplex scalar double.");
    } 
    mexinput345_temp = mxGetPr(prhs[345]); 
    double mexinput345 = *mexinput345_temp; 

    double *mexinput346_temp = NULL; 
    if( !mxIsDouble(prhs[346]) || mxIsComplex(prhs[346]) || !(mxGetM(prhs[346])==1 && mxGetN(prhs[346])==1) ) { 
      mexErrMsgTxt("Input 346 must be a noncomplex scalar double.");
    } 
    mexinput346_temp = mxGetPr(prhs[346]); 
    double mexinput346 = *mexinput346_temp; 

    double *mexinput347_temp = NULL; 
    if( !mxIsDouble(prhs[347]) || mxIsComplex(prhs[347]) || !(mxGetM(prhs[347])==1 && mxGetN(prhs[347])==1) ) { 
      mexErrMsgTxt("Input 347 must be a noncomplex scalar double.");
    } 
    mexinput347_temp = mxGetPr(prhs[347]); 
    double mexinput347 = *mexinput347_temp; 

    double *mexinput348_temp = NULL; 
    if( !mxIsDouble(prhs[348]) || mxIsComplex(prhs[348]) || !(mxGetM(prhs[348])==1 && mxGetN(prhs[348])==1) ) { 
      mexErrMsgTxt("Input 348 must be a noncomplex scalar double.");
    } 
    mexinput348_temp = mxGetPr(prhs[348]); 
    double mexinput348 = *mexinput348_temp; 

    double *mexinput349_temp = NULL; 
    if( !mxIsDouble(prhs[349]) || mxIsComplex(prhs[349]) || !(mxGetM(prhs[349])==1 && mxGetN(prhs[349])==1) ) { 
      mexErrMsgTxt("Input 349 must be a noncomplex scalar double.");
    } 
    mexinput349_temp = mxGetPr(prhs[349]); 
    double mexinput349 = *mexinput349_temp; 

    double *mexinput350_temp = NULL; 
    if( !mxIsDouble(prhs[350]) || mxIsComplex(prhs[350]) || !(mxGetM(prhs[350])==1 && mxGetN(prhs[350])==1) ) { 
      mexErrMsgTxt("Input 350 must be a noncomplex scalar double.");
    } 
    mexinput350_temp = mxGetPr(prhs[350]); 
    double mexinput350 = *mexinput350_temp; 

    double *mexinput351_temp = NULL; 
    if( !mxIsDouble(prhs[351]) || mxIsComplex(prhs[351]) || !(mxGetM(prhs[351])==1 && mxGetN(prhs[351])==1) ) { 
      mexErrMsgTxt("Input 351 must be a noncomplex scalar double.");
    } 
    mexinput351_temp = mxGetPr(prhs[351]); 
    double mexinput351 = *mexinput351_temp; 

    double *mexinput352_temp = NULL; 
    if( !mxIsDouble(prhs[352]) || mxIsComplex(prhs[352]) || !(mxGetM(prhs[352])==1 && mxGetN(prhs[352])==1) ) { 
      mexErrMsgTxt("Input 352 must be a noncomplex scalar double.");
    } 
    mexinput352_temp = mxGetPr(prhs[352]); 
    double mexinput352 = *mexinput352_temp; 

    double *mexinput353_temp = NULL; 
    if( !mxIsDouble(prhs[353]) || mxIsComplex(prhs[353]) || !(mxGetM(prhs[353])==1 && mxGetN(prhs[353])==1) ) { 
      mexErrMsgTxt("Input 353 must be a noncomplex scalar double.");
    } 
    mexinput353_temp = mxGetPr(prhs[353]); 
    double mexinput353 = *mexinput353_temp; 

    double *mexinput354_temp = NULL; 
    if( !mxIsDouble(prhs[354]) || mxIsComplex(prhs[354]) || !(mxGetM(prhs[354])==1 && mxGetN(prhs[354])==1) ) { 
      mexErrMsgTxt("Input 354 must be a noncomplex scalar double.");
    } 
    mexinput354_temp = mxGetPr(prhs[354]); 
    double mexinput354 = *mexinput354_temp; 

    double *mexinput355_temp = NULL; 
    if( !mxIsDouble(prhs[355]) || mxIsComplex(prhs[355]) || !(mxGetM(prhs[355])==1 && mxGetN(prhs[355])==1) ) { 
      mexErrMsgTxt("Input 355 must be a noncomplex scalar double.");
    } 
    mexinput355_temp = mxGetPr(prhs[355]); 
    double mexinput355 = *mexinput355_temp; 

    double *mexinput356_temp = NULL; 
    if( !mxIsDouble(prhs[356]) || mxIsComplex(prhs[356]) || !(mxGetM(prhs[356])==1 && mxGetN(prhs[356])==1) ) { 
      mexErrMsgTxt("Input 356 must be a noncomplex scalar double.");
    } 
    mexinput356_temp = mxGetPr(prhs[356]); 
    double mexinput356 = *mexinput356_temp; 

    double *mexinput357_temp = NULL; 
    if( !mxIsDouble(prhs[357]) || mxIsComplex(prhs[357]) || !(mxGetM(prhs[357])==1 && mxGetN(prhs[357])==1) ) { 
      mexErrMsgTxt("Input 357 must be a noncomplex scalar double.");
    } 
    mexinput357_temp = mxGetPr(prhs[357]); 
    double mexinput357 = *mexinput357_temp; 

    double *mexinput358_temp = NULL; 
    if( !mxIsDouble(prhs[358]) || mxIsComplex(prhs[358]) || !(mxGetM(prhs[358])==1 && mxGetN(prhs[358])==1) ) { 
      mexErrMsgTxt("Input 358 must be a noncomplex scalar double.");
    } 
    mexinput358_temp = mxGetPr(prhs[358]); 
    double mexinput358 = *mexinput358_temp; 

    double *mexinput359_temp = NULL; 
    if( !mxIsDouble(prhs[359]) || mxIsComplex(prhs[359]) || !(mxGetM(prhs[359])==1 && mxGetN(prhs[359])==1) ) { 
      mexErrMsgTxt("Input 359 must be a noncomplex scalar double.");
    } 
    mexinput359_temp = mxGetPr(prhs[359]); 
    double mexinput359 = *mexinput359_temp; 

    DifferentialEquation acadodata_f1;
    acadodata_f1 << dot(x1) == (u1-x1);
    acadodata_f1 << dot(x2) == (u2-x2);
    acadodata_f1 << dot(x3) == (u3-x3);
    acadodata_f1 << dot(x4) == ((-1/3.10900000000000000000e+03*4.96000000000000000000e+03*sin((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x9))+1/3.10900000000000000000e+03*5.20000000000000000000e+02*cos((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x9))-1/5.62949953421312000000e+15*6.24140708480766300000e+15*sin((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x8))+3.64082079947113700000e+15/7.03687441776640000000e+16*cos((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x8))+9.29738945258875570943e-01)*4.71238898038468931873e+01-(1/2.50000000000000000000e+01*x4+x1)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x5) == ((-1.20000000000000000000e+03/9.01000000000000000000e+02*sin((1/1.00000000000000000000e+02*x8-1/1.00000000000000000000e+02*x9))+1/5.62949953421312000000e+15*6.24140708480766300000e+15*sin((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x8))+3.64082079947113700000e+15/7.03687441776640000000e+16*cos((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x8))+4.00000000000000000000e+01/9.01000000000000000000e+02*cos((1/1.00000000000000000000e+02*x8-1/1.00000000000000000000e+02*x9))-6.99441961505383846820e-01)*4.71238898038468931873e+01-(1/2.50000000000000000000e+01*x5+x2)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x6) == ((1.20000000000000000000e+03/9.01000000000000000000e+02*sin((1/1.00000000000000000000e+02*x8-1/1.00000000000000000000e+02*x9))+1/3.10900000000000000000e+03*4.96000000000000000000e+03*sin((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x9))+1/3.10900000000000000000e+03*5.20000000000000000000e+02*cos((1/1.00000000000000000000e+02*x7-1/1.00000000000000000000e+02*x9))+4.00000000000000000000e+01/9.01000000000000000000e+02*cos((1/1.00000000000000000000e+02*x8-1/1.00000000000000000000e+02*x9))-7.18877926255120813792e-01)*4.71238898038468931873e+01-(1/2.50000000000000000000e+01*x6+x3)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x7) == 1.00000000000000000000e+02*x4;
    acadodata_f1 << dot(x8) == 1.00000000000000000000e+02*x5;
    acadodata_f1 << dot(x9) == 1.00000000000000000000e+02*x6;
    acadodata_f1 << dot(x10) == (1/1.00000000000000000000e+04*pow(x7,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x8,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x9,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x1,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x2,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x3,2.00000000000000000000e+00)+1/5.00000000000000000000e+01*pow(x4,2.00000000000000000000e+00)+1/5.00000000000000000000e+01*pow(x5,2.00000000000000000000e+00)+1/5.00000000000000000000e+01*pow(x6,2.00000000000000000000e+00));
    acadodata_f1 << dot(inputcost) == ((mexinput120*u1+mexinput123*u2+mexinput126*u3)*u1+(mexinput121*u1+mexinput124*u2+mexinput127*u3)*u2+(mexinput122*u1+mexinput125*u2+mexinput128*u3)*u3);

    OCP ocp1(0, mexinput130, mexinput129);
    ocp1.minimizeMayerTerm((((-mexinput10+x1)*mexinput20+(-mexinput11+x2)*mexinput30+(-mexinput12+x3)*mexinput40+(-mexinput13+x4)*mexinput50+(-mexinput14+x5)*mexinput60+(-mexinput15+x6)*mexinput70+(-mexinput16+x7)*mexinput80+(-mexinput17+x8)*mexinput90+(-mexinput18+x9)*mexinput100+(-mexinput19+x10)*mexinput110)*(-mexinput10+x1)+((-mexinput10+x1)*mexinput21+(-mexinput11+x2)*mexinput31+(-mexinput12+x3)*mexinput41+(-mexinput13+x4)*mexinput51+(-mexinput14+x5)*mexinput61+(-mexinput15+x6)*mexinput71+(-mexinput16+x7)*mexinput81+(-mexinput17+x8)*mexinput91+(-mexinput18+x9)*mexinput101+(-mexinput19+x10)*mexinput111)*(-mexinput11+x2)+((-mexinput10+x1)*mexinput22+(-mexinput11+x2)*mexinput32+(-mexinput12+x3)*mexinput42+(-mexinput13+x4)*mexinput52+(-mexinput14+x5)*mexinput62+(-mexinput15+x6)*mexinput72+(-mexinput16+x7)*mexinput82+(-mexinput17+x8)*mexinput92+(-mexinput18+x9)*mexinput102+(-mexinput19+x10)*mexinput112)*(-mexinput12+x3)+((-mexinput10+x1)*mexinput23+(-mexinput11+x2)*mexinput33+(-mexinput12+x3)*mexinput43+(-mexinput13+x4)*mexinput53+(-mexinput14+x5)*mexinput63+(-mexinput15+x6)*mexinput73+(-mexinput16+x7)*mexinput83+(-mexinput17+x8)*mexinput93+(-mexinput18+x9)*mexinput103+(-mexinput19+x10)*mexinput113)*(-mexinput13+x4)+((-mexinput10+x1)*mexinput24+(-mexinput11+x2)*mexinput34+(-mexinput12+x3)*mexinput44+(-mexinput13+x4)*mexinput54+(-mexinput14+x5)*mexinput64+(-mexinput15+x6)*mexinput74+(-mexinput16+x7)*mexinput84+(-mexinput17+x8)*mexinput94+(-mexinput18+x9)*mexinput104+(-mexinput19+x10)*mexinput114)*(-mexinput14+x5)+((-mexinput10+x1)*mexinput25+(-mexinput11+x2)*mexinput35+(-mexinput12+x3)*mexinput45+(-mexinput13+x4)*mexinput55+(-mexinput14+x5)*mexinput65+(-mexinput15+x6)*mexinput75+(-mexinput16+x7)*mexinput85+(-mexinput17+x8)*mexinput95+(-mexinput18+x9)*mexinput105+(-mexinput19+x10)*mexinput115)*(-mexinput15+x6)+((-mexinput10+x1)*mexinput26+(-mexinput11+x2)*mexinput36+(-mexinput12+x3)*mexinput46+(-mexinput13+x4)*mexinput56+(-mexinput14+x5)*mexinput66+(-mexinput15+x6)*mexinput76+(-mexinput16+x7)*mexinput86+(-mexinput17+x8)*mexinput96+(-mexinput18+x9)*mexinput106+(-mexinput19+x10)*mexinput116)*(-mexinput16+x7)+((-mexinput10+x1)*mexinput27+(-mexinput11+x2)*mexinput37+(-mexinput12+x3)*mexinput47+(-mexinput13+x4)*mexinput57+(-mexinput14+x5)*mexinput67+(-mexinput15+x6)*mexinput77+(-mexinput16+x7)*mexinput87+(-mexinput17+x8)*mexinput97+(-mexinput18+x9)*mexinput107+(-mexinput19+x10)*mexinput117)*(-mexinput17+x8)+((-mexinput10+x1)*mexinput28+(-mexinput11+x2)*mexinput38+(-mexinput12+x3)*mexinput48+(-mexinput13+x4)*mexinput58+(-mexinput14+x5)*mexinput68+(-mexinput15+x6)*mexinput78+(-mexinput16+x7)*mexinput88+(-mexinput17+x8)*mexinput98+(-mexinput18+x9)*mexinput108+(-mexinput19+x10)*mexinput118)*(-mexinput18+x9)+((-mexinput10+x1)*mexinput29+(-mexinput11+x2)*mexinput39+(-mexinput12+x3)*mexinput49+(-mexinput13+x4)*mexinput59+(-mexinput14+x5)*mexinput69+(-mexinput15+x6)*mexinput79+(-mexinput16+x7)*mexinput89+(-mexinput17+x8)*mexinput99+(-mexinput18+x9)*mexinput109+(-mexinput19+x10)*mexinput119)*(-mexinput19+x10)+9.99999999999999954748e-07*ps1+inputcost));
    ocp1.subjectTo(acadodata_f1);
    ocp1.subjectTo(AT_START, x1 == mexinput0);
    ocp1.subjectTo(AT_START, x2 == mexinput1);
    ocp1.subjectTo(AT_START, x3 == mexinput2);
    ocp1.subjectTo(AT_START, x4 == mexinput3);
    ocp1.subjectTo(AT_START, x5 == mexinput4);
    ocp1.subjectTo(AT_START, x6 == mexinput5);
    ocp1.subjectTo(AT_START, x7 == mexinput6);
    ocp1.subjectTo(AT_START, x8 == mexinput7);
    ocp1.subjectTo(AT_START, x9 == mexinput8);
    ocp1.subjectTo(AT_START, x10 == mexinput9);
    ocp1.subjectTo(AT_START, inputcost == 0.00000000000000000000e+00);
    ocp1.subjectTo(mexinput134 <= u1 <= mexinput131);
    ocp1.subjectTo(mexinput135 <= u2 <= mexinput132);
    ocp1.subjectTo(mexinput136 <= u3 <= mexinput133);
    ocp1.subjectTo(AT_START, ((mexinput137*x1+mexinput138*x2+mexinput139*x3+mexinput140*x4+mexinput141*x5+mexinput142*x6+mexinput143*x7+mexinput144*x8+mexinput145*x9+mexinput146*x10-mexinput337*mexinput357)/mexinput337/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput147*x1+mexinput148*x2+mexinput149*x3+mexinput150*x4+mexinput151*x5+mexinput152*x6+mexinput153*x7+mexinput154*x8+mexinput155*x9+mexinput156*x10-mexinput338*mexinput357)/mexinput338/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput157*x1+mexinput158*x2+mexinput159*x3+mexinput160*x4+mexinput161*x5+mexinput162*x6+mexinput163*x7+mexinput164*x8+mexinput165*x9+mexinput166*x10-mexinput339*mexinput357)/mexinput339/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput167*x1+mexinput168*x2+mexinput169*x3+mexinput170*x4+mexinput171*x5+mexinput172*x6+mexinput173*x7+mexinput174*x8+mexinput175*x9+mexinput176*x10-mexinput340*mexinput357)/mexinput340/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput177*x1+mexinput178*x2+mexinput179*x3+mexinput180*x4+mexinput181*x5+mexinput182*x6+mexinput183*x7+mexinput184*x8+mexinput185*x9+mexinput186*x10-mexinput341*mexinput357)/mexinput341/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput187*x1+mexinput188*x2+mexinput189*x3+mexinput190*x4+mexinput191*x5+mexinput192*x6+mexinput193*x7+mexinput194*x8+mexinput195*x9+mexinput196*x10-mexinput342*mexinput357)/mexinput342/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput197*x1+mexinput198*x2+mexinput199*x3+mexinput200*x4+mexinput201*x5+mexinput202*x6+mexinput203*x7+mexinput204*x8+mexinput205*x9+mexinput206*x10-mexinput343*mexinput357)/mexinput343/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput207*x1+mexinput208*x2+mexinput209*x3+mexinput210*x4+mexinput211*x5+mexinput212*x6+mexinput213*x7+mexinput214*x8+mexinput215*x9+mexinput216*x10-mexinput344*mexinput357)/mexinput344/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput217*x1+mexinput218*x2+mexinput219*x3+mexinput220*x4+mexinput221*x5+mexinput222*x6+mexinput223*x7+mexinput224*x8+mexinput225*x9+mexinput226*x10-mexinput345*mexinput357)/mexinput345/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput227*x1+mexinput228*x2+mexinput229*x3+mexinput230*x4+mexinput231*x5+mexinput232*x6+mexinput233*x7+mexinput234*x8+mexinput235*x9+mexinput236*x10-mexinput346*mexinput357)/mexinput346/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput237*x1+mexinput238*x2+mexinput239*x3+mexinput240*x4+mexinput241*x5+mexinput242*x6+mexinput243*x7+mexinput244*x8+mexinput245*x9+mexinput246*x10-mexinput347*mexinput357)/mexinput347/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput247*x1+mexinput248*x2+mexinput249*x3+mexinput250*x4+mexinput251*x5+mexinput252*x6+mexinput253*x7+mexinput254*x8+mexinput255*x9+mexinput256*x10-mexinput348*mexinput357)/mexinput348/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput257*x1+mexinput258*x2+mexinput259*x3+mexinput260*x4+mexinput261*x5+mexinput262*x6+mexinput263*x7+mexinput264*x8+mexinput265*x9+mexinput266*x10-mexinput349*mexinput357)/mexinput349/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput267*x1+mexinput268*x2+mexinput269*x3+mexinput270*x4+mexinput271*x5+mexinput272*x6+mexinput273*x7+mexinput274*x8+mexinput275*x9+mexinput276*x10-mexinput350*mexinput357)/mexinput350/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput277*x1+mexinput278*x2+mexinput279*x3+mexinput280*x4+mexinput281*x5+mexinput282*x6+mexinput283*x7+mexinput284*x8+mexinput285*x9+mexinput286*x10-mexinput351*mexinput357)/mexinput351/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput287*x1+mexinput288*x2+mexinput289*x3+mexinput290*x4+mexinput291*x5+mexinput292*x6+mexinput293*x7+mexinput294*x8+mexinput295*x9+mexinput296*x10-mexinput352*mexinput357)/mexinput352/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput297*x1+mexinput298*x2+mexinput299*x3+mexinput300*x4+mexinput301*x5+mexinput302*x6+mexinput303*x7+mexinput304*x8+mexinput305*x9+mexinput306*x10-mexinput353*mexinput357)/mexinput353/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput307*x1+mexinput308*x2+mexinput309*x3+mexinput310*x4+mexinput311*x5+mexinput312*x6+mexinput313*x7+mexinput314*x8+mexinput315*x9+mexinput316*x10-mexinput354*mexinput357)/mexinput354/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput317*x1+mexinput318*x2+mexinput319*x3+mexinput320*x4+mexinput321*x5+mexinput322*x6+mexinput323*x7+mexinput324*x8+mexinput325*x9+mexinput326*x10-mexinput355*mexinput357)/mexinput355/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput327*x1+mexinput328*x2+mexinput329*x3+mexinput330*x4+mexinput331*x5+mexinput332*x6+mexinput333*x7+mexinput334*x8+mexinput335*x9+mexinput336*x10-mexinput356*mexinput357)/mexinput356/mexinput357-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps1 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput137*x1+mexinput138*x2+mexinput139*x3+mexinput140*x4+mexinput141*x5+mexinput142*x6+mexinput143*x7+mexinput144*x8+mexinput145*x9+mexinput146*x10-mexinput337*mexinput357)/mexinput337/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput147*x1+mexinput148*x2+mexinput149*x3+mexinput150*x4+mexinput151*x5+mexinput152*x6+mexinput153*x7+mexinput154*x8+mexinput155*x9+mexinput156*x10-mexinput338*mexinput357)/mexinput338/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput157*x1+mexinput158*x2+mexinput159*x3+mexinput160*x4+mexinput161*x5+mexinput162*x6+mexinput163*x7+mexinput164*x8+mexinput165*x9+mexinput166*x10-mexinput339*mexinput357)/mexinput339/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput167*x1+mexinput168*x2+mexinput169*x3+mexinput170*x4+mexinput171*x5+mexinput172*x6+mexinput173*x7+mexinput174*x8+mexinput175*x9+mexinput176*x10-mexinput340*mexinput357)/mexinput340/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput177*x1+mexinput178*x2+mexinput179*x3+mexinput180*x4+mexinput181*x5+mexinput182*x6+mexinput183*x7+mexinput184*x8+mexinput185*x9+mexinput186*x10-mexinput341*mexinput357)/mexinput341/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput187*x1+mexinput188*x2+mexinput189*x3+mexinput190*x4+mexinput191*x5+mexinput192*x6+mexinput193*x7+mexinput194*x8+mexinput195*x9+mexinput196*x10-mexinput342*mexinput357)/mexinput342/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput197*x1+mexinput198*x2+mexinput199*x3+mexinput200*x4+mexinput201*x5+mexinput202*x6+mexinput203*x7+mexinput204*x8+mexinput205*x9+mexinput206*x10-mexinput343*mexinput357)/mexinput343/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput207*x1+mexinput208*x2+mexinput209*x3+mexinput210*x4+mexinput211*x5+mexinput212*x6+mexinput213*x7+mexinput214*x8+mexinput215*x9+mexinput216*x10-mexinput344*mexinput357)/mexinput344/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput217*x1+mexinput218*x2+mexinput219*x3+mexinput220*x4+mexinput221*x5+mexinput222*x6+mexinput223*x7+mexinput224*x8+mexinput225*x9+mexinput226*x10-mexinput345*mexinput357)/mexinput345/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput227*x1+mexinput228*x2+mexinput229*x3+mexinput230*x4+mexinput231*x5+mexinput232*x6+mexinput233*x7+mexinput234*x8+mexinput235*x9+mexinput236*x10-mexinput346*mexinput357)/mexinput346/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput237*x1+mexinput238*x2+mexinput239*x3+mexinput240*x4+mexinput241*x5+mexinput242*x6+mexinput243*x7+mexinput244*x8+mexinput245*x9+mexinput246*x10-mexinput347*mexinput357)/mexinput347/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput247*x1+mexinput248*x2+mexinput249*x3+mexinput250*x4+mexinput251*x5+mexinput252*x6+mexinput253*x7+mexinput254*x8+mexinput255*x9+mexinput256*x10-mexinput348*mexinput357)/mexinput348/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput257*x1+mexinput258*x2+mexinput259*x3+mexinput260*x4+mexinput261*x5+mexinput262*x6+mexinput263*x7+mexinput264*x8+mexinput265*x9+mexinput266*x10-mexinput349*mexinput357)/mexinput349/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput267*x1+mexinput268*x2+mexinput269*x3+mexinput270*x4+mexinput271*x5+mexinput272*x6+mexinput273*x7+mexinput274*x8+mexinput275*x9+mexinput276*x10-mexinput350*mexinput357)/mexinput350/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput277*x1+mexinput278*x2+mexinput279*x3+mexinput280*x4+mexinput281*x5+mexinput282*x6+mexinput283*x7+mexinput284*x8+mexinput285*x9+mexinput286*x10-mexinput351*mexinput357)/mexinput351/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput287*x1+mexinput288*x2+mexinput289*x3+mexinput290*x4+mexinput291*x5+mexinput292*x6+mexinput293*x7+mexinput294*x8+mexinput295*x9+mexinput296*x10-mexinput352*mexinput357)/mexinput352/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput297*x1+mexinput298*x2+mexinput299*x3+mexinput300*x4+mexinput301*x5+mexinput302*x6+mexinput303*x7+mexinput304*x8+mexinput305*x9+mexinput306*x10-mexinput353*mexinput357)/mexinput353/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput307*x1+mexinput308*x2+mexinput309*x3+mexinput310*x4+mexinput311*x5+mexinput312*x6+mexinput313*x7+mexinput314*x8+mexinput315*x9+mexinput316*x10-mexinput354*mexinput357)/mexinput354/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput317*x1+mexinput318*x2+mexinput319*x3+mexinput320*x4+mexinput321*x5+mexinput322*x6+mexinput323*x7+mexinput324*x8+mexinput325*x9+mexinput326*x10-mexinput355*mexinput357)/mexinput355/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput327*x1+mexinput328*x2+mexinput329*x3+mexinput330*x4+mexinput331*x5+mexinput332*x6+mexinput333*x7+mexinput334*x8+mexinput335*x9+mexinput336*x10-mexinput356*mexinput357)/mexinput356/mexinput357 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-mexinput358+ps1) <= (-mexinput359));


    OptimizationAlgorithm algo1(ocp1);
    algo1.set( HESSIAN_APPROXIMATION, EXACT_HESSIAN );
    algo1.set( KKT_TOLERANCE, 1.000000E-12 );
    algo1.set( INTEGRATOR_TOLERANCE, 1.000000E-06 );
    algo1.set( INTEGRATOR_TYPE, INT_RK45 );
    algo1.set( DISCRETIZATION_TYPE, MULTIPLE_SHOOTING );
    algo1.set( ABSOLUTE_TOLERANCE, 1.000000E-06 );
    algo1.set( MAX_NUM_ITERATIONS, 1000 );
    returnValue returnvalue = algo1.solve();

    VariablesGrid out_states; 
    VariablesGrid out_parameters; 
    VariablesGrid out_controls; 
    VariablesGrid out_disturbances; 
    VariablesGrid out_algstates; 
    algo1.getDifferentialStates(out_states);
    algo1.getControls(out_controls);
    algo1.getParameters(out_parameters);
    const char* outputFieldNames[] = {"STATES", "CONTROLS", "PARAMETERS", "DISTURBANCES", "ALGEBRAICSTATES", "CONVERGENCE_ACHIEVED"}; 
    plhs[0] = mxCreateStructMatrix( 1,1,6,outputFieldNames ); 
    mxArray *OutS = NULL;
    double  *outS = NULL;
    OutS = mxCreateDoubleMatrix( out_states.getNumPoints(),1+out_states.getNumValues(),mxREAL ); 
    outS = mxGetPr( OutS );
    for( int i=0; i<out_states.getNumPoints(); ++i ){ 
      outS[0*out_states.getNumPoints() + i] = out_states.getTime(i); 
      for( int j=0; j<out_states.getNumValues(); ++j ){ 
        outS[(1+j)*out_states.getNumPoints() + i] = out_states(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"STATES",OutS );
    mxArray *OutC = NULL;
    double  *outC = NULL;
    OutC = mxCreateDoubleMatrix( out_controls.getNumPoints(),1+out_controls.getNumValues(),mxREAL ); 
    outC = mxGetPr( OutC );
    for( int i=0; i<out_controls.getNumPoints(); ++i ){ 
      outC[0*out_controls.getNumPoints() + i] = out_controls.getTime(i); 
      for( int j=0; j<out_controls.getNumValues(); ++j ){ 
        outC[(1+j)*out_controls.getNumPoints() + i] = out_controls(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"CONTROLS",OutC );
    mxArray *OutP = NULL;
    double  *outP = NULL;
    OutP = mxCreateDoubleMatrix( out_parameters.getNumPoints(),1+out_parameters.getNumValues(),mxREAL ); 
    outP = mxGetPr( OutP );
    for( int i=0; i<out_parameters.getNumPoints(); ++i ){ 
      outP[0*out_parameters.getNumPoints() + i] = out_parameters.getTime(i); 
      for( int j=0; j<out_parameters.getNumValues(); ++j ){ 
        outP[(1+j)*out_parameters.getNumPoints() + i] = out_parameters(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"PARAMETERS",OutP );
    mxArray *OutW = NULL;
    double  *outW = NULL;
    OutW = mxCreateDoubleMatrix( out_disturbances.getNumPoints(),1+out_disturbances.getNumValues(),mxREAL ); 
    outW = mxGetPr( OutW );
    for( int i=0; i<out_disturbances.getNumPoints(); ++i ){ 
      outW[0*out_disturbances.getNumPoints() + i] = out_disturbances.getTime(i); 
      for( int j=0; j<out_disturbances.getNumValues(); ++j ){ 
        outW[(1+j)*out_disturbances.getNumPoints() + i] = out_disturbances(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"DISTURBANCES",OutW );
    mxArray *OutZ = NULL;
    double  *outZ = NULL;
    OutZ = mxCreateDoubleMatrix( out_algstates.getNumPoints(),1+out_algstates.getNumValues(),mxREAL ); 
    outZ = mxGetPr( OutZ );
    for( int i=0; i<out_algstates.getNumPoints(); ++i ){ 
      outZ[0*out_algstates.getNumPoints() + i] = out_algstates.getTime(i); 
      for( int j=0; j<out_algstates.getNumValues(); ++j ){ 
        outZ[(1+j)*out_algstates.getNumPoints() + i] = out_algstates(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"ALGEBRAICSTATES",OutZ );
    mxArray *OutConv = NULL;
    if ( returnvalue == SUCCESSFUL_RETURN ) { OutConv = mxCreateDoubleScalar( 1 ); }else{ OutConv = mxCreateDoubleScalar( 0 ); } 
    mxSetField( plhs[0],0,"CONVERGENCE_ACHIEVED",OutConv );


    clearAllStaticCounters( ); 
 
} 

