%% Begin ACADO Initialization

BEGIN_ACADO;

% Problem name
acadoSet('problemname', 'acadoReachsetMPC');


%% Initialize variables

% States
DifferentialState	x1;
DifferentialState	x2;
DifferentialState	x3;
DifferentialState	x4;
DifferentialState	x5;
DifferentialState	x6;
DifferentialState	x7;
DifferentialState	x8;
DifferentialState	x9;
DifferentialState	x10;

DifferentialState	inputcost;

% Parameters (needed to couple differential states in constraints)

% Parameters (for computing maximal distance to set)
Parameter	ps1;

% Control inputs
Control	u1;
Control	u2;
Control	u3;


%% Parse inputs to the MEX-file

% Input 1: x0
x01 = acado.MexInput;
x02 = acado.MexInput;
x03 = acado.MexInput;
x04 = acado.MexInput;
x05 = acado.MexInput;
x06 = acado.MexInput;
x07 = acado.MexInput;
x08 = acado.MexInput;
x09 = acado.MexInput;
x010 = acado.MexInput;

x0 = [x01;x02;x03;x04;x05;x06;x07;x08;x09;x010];

% Input 2: xf
xf1 = acado.MexInput;
xf2 = acado.MexInput;
xf3 = acado.MexInput;
xf4 = acado.MexInput;
xf5 = acado.MexInput;
xf6 = acado.MexInput;
xf7 = acado.MexInput;
xf8 = acado.MexInput;
xf9 = acado.MexInput;
xf10 = acado.MexInput;

xf = [xf1;xf2;xf3;xf4;xf5;xf6;xf7;xf8;xf9;xf10];

% Input 3: Q
Q11 = acado.MexInput;
Q12 = acado.MexInput;
Q13 = acado.MexInput;
Q14 = acado.MexInput;
Q15 = acado.MexInput;
Q16 = acado.MexInput;
Q17 = acado.MexInput;
Q18 = acado.MexInput;
Q19 = acado.MexInput;
Q110 = acado.MexInput;

Q21 = acado.MexInput;
Q22 = acado.MexInput;
Q23 = acado.MexInput;
Q24 = acado.MexInput;
Q25 = acado.MexInput;
Q26 = acado.MexInput;
Q27 = acado.MexInput;
Q28 = acado.MexInput;
Q29 = acado.MexInput;
Q210 = acado.MexInput;

Q31 = acado.MexInput;
Q32 = acado.MexInput;
Q33 = acado.MexInput;
Q34 = acado.MexInput;
Q35 = acado.MexInput;
Q36 = acado.MexInput;
Q37 = acado.MexInput;
Q38 = acado.MexInput;
Q39 = acado.MexInput;
Q310 = acado.MexInput;

Q41 = acado.MexInput;
Q42 = acado.MexInput;
Q43 = acado.MexInput;
Q44 = acado.MexInput;
Q45 = acado.MexInput;
Q46 = acado.MexInput;
Q47 = acado.MexInput;
Q48 = acado.MexInput;
Q49 = acado.MexInput;
Q410 = acado.MexInput;

Q51 = acado.MexInput;
Q52 = acado.MexInput;
Q53 = acado.MexInput;
Q54 = acado.MexInput;
Q55 = acado.MexInput;
Q56 = acado.MexInput;
Q57 = acado.MexInput;
Q58 = acado.MexInput;
Q59 = acado.MexInput;
Q510 = acado.MexInput;

Q61 = acado.MexInput;
Q62 = acado.MexInput;
Q63 = acado.MexInput;
Q64 = acado.MexInput;
Q65 = acado.MexInput;
Q66 = acado.MexInput;
Q67 = acado.MexInput;
Q68 = acado.MexInput;
Q69 = acado.MexInput;
Q610 = acado.MexInput;

Q71 = acado.MexInput;
Q72 = acado.MexInput;
Q73 = acado.MexInput;
Q74 = acado.MexInput;
Q75 = acado.MexInput;
Q76 = acado.MexInput;
Q77 = acado.MexInput;
Q78 = acado.MexInput;
Q79 = acado.MexInput;
Q710 = acado.MexInput;

Q81 = acado.MexInput;
Q82 = acado.MexInput;
Q83 = acado.MexInput;
Q84 = acado.MexInput;
Q85 = acado.MexInput;
Q86 = acado.MexInput;
Q87 = acado.MexInput;
Q88 = acado.MexInput;
Q89 = acado.MexInput;
Q810 = acado.MexInput;

Q91 = acado.MexInput;
Q92 = acado.MexInput;
Q93 = acado.MexInput;
Q94 = acado.MexInput;
Q95 = acado.MexInput;
Q96 = acado.MexInput;
Q97 = acado.MexInput;
Q98 = acado.MexInput;
Q99 = acado.MexInput;
Q910 = acado.MexInput;

Q101 = acado.MexInput;
Q102 = acado.MexInput;
Q103 = acado.MexInput;
Q104 = acado.MexInput;
Q105 = acado.MexInput;
Q106 = acado.MexInput;
Q107 = acado.MexInput;
Q108 = acado.MexInput;
Q109 = acado.MexInput;
Q1010 = acado.MexInput;

Q = [Q11,Q12,Q13,Q14,Q15,Q16,Q17,Q18,Q19,Q110; ...
	Q21,Q22,Q23,Q24,Q25,Q26,Q27,Q28,Q29,Q210; ...
	Q31,Q32,Q33,Q34,Q35,Q36,Q37,Q38,Q39,Q310; ...
	Q41,Q42,Q43,Q44,Q45,Q46,Q47,Q48,Q49,Q410; ...
	Q51,Q52,Q53,Q54,Q55,Q56,Q57,Q58,Q59,Q510; ...
	Q61,Q62,Q63,Q64,Q65,Q66,Q67,Q68,Q69,Q610; ...
	Q71,Q72,Q73,Q74,Q75,Q76,Q77,Q78,Q79,Q710; ...
	Q81,Q82,Q83,Q84,Q85,Q86,Q87,Q88,Q89,Q810; ...
	Q91,Q92,Q93,Q94,Q95,Q96,Q97,Q98,Q99,Q910; ...
	Q101,Q102,Q103,Q104,Q105,Q106,Q107,Q108,Q109,Q1010];

% Input 4: R
R11 = acado.MexInput;
R12 = acado.MexInput;
R13 = acado.MexInput;

R21 = acado.MexInput;
R22 = acado.MexInput;
R23 = acado.MexInput;

R31 = acado.MexInput;
R32 = acado.MexInput;
R33 = acado.MexInput;

R = [R11,R12,R13; ...
	R21,R22,R23; ...
	R31,R32,R33];

% Input 5: multiple shooting steps
Nc = acado.MexInput;

% Input 6: optimization termination time T
t_end = acado.MexInput;

% Input 7: u_max
u_max1 = acado.MexInput;
u_max2 = acado.MexInput;
u_max3 = acado.MexInput;

u_max = [u_max1;u_max2;u_max3];

% Input 8: u_min
u_min1 = acado.MexInput;
u_min2 = acado.MexInput;
u_min3 = acado.MexInput;

u_min = [u_min1;u_min2;u_min3];

% Input 9: polytope parameter D
D11 = acado.MexInput;
D12 = acado.MexInput;
D13 = acado.MexInput;
D14 = acado.MexInput;
D15 = acado.MexInput;
D16 = acado.MexInput;
D17 = acado.MexInput;
D18 = acado.MexInput;
D19 = acado.MexInput;
D110 = acado.MexInput;
D21 = acado.MexInput;
D22 = acado.MexInput;
D23 = acado.MexInput;
D24 = acado.MexInput;
D25 = acado.MexInput;
D26 = acado.MexInput;
D27 = acado.MexInput;
D28 = acado.MexInput;
D29 = acado.MexInput;
D210 = acado.MexInput;
D31 = acado.MexInput;
D32 = acado.MexInput;
D33 = acado.MexInput;
D34 = acado.MexInput;
D35 = acado.MexInput;
D36 = acado.MexInput;
D37 = acado.MexInput;
D38 = acado.MexInput;
D39 = acado.MexInput;
D310 = acado.MexInput;
D41 = acado.MexInput;
D42 = acado.MexInput;
D43 = acado.MexInput;
D44 = acado.MexInput;
D45 = acado.MexInput;
D46 = acado.MexInput;
D47 = acado.MexInput;
D48 = acado.MexInput;
D49 = acado.MexInput;
D410 = acado.MexInput;
D51 = acado.MexInput;
D52 = acado.MexInput;
D53 = acado.MexInput;
D54 = acado.MexInput;
D55 = acado.MexInput;
D56 = acado.MexInput;
D57 = acado.MexInput;
D58 = acado.MexInput;
D59 = acado.MexInput;
D510 = acado.MexInput;
D61 = acado.MexInput;
D62 = acado.MexInput;
D63 = acado.MexInput;
D64 = acado.MexInput;
D65 = acado.MexInput;
D66 = acado.MexInput;
D67 = acado.MexInput;
D68 = acado.MexInput;
D69 = acado.MexInput;
D610 = acado.MexInput;
D71 = acado.MexInput;
D72 = acado.MexInput;
D73 = acado.MexInput;
D74 = acado.MexInput;
D75 = acado.MexInput;
D76 = acado.MexInput;
D77 = acado.MexInput;
D78 = acado.MexInput;
D79 = acado.MexInput;
D710 = acado.MexInput;
D81 = acado.MexInput;
D82 = acado.MexInput;
D83 = acado.MexInput;
D84 = acado.MexInput;
D85 = acado.MexInput;
D86 = acado.MexInput;
D87 = acado.MexInput;
D88 = acado.MexInput;
D89 = acado.MexInput;
D810 = acado.MexInput;
D91 = acado.MexInput;
D92 = acado.MexInput;
D93 = acado.MexInput;
D94 = acado.MexInput;
D95 = acado.MexInput;
D96 = acado.MexInput;
D97 = acado.MexInput;
D98 = acado.MexInput;
D99 = acado.MexInput;
D910 = acado.MexInput;
D101 = acado.MexInput;
D102 = acado.MexInput;
D103 = acado.MexInput;
D104 = acado.MexInput;
D105 = acado.MexInput;
D106 = acado.MexInput;
D107 = acado.MexInput;
D108 = acado.MexInput;
D109 = acado.MexInput;
D1010 = acado.MexInput;
D111 = acado.MexInput;
D112 = acado.MexInput;
D113 = acado.MexInput;
D114 = acado.MexInput;
D115 = acado.MexInput;
D116 = acado.MexInput;
D117 = acado.MexInput;
D118 = acado.MexInput;
D119 = acado.MexInput;
D1110 = acado.MexInput;
D121 = acado.MexInput;
D122 = acado.MexInput;
D123 = acado.MexInput;
D124 = acado.MexInput;
D125 = acado.MexInput;
D126 = acado.MexInput;
D127 = acado.MexInput;
D128 = acado.MexInput;
D129 = acado.MexInput;
D1210 = acado.MexInput;
D131 = acado.MexInput;
D132 = acado.MexInput;
D133 = acado.MexInput;
D134 = acado.MexInput;
D135 = acado.MexInput;
D136 = acado.MexInput;
D137 = acado.MexInput;
D138 = acado.MexInput;
D139 = acado.MexInput;
D1310 = acado.MexInput;
D141 = acado.MexInput;
D142 = acado.MexInput;
D143 = acado.MexInput;
D144 = acado.MexInput;
D145 = acado.MexInput;
D146 = acado.MexInput;
D147 = acado.MexInput;
D148 = acado.MexInput;
D149 = acado.MexInput;
D1410 = acado.MexInput;
D151 = acado.MexInput;
D152 = acado.MexInput;
D153 = acado.MexInput;
D154 = acado.MexInput;
D155 = acado.MexInput;
D156 = acado.MexInput;
D157 = acado.MexInput;
D158 = acado.MexInput;
D159 = acado.MexInput;
D1510 = acado.MexInput;
D161 = acado.MexInput;
D162 = acado.MexInput;
D163 = acado.MexInput;
D164 = acado.MexInput;
D165 = acado.MexInput;
D166 = acado.MexInput;
D167 = acado.MexInput;
D168 = acado.MexInput;
D169 = acado.MexInput;
D1610 = acado.MexInput;
D171 = acado.MexInput;
D172 = acado.MexInput;
D173 = acado.MexInput;
D174 = acado.MexInput;
D175 = acado.MexInput;
D176 = acado.MexInput;
D177 = acado.MexInput;
D178 = acado.MexInput;
D179 = acado.MexInput;
D1710 = acado.MexInput;
D181 = acado.MexInput;
D182 = acado.MexInput;
D183 = acado.MexInput;
D184 = acado.MexInput;
D185 = acado.MexInput;
D186 = acado.MexInput;
D187 = acado.MexInput;
D188 = acado.MexInput;
D189 = acado.MexInput;
D1810 = acado.MexInput;
D191 = acado.MexInput;
D192 = acado.MexInput;
D193 = acado.MexInput;
D194 = acado.MexInput;
D195 = acado.MexInput;
D196 = acado.MexInput;
D197 = acado.MexInput;
D198 = acado.MexInput;
D199 = acado.MexInput;
D1910 = acado.MexInput;
D201 = acado.MexInput;
D202 = acado.MexInput;
D203 = acado.MexInput;
D204 = acado.MexInput;
D205 = acado.MexInput;
D206 = acado.MexInput;
D207 = acado.MexInput;
D208 = acado.MexInput;
D209 = acado.MexInput;
D2010 = acado.MexInput;
D = [D11,D12,D13,D14,D15,D16,D17,D18,D19,D110; ...
	D21,D22,D23,D24,D25,D26,D27,D28,D29,D210; ...
	D31,D32,D33,D34,D35,D36,D37,D38,D39,D310; ...
	D41,D42,D43,D44,D45,D46,D47,D48,D49,D410; ...
	D51,D52,D53,D54,D55,D56,D57,D58,D59,D510; ...
	D61,D62,D63,D64,D65,D66,D67,D68,D69,D610; ...
	D71,D72,D73,D74,D75,D76,D77,D78,D79,D710; ...
	D81,D82,D83,D84,D85,D86,D87,D88,D89,D810; ...
	D91,D92,D93,D94,D95,D96,D97,D98,D99,D910; ...
	D101,D102,D103,D104,D105,D106,D107,D108,D109,D1010; ...
	D111,D112,D113,D114,D115,D116,D117,D118,D119,D1110; ...
	D121,D122,D123,D124,D125,D126,D127,D128,D129,D1210; ...
	D131,D132,D133,D134,D135,D136,D137,D138,D139,D1310; ...
	D141,D142,D143,D144,D145,D146,D147,D148,D149,D1410; ...
	D151,D152,D153,D154,D155,D156,D157,D158,D159,D1510; ...
	D161,D162,D163,D164,D165,D166,D167,D168,D169,D1610; ...
	D171,D172,D173,D174,D175,D176,D177,D178,D179,D1710; ...
	D181,D182,D183,D184,D185,D186,D187,D188,D189,D1810; ...
	D191,D192,D193,D194,D195,D196,D197,D198,D199,D1910; ...
	D201,D202,D203,D204,D205,D206,D207,D208,D209,D2010];

% Input 10: polytope parameter e
e1 = acado.MexInput;
e2 = acado.MexInput;
e3 = acado.MexInput;
e4 = acado.MexInput;
e5 = acado.MexInput;
e6 = acado.MexInput;
e7 = acado.MexInput;
e8 = acado.MexInput;
e9 = acado.MexInput;
e10 = acado.MexInput;
e11 = acado.MexInput;
e12 = acado.MexInput;
e13 = acado.MexInput;
e14 = acado.MexInput;
e15 = acado.MexInput;
e16 = acado.MexInput;
e17 = acado.MexInput;
e18 = acado.MexInput;
e19 = acado.MexInput;
e20 = acado.MexInput;

e = [e1;e2;e3;e4;e5;e6;e7;e8;e9;e10;e11;e12;e13;e14;e15;e16;e17;e18;e19;e20];

% Input 11: scaling factor (polytope)
alphaPoly = acado.MexInput;


% Input 12: Previous value of the cost function
J = acado.MexInput;


% Input 13: contraction rate
alpha = acado.MexInput;



%% Differential Equation

% Set the differential equation object for continous time in ACADO
f = acado.DifferentialEquation();

% System Dynamics
f.add(dot(x1) == u1 - x1);
f.add(dot(x2) == u2 - x2);
f.add(dot(x3) == u3 - x3);
f.add(dot(x4) == 15*pi*((3640820799471137*cos(x7/100 - x8/100))/70368744177664000 + (520*cos(x7/100 - x9/100))/3109 - (6241407084807663*sin(x7/100 - x8/100))/5629499534213120 - (4960*sin(x7/100 - x9/100))/3109 + 2093585983709855/2251799813685248) - 15*pi*(x1 + x4/25));
f.add(dot(x5) == 15*pi*((3640820799471137*cos(x7/100 - x8/100))/70368744177664000 + (40*cos(x8/100 - x9/100))/901 + (6241407084807663*sin(x7/100 - x8/100))/5629499534213120 - (1200*sin(x8/100 - x9/100))/901 - 6300013114405871/9007199254740992) - 15*pi*(x2 + x5/25));
f.add(dot(x6) == 15*pi*((520*cos(x7/100 - x9/100))/3109 + (40*cos(x8/100 - x9/100))/901 + (4960*sin(x7/100 - x9/100))/3109 + (1200*sin(x8/100 - x9/100))/901 - 3237538360807437/4503599627370496) - 15*pi*(x3 + x6/25));
f.add(dot(x7) == 100*x4);
f.add(dot(x8) == 100*x5);
f.add(dot(x9) == 100*x6);
f.add(dot(x10) == x1^2/2 + x2^2/2 + x3^2/2 + x4^2/50 + x5^2/50 + x6^2/50 + x7^2/10000 + x8^2/10000 + x9^2/10000);



% Forming control vectors u

u_1 = [u1;u2;u3];

% Integration of control input costs
f.add(dot(inputcost) ==		u_1' * R * u_1);


%% Optimal Control Problem

% Parameters
start_time = 0;		% Set up start time of optimization
end_time = t_end;	% Set up termination time of optimization
grid_points = Nc;	% Set up gridpoints of optimization

% Set up the Optimal Control Problem (OCP) for ACADO
ocp = acado.OCP(start_time, end_time, grid_points);

% Forming state vectors x
x_1 =[x1;x2;x3;x4;x5;x6;x7;x8;x9;x10];

% Define objective function
objective = (x_1-xf)'*Q*(x_1-xf);
objective = objective + 1e-6 * ps1;

% Min(x,u) integral 0-T(inputcost) + Quadratic Distance Cost 
ocp.minimizeMayerTerm(inputcost + objective);


%% Polytope

% Scale the polytope
e = alphaPoly * e;

% Compute distances of points from hyperplanes
temp1 = (D*x_1 - e)./e;



%% Constraints

% Optimize with respect to your differential equation
ocp.subjectTo( f );

% Initial point
ocp.subjectTo( 'AT_START', x1 ==  x0(1) );
ocp.subjectTo( 'AT_START', x2 ==  x0(2) );
ocp.subjectTo( 'AT_START', x3 ==  x0(3) );
ocp.subjectTo( 'AT_START', x4 ==  x0(4) );
ocp.subjectTo( 'AT_START', x5 ==  x0(5) );
ocp.subjectTo( 'AT_START', x6 ==  x0(6) );
ocp.subjectTo( 'AT_START', x7 ==  x0(7) );
ocp.subjectTo( 'AT_START', x8 ==  x0(8) );
ocp.subjectTo( 'AT_START', x9 ==  x0(9) );
ocp.subjectTo( 'AT_START', x10 ==  x0(10) );

% Initial value for input costs L(0) = 0
ocp.subjectTo( 'AT_START', inputcost ==  0.0 );

% Input constraints
ocp.subjectTo( u_min(1) <= u1 <= u_max(1) );
ocp.subjectTo( u_min(2) <= u2 <= u_max(2) );
ocp.subjectTo( u_min(3) <= u3 <= u_max(3) );

% Distance computaion constraints
ocp.subjectTo('AT_START', temp1(1) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(2) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(3) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(4) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(5) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(6) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(7) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(8) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(9) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(10) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(11) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(12) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(13) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(14) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(15) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(16) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(17) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(18) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(19) - ps1 <= 0 );
ocp.subjectTo('AT_START', temp1(20) - ps1 <= 0 );
ocp.subjectTo('AT_START', ps1 >= 0 );

% Distance computaion constraints
ocp.subjectTo('AT_END', temp1(1) <= 0 );
ocp.subjectTo('AT_END', temp1(2) <= 0 );
ocp.subjectTo('AT_END', temp1(3) <= 0 );
ocp.subjectTo('AT_END', temp1(4) <= 0 );
ocp.subjectTo('AT_END', temp1(5) <= 0 );
ocp.subjectTo('AT_END', temp1(6) <= 0 );
ocp.subjectTo('AT_END', temp1(7) <= 0 );
ocp.subjectTo('AT_END', temp1(8) <= 0 );
ocp.subjectTo('AT_END', temp1(9) <= 0 );
ocp.subjectTo('AT_END', temp1(10) <= 0 );
ocp.subjectTo('AT_END', temp1(11) <= 0 );
ocp.subjectTo('AT_END', temp1(12) <= 0 );
ocp.subjectTo('AT_END', temp1(13) <= 0 );
ocp.subjectTo('AT_END', temp1(14) <= 0 );
ocp.subjectTo('AT_END', temp1(15) <= 0 );
ocp.subjectTo('AT_END', temp1(16) <= 0 );
ocp.subjectTo('AT_END', temp1(17) <= 0 );
ocp.subjectTo('AT_END', temp1(18) <= 0 );
ocp.subjectTo('AT_END', temp1(19) <= 0 );
ocp.subjectTo('AT_END', temp1(20) <= 0 );

% Contraction constraint
sumNew = ps1;
ocp.subjectTo('AT_START', sumNew - J <= -alpha );


%% Optimization Algorithm 

% Set up the optimization algorithm, link it to the OCP
algo =acado.OptimizationAlgorithm(ocp); 

% Set options for optimization
algo.set( 'HESSIAN_APPROXIMATION', 'EXACT_HESSIAN' );
algo.set( 'KKT_TOLERANCE', 1e-12 );
algo.set( 'INTEGRATOR_TOLERANCE', 1e-6 ); 
algo.set( 'INTEGRATOR_TYPE', 'INT_RK45' );
algo.set( 'DISCRETIZATION_TYPE', 'MULTIPLE_SHOOTING');
algo.set( 'ABSOLUTE_TOLERANCE', 1e-6 );
algo.set( 'MAX_NUM_ITERATIONS', 1000 );
END_ACADO;