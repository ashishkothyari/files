/*
*    This file is part of ACADO Toolkit.
*
*    ACADO Toolkit -- A Toolkit for Automatic Control and Dynamic Optimization.
*    Copyright (C) 2008-2009 by Boris Houska and Hans Joachim Ferreau, K.U.Leuven.
*    Developed within the Optimization in Engineering Center (OPTEC) under
*    supervision of Moritz Diehl. All rights reserved.
*
*    ACADO Toolkit is free software; you can redistribute it and/or
*    modify it under the terms of the GNU Lesser General Public
*    License as published by the Free Software Foundation; either
*    version 3 of the License, or (at your option) any later version.
*
*    ACADO Toolkit is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*    Lesser General Public License for more details.
*
*    You should have received a copy of the GNU Lesser General Public
*    License along with ACADO Toolkit; if not, write to the Free Software
*    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*
*/


/**
*    Author David Ariens, Rien Quirynen
*    Date 2009-2013
*    http://www.acadotoolkit.org/matlab 
*/

#include <acado_optimal_control.hpp>
#include <acado_toolkit.hpp>
#include <acado/utils/matlab_acado_utils.hpp>

USING_NAMESPACE_ACADO

#include <mex.h>


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] ) 
 { 
 
    MatlabConsoleStreamBuf mybuf;
    RedirectStream redirect(std::cout, mybuf);
    clearAllStaticCounters( ); 
 
    mexPrintf("\nACADO Toolkit for Matlab - Developed by David Ariens and Rien Quirynen, 2009-2013 \n"); 
    mexPrintf("Support available at http://www.acadotoolkit.org/matlab \n \n"); 

    if (nrhs != 2015){ 
      mexErrMsgTxt("This problem expects 2015 right hand side argument(s) since you have defined 2015 MexInput(s)");
    } 
 
    TIME autotime;
    DifferentialState x1;
    DifferentialState x2;
    DifferentialState x3;
    DifferentialState x4;
    DifferentialState x5;
    DifferentialState x6;
    DifferentialState x7;
    DifferentialState x8;
    DifferentialState x9;
    DifferentialState x10;
    DifferentialState x11;
    DifferentialState x12;
    DifferentialState x13;
    DifferentialState x14;
    DifferentialState x15;
    DifferentialState x16;
    DifferentialState x17;
    DifferentialState x18;
    DifferentialState x19;
    DifferentialState x20;
    DifferentialState x21;
    DifferentialState x22;
    DifferentialState x23;
    DifferentialState x24;
    DifferentialState x25;
    DifferentialState inputcost;
    Parameter ps1; 
    Control u1;
    Control u2;
    Control u3;
    Control u4;
    Control u5;
    double *mexinput0_temp = NULL; 
    if( !mxIsDouble(prhs[0]) || mxIsComplex(prhs[0]) || !(mxGetM(prhs[0])==1 && mxGetN(prhs[0])==1) ) { 
      mexErrMsgTxt("Input 0 must be a noncomplex scalar double.");
    } 
    mexinput0_temp = mxGetPr(prhs[0]); 
    double mexinput0 = *mexinput0_temp; 

    double *mexinput1_temp = NULL; 
    if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) ) { 
      mexErrMsgTxt("Input 1 must be a noncomplex scalar double.");
    } 
    mexinput1_temp = mxGetPr(prhs[1]); 
    double mexinput1 = *mexinput1_temp; 

    double *mexinput2_temp = NULL; 
    if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) ) { 
      mexErrMsgTxt("Input 2 must be a noncomplex scalar double.");
    } 
    mexinput2_temp = mxGetPr(prhs[2]); 
    double mexinput2 = *mexinput2_temp; 

    double *mexinput3_temp = NULL; 
    if( !mxIsDouble(prhs[3]) || mxIsComplex(prhs[3]) || !(mxGetM(prhs[3])==1 && mxGetN(prhs[3])==1) ) { 
      mexErrMsgTxt("Input 3 must be a noncomplex scalar double.");
    } 
    mexinput3_temp = mxGetPr(prhs[3]); 
    double mexinput3 = *mexinput3_temp; 

    double *mexinput4_temp = NULL; 
    if( !mxIsDouble(prhs[4]) || mxIsComplex(prhs[4]) || !(mxGetM(prhs[4])==1 && mxGetN(prhs[4])==1) ) { 
      mexErrMsgTxt("Input 4 must be a noncomplex scalar double.");
    } 
    mexinput4_temp = mxGetPr(prhs[4]); 
    double mexinput4 = *mexinput4_temp; 

    double *mexinput5_temp = NULL; 
    if( !mxIsDouble(prhs[5]) || mxIsComplex(prhs[5]) || !(mxGetM(prhs[5])==1 && mxGetN(prhs[5])==1) ) { 
      mexErrMsgTxt("Input 5 must be a noncomplex scalar double.");
    } 
    mexinput5_temp = mxGetPr(prhs[5]); 
    double mexinput5 = *mexinput5_temp; 

    double *mexinput6_temp = NULL; 
    if( !mxIsDouble(prhs[6]) || mxIsComplex(prhs[6]) || !(mxGetM(prhs[6])==1 && mxGetN(prhs[6])==1) ) { 
      mexErrMsgTxt("Input 6 must be a noncomplex scalar double.");
    } 
    mexinput6_temp = mxGetPr(prhs[6]); 
    double mexinput6 = *mexinput6_temp; 

    double *mexinput7_temp = NULL; 
    if( !mxIsDouble(prhs[7]) || mxIsComplex(prhs[7]) || !(mxGetM(prhs[7])==1 && mxGetN(prhs[7])==1) ) { 
      mexErrMsgTxt("Input 7 must be a noncomplex scalar double.");
    } 
    mexinput7_temp = mxGetPr(prhs[7]); 
    double mexinput7 = *mexinput7_temp; 

    double *mexinput8_temp = NULL; 
    if( !mxIsDouble(prhs[8]) || mxIsComplex(prhs[8]) || !(mxGetM(prhs[8])==1 && mxGetN(prhs[8])==1) ) { 
      mexErrMsgTxt("Input 8 must be a noncomplex scalar double.");
    } 
    mexinput8_temp = mxGetPr(prhs[8]); 
    double mexinput8 = *mexinput8_temp; 

    double *mexinput9_temp = NULL; 
    if( !mxIsDouble(prhs[9]) || mxIsComplex(prhs[9]) || !(mxGetM(prhs[9])==1 && mxGetN(prhs[9])==1) ) { 
      mexErrMsgTxt("Input 9 must be a noncomplex scalar double.");
    } 
    mexinput9_temp = mxGetPr(prhs[9]); 
    double mexinput9 = *mexinput9_temp; 

    double *mexinput10_temp = NULL; 
    if( !mxIsDouble(prhs[10]) || mxIsComplex(prhs[10]) || !(mxGetM(prhs[10])==1 && mxGetN(prhs[10])==1) ) { 
      mexErrMsgTxt("Input 10 must be a noncomplex scalar double.");
    } 
    mexinput10_temp = mxGetPr(prhs[10]); 
    double mexinput10 = *mexinput10_temp; 

    double *mexinput11_temp = NULL; 
    if( !mxIsDouble(prhs[11]) || mxIsComplex(prhs[11]) || !(mxGetM(prhs[11])==1 && mxGetN(prhs[11])==1) ) { 
      mexErrMsgTxt("Input 11 must be a noncomplex scalar double.");
    } 
    mexinput11_temp = mxGetPr(prhs[11]); 
    double mexinput11 = *mexinput11_temp; 

    double *mexinput12_temp = NULL; 
    if( !mxIsDouble(prhs[12]) || mxIsComplex(prhs[12]) || !(mxGetM(prhs[12])==1 && mxGetN(prhs[12])==1) ) { 
      mexErrMsgTxt("Input 12 must be a noncomplex scalar double.");
    } 
    mexinput12_temp = mxGetPr(prhs[12]); 
    double mexinput12 = *mexinput12_temp; 

    double *mexinput13_temp = NULL; 
    if( !mxIsDouble(prhs[13]) || mxIsComplex(prhs[13]) || !(mxGetM(prhs[13])==1 && mxGetN(prhs[13])==1) ) { 
      mexErrMsgTxt("Input 13 must be a noncomplex scalar double.");
    } 
    mexinput13_temp = mxGetPr(prhs[13]); 
    double mexinput13 = *mexinput13_temp; 

    double *mexinput14_temp = NULL; 
    if( !mxIsDouble(prhs[14]) || mxIsComplex(prhs[14]) || !(mxGetM(prhs[14])==1 && mxGetN(prhs[14])==1) ) { 
      mexErrMsgTxt("Input 14 must be a noncomplex scalar double.");
    } 
    mexinput14_temp = mxGetPr(prhs[14]); 
    double mexinput14 = *mexinput14_temp; 

    double *mexinput15_temp = NULL; 
    if( !mxIsDouble(prhs[15]) || mxIsComplex(prhs[15]) || !(mxGetM(prhs[15])==1 && mxGetN(prhs[15])==1) ) { 
      mexErrMsgTxt("Input 15 must be a noncomplex scalar double.");
    } 
    mexinput15_temp = mxGetPr(prhs[15]); 
    double mexinput15 = *mexinput15_temp; 

    double *mexinput16_temp = NULL; 
    if( !mxIsDouble(prhs[16]) || mxIsComplex(prhs[16]) || !(mxGetM(prhs[16])==1 && mxGetN(prhs[16])==1) ) { 
      mexErrMsgTxt("Input 16 must be a noncomplex scalar double.");
    } 
    mexinput16_temp = mxGetPr(prhs[16]); 
    double mexinput16 = *mexinput16_temp; 

    double *mexinput17_temp = NULL; 
    if( !mxIsDouble(prhs[17]) || mxIsComplex(prhs[17]) || !(mxGetM(prhs[17])==1 && mxGetN(prhs[17])==1) ) { 
      mexErrMsgTxt("Input 17 must be a noncomplex scalar double.");
    } 
    mexinput17_temp = mxGetPr(prhs[17]); 
    double mexinput17 = *mexinput17_temp; 

    double *mexinput18_temp = NULL; 
    if( !mxIsDouble(prhs[18]) || mxIsComplex(prhs[18]) || !(mxGetM(prhs[18])==1 && mxGetN(prhs[18])==1) ) { 
      mexErrMsgTxt("Input 18 must be a noncomplex scalar double.");
    } 
    mexinput18_temp = mxGetPr(prhs[18]); 
    double mexinput18 = *mexinput18_temp; 

    double *mexinput19_temp = NULL; 
    if( !mxIsDouble(prhs[19]) || mxIsComplex(prhs[19]) || !(mxGetM(prhs[19])==1 && mxGetN(prhs[19])==1) ) { 
      mexErrMsgTxt("Input 19 must be a noncomplex scalar double.");
    } 
    mexinput19_temp = mxGetPr(prhs[19]); 
    double mexinput19 = *mexinput19_temp; 

    double *mexinput20_temp = NULL; 
    if( !mxIsDouble(prhs[20]) || mxIsComplex(prhs[20]) || !(mxGetM(prhs[20])==1 && mxGetN(prhs[20])==1) ) { 
      mexErrMsgTxt("Input 20 must be a noncomplex scalar double.");
    } 
    mexinput20_temp = mxGetPr(prhs[20]); 
    double mexinput20 = *mexinput20_temp; 

    double *mexinput21_temp = NULL; 
    if( !mxIsDouble(prhs[21]) || mxIsComplex(prhs[21]) || !(mxGetM(prhs[21])==1 && mxGetN(prhs[21])==1) ) { 
      mexErrMsgTxt("Input 21 must be a noncomplex scalar double.");
    } 
    mexinput21_temp = mxGetPr(prhs[21]); 
    double mexinput21 = *mexinput21_temp; 

    double *mexinput22_temp = NULL; 
    if( !mxIsDouble(prhs[22]) || mxIsComplex(prhs[22]) || !(mxGetM(prhs[22])==1 && mxGetN(prhs[22])==1) ) { 
      mexErrMsgTxt("Input 22 must be a noncomplex scalar double.");
    } 
    mexinput22_temp = mxGetPr(prhs[22]); 
    double mexinput22 = *mexinput22_temp; 

    double *mexinput23_temp = NULL; 
    if( !mxIsDouble(prhs[23]) || mxIsComplex(prhs[23]) || !(mxGetM(prhs[23])==1 && mxGetN(prhs[23])==1) ) { 
      mexErrMsgTxt("Input 23 must be a noncomplex scalar double.");
    } 
    mexinput23_temp = mxGetPr(prhs[23]); 
    double mexinput23 = *mexinput23_temp; 

    double *mexinput24_temp = NULL; 
    if( !mxIsDouble(prhs[24]) || mxIsComplex(prhs[24]) || !(mxGetM(prhs[24])==1 && mxGetN(prhs[24])==1) ) { 
      mexErrMsgTxt("Input 24 must be a noncomplex scalar double.");
    } 
    mexinput24_temp = mxGetPr(prhs[24]); 
    double mexinput24 = *mexinput24_temp; 

    double *mexinput25_temp = NULL; 
    if( !mxIsDouble(prhs[25]) || mxIsComplex(prhs[25]) || !(mxGetM(prhs[25])==1 && mxGetN(prhs[25])==1) ) { 
      mexErrMsgTxt("Input 25 must be a noncomplex scalar double.");
    } 
    mexinput25_temp = mxGetPr(prhs[25]); 
    double mexinput25 = *mexinput25_temp; 

    double *mexinput26_temp = NULL; 
    if( !mxIsDouble(prhs[26]) || mxIsComplex(prhs[26]) || !(mxGetM(prhs[26])==1 && mxGetN(prhs[26])==1) ) { 
      mexErrMsgTxt("Input 26 must be a noncomplex scalar double.");
    } 
    mexinput26_temp = mxGetPr(prhs[26]); 
    double mexinput26 = *mexinput26_temp; 

    double *mexinput27_temp = NULL; 
    if( !mxIsDouble(prhs[27]) || mxIsComplex(prhs[27]) || !(mxGetM(prhs[27])==1 && mxGetN(prhs[27])==1) ) { 
      mexErrMsgTxt("Input 27 must be a noncomplex scalar double.");
    } 
    mexinput27_temp = mxGetPr(prhs[27]); 
    double mexinput27 = *mexinput27_temp; 

    double *mexinput28_temp = NULL; 
    if( !mxIsDouble(prhs[28]) || mxIsComplex(prhs[28]) || !(mxGetM(prhs[28])==1 && mxGetN(prhs[28])==1) ) { 
      mexErrMsgTxt("Input 28 must be a noncomplex scalar double.");
    } 
    mexinput28_temp = mxGetPr(prhs[28]); 
    double mexinput28 = *mexinput28_temp; 

    double *mexinput29_temp = NULL; 
    if( !mxIsDouble(prhs[29]) || mxIsComplex(prhs[29]) || !(mxGetM(prhs[29])==1 && mxGetN(prhs[29])==1) ) { 
      mexErrMsgTxt("Input 29 must be a noncomplex scalar double.");
    } 
    mexinput29_temp = mxGetPr(prhs[29]); 
    double mexinput29 = *mexinput29_temp; 

    double *mexinput30_temp = NULL; 
    if( !mxIsDouble(prhs[30]) || mxIsComplex(prhs[30]) || !(mxGetM(prhs[30])==1 && mxGetN(prhs[30])==1) ) { 
      mexErrMsgTxt("Input 30 must be a noncomplex scalar double.");
    } 
    mexinput30_temp = mxGetPr(prhs[30]); 
    double mexinput30 = *mexinput30_temp; 

    double *mexinput31_temp = NULL; 
    if( !mxIsDouble(prhs[31]) || mxIsComplex(prhs[31]) || !(mxGetM(prhs[31])==1 && mxGetN(prhs[31])==1) ) { 
      mexErrMsgTxt("Input 31 must be a noncomplex scalar double.");
    } 
    mexinput31_temp = mxGetPr(prhs[31]); 
    double mexinput31 = *mexinput31_temp; 

    double *mexinput32_temp = NULL; 
    if( !mxIsDouble(prhs[32]) || mxIsComplex(prhs[32]) || !(mxGetM(prhs[32])==1 && mxGetN(prhs[32])==1) ) { 
      mexErrMsgTxt("Input 32 must be a noncomplex scalar double.");
    } 
    mexinput32_temp = mxGetPr(prhs[32]); 
    double mexinput32 = *mexinput32_temp; 

    double *mexinput33_temp = NULL; 
    if( !mxIsDouble(prhs[33]) || mxIsComplex(prhs[33]) || !(mxGetM(prhs[33])==1 && mxGetN(prhs[33])==1) ) { 
      mexErrMsgTxt("Input 33 must be a noncomplex scalar double.");
    } 
    mexinput33_temp = mxGetPr(prhs[33]); 
    double mexinput33 = *mexinput33_temp; 

    double *mexinput34_temp = NULL; 
    if( !mxIsDouble(prhs[34]) || mxIsComplex(prhs[34]) || !(mxGetM(prhs[34])==1 && mxGetN(prhs[34])==1) ) { 
      mexErrMsgTxt("Input 34 must be a noncomplex scalar double.");
    } 
    mexinput34_temp = mxGetPr(prhs[34]); 
    double mexinput34 = *mexinput34_temp; 

    double *mexinput35_temp = NULL; 
    if( !mxIsDouble(prhs[35]) || mxIsComplex(prhs[35]) || !(mxGetM(prhs[35])==1 && mxGetN(prhs[35])==1) ) { 
      mexErrMsgTxt("Input 35 must be a noncomplex scalar double.");
    } 
    mexinput35_temp = mxGetPr(prhs[35]); 
    double mexinput35 = *mexinput35_temp; 

    double *mexinput36_temp = NULL; 
    if( !mxIsDouble(prhs[36]) || mxIsComplex(prhs[36]) || !(mxGetM(prhs[36])==1 && mxGetN(prhs[36])==1) ) { 
      mexErrMsgTxt("Input 36 must be a noncomplex scalar double.");
    } 
    mexinput36_temp = mxGetPr(prhs[36]); 
    double mexinput36 = *mexinput36_temp; 

    double *mexinput37_temp = NULL; 
    if( !mxIsDouble(prhs[37]) || mxIsComplex(prhs[37]) || !(mxGetM(prhs[37])==1 && mxGetN(prhs[37])==1) ) { 
      mexErrMsgTxt("Input 37 must be a noncomplex scalar double.");
    } 
    mexinput37_temp = mxGetPr(prhs[37]); 
    double mexinput37 = *mexinput37_temp; 

    double *mexinput38_temp = NULL; 
    if( !mxIsDouble(prhs[38]) || mxIsComplex(prhs[38]) || !(mxGetM(prhs[38])==1 && mxGetN(prhs[38])==1) ) { 
      mexErrMsgTxt("Input 38 must be a noncomplex scalar double.");
    } 
    mexinput38_temp = mxGetPr(prhs[38]); 
    double mexinput38 = *mexinput38_temp; 

    double *mexinput39_temp = NULL; 
    if( !mxIsDouble(prhs[39]) || mxIsComplex(prhs[39]) || !(mxGetM(prhs[39])==1 && mxGetN(prhs[39])==1) ) { 
      mexErrMsgTxt("Input 39 must be a noncomplex scalar double.");
    } 
    mexinput39_temp = mxGetPr(prhs[39]); 
    double mexinput39 = *mexinput39_temp; 

    double *mexinput40_temp = NULL; 
    if( !mxIsDouble(prhs[40]) || mxIsComplex(prhs[40]) || !(mxGetM(prhs[40])==1 && mxGetN(prhs[40])==1) ) { 
      mexErrMsgTxt("Input 40 must be a noncomplex scalar double.");
    } 
    mexinput40_temp = mxGetPr(prhs[40]); 
    double mexinput40 = *mexinput40_temp; 

    double *mexinput41_temp = NULL; 
    if( !mxIsDouble(prhs[41]) || mxIsComplex(prhs[41]) || !(mxGetM(prhs[41])==1 && mxGetN(prhs[41])==1) ) { 
      mexErrMsgTxt("Input 41 must be a noncomplex scalar double.");
    } 
    mexinput41_temp = mxGetPr(prhs[41]); 
    double mexinput41 = *mexinput41_temp; 

    double *mexinput42_temp = NULL; 
    if( !mxIsDouble(prhs[42]) || mxIsComplex(prhs[42]) || !(mxGetM(prhs[42])==1 && mxGetN(prhs[42])==1) ) { 
      mexErrMsgTxt("Input 42 must be a noncomplex scalar double.");
    } 
    mexinput42_temp = mxGetPr(prhs[42]); 
    double mexinput42 = *mexinput42_temp; 

    double *mexinput43_temp = NULL; 
    if( !mxIsDouble(prhs[43]) || mxIsComplex(prhs[43]) || !(mxGetM(prhs[43])==1 && mxGetN(prhs[43])==1) ) { 
      mexErrMsgTxt("Input 43 must be a noncomplex scalar double.");
    } 
    mexinput43_temp = mxGetPr(prhs[43]); 
    double mexinput43 = *mexinput43_temp; 

    double *mexinput44_temp = NULL; 
    if( !mxIsDouble(prhs[44]) || mxIsComplex(prhs[44]) || !(mxGetM(prhs[44])==1 && mxGetN(prhs[44])==1) ) { 
      mexErrMsgTxt("Input 44 must be a noncomplex scalar double.");
    } 
    mexinput44_temp = mxGetPr(prhs[44]); 
    double mexinput44 = *mexinput44_temp; 

    double *mexinput45_temp = NULL; 
    if( !mxIsDouble(prhs[45]) || mxIsComplex(prhs[45]) || !(mxGetM(prhs[45])==1 && mxGetN(prhs[45])==1) ) { 
      mexErrMsgTxt("Input 45 must be a noncomplex scalar double.");
    } 
    mexinput45_temp = mxGetPr(prhs[45]); 
    double mexinput45 = *mexinput45_temp; 

    double *mexinput46_temp = NULL; 
    if( !mxIsDouble(prhs[46]) || mxIsComplex(prhs[46]) || !(mxGetM(prhs[46])==1 && mxGetN(prhs[46])==1) ) { 
      mexErrMsgTxt("Input 46 must be a noncomplex scalar double.");
    } 
    mexinput46_temp = mxGetPr(prhs[46]); 
    double mexinput46 = *mexinput46_temp; 

    double *mexinput47_temp = NULL; 
    if( !mxIsDouble(prhs[47]) || mxIsComplex(prhs[47]) || !(mxGetM(prhs[47])==1 && mxGetN(prhs[47])==1) ) { 
      mexErrMsgTxt("Input 47 must be a noncomplex scalar double.");
    } 
    mexinput47_temp = mxGetPr(prhs[47]); 
    double mexinput47 = *mexinput47_temp; 

    double *mexinput48_temp = NULL; 
    if( !mxIsDouble(prhs[48]) || mxIsComplex(prhs[48]) || !(mxGetM(prhs[48])==1 && mxGetN(prhs[48])==1) ) { 
      mexErrMsgTxt("Input 48 must be a noncomplex scalar double.");
    } 
    mexinput48_temp = mxGetPr(prhs[48]); 
    double mexinput48 = *mexinput48_temp; 

    double *mexinput49_temp = NULL; 
    if( !mxIsDouble(prhs[49]) || mxIsComplex(prhs[49]) || !(mxGetM(prhs[49])==1 && mxGetN(prhs[49])==1) ) { 
      mexErrMsgTxt("Input 49 must be a noncomplex scalar double.");
    } 
    mexinput49_temp = mxGetPr(prhs[49]); 
    double mexinput49 = *mexinput49_temp; 

    double *mexinput50_temp = NULL; 
    if( !mxIsDouble(prhs[50]) || mxIsComplex(prhs[50]) || !(mxGetM(prhs[50])==1 && mxGetN(prhs[50])==1) ) { 
      mexErrMsgTxt("Input 50 must be a noncomplex scalar double.");
    } 
    mexinput50_temp = mxGetPr(prhs[50]); 
    double mexinput50 = *mexinput50_temp; 

    double *mexinput51_temp = NULL; 
    if( !mxIsDouble(prhs[51]) || mxIsComplex(prhs[51]) || !(mxGetM(prhs[51])==1 && mxGetN(prhs[51])==1) ) { 
      mexErrMsgTxt("Input 51 must be a noncomplex scalar double.");
    } 
    mexinput51_temp = mxGetPr(prhs[51]); 
    double mexinput51 = *mexinput51_temp; 

    double *mexinput52_temp = NULL; 
    if( !mxIsDouble(prhs[52]) || mxIsComplex(prhs[52]) || !(mxGetM(prhs[52])==1 && mxGetN(prhs[52])==1) ) { 
      mexErrMsgTxt("Input 52 must be a noncomplex scalar double.");
    } 
    mexinput52_temp = mxGetPr(prhs[52]); 
    double mexinput52 = *mexinput52_temp; 

    double *mexinput53_temp = NULL; 
    if( !mxIsDouble(prhs[53]) || mxIsComplex(prhs[53]) || !(mxGetM(prhs[53])==1 && mxGetN(prhs[53])==1) ) { 
      mexErrMsgTxt("Input 53 must be a noncomplex scalar double.");
    } 
    mexinput53_temp = mxGetPr(prhs[53]); 
    double mexinput53 = *mexinput53_temp; 

    double *mexinput54_temp = NULL; 
    if( !mxIsDouble(prhs[54]) || mxIsComplex(prhs[54]) || !(mxGetM(prhs[54])==1 && mxGetN(prhs[54])==1) ) { 
      mexErrMsgTxt("Input 54 must be a noncomplex scalar double.");
    } 
    mexinput54_temp = mxGetPr(prhs[54]); 
    double mexinput54 = *mexinput54_temp; 

    double *mexinput55_temp = NULL; 
    if( !mxIsDouble(prhs[55]) || mxIsComplex(prhs[55]) || !(mxGetM(prhs[55])==1 && mxGetN(prhs[55])==1) ) { 
      mexErrMsgTxt("Input 55 must be a noncomplex scalar double.");
    } 
    mexinput55_temp = mxGetPr(prhs[55]); 
    double mexinput55 = *mexinput55_temp; 

    double *mexinput56_temp = NULL; 
    if( !mxIsDouble(prhs[56]) || mxIsComplex(prhs[56]) || !(mxGetM(prhs[56])==1 && mxGetN(prhs[56])==1) ) { 
      mexErrMsgTxt("Input 56 must be a noncomplex scalar double.");
    } 
    mexinput56_temp = mxGetPr(prhs[56]); 
    double mexinput56 = *mexinput56_temp; 

    double *mexinput57_temp = NULL; 
    if( !mxIsDouble(prhs[57]) || mxIsComplex(prhs[57]) || !(mxGetM(prhs[57])==1 && mxGetN(prhs[57])==1) ) { 
      mexErrMsgTxt("Input 57 must be a noncomplex scalar double.");
    } 
    mexinput57_temp = mxGetPr(prhs[57]); 
    double mexinput57 = *mexinput57_temp; 

    double *mexinput58_temp = NULL; 
    if( !mxIsDouble(prhs[58]) || mxIsComplex(prhs[58]) || !(mxGetM(prhs[58])==1 && mxGetN(prhs[58])==1) ) { 
      mexErrMsgTxt("Input 58 must be a noncomplex scalar double.");
    } 
    mexinput58_temp = mxGetPr(prhs[58]); 
    double mexinput58 = *mexinput58_temp; 

    double *mexinput59_temp = NULL; 
    if( !mxIsDouble(prhs[59]) || mxIsComplex(prhs[59]) || !(mxGetM(prhs[59])==1 && mxGetN(prhs[59])==1) ) { 
      mexErrMsgTxt("Input 59 must be a noncomplex scalar double.");
    } 
    mexinput59_temp = mxGetPr(prhs[59]); 
    double mexinput59 = *mexinput59_temp; 

    double *mexinput60_temp = NULL; 
    if( !mxIsDouble(prhs[60]) || mxIsComplex(prhs[60]) || !(mxGetM(prhs[60])==1 && mxGetN(prhs[60])==1) ) { 
      mexErrMsgTxt("Input 60 must be a noncomplex scalar double.");
    } 
    mexinput60_temp = mxGetPr(prhs[60]); 
    double mexinput60 = *mexinput60_temp; 

    double *mexinput61_temp = NULL; 
    if( !mxIsDouble(prhs[61]) || mxIsComplex(prhs[61]) || !(mxGetM(prhs[61])==1 && mxGetN(prhs[61])==1) ) { 
      mexErrMsgTxt("Input 61 must be a noncomplex scalar double.");
    } 
    mexinput61_temp = mxGetPr(prhs[61]); 
    double mexinput61 = *mexinput61_temp; 

    double *mexinput62_temp = NULL; 
    if( !mxIsDouble(prhs[62]) || mxIsComplex(prhs[62]) || !(mxGetM(prhs[62])==1 && mxGetN(prhs[62])==1) ) { 
      mexErrMsgTxt("Input 62 must be a noncomplex scalar double.");
    } 
    mexinput62_temp = mxGetPr(prhs[62]); 
    double mexinput62 = *mexinput62_temp; 

    double *mexinput63_temp = NULL; 
    if( !mxIsDouble(prhs[63]) || mxIsComplex(prhs[63]) || !(mxGetM(prhs[63])==1 && mxGetN(prhs[63])==1) ) { 
      mexErrMsgTxt("Input 63 must be a noncomplex scalar double.");
    } 
    mexinput63_temp = mxGetPr(prhs[63]); 
    double mexinput63 = *mexinput63_temp; 

    double *mexinput64_temp = NULL; 
    if( !mxIsDouble(prhs[64]) || mxIsComplex(prhs[64]) || !(mxGetM(prhs[64])==1 && mxGetN(prhs[64])==1) ) { 
      mexErrMsgTxt("Input 64 must be a noncomplex scalar double.");
    } 
    mexinput64_temp = mxGetPr(prhs[64]); 
    double mexinput64 = *mexinput64_temp; 

    double *mexinput65_temp = NULL; 
    if( !mxIsDouble(prhs[65]) || mxIsComplex(prhs[65]) || !(mxGetM(prhs[65])==1 && mxGetN(prhs[65])==1) ) { 
      mexErrMsgTxt("Input 65 must be a noncomplex scalar double.");
    } 
    mexinput65_temp = mxGetPr(prhs[65]); 
    double mexinput65 = *mexinput65_temp; 

    double *mexinput66_temp = NULL; 
    if( !mxIsDouble(prhs[66]) || mxIsComplex(prhs[66]) || !(mxGetM(prhs[66])==1 && mxGetN(prhs[66])==1) ) { 
      mexErrMsgTxt("Input 66 must be a noncomplex scalar double.");
    } 
    mexinput66_temp = mxGetPr(prhs[66]); 
    double mexinput66 = *mexinput66_temp; 

    double *mexinput67_temp = NULL; 
    if( !mxIsDouble(prhs[67]) || mxIsComplex(prhs[67]) || !(mxGetM(prhs[67])==1 && mxGetN(prhs[67])==1) ) { 
      mexErrMsgTxt("Input 67 must be a noncomplex scalar double.");
    } 
    mexinput67_temp = mxGetPr(prhs[67]); 
    double mexinput67 = *mexinput67_temp; 

    double *mexinput68_temp = NULL; 
    if( !mxIsDouble(prhs[68]) || mxIsComplex(prhs[68]) || !(mxGetM(prhs[68])==1 && mxGetN(prhs[68])==1) ) { 
      mexErrMsgTxt("Input 68 must be a noncomplex scalar double.");
    } 
    mexinput68_temp = mxGetPr(prhs[68]); 
    double mexinput68 = *mexinput68_temp; 

    double *mexinput69_temp = NULL; 
    if( !mxIsDouble(prhs[69]) || mxIsComplex(prhs[69]) || !(mxGetM(prhs[69])==1 && mxGetN(prhs[69])==1) ) { 
      mexErrMsgTxt("Input 69 must be a noncomplex scalar double.");
    } 
    mexinput69_temp = mxGetPr(prhs[69]); 
    double mexinput69 = *mexinput69_temp; 

    double *mexinput70_temp = NULL; 
    if( !mxIsDouble(prhs[70]) || mxIsComplex(prhs[70]) || !(mxGetM(prhs[70])==1 && mxGetN(prhs[70])==1) ) { 
      mexErrMsgTxt("Input 70 must be a noncomplex scalar double.");
    } 
    mexinput70_temp = mxGetPr(prhs[70]); 
    double mexinput70 = *mexinput70_temp; 

    double *mexinput71_temp = NULL; 
    if( !mxIsDouble(prhs[71]) || mxIsComplex(prhs[71]) || !(mxGetM(prhs[71])==1 && mxGetN(prhs[71])==1) ) { 
      mexErrMsgTxt("Input 71 must be a noncomplex scalar double.");
    } 
    mexinput71_temp = mxGetPr(prhs[71]); 
    double mexinput71 = *mexinput71_temp; 

    double *mexinput72_temp = NULL; 
    if( !mxIsDouble(prhs[72]) || mxIsComplex(prhs[72]) || !(mxGetM(prhs[72])==1 && mxGetN(prhs[72])==1) ) { 
      mexErrMsgTxt("Input 72 must be a noncomplex scalar double.");
    } 
    mexinput72_temp = mxGetPr(prhs[72]); 
    double mexinput72 = *mexinput72_temp; 

    double *mexinput73_temp = NULL; 
    if( !mxIsDouble(prhs[73]) || mxIsComplex(prhs[73]) || !(mxGetM(prhs[73])==1 && mxGetN(prhs[73])==1) ) { 
      mexErrMsgTxt("Input 73 must be a noncomplex scalar double.");
    } 
    mexinput73_temp = mxGetPr(prhs[73]); 
    double mexinput73 = *mexinput73_temp; 

    double *mexinput74_temp = NULL; 
    if( !mxIsDouble(prhs[74]) || mxIsComplex(prhs[74]) || !(mxGetM(prhs[74])==1 && mxGetN(prhs[74])==1) ) { 
      mexErrMsgTxt("Input 74 must be a noncomplex scalar double.");
    } 
    mexinput74_temp = mxGetPr(prhs[74]); 
    double mexinput74 = *mexinput74_temp; 

    double *mexinput75_temp = NULL; 
    if( !mxIsDouble(prhs[75]) || mxIsComplex(prhs[75]) || !(mxGetM(prhs[75])==1 && mxGetN(prhs[75])==1) ) { 
      mexErrMsgTxt("Input 75 must be a noncomplex scalar double.");
    } 
    mexinput75_temp = mxGetPr(prhs[75]); 
    double mexinput75 = *mexinput75_temp; 

    double *mexinput76_temp = NULL; 
    if( !mxIsDouble(prhs[76]) || mxIsComplex(prhs[76]) || !(mxGetM(prhs[76])==1 && mxGetN(prhs[76])==1) ) { 
      mexErrMsgTxt("Input 76 must be a noncomplex scalar double.");
    } 
    mexinput76_temp = mxGetPr(prhs[76]); 
    double mexinput76 = *mexinput76_temp; 

    double *mexinput77_temp = NULL; 
    if( !mxIsDouble(prhs[77]) || mxIsComplex(prhs[77]) || !(mxGetM(prhs[77])==1 && mxGetN(prhs[77])==1) ) { 
      mexErrMsgTxt("Input 77 must be a noncomplex scalar double.");
    } 
    mexinput77_temp = mxGetPr(prhs[77]); 
    double mexinput77 = *mexinput77_temp; 

    double *mexinput78_temp = NULL; 
    if( !mxIsDouble(prhs[78]) || mxIsComplex(prhs[78]) || !(mxGetM(prhs[78])==1 && mxGetN(prhs[78])==1) ) { 
      mexErrMsgTxt("Input 78 must be a noncomplex scalar double.");
    } 
    mexinput78_temp = mxGetPr(prhs[78]); 
    double mexinput78 = *mexinput78_temp; 

    double *mexinput79_temp = NULL; 
    if( !mxIsDouble(prhs[79]) || mxIsComplex(prhs[79]) || !(mxGetM(prhs[79])==1 && mxGetN(prhs[79])==1) ) { 
      mexErrMsgTxt("Input 79 must be a noncomplex scalar double.");
    } 
    mexinput79_temp = mxGetPr(prhs[79]); 
    double mexinput79 = *mexinput79_temp; 

    double *mexinput80_temp = NULL; 
    if( !mxIsDouble(prhs[80]) || mxIsComplex(prhs[80]) || !(mxGetM(prhs[80])==1 && mxGetN(prhs[80])==1) ) { 
      mexErrMsgTxt("Input 80 must be a noncomplex scalar double.");
    } 
    mexinput80_temp = mxGetPr(prhs[80]); 
    double mexinput80 = *mexinput80_temp; 

    double *mexinput81_temp = NULL; 
    if( !mxIsDouble(prhs[81]) || mxIsComplex(prhs[81]) || !(mxGetM(prhs[81])==1 && mxGetN(prhs[81])==1) ) { 
      mexErrMsgTxt("Input 81 must be a noncomplex scalar double.");
    } 
    mexinput81_temp = mxGetPr(prhs[81]); 
    double mexinput81 = *mexinput81_temp; 

    double *mexinput82_temp = NULL; 
    if( !mxIsDouble(prhs[82]) || mxIsComplex(prhs[82]) || !(mxGetM(prhs[82])==1 && mxGetN(prhs[82])==1) ) { 
      mexErrMsgTxt("Input 82 must be a noncomplex scalar double.");
    } 
    mexinput82_temp = mxGetPr(prhs[82]); 
    double mexinput82 = *mexinput82_temp; 

    double *mexinput83_temp = NULL; 
    if( !mxIsDouble(prhs[83]) || mxIsComplex(prhs[83]) || !(mxGetM(prhs[83])==1 && mxGetN(prhs[83])==1) ) { 
      mexErrMsgTxt("Input 83 must be a noncomplex scalar double.");
    } 
    mexinput83_temp = mxGetPr(prhs[83]); 
    double mexinput83 = *mexinput83_temp; 

    double *mexinput84_temp = NULL; 
    if( !mxIsDouble(prhs[84]) || mxIsComplex(prhs[84]) || !(mxGetM(prhs[84])==1 && mxGetN(prhs[84])==1) ) { 
      mexErrMsgTxt("Input 84 must be a noncomplex scalar double.");
    } 
    mexinput84_temp = mxGetPr(prhs[84]); 
    double mexinput84 = *mexinput84_temp; 

    double *mexinput85_temp = NULL; 
    if( !mxIsDouble(prhs[85]) || mxIsComplex(prhs[85]) || !(mxGetM(prhs[85])==1 && mxGetN(prhs[85])==1) ) { 
      mexErrMsgTxt("Input 85 must be a noncomplex scalar double.");
    } 
    mexinput85_temp = mxGetPr(prhs[85]); 
    double mexinput85 = *mexinput85_temp; 

    double *mexinput86_temp = NULL; 
    if( !mxIsDouble(prhs[86]) || mxIsComplex(prhs[86]) || !(mxGetM(prhs[86])==1 && mxGetN(prhs[86])==1) ) { 
      mexErrMsgTxt("Input 86 must be a noncomplex scalar double.");
    } 
    mexinput86_temp = mxGetPr(prhs[86]); 
    double mexinput86 = *mexinput86_temp; 

    double *mexinput87_temp = NULL; 
    if( !mxIsDouble(prhs[87]) || mxIsComplex(prhs[87]) || !(mxGetM(prhs[87])==1 && mxGetN(prhs[87])==1) ) { 
      mexErrMsgTxt("Input 87 must be a noncomplex scalar double.");
    } 
    mexinput87_temp = mxGetPr(prhs[87]); 
    double mexinput87 = *mexinput87_temp; 

    double *mexinput88_temp = NULL; 
    if( !mxIsDouble(prhs[88]) || mxIsComplex(prhs[88]) || !(mxGetM(prhs[88])==1 && mxGetN(prhs[88])==1) ) { 
      mexErrMsgTxt("Input 88 must be a noncomplex scalar double.");
    } 
    mexinput88_temp = mxGetPr(prhs[88]); 
    double mexinput88 = *mexinput88_temp; 

    double *mexinput89_temp = NULL; 
    if( !mxIsDouble(prhs[89]) || mxIsComplex(prhs[89]) || !(mxGetM(prhs[89])==1 && mxGetN(prhs[89])==1) ) { 
      mexErrMsgTxt("Input 89 must be a noncomplex scalar double.");
    } 
    mexinput89_temp = mxGetPr(prhs[89]); 
    double mexinput89 = *mexinput89_temp; 

    double *mexinput90_temp = NULL; 
    if( !mxIsDouble(prhs[90]) || mxIsComplex(prhs[90]) || !(mxGetM(prhs[90])==1 && mxGetN(prhs[90])==1) ) { 
      mexErrMsgTxt("Input 90 must be a noncomplex scalar double.");
    } 
    mexinput90_temp = mxGetPr(prhs[90]); 
    double mexinput90 = *mexinput90_temp; 

    double *mexinput91_temp = NULL; 
    if( !mxIsDouble(prhs[91]) || mxIsComplex(prhs[91]) || !(mxGetM(prhs[91])==1 && mxGetN(prhs[91])==1) ) { 
      mexErrMsgTxt("Input 91 must be a noncomplex scalar double.");
    } 
    mexinput91_temp = mxGetPr(prhs[91]); 
    double mexinput91 = *mexinput91_temp; 

    double *mexinput92_temp = NULL; 
    if( !mxIsDouble(prhs[92]) || mxIsComplex(prhs[92]) || !(mxGetM(prhs[92])==1 && mxGetN(prhs[92])==1) ) { 
      mexErrMsgTxt("Input 92 must be a noncomplex scalar double.");
    } 
    mexinput92_temp = mxGetPr(prhs[92]); 
    double mexinput92 = *mexinput92_temp; 

    double *mexinput93_temp = NULL; 
    if( !mxIsDouble(prhs[93]) || mxIsComplex(prhs[93]) || !(mxGetM(prhs[93])==1 && mxGetN(prhs[93])==1) ) { 
      mexErrMsgTxt("Input 93 must be a noncomplex scalar double.");
    } 
    mexinput93_temp = mxGetPr(prhs[93]); 
    double mexinput93 = *mexinput93_temp; 

    double *mexinput94_temp = NULL; 
    if( !mxIsDouble(prhs[94]) || mxIsComplex(prhs[94]) || !(mxGetM(prhs[94])==1 && mxGetN(prhs[94])==1) ) { 
      mexErrMsgTxt("Input 94 must be a noncomplex scalar double.");
    } 
    mexinput94_temp = mxGetPr(prhs[94]); 
    double mexinput94 = *mexinput94_temp; 

    double *mexinput95_temp = NULL; 
    if( !mxIsDouble(prhs[95]) || mxIsComplex(prhs[95]) || !(mxGetM(prhs[95])==1 && mxGetN(prhs[95])==1) ) { 
      mexErrMsgTxt("Input 95 must be a noncomplex scalar double.");
    } 
    mexinput95_temp = mxGetPr(prhs[95]); 
    double mexinput95 = *mexinput95_temp; 

    double *mexinput96_temp = NULL; 
    if( !mxIsDouble(prhs[96]) || mxIsComplex(prhs[96]) || !(mxGetM(prhs[96])==1 && mxGetN(prhs[96])==1) ) { 
      mexErrMsgTxt("Input 96 must be a noncomplex scalar double.");
    } 
    mexinput96_temp = mxGetPr(prhs[96]); 
    double mexinput96 = *mexinput96_temp; 

    double *mexinput97_temp = NULL; 
    if( !mxIsDouble(prhs[97]) || mxIsComplex(prhs[97]) || !(mxGetM(prhs[97])==1 && mxGetN(prhs[97])==1) ) { 
      mexErrMsgTxt("Input 97 must be a noncomplex scalar double.");
    } 
    mexinput97_temp = mxGetPr(prhs[97]); 
    double mexinput97 = *mexinput97_temp; 

    double *mexinput98_temp = NULL; 
    if( !mxIsDouble(prhs[98]) || mxIsComplex(prhs[98]) || !(mxGetM(prhs[98])==1 && mxGetN(prhs[98])==1) ) { 
      mexErrMsgTxt("Input 98 must be a noncomplex scalar double.");
    } 
    mexinput98_temp = mxGetPr(prhs[98]); 
    double mexinput98 = *mexinput98_temp; 

    double *mexinput99_temp = NULL; 
    if( !mxIsDouble(prhs[99]) || mxIsComplex(prhs[99]) || !(mxGetM(prhs[99])==1 && mxGetN(prhs[99])==1) ) { 
      mexErrMsgTxt("Input 99 must be a noncomplex scalar double.");
    } 
    mexinput99_temp = mxGetPr(prhs[99]); 
    double mexinput99 = *mexinput99_temp; 

    double *mexinput100_temp = NULL; 
    if( !mxIsDouble(prhs[100]) || mxIsComplex(prhs[100]) || !(mxGetM(prhs[100])==1 && mxGetN(prhs[100])==1) ) { 
      mexErrMsgTxt("Input 100 must be a noncomplex scalar double.");
    } 
    mexinput100_temp = mxGetPr(prhs[100]); 
    double mexinput100 = *mexinput100_temp; 

    double *mexinput101_temp = NULL; 
    if( !mxIsDouble(prhs[101]) || mxIsComplex(prhs[101]) || !(mxGetM(prhs[101])==1 && mxGetN(prhs[101])==1) ) { 
      mexErrMsgTxt("Input 101 must be a noncomplex scalar double.");
    } 
    mexinput101_temp = mxGetPr(prhs[101]); 
    double mexinput101 = *mexinput101_temp; 

    double *mexinput102_temp = NULL; 
    if( !mxIsDouble(prhs[102]) || mxIsComplex(prhs[102]) || !(mxGetM(prhs[102])==1 && mxGetN(prhs[102])==1) ) { 
      mexErrMsgTxt("Input 102 must be a noncomplex scalar double.");
    } 
    mexinput102_temp = mxGetPr(prhs[102]); 
    double mexinput102 = *mexinput102_temp; 

    double *mexinput103_temp = NULL; 
    if( !mxIsDouble(prhs[103]) || mxIsComplex(prhs[103]) || !(mxGetM(prhs[103])==1 && mxGetN(prhs[103])==1) ) { 
      mexErrMsgTxt("Input 103 must be a noncomplex scalar double.");
    } 
    mexinput103_temp = mxGetPr(prhs[103]); 
    double mexinput103 = *mexinput103_temp; 

    double *mexinput104_temp = NULL; 
    if( !mxIsDouble(prhs[104]) || mxIsComplex(prhs[104]) || !(mxGetM(prhs[104])==1 && mxGetN(prhs[104])==1) ) { 
      mexErrMsgTxt("Input 104 must be a noncomplex scalar double.");
    } 
    mexinput104_temp = mxGetPr(prhs[104]); 
    double mexinput104 = *mexinput104_temp; 

    double *mexinput105_temp = NULL; 
    if( !mxIsDouble(prhs[105]) || mxIsComplex(prhs[105]) || !(mxGetM(prhs[105])==1 && mxGetN(prhs[105])==1) ) { 
      mexErrMsgTxt("Input 105 must be a noncomplex scalar double.");
    } 
    mexinput105_temp = mxGetPr(prhs[105]); 
    double mexinput105 = *mexinput105_temp; 

    double *mexinput106_temp = NULL; 
    if( !mxIsDouble(prhs[106]) || mxIsComplex(prhs[106]) || !(mxGetM(prhs[106])==1 && mxGetN(prhs[106])==1) ) { 
      mexErrMsgTxt("Input 106 must be a noncomplex scalar double.");
    } 
    mexinput106_temp = mxGetPr(prhs[106]); 
    double mexinput106 = *mexinput106_temp; 

    double *mexinput107_temp = NULL; 
    if( !mxIsDouble(prhs[107]) || mxIsComplex(prhs[107]) || !(mxGetM(prhs[107])==1 && mxGetN(prhs[107])==1) ) { 
      mexErrMsgTxt("Input 107 must be a noncomplex scalar double.");
    } 
    mexinput107_temp = mxGetPr(prhs[107]); 
    double mexinput107 = *mexinput107_temp; 

    double *mexinput108_temp = NULL; 
    if( !mxIsDouble(prhs[108]) || mxIsComplex(prhs[108]) || !(mxGetM(prhs[108])==1 && mxGetN(prhs[108])==1) ) { 
      mexErrMsgTxt("Input 108 must be a noncomplex scalar double.");
    } 
    mexinput108_temp = mxGetPr(prhs[108]); 
    double mexinput108 = *mexinput108_temp; 

    double *mexinput109_temp = NULL; 
    if( !mxIsDouble(prhs[109]) || mxIsComplex(prhs[109]) || !(mxGetM(prhs[109])==1 && mxGetN(prhs[109])==1) ) { 
      mexErrMsgTxt("Input 109 must be a noncomplex scalar double.");
    } 
    mexinput109_temp = mxGetPr(prhs[109]); 
    double mexinput109 = *mexinput109_temp; 

    double *mexinput110_temp = NULL; 
    if( !mxIsDouble(prhs[110]) || mxIsComplex(prhs[110]) || !(mxGetM(prhs[110])==1 && mxGetN(prhs[110])==1) ) { 
      mexErrMsgTxt("Input 110 must be a noncomplex scalar double.");
    } 
    mexinput110_temp = mxGetPr(prhs[110]); 
    double mexinput110 = *mexinput110_temp; 

    double *mexinput111_temp = NULL; 
    if( !mxIsDouble(prhs[111]) || mxIsComplex(prhs[111]) || !(mxGetM(prhs[111])==1 && mxGetN(prhs[111])==1) ) { 
      mexErrMsgTxt("Input 111 must be a noncomplex scalar double.");
    } 
    mexinput111_temp = mxGetPr(prhs[111]); 
    double mexinput111 = *mexinput111_temp; 

    double *mexinput112_temp = NULL; 
    if( !mxIsDouble(prhs[112]) || mxIsComplex(prhs[112]) || !(mxGetM(prhs[112])==1 && mxGetN(prhs[112])==1) ) { 
      mexErrMsgTxt("Input 112 must be a noncomplex scalar double.");
    } 
    mexinput112_temp = mxGetPr(prhs[112]); 
    double mexinput112 = *mexinput112_temp; 

    double *mexinput113_temp = NULL; 
    if( !mxIsDouble(prhs[113]) || mxIsComplex(prhs[113]) || !(mxGetM(prhs[113])==1 && mxGetN(prhs[113])==1) ) { 
      mexErrMsgTxt("Input 113 must be a noncomplex scalar double.");
    } 
    mexinput113_temp = mxGetPr(prhs[113]); 
    double mexinput113 = *mexinput113_temp; 

    double *mexinput114_temp = NULL; 
    if( !mxIsDouble(prhs[114]) || mxIsComplex(prhs[114]) || !(mxGetM(prhs[114])==1 && mxGetN(prhs[114])==1) ) { 
      mexErrMsgTxt("Input 114 must be a noncomplex scalar double.");
    } 
    mexinput114_temp = mxGetPr(prhs[114]); 
    double mexinput114 = *mexinput114_temp; 

    double *mexinput115_temp = NULL; 
    if( !mxIsDouble(prhs[115]) || mxIsComplex(prhs[115]) || !(mxGetM(prhs[115])==1 && mxGetN(prhs[115])==1) ) { 
      mexErrMsgTxt("Input 115 must be a noncomplex scalar double.");
    } 
    mexinput115_temp = mxGetPr(prhs[115]); 
    double mexinput115 = *mexinput115_temp; 

    double *mexinput116_temp = NULL; 
    if( !mxIsDouble(prhs[116]) || mxIsComplex(prhs[116]) || !(mxGetM(prhs[116])==1 && mxGetN(prhs[116])==1) ) { 
      mexErrMsgTxt("Input 116 must be a noncomplex scalar double.");
    } 
    mexinput116_temp = mxGetPr(prhs[116]); 
    double mexinput116 = *mexinput116_temp; 

    double *mexinput117_temp = NULL; 
    if( !mxIsDouble(prhs[117]) || mxIsComplex(prhs[117]) || !(mxGetM(prhs[117])==1 && mxGetN(prhs[117])==1) ) { 
      mexErrMsgTxt("Input 117 must be a noncomplex scalar double.");
    } 
    mexinput117_temp = mxGetPr(prhs[117]); 
    double mexinput117 = *mexinput117_temp; 

    double *mexinput118_temp = NULL; 
    if( !mxIsDouble(prhs[118]) || mxIsComplex(prhs[118]) || !(mxGetM(prhs[118])==1 && mxGetN(prhs[118])==1) ) { 
      mexErrMsgTxt("Input 118 must be a noncomplex scalar double.");
    } 
    mexinput118_temp = mxGetPr(prhs[118]); 
    double mexinput118 = *mexinput118_temp; 

    double *mexinput119_temp = NULL; 
    if( !mxIsDouble(prhs[119]) || mxIsComplex(prhs[119]) || !(mxGetM(prhs[119])==1 && mxGetN(prhs[119])==1) ) { 
      mexErrMsgTxt("Input 119 must be a noncomplex scalar double.");
    } 
    mexinput119_temp = mxGetPr(prhs[119]); 
    double mexinput119 = *mexinput119_temp; 

    double *mexinput120_temp = NULL; 
    if( !mxIsDouble(prhs[120]) || mxIsComplex(prhs[120]) || !(mxGetM(prhs[120])==1 && mxGetN(prhs[120])==1) ) { 
      mexErrMsgTxt("Input 120 must be a noncomplex scalar double.");
    } 
    mexinput120_temp = mxGetPr(prhs[120]); 
    double mexinput120 = *mexinput120_temp; 

    double *mexinput121_temp = NULL; 
    if( !mxIsDouble(prhs[121]) || mxIsComplex(prhs[121]) || !(mxGetM(prhs[121])==1 && mxGetN(prhs[121])==1) ) { 
      mexErrMsgTxt("Input 121 must be a noncomplex scalar double.");
    } 
    mexinput121_temp = mxGetPr(prhs[121]); 
    double mexinput121 = *mexinput121_temp; 

    double *mexinput122_temp = NULL; 
    if( !mxIsDouble(prhs[122]) || mxIsComplex(prhs[122]) || !(mxGetM(prhs[122])==1 && mxGetN(prhs[122])==1) ) { 
      mexErrMsgTxt("Input 122 must be a noncomplex scalar double.");
    } 
    mexinput122_temp = mxGetPr(prhs[122]); 
    double mexinput122 = *mexinput122_temp; 

    double *mexinput123_temp = NULL; 
    if( !mxIsDouble(prhs[123]) || mxIsComplex(prhs[123]) || !(mxGetM(prhs[123])==1 && mxGetN(prhs[123])==1) ) { 
      mexErrMsgTxt("Input 123 must be a noncomplex scalar double.");
    } 
    mexinput123_temp = mxGetPr(prhs[123]); 
    double mexinput123 = *mexinput123_temp; 

    double *mexinput124_temp = NULL; 
    if( !mxIsDouble(prhs[124]) || mxIsComplex(prhs[124]) || !(mxGetM(prhs[124])==1 && mxGetN(prhs[124])==1) ) { 
      mexErrMsgTxt("Input 124 must be a noncomplex scalar double.");
    } 
    mexinput124_temp = mxGetPr(prhs[124]); 
    double mexinput124 = *mexinput124_temp; 

    double *mexinput125_temp = NULL; 
    if( !mxIsDouble(prhs[125]) || mxIsComplex(prhs[125]) || !(mxGetM(prhs[125])==1 && mxGetN(prhs[125])==1) ) { 
      mexErrMsgTxt("Input 125 must be a noncomplex scalar double.");
    } 
    mexinput125_temp = mxGetPr(prhs[125]); 
    double mexinput125 = *mexinput125_temp; 

    double *mexinput126_temp = NULL; 
    if( !mxIsDouble(prhs[126]) || mxIsComplex(prhs[126]) || !(mxGetM(prhs[126])==1 && mxGetN(prhs[126])==1) ) { 
      mexErrMsgTxt("Input 126 must be a noncomplex scalar double.");
    } 
    mexinput126_temp = mxGetPr(prhs[126]); 
    double mexinput126 = *mexinput126_temp; 

    double *mexinput127_temp = NULL; 
    if( !mxIsDouble(prhs[127]) || mxIsComplex(prhs[127]) || !(mxGetM(prhs[127])==1 && mxGetN(prhs[127])==1) ) { 
      mexErrMsgTxt("Input 127 must be a noncomplex scalar double.");
    } 
    mexinput127_temp = mxGetPr(prhs[127]); 
    double mexinput127 = *mexinput127_temp; 

    double *mexinput128_temp = NULL; 
    if( !mxIsDouble(prhs[128]) || mxIsComplex(prhs[128]) || !(mxGetM(prhs[128])==1 && mxGetN(prhs[128])==1) ) { 
      mexErrMsgTxt("Input 128 must be a noncomplex scalar double.");
    } 
    mexinput128_temp = mxGetPr(prhs[128]); 
    double mexinput128 = *mexinput128_temp; 

    double *mexinput129_temp = NULL; 
    if( !mxIsDouble(prhs[129]) || mxIsComplex(prhs[129]) || !(mxGetM(prhs[129])==1 && mxGetN(prhs[129])==1) ) { 
      mexErrMsgTxt("Input 129 must be a noncomplex scalar double.");
    } 
    mexinput129_temp = mxGetPr(prhs[129]); 
    double mexinput129 = *mexinput129_temp; 

    double *mexinput130_temp = NULL; 
    if( !mxIsDouble(prhs[130]) || mxIsComplex(prhs[130]) || !(mxGetM(prhs[130])==1 && mxGetN(prhs[130])==1) ) { 
      mexErrMsgTxt("Input 130 must be a noncomplex scalar double.");
    } 
    mexinput130_temp = mxGetPr(prhs[130]); 
    double mexinput130 = *mexinput130_temp; 

    double *mexinput131_temp = NULL; 
    if( !mxIsDouble(prhs[131]) || mxIsComplex(prhs[131]) || !(mxGetM(prhs[131])==1 && mxGetN(prhs[131])==1) ) { 
      mexErrMsgTxt("Input 131 must be a noncomplex scalar double.");
    } 
    mexinput131_temp = mxGetPr(prhs[131]); 
    double mexinput131 = *mexinput131_temp; 

    double *mexinput132_temp = NULL; 
    if( !mxIsDouble(prhs[132]) || mxIsComplex(prhs[132]) || !(mxGetM(prhs[132])==1 && mxGetN(prhs[132])==1) ) { 
      mexErrMsgTxt("Input 132 must be a noncomplex scalar double.");
    } 
    mexinput132_temp = mxGetPr(prhs[132]); 
    double mexinput132 = *mexinput132_temp; 

    double *mexinput133_temp = NULL; 
    if( !mxIsDouble(prhs[133]) || mxIsComplex(prhs[133]) || !(mxGetM(prhs[133])==1 && mxGetN(prhs[133])==1) ) { 
      mexErrMsgTxt("Input 133 must be a noncomplex scalar double.");
    } 
    mexinput133_temp = mxGetPr(prhs[133]); 
    double mexinput133 = *mexinput133_temp; 

    double *mexinput134_temp = NULL; 
    if( !mxIsDouble(prhs[134]) || mxIsComplex(prhs[134]) || !(mxGetM(prhs[134])==1 && mxGetN(prhs[134])==1) ) { 
      mexErrMsgTxt("Input 134 must be a noncomplex scalar double.");
    } 
    mexinput134_temp = mxGetPr(prhs[134]); 
    double mexinput134 = *mexinput134_temp; 

    double *mexinput135_temp = NULL; 
    if( !mxIsDouble(prhs[135]) || mxIsComplex(prhs[135]) || !(mxGetM(prhs[135])==1 && mxGetN(prhs[135])==1) ) { 
      mexErrMsgTxt("Input 135 must be a noncomplex scalar double.");
    } 
    mexinput135_temp = mxGetPr(prhs[135]); 
    double mexinput135 = *mexinput135_temp; 

    double *mexinput136_temp = NULL; 
    if( !mxIsDouble(prhs[136]) || mxIsComplex(prhs[136]) || !(mxGetM(prhs[136])==1 && mxGetN(prhs[136])==1) ) { 
      mexErrMsgTxt("Input 136 must be a noncomplex scalar double.");
    } 
    mexinput136_temp = mxGetPr(prhs[136]); 
    double mexinput136 = *mexinput136_temp; 

    double *mexinput137_temp = NULL; 
    if( !mxIsDouble(prhs[137]) || mxIsComplex(prhs[137]) || !(mxGetM(prhs[137])==1 && mxGetN(prhs[137])==1) ) { 
      mexErrMsgTxt("Input 137 must be a noncomplex scalar double.");
    } 
    mexinput137_temp = mxGetPr(prhs[137]); 
    double mexinput137 = *mexinput137_temp; 

    double *mexinput138_temp = NULL; 
    if( !mxIsDouble(prhs[138]) || mxIsComplex(prhs[138]) || !(mxGetM(prhs[138])==1 && mxGetN(prhs[138])==1) ) { 
      mexErrMsgTxt("Input 138 must be a noncomplex scalar double.");
    } 
    mexinput138_temp = mxGetPr(prhs[138]); 
    double mexinput138 = *mexinput138_temp; 

    double *mexinput139_temp = NULL; 
    if( !mxIsDouble(prhs[139]) || mxIsComplex(prhs[139]) || !(mxGetM(prhs[139])==1 && mxGetN(prhs[139])==1) ) { 
      mexErrMsgTxt("Input 139 must be a noncomplex scalar double.");
    } 
    mexinput139_temp = mxGetPr(prhs[139]); 
    double mexinput139 = *mexinput139_temp; 

    double *mexinput140_temp = NULL; 
    if( !mxIsDouble(prhs[140]) || mxIsComplex(prhs[140]) || !(mxGetM(prhs[140])==1 && mxGetN(prhs[140])==1) ) { 
      mexErrMsgTxt("Input 140 must be a noncomplex scalar double.");
    } 
    mexinput140_temp = mxGetPr(prhs[140]); 
    double mexinput140 = *mexinput140_temp; 

    double *mexinput141_temp = NULL; 
    if( !mxIsDouble(prhs[141]) || mxIsComplex(prhs[141]) || !(mxGetM(prhs[141])==1 && mxGetN(prhs[141])==1) ) { 
      mexErrMsgTxt("Input 141 must be a noncomplex scalar double.");
    } 
    mexinput141_temp = mxGetPr(prhs[141]); 
    double mexinput141 = *mexinput141_temp; 

    double *mexinput142_temp = NULL; 
    if( !mxIsDouble(prhs[142]) || mxIsComplex(prhs[142]) || !(mxGetM(prhs[142])==1 && mxGetN(prhs[142])==1) ) { 
      mexErrMsgTxt("Input 142 must be a noncomplex scalar double.");
    } 
    mexinput142_temp = mxGetPr(prhs[142]); 
    double mexinput142 = *mexinput142_temp; 

    double *mexinput143_temp = NULL; 
    if( !mxIsDouble(prhs[143]) || mxIsComplex(prhs[143]) || !(mxGetM(prhs[143])==1 && mxGetN(prhs[143])==1) ) { 
      mexErrMsgTxt("Input 143 must be a noncomplex scalar double.");
    } 
    mexinput143_temp = mxGetPr(prhs[143]); 
    double mexinput143 = *mexinput143_temp; 

    double *mexinput144_temp = NULL; 
    if( !mxIsDouble(prhs[144]) || mxIsComplex(prhs[144]) || !(mxGetM(prhs[144])==1 && mxGetN(prhs[144])==1) ) { 
      mexErrMsgTxt("Input 144 must be a noncomplex scalar double.");
    } 
    mexinput144_temp = mxGetPr(prhs[144]); 
    double mexinput144 = *mexinput144_temp; 

    double *mexinput145_temp = NULL; 
    if( !mxIsDouble(prhs[145]) || mxIsComplex(prhs[145]) || !(mxGetM(prhs[145])==1 && mxGetN(prhs[145])==1) ) { 
      mexErrMsgTxt("Input 145 must be a noncomplex scalar double.");
    } 
    mexinput145_temp = mxGetPr(prhs[145]); 
    double mexinput145 = *mexinput145_temp; 

    double *mexinput146_temp = NULL; 
    if( !mxIsDouble(prhs[146]) || mxIsComplex(prhs[146]) || !(mxGetM(prhs[146])==1 && mxGetN(prhs[146])==1) ) { 
      mexErrMsgTxt("Input 146 must be a noncomplex scalar double.");
    } 
    mexinput146_temp = mxGetPr(prhs[146]); 
    double mexinput146 = *mexinput146_temp; 

    double *mexinput147_temp = NULL; 
    if( !mxIsDouble(prhs[147]) || mxIsComplex(prhs[147]) || !(mxGetM(prhs[147])==1 && mxGetN(prhs[147])==1) ) { 
      mexErrMsgTxt("Input 147 must be a noncomplex scalar double.");
    } 
    mexinput147_temp = mxGetPr(prhs[147]); 
    double mexinput147 = *mexinput147_temp; 

    double *mexinput148_temp = NULL; 
    if( !mxIsDouble(prhs[148]) || mxIsComplex(prhs[148]) || !(mxGetM(prhs[148])==1 && mxGetN(prhs[148])==1) ) { 
      mexErrMsgTxt("Input 148 must be a noncomplex scalar double.");
    } 
    mexinput148_temp = mxGetPr(prhs[148]); 
    double mexinput148 = *mexinput148_temp; 

    double *mexinput149_temp = NULL; 
    if( !mxIsDouble(prhs[149]) || mxIsComplex(prhs[149]) || !(mxGetM(prhs[149])==1 && mxGetN(prhs[149])==1) ) { 
      mexErrMsgTxt("Input 149 must be a noncomplex scalar double.");
    } 
    mexinput149_temp = mxGetPr(prhs[149]); 
    double mexinput149 = *mexinput149_temp; 

    double *mexinput150_temp = NULL; 
    if( !mxIsDouble(prhs[150]) || mxIsComplex(prhs[150]) || !(mxGetM(prhs[150])==1 && mxGetN(prhs[150])==1) ) { 
      mexErrMsgTxt("Input 150 must be a noncomplex scalar double.");
    } 
    mexinput150_temp = mxGetPr(prhs[150]); 
    double mexinput150 = *mexinput150_temp; 

    double *mexinput151_temp = NULL; 
    if( !mxIsDouble(prhs[151]) || mxIsComplex(prhs[151]) || !(mxGetM(prhs[151])==1 && mxGetN(prhs[151])==1) ) { 
      mexErrMsgTxt("Input 151 must be a noncomplex scalar double.");
    } 
    mexinput151_temp = mxGetPr(prhs[151]); 
    double mexinput151 = *mexinput151_temp; 

    double *mexinput152_temp = NULL; 
    if( !mxIsDouble(prhs[152]) || mxIsComplex(prhs[152]) || !(mxGetM(prhs[152])==1 && mxGetN(prhs[152])==1) ) { 
      mexErrMsgTxt("Input 152 must be a noncomplex scalar double.");
    } 
    mexinput152_temp = mxGetPr(prhs[152]); 
    double mexinput152 = *mexinput152_temp; 

    double *mexinput153_temp = NULL; 
    if( !mxIsDouble(prhs[153]) || mxIsComplex(prhs[153]) || !(mxGetM(prhs[153])==1 && mxGetN(prhs[153])==1) ) { 
      mexErrMsgTxt("Input 153 must be a noncomplex scalar double.");
    } 
    mexinput153_temp = mxGetPr(prhs[153]); 
    double mexinput153 = *mexinput153_temp; 

    double *mexinput154_temp = NULL; 
    if( !mxIsDouble(prhs[154]) || mxIsComplex(prhs[154]) || !(mxGetM(prhs[154])==1 && mxGetN(prhs[154])==1) ) { 
      mexErrMsgTxt("Input 154 must be a noncomplex scalar double.");
    } 
    mexinput154_temp = mxGetPr(prhs[154]); 
    double mexinput154 = *mexinput154_temp; 

    double *mexinput155_temp = NULL; 
    if( !mxIsDouble(prhs[155]) || mxIsComplex(prhs[155]) || !(mxGetM(prhs[155])==1 && mxGetN(prhs[155])==1) ) { 
      mexErrMsgTxt("Input 155 must be a noncomplex scalar double.");
    } 
    mexinput155_temp = mxGetPr(prhs[155]); 
    double mexinput155 = *mexinput155_temp; 

    double *mexinput156_temp = NULL; 
    if( !mxIsDouble(prhs[156]) || mxIsComplex(prhs[156]) || !(mxGetM(prhs[156])==1 && mxGetN(prhs[156])==1) ) { 
      mexErrMsgTxt("Input 156 must be a noncomplex scalar double.");
    } 
    mexinput156_temp = mxGetPr(prhs[156]); 
    double mexinput156 = *mexinput156_temp; 

    double *mexinput157_temp = NULL; 
    if( !mxIsDouble(prhs[157]) || mxIsComplex(prhs[157]) || !(mxGetM(prhs[157])==1 && mxGetN(prhs[157])==1) ) { 
      mexErrMsgTxt("Input 157 must be a noncomplex scalar double.");
    } 
    mexinput157_temp = mxGetPr(prhs[157]); 
    double mexinput157 = *mexinput157_temp; 

    double *mexinput158_temp = NULL; 
    if( !mxIsDouble(prhs[158]) || mxIsComplex(prhs[158]) || !(mxGetM(prhs[158])==1 && mxGetN(prhs[158])==1) ) { 
      mexErrMsgTxt("Input 158 must be a noncomplex scalar double.");
    } 
    mexinput158_temp = mxGetPr(prhs[158]); 
    double mexinput158 = *mexinput158_temp; 

    double *mexinput159_temp = NULL; 
    if( !mxIsDouble(prhs[159]) || mxIsComplex(prhs[159]) || !(mxGetM(prhs[159])==1 && mxGetN(prhs[159])==1) ) { 
      mexErrMsgTxt("Input 159 must be a noncomplex scalar double.");
    } 
    mexinput159_temp = mxGetPr(prhs[159]); 
    double mexinput159 = *mexinput159_temp; 

    double *mexinput160_temp = NULL; 
    if( !mxIsDouble(prhs[160]) || mxIsComplex(prhs[160]) || !(mxGetM(prhs[160])==1 && mxGetN(prhs[160])==1) ) { 
      mexErrMsgTxt("Input 160 must be a noncomplex scalar double.");
    } 
    mexinput160_temp = mxGetPr(prhs[160]); 
    double mexinput160 = *mexinput160_temp; 

    double *mexinput161_temp = NULL; 
    if( !mxIsDouble(prhs[161]) || mxIsComplex(prhs[161]) || !(mxGetM(prhs[161])==1 && mxGetN(prhs[161])==1) ) { 
      mexErrMsgTxt("Input 161 must be a noncomplex scalar double.");
    } 
    mexinput161_temp = mxGetPr(prhs[161]); 
    double mexinput161 = *mexinput161_temp; 

    double *mexinput162_temp = NULL; 
    if( !mxIsDouble(prhs[162]) || mxIsComplex(prhs[162]) || !(mxGetM(prhs[162])==1 && mxGetN(prhs[162])==1) ) { 
      mexErrMsgTxt("Input 162 must be a noncomplex scalar double.");
    } 
    mexinput162_temp = mxGetPr(prhs[162]); 
    double mexinput162 = *mexinput162_temp; 

    double *mexinput163_temp = NULL; 
    if( !mxIsDouble(prhs[163]) || mxIsComplex(prhs[163]) || !(mxGetM(prhs[163])==1 && mxGetN(prhs[163])==1) ) { 
      mexErrMsgTxt("Input 163 must be a noncomplex scalar double.");
    } 
    mexinput163_temp = mxGetPr(prhs[163]); 
    double mexinput163 = *mexinput163_temp; 

    double *mexinput164_temp = NULL; 
    if( !mxIsDouble(prhs[164]) || mxIsComplex(prhs[164]) || !(mxGetM(prhs[164])==1 && mxGetN(prhs[164])==1) ) { 
      mexErrMsgTxt("Input 164 must be a noncomplex scalar double.");
    } 
    mexinput164_temp = mxGetPr(prhs[164]); 
    double mexinput164 = *mexinput164_temp; 

    double *mexinput165_temp = NULL; 
    if( !mxIsDouble(prhs[165]) || mxIsComplex(prhs[165]) || !(mxGetM(prhs[165])==1 && mxGetN(prhs[165])==1) ) { 
      mexErrMsgTxt("Input 165 must be a noncomplex scalar double.");
    } 
    mexinput165_temp = mxGetPr(prhs[165]); 
    double mexinput165 = *mexinput165_temp; 

    double *mexinput166_temp = NULL; 
    if( !mxIsDouble(prhs[166]) || mxIsComplex(prhs[166]) || !(mxGetM(prhs[166])==1 && mxGetN(prhs[166])==1) ) { 
      mexErrMsgTxt("Input 166 must be a noncomplex scalar double.");
    } 
    mexinput166_temp = mxGetPr(prhs[166]); 
    double mexinput166 = *mexinput166_temp; 

    double *mexinput167_temp = NULL; 
    if( !mxIsDouble(prhs[167]) || mxIsComplex(prhs[167]) || !(mxGetM(prhs[167])==1 && mxGetN(prhs[167])==1) ) { 
      mexErrMsgTxt("Input 167 must be a noncomplex scalar double.");
    } 
    mexinput167_temp = mxGetPr(prhs[167]); 
    double mexinput167 = *mexinput167_temp; 

    double *mexinput168_temp = NULL; 
    if( !mxIsDouble(prhs[168]) || mxIsComplex(prhs[168]) || !(mxGetM(prhs[168])==1 && mxGetN(prhs[168])==1) ) { 
      mexErrMsgTxt("Input 168 must be a noncomplex scalar double.");
    } 
    mexinput168_temp = mxGetPr(prhs[168]); 
    double mexinput168 = *mexinput168_temp; 

    double *mexinput169_temp = NULL; 
    if( !mxIsDouble(prhs[169]) || mxIsComplex(prhs[169]) || !(mxGetM(prhs[169])==1 && mxGetN(prhs[169])==1) ) { 
      mexErrMsgTxt("Input 169 must be a noncomplex scalar double.");
    } 
    mexinput169_temp = mxGetPr(prhs[169]); 
    double mexinput169 = *mexinput169_temp; 

    double *mexinput170_temp = NULL; 
    if( !mxIsDouble(prhs[170]) || mxIsComplex(prhs[170]) || !(mxGetM(prhs[170])==1 && mxGetN(prhs[170])==1) ) { 
      mexErrMsgTxt("Input 170 must be a noncomplex scalar double.");
    } 
    mexinput170_temp = mxGetPr(prhs[170]); 
    double mexinput170 = *mexinput170_temp; 

    double *mexinput171_temp = NULL; 
    if( !mxIsDouble(prhs[171]) || mxIsComplex(prhs[171]) || !(mxGetM(prhs[171])==1 && mxGetN(prhs[171])==1) ) { 
      mexErrMsgTxt("Input 171 must be a noncomplex scalar double.");
    } 
    mexinput171_temp = mxGetPr(prhs[171]); 
    double mexinput171 = *mexinput171_temp; 

    double *mexinput172_temp = NULL; 
    if( !mxIsDouble(prhs[172]) || mxIsComplex(prhs[172]) || !(mxGetM(prhs[172])==1 && mxGetN(prhs[172])==1) ) { 
      mexErrMsgTxt("Input 172 must be a noncomplex scalar double.");
    } 
    mexinput172_temp = mxGetPr(prhs[172]); 
    double mexinput172 = *mexinput172_temp; 

    double *mexinput173_temp = NULL; 
    if( !mxIsDouble(prhs[173]) || mxIsComplex(prhs[173]) || !(mxGetM(prhs[173])==1 && mxGetN(prhs[173])==1) ) { 
      mexErrMsgTxt("Input 173 must be a noncomplex scalar double.");
    } 
    mexinput173_temp = mxGetPr(prhs[173]); 
    double mexinput173 = *mexinput173_temp; 

    double *mexinput174_temp = NULL; 
    if( !mxIsDouble(prhs[174]) || mxIsComplex(prhs[174]) || !(mxGetM(prhs[174])==1 && mxGetN(prhs[174])==1) ) { 
      mexErrMsgTxt("Input 174 must be a noncomplex scalar double.");
    } 
    mexinput174_temp = mxGetPr(prhs[174]); 
    double mexinput174 = *mexinput174_temp; 

    double *mexinput175_temp = NULL; 
    if( !mxIsDouble(prhs[175]) || mxIsComplex(prhs[175]) || !(mxGetM(prhs[175])==1 && mxGetN(prhs[175])==1) ) { 
      mexErrMsgTxt("Input 175 must be a noncomplex scalar double.");
    } 
    mexinput175_temp = mxGetPr(prhs[175]); 
    double mexinput175 = *mexinput175_temp; 

    double *mexinput176_temp = NULL; 
    if( !mxIsDouble(prhs[176]) || mxIsComplex(prhs[176]) || !(mxGetM(prhs[176])==1 && mxGetN(prhs[176])==1) ) { 
      mexErrMsgTxt("Input 176 must be a noncomplex scalar double.");
    } 
    mexinput176_temp = mxGetPr(prhs[176]); 
    double mexinput176 = *mexinput176_temp; 

    double *mexinput177_temp = NULL; 
    if( !mxIsDouble(prhs[177]) || mxIsComplex(prhs[177]) || !(mxGetM(prhs[177])==1 && mxGetN(prhs[177])==1) ) { 
      mexErrMsgTxt("Input 177 must be a noncomplex scalar double.");
    } 
    mexinput177_temp = mxGetPr(prhs[177]); 
    double mexinput177 = *mexinput177_temp; 

    double *mexinput178_temp = NULL; 
    if( !mxIsDouble(prhs[178]) || mxIsComplex(prhs[178]) || !(mxGetM(prhs[178])==1 && mxGetN(prhs[178])==1) ) { 
      mexErrMsgTxt("Input 178 must be a noncomplex scalar double.");
    } 
    mexinput178_temp = mxGetPr(prhs[178]); 
    double mexinput178 = *mexinput178_temp; 

    double *mexinput179_temp = NULL; 
    if( !mxIsDouble(prhs[179]) || mxIsComplex(prhs[179]) || !(mxGetM(prhs[179])==1 && mxGetN(prhs[179])==1) ) { 
      mexErrMsgTxt("Input 179 must be a noncomplex scalar double.");
    } 
    mexinput179_temp = mxGetPr(prhs[179]); 
    double mexinput179 = *mexinput179_temp; 

    double *mexinput180_temp = NULL; 
    if( !mxIsDouble(prhs[180]) || mxIsComplex(prhs[180]) || !(mxGetM(prhs[180])==1 && mxGetN(prhs[180])==1) ) { 
      mexErrMsgTxt("Input 180 must be a noncomplex scalar double.");
    } 
    mexinput180_temp = mxGetPr(prhs[180]); 
    double mexinput180 = *mexinput180_temp; 

    double *mexinput181_temp = NULL; 
    if( !mxIsDouble(prhs[181]) || mxIsComplex(prhs[181]) || !(mxGetM(prhs[181])==1 && mxGetN(prhs[181])==1) ) { 
      mexErrMsgTxt("Input 181 must be a noncomplex scalar double.");
    } 
    mexinput181_temp = mxGetPr(prhs[181]); 
    double mexinput181 = *mexinput181_temp; 

    double *mexinput182_temp = NULL; 
    if( !mxIsDouble(prhs[182]) || mxIsComplex(prhs[182]) || !(mxGetM(prhs[182])==1 && mxGetN(prhs[182])==1) ) { 
      mexErrMsgTxt("Input 182 must be a noncomplex scalar double.");
    } 
    mexinput182_temp = mxGetPr(prhs[182]); 
    double mexinput182 = *mexinput182_temp; 

    double *mexinput183_temp = NULL; 
    if( !mxIsDouble(prhs[183]) || mxIsComplex(prhs[183]) || !(mxGetM(prhs[183])==1 && mxGetN(prhs[183])==1) ) { 
      mexErrMsgTxt("Input 183 must be a noncomplex scalar double.");
    } 
    mexinput183_temp = mxGetPr(prhs[183]); 
    double mexinput183 = *mexinput183_temp; 

    double *mexinput184_temp = NULL; 
    if( !mxIsDouble(prhs[184]) || mxIsComplex(prhs[184]) || !(mxGetM(prhs[184])==1 && mxGetN(prhs[184])==1) ) { 
      mexErrMsgTxt("Input 184 must be a noncomplex scalar double.");
    } 
    mexinput184_temp = mxGetPr(prhs[184]); 
    double mexinput184 = *mexinput184_temp; 

    double *mexinput185_temp = NULL; 
    if( !mxIsDouble(prhs[185]) || mxIsComplex(prhs[185]) || !(mxGetM(prhs[185])==1 && mxGetN(prhs[185])==1) ) { 
      mexErrMsgTxt("Input 185 must be a noncomplex scalar double.");
    } 
    mexinput185_temp = mxGetPr(prhs[185]); 
    double mexinput185 = *mexinput185_temp; 

    double *mexinput186_temp = NULL; 
    if( !mxIsDouble(prhs[186]) || mxIsComplex(prhs[186]) || !(mxGetM(prhs[186])==1 && mxGetN(prhs[186])==1) ) { 
      mexErrMsgTxt("Input 186 must be a noncomplex scalar double.");
    } 
    mexinput186_temp = mxGetPr(prhs[186]); 
    double mexinput186 = *mexinput186_temp; 

    double *mexinput187_temp = NULL; 
    if( !mxIsDouble(prhs[187]) || mxIsComplex(prhs[187]) || !(mxGetM(prhs[187])==1 && mxGetN(prhs[187])==1) ) { 
      mexErrMsgTxt("Input 187 must be a noncomplex scalar double.");
    } 
    mexinput187_temp = mxGetPr(prhs[187]); 
    double mexinput187 = *mexinput187_temp; 

    double *mexinput188_temp = NULL; 
    if( !mxIsDouble(prhs[188]) || mxIsComplex(prhs[188]) || !(mxGetM(prhs[188])==1 && mxGetN(prhs[188])==1) ) { 
      mexErrMsgTxt("Input 188 must be a noncomplex scalar double.");
    } 
    mexinput188_temp = mxGetPr(prhs[188]); 
    double mexinput188 = *mexinput188_temp; 

    double *mexinput189_temp = NULL; 
    if( !mxIsDouble(prhs[189]) || mxIsComplex(prhs[189]) || !(mxGetM(prhs[189])==1 && mxGetN(prhs[189])==1) ) { 
      mexErrMsgTxt("Input 189 must be a noncomplex scalar double.");
    } 
    mexinput189_temp = mxGetPr(prhs[189]); 
    double mexinput189 = *mexinput189_temp; 

    double *mexinput190_temp = NULL; 
    if( !mxIsDouble(prhs[190]) || mxIsComplex(prhs[190]) || !(mxGetM(prhs[190])==1 && mxGetN(prhs[190])==1) ) { 
      mexErrMsgTxt("Input 190 must be a noncomplex scalar double.");
    } 
    mexinput190_temp = mxGetPr(prhs[190]); 
    double mexinput190 = *mexinput190_temp; 

    double *mexinput191_temp = NULL; 
    if( !mxIsDouble(prhs[191]) || mxIsComplex(prhs[191]) || !(mxGetM(prhs[191])==1 && mxGetN(prhs[191])==1) ) { 
      mexErrMsgTxt("Input 191 must be a noncomplex scalar double.");
    } 
    mexinput191_temp = mxGetPr(prhs[191]); 
    double mexinput191 = *mexinput191_temp; 

    double *mexinput192_temp = NULL; 
    if( !mxIsDouble(prhs[192]) || mxIsComplex(prhs[192]) || !(mxGetM(prhs[192])==1 && mxGetN(prhs[192])==1) ) { 
      mexErrMsgTxt("Input 192 must be a noncomplex scalar double.");
    } 
    mexinput192_temp = mxGetPr(prhs[192]); 
    double mexinput192 = *mexinput192_temp; 

    double *mexinput193_temp = NULL; 
    if( !mxIsDouble(prhs[193]) || mxIsComplex(prhs[193]) || !(mxGetM(prhs[193])==1 && mxGetN(prhs[193])==1) ) { 
      mexErrMsgTxt("Input 193 must be a noncomplex scalar double.");
    } 
    mexinput193_temp = mxGetPr(prhs[193]); 
    double mexinput193 = *mexinput193_temp; 

    double *mexinput194_temp = NULL; 
    if( !mxIsDouble(prhs[194]) || mxIsComplex(prhs[194]) || !(mxGetM(prhs[194])==1 && mxGetN(prhs[194])==1) ) { 
      mexErrMsgTxt("Input 194 must be a noncomplex scalar double.");
    } 
    mexinput194_temp = mxGetPr(prhs[194]); 
    double mexinput194 = *mexinput194_temp; 

    double *mexinput195_temp = NULL; 
    if( !mxIsDouble(prhs[195]) || mxIsComplex(prhs[195]) || !(mxGetM(prhs[195])==1 && mxGetN(prhs[195])==1) ) { 
      mexErrMsgTxt("Input 195 must be a noncomplex scalar double.");
    } 
    mexinput195_temp = mxGetPr(prhs[195]); 
    double mexinput195 = *mexinput195_temp; 

    double *mexinput196_temp = NULL; 
    if( !mxIsDouble(prhs[196]) || mxIsComplex(prhs[196]) || !(mxGetM(prhs[196])==1 && mxGetN(prhs[196])==1) ) { 
      mexErrMsgTxt("Input 196 must be a noncomplex scalar double.");
    } 
    mexinput196_temp = mxGetPr(prhs[196]); 
    double mexinput196 = *mexinput196_temp; 

    double *mexinput197_temp = NULL; 
    if( !mxIsDouble(prhs[197]) || mxIsComplex(prhs[197]) || !(mxGetM(prhs[197])==1 && mxGetN(prhs[197])==1) ) { 
      mexErrMsgTxt("Input 197 must be a noncomplex scalar double.");
    } 
    mexinput197_temp = mxGetPr(prhs[197]); 
    double mexinput197 = *mexinput197_temp; 

    double *mexinput198_temp = NULL; 
    if( !mxIsDouble(prhs[198]) || mxIsComplex(prhs[198]) || !(mxGetM(prhs[198])==1 && mxGetN(prhs[198])==1) ) { 
      mexErrMsgTxt("Input 198 must be a noncomplex scalar double.");
    } 
    mexinput198_temp = mxGetPr(prhs[198]); 
    double mexinput198 = *mexinput198_temp; 

    double *mexinput199_temp = NULL; 
    if( !mxIsDouble(prhs[199]) || mxIsComplex(prhs[199]) || !(mxGetM(prhs[199])==1 && mxGetN(prhs[199])==1) ) { 
      mexErrMsgTxt("Input 199 must be a noncomplex scalar double.");
    } 
    mexinput199_temp = mxGetPr(prhs[199]); 
    double mexinput199 = *mexinput199_temp; 

    double *mexinput200_temp = NULL; 
    if( !mxIsDouble(prhs[200]) || mxIsComplex(prhs[200]) || !(mxGetM(prhs[200])==1 && mxGetN(prhs[200])==1) ) { 
      mexErrMsgTxt("Input 200 must be a noncomplex scalar double.");
    } 
    mexinput200_temp = mxGetPr(prhs[200]); 
    double mexinput200 = *mexinput200_temp; 

    double *mexinput201_temp = NULL; 
    if( !mxIsDouble(prhs[201]) || mxIsComplex(prhs[201]) || !(mxGetM(prhs[201])==1 && mxGetN(prhs[201])==1) ) { 
      mexErrMsgTxt("Input 201 must be a noncomplex scalar double.");
    } 
    mexinput201_temp = mxGetPr(prhs[201]); 
    double mexinput201 = *mexinput201_temp; 

    double *mexinput202_temp = NULL; 
    if( !mxIsDouble(prhs[202]) || mxIsComplex(prhs[202]) || !(mxGetM(prhs[202])==1 && mxGetN(prhs[202])==1) ) { 
      mexErrMsgTxt("Input 202 must be a noncomplex scalar double.");
    } 
    mexinput202_temp = mxGetPr(prhs[202]); 
    double mexinput202 = *mexinput202_temp; 

    double *mexinput203_temp = NULL; 
    if( !mxIsDouble(prhs[203]) || mxIsComplex(prhs[203]) || !(mxGetM(prhs[203])==1 && mxGetN(prhs[203])==1) ) { 
      mexErrMsgTxt("Input 203 must be a noncomplex scalar double.");
    } 
    mexinput203_temp = mxGetPr(prhs[203]); 
    double mexinput203 = *mexinput203_temp; 

    double *mexinput204_temp = NULL; 
    if( !mxIsDouble(prhs[204]) || mxIsComplex(prhs[204]) || !(mxGetM(prhs[204])==1 && mxGetN(prhs[204])==1) ) { 
      mexErrMsgTxt("Input 204 must be a noncomplex scalar double.");
    } 
    mexinput204_temp = mxGetPr(prhs[204]); 
    double mexinput204 = *mexinput204_temp; 

    double *mexinput205_temp = NULL; 
    if( !mxIsDouble(prhs[205]) || mxIsComplex(prhs[205]) || !(mxGetM(prhs[205])==1 && mxGetN(prhs[205])==1) ) { 
      mexErrMsgTxt("Input 205 must be a noncomplex scalar double.");
    } 
    mexinput205_temp = mxGetPr(prhs[205]); 
    double mexinput205 = *mexinput205_temp; 

    double *mexinput206_temp = NULL; 
    if( !mxIsDouble(prhs[206]) || mxIsComplex(prhs[206]) || !(mxGetM(prhs[206])==1 && mxGetN(prhs[206])==1) ) { 
      mexErrMsgTxt("Input 206 must be a noncomplex scalar double.");
    } 
    mexinput206_temp = mxGetPr(prhs[206]); 
    double mexinput206 = *mexinput206_temp; 

    double *mexinput207_temp = NULL; 
    if( !mxIsDouble(prhs[207]) || mxIsComplex(prhs[207]) || !(mxGetM(prhs[207])==1 && mxGetN(prhs[207])==1) ) { 
      mexErrMsgTxt("Input 207 must be a noncomplex scalar double.");
    } 
    mexinput207_temp = mxGetPr(prhs[207]); 
    double mexinput207 = *mexinput207_temp; 

    double *mexinput208_temp = NULL; 
    if( !mxIsDouble(prhs[208]) || mxIsComplex(prhs[208]) || !(mxGetM(prhs[208])==1 && mxGetN(prhs[208])==1) ) { 
      mexErrMsgTxt("Input 208 must be a noncomplex scalar double.");
    } 
    mexinput208_temp = mxGetPr(prhs[208]); 
    double mexinput208 = *mexinput208_temp; 

    double *mexinput209_temp = NULL; 
    if( !mxIsDouble(prhs[209]) || mxIsComplex(prhs[209]) || !(mxGetM(prhs[209])==1 && mxGetN(prhs[209])==1) ) { 
      mexErrMsgTxt("Input 209 must be a noncomplex scalar double.");
    } 
    mexinput209_temp = mxGetPr(prhs[209]); 
    double mexinput209 = *mexinput209_temp; 

    double *mexinput210_temp = NULL; 
    if( !mxIsDouble(prhs[210]) || mxIsComplex(prhs[210]) || !(mxGetM(prhs[210])==1 && mxGetN(prhs[210])==1) ) { 
      mexErrMsgTxt("Input 210 must be a noncomplex scalar double.");
    } 
    mexinput210_temp = mxGetPr(prhs[210]); 
    double mexinput210 = *mexinput210_temp; 

    double *mexinput211_temp = NULL; 
    if( !mxIsDouble(prhs[211]) || mxIsComplex(prhs[211]) || !(mxGetM(prhs[211])==1 && mxGetN(prhs[211])==1) ) { 
      mexErrMsgTxt("Input 211 must be a noncomplex scalar double.");
    } 
    mexinput211_temp = mxGetPr(prhs[211]); 
    double mexinput211 = *mexinput211_temp; 

    double *mexinput212_temp = NULL; 
    if( !mxIsDouble(prhs[212]) || mxIsComplex(prhs[212]) || !(mxGetM(prhs[212])==1 && mxGetN(prhs[212])==1) ) { 
      mexErrMsgTxt("Input 212 must be a noncomplex scalar double.");
    } 
    mexinput212_temp = mxGetPr(prhs[212]); 
    double mexinput212 = *mexinput212_temp; 

    double *mexinput213_temp = NULL; 
    if( !mxIsDouble(prhs[213]) || mxIsComplex(prhs[213]) || !(mxGetM(prhs[213])==1 && mxGetN(prhs[213])==1) ) { 
      mexErrMsgTxt("Input 213 must be a noncomplex scalar double.");
    } 
    mexinput213_temp = mxGetPr(prhs[213]); 
    double mexinput213 = *mexinput213_temp; 

    double *mexinput214_temp = NULL; 
    if( !mxIsDouble(prhs[214]) || mxIsComplex(prhs[214]) || !(mxGetM(prhs[214])==1 && mxGetN(prhs[214])==1) ) { 
      mexErrMsgTxt("Input 214 must be a noncomplex scalar double.");
    } 
    mexinput214_temp = mxGetPr(prhs[214]); 
    double mexinput214 = *mexinput214_temp; 

    double *mexinput215_temp = NULL; 
    if( !mxIsDouble(prhs[215]) || mxIsComplex(prhs[215]) || !(mxGetM(prhs[215])==1 && mxGetN(prhs[215])==1) ) { 
      mexErrMsgTxt("Input 215 must be a noncomplex scalar double.");
    } 
    mexinput215_temp = mxGetPr(prhs[215]); 
    double mexinput215 = *mexinput215_temp; 

    double *mexinput216_temp = NULL; 
    if( !mxIsDouble(prhs[216]) || mxIsComplex(prhs[216]) || !(mxGetM(prhs[216])==1 && mxGetN(prhs[216])==1) ) { 
      mexErrMsgTxt("Input 216 must be a noncomplex scalar double.");
    } 
    mexinput216_temp = mxGetPr(prhs[216]); 
    double mexinput216 = *mexinput216_temp; 

    double *mexinput217_temp = NULL; 
    if( !mxIsDouble(prhs[217]) || mxIsComplex(prhs[217]) || !(mxGetM(prhs[217])==1 && mxGetN(prhs[217])==1) ) { 
      mexErrMsgTxt("Input 217 must be a noncomplex scalar double.");
    } 
    mexinput217_temp = mxGetPr(prhs[217]); 
    double mexinput217 = *mexinput217_temp; 

    double *mexinput218_temp = NULL; 
    if( !mxIsDouble(prhs[218]) || mxIsComplex(prhs[218]) || !(mxGetM(prhs[218])==1 && mxGetN(prhs[218])==1) ) { 
      mexErrMsgTxt("Input 218 must be a noncomplex scalar double.");
    } 
    mexinput218_temp = mxGetPr(prhs[218]); 
    double mexinput218 = *mexinput218_temp; 

    double *mexinput219_temp = NULL; 
    if( !mxIsDouble(prhs[219]) || mxIsComplex(prhs[219]) || !(mxGetM(prhs[219])==1 && mxGetN(prhs[219])==1) ) { 
      mexErrMsgTxt("Input 219 must be a noncomplex scalar double.");
    } 
    mexinput219_temp = mxGetPr(prhs[219]); 
    double mexinput219 = *mexinput219_temp; 

    double *mexinput220_temp = NULL; 
    if( !mxIsDouble(prhs[220]) || mxIsComplex(prhs[220]) || !(mxGetM(prhs[220])==1 && mxGetN(prhs[220])==1) ) { 
      mexErrMsgTxt("Input 220 must be a noncomplex scalar double.");
    } 
    mexinput220_temp = mxGetPr(prhs[220]); 
    double mexinput220 = *mexinput220_temp; 

    double *mexinput221_temp = NULL; 
    if( !mxIsDouble(prhs[221]) || mxIsComplex(prhs[221]) || !(mxGetM(prhs[221])==1 && mxGetN(prhs[221])==1) ) { 
      mexErrMsgTxt("Input 221 must be a noncomplex scalar double.");
    } 
    mexinput221_temp = mxGetPr(prhs[221]); 
    double mexinput221 = *mexinput221_temp; 

    double *mexinput222_temp = NULL; 
    if( !mxIsDouble(prhs[222]) || mxIsComplex(prhs[222]) || !(mxGetM(prhs[222])==1 && mxGetN(prhs[222])==1) ) { 
      mexErrMsgTxt("Input 222 must be a noncomplex scalar double.");
    } 
    mexinput222_temp = mxGetPr(prhs[222]); 
    double mexinput222 = *mexinput222_temp; 

    double *mexinput223_temp = NULL; 
    if( !mxIsDouble(prhs[223]) || mxIsComplex(prhs[223]) || !(mxGetM(prhs[223])==1 && mxGetN(prhs[223])==1) ) { 
      mexErrMsgTxt("Input 223 must be a noncomplex scalar double.");
    } 
    mexinput223_temp = mxGetPr(prhs[223]); 
    double mexinput223 = *mexinput223_temp; 

    double *mexinput224_temp = NULL; 
    if( !mxIsDouble(prhs[224]) || mxIsComplex(prhs[224]) || !(mxGetM(prhs[224])==1 && mxGetN(prhs[224])==1) ) { 
      mexErrMsgTxt("Input 224 must be a noncomplex scalar double.");
    } 
    mexinput224_temp = mxGetPr(prhs[224]); 
    double mexinput224 = *mexinput224_temp; 

    double *mexinput225_temp = NULL; 
    if( !mxIsDouble(prhs[225]) || mxIsComplex(prhs[225]) || !(mxGetM(prhs[225])==1 && mxGetN(prhs[225])==1) ) { 
      mexErrMsgTxt("Input 225 must be a noncomplex scalar double.");
    } 
    mexinput225_temp = mxGetPr(prhs[225]); 
    double mexinput225 = *mexinput225_temp; 

    double *mexinput226_temp = NULL; 
    if( !mxIsDouble(prhs[226]) || mxIsComplex(prhs[226]) || !(mxGetM(prhs[226])==1 && mxGetN(prhs[226])==1) ) { 
      mexErrMsgTxt("Input 226 must be a noncomplex scalar double.");
    } 
    mexinput226_temp = mxGetPr(prhs[226]); 
    double mexinput226 = *mexinput226_temp; 

    double *mexinput227_temp = NULL; 
    if( !mxIsDouble(prhs[227]) || mxIsComplex(prhs[227]) || !(mxGetM(prhs[227])==1 && mxGetN(prhs[227])==1) ) { 
      mexErrMsgTxt("Input 227 must be a noncomplex scalar double.");
    } 
    mexinput227_temp = mxGetPr(prhs[227]); 
    double mexinput227 = *mexinput227_temp; 

    double *mexinput228_temp = NULL; 
    if( !mxIsDouble(prhs[228]) || mxIsComplex(prhs[228]) || !(mxGetM(prhs[228])==1 && mxGetN(prhs[228])==1) ) { 
      mexErrMsgTxt("Input 228 must be a noncomplex scalar double.");
    } 
    mexinput228_temp = mxGetPr(prhs[228]); 
    double mexinput228 = *mexinput228_temp; 

    double *mexinput229_temp = NULL; 
    if( !mxIsDouble(prhs[229]) || mxIsComplex(prhs[229]) || !(mxGetM(prhs[229])==1 && mxGetN(prhs[229])==1) ) { 
      mexErrMsgTxt("Input 229 must be a noncomplex scalar double.");
    } 
    mexinput229_temp = mxGetPr(prhs[229]); 
    double mexinput229 = *mexinput229_temp; 

    double *mexinput230_temp = NULL; 
    if( !mxIsDouble(prhs[230]) || mxIsComplex(prhs[230]) || !(mxGetM(prhs[230])==1 && mxGetN(prhs[230])==1) ) { 
      mexErrMsgTxt("Input 230 must be a noncomplex scalar double.");
    } 
    mexinput230_temp = mxGetPr(prhs[230]); 
    double mexinput230 = *mexinput230_temp; 

    double *mexinput231_temp = NULL; 
    if( !mxIsDouble(prhs[231]) || mxIsComplex(prhs[231]) || !(mxGetM(prhs[231])==1 && mxGetN(prhs[231])==1) ) { 
      mexErrMsgTxt("Input 231 must be a noncomplex scalar double.");
    } 
    mexinput231_temp = mxGetPr(prhs[231]); 
    double mexinput231 = *mexinput231_temp; 

    double *mexinput232_temp = NULL; 
    if( !mxIsDouble(prhs[232]) || mxIsComplex(prhs[232]) || !(mxGetM(prhs[232])==1 && mxGetN(prhs[232])==1) ) { 
      mexErrMsgTxt("Input 232 must be a noncomplex scalar double.");
    } 
    mexinput232_temp = mxGetPr(prhs[232]); 
    double mexinput232 = *mexinput232_temp; 

    double *mexinput233_temp = NULL; 
    if( !mxIsDouble(prhs[233]) || mxIsComplex(prhs[233]) || !(mxGetM(prhs[233])==1 && mxGetN(prhs[233])==1) ) { 
      mexErrMsgTxt("Input 233 must be a noncomplex scalar double.");
    } 
    mexinput233_temp = mxGetPr(prhs[233]); 
    double mexinput233 = *mexinput233_temp; 

    double *mexinput234_temp = NULL; 
    if( !mxIsDouble(prhs[234]) || mxIsComplex(prhs[234]) || !(mxGetM(prhs[234])==1 && mxGetN(prhs[234])==1) ) { 
      mexErrMsgTxt("Input 234 must be a noncomplex scalar double.");
    } 
    mexinput234_temp = mxGetPr(prhs[234]); 
    double mexinput234 = *mexinput234_temp; 

    double *mexinput235_temp = NULL; 
    if( !mxIsDouble(prhs[235]) || mxIsComplex(prhs[235]) || !(mxGetM(prhs[235])==1 && mxGetN(prhs[235])==1) ) { 
      mexErrMsgTxt("Input 235 must be a noncomplex scalar double.");
    } 
    mexinput235_temp = mxGetPr(prhs[235]); 
    double mexinput235 = *mexinput235_temp; 

    double *mexinput236_temp = NULL; 
    if( !mxIsDouble(prhs[236]) || mxIsComplex(prhs[236]) || !(mxGetM(prhs[236])==1 && mxGetN(prhs[236])==1) ) { 
      mexErrMsgTxt("Input 236 must be a noncomplex scalar double.");
    } 
    mexinput236_temp = mxGetPr(prhs[236]); 
    double mexinput236 = *mexinput236_temp; 

    double *mexinput237_temp = NULL; 
    if( !mxIsDouble(prhs[237]) || mxIsComplex(prhs[237]) || !(mxGetM(prhs[237])==1 && mxGetN(prhs[237])==1) ) { 
      mexErrMsgTxt("Input 237 must be a noncomplex scalar double.");
    } 
    mexinput237_temp = mxGetPr(prhs[237]); 
    double mexinput237 = *mexinput237_temp; 

    double *mexinput238_temp = NULL; 
    if( !mxIsDouble(prhs[238]) || mxIsComplex(prhs[238]) || !(mxGetM(prhs[238])==1 && mxGetN(prhs[238])==1) ) { 
      mexErrMsgTxt("Input 238 must be a noncomplex scalar double.");
    } 
    mexinput238_temp = mxGetPr(prhs[238]); 
    double mexinput238 = *mexinput238_temp; 

    double *mexinput239_temp = NULL; 
    if( !mxIsDouble(prhs[239]) || mxIsComplex(prhs[239]) || !(mxGetM(prhs[239])==1 && mxGetN(prhs[239])==1) ) { 
      mexErrMsgTxt("Input 239 must be a noncomplex scalar double.");
    } 
    mexinput239_temp = mxGetPr(prhs[239]); 
    double mexinput239 = *mexinput239_temp; 

    double *mexinput240_temp = NULL; 
    if( !mxIsDouble(prhs[240]) || mxIsComplex(prhs[240]) || !(mxGetM(prhs[240])==1 && mxGetN(prhs[240])==1) ) { 
      mexErrMsgTxt("Input 240 must be a noncomplex scalar double.");
    } 
    mexinput240_temp = mxGetPr(prhs[240]); 
    double mexinput240 = *mexinput240_temp; 

    double *mexinput241_temp = NULL; 
    if( !mxIsDouble(prhs[241]) || mxIsComplex(prhs[241]) || !(mxGetM(prhs[241])==1 && mxGetN(prhs[241])==1) ) { 
      mexErrMsgTxt("Input 241 must be a noncomplex scalar double.");
    } 
    mexinput241_temp = mxGetPr(prhs[241]); 
    double mexinput241 = *mexinput241_temp; 

    double *mexinput242_temp = NULL; 
    if( !mxIsDouble(prhs[242]) || mxIsComplex(prhs[242]) || !(mxGetM(prhs[242])==1 && mxGetN(prhs[242])==1) ) { 
      mexErrMsgTxt("Input 242 must be a noncomplex scalar double.");
    } 
    mexinput242_temp = mxGetPr(prhs[242]); 
    double mexinput242 = *mexinput242_temp; 

    double *mexinput243_temp = NULL; 
    if( !mxIsDouble(prhs[243]) || mxIsComplex(prhs[243]) || !(mxGetM(prhs[243])==1 && mxGetN(prhs[243])==1) ) { 
      mexErrMsgTxt("Input 243 must be a noncomplex scalar double.");
    } 
    mexinput243_temp = mxGetPr(prhs[243]); 
    double mexinput243 = *mexinput243_temp; 

    double *mexinput244_temp = NULL; 
    if( !mxIsDouble(prhs[244]) || mxIsComplex(prhs[244]) || !(mxGetM(prhs[244])==1 && mxGetN(prhs[244])==1) ) { 
      mexErrMsgTxt("Input 244 must be a noncomplex scalar double.");
    } 
    mexinput244_temp = mxGetPr(prhs[244]); 
    double mexinput244 = *mexinput244_temp; 

    double *mexinput245_temp = NULL; 
    if( !mxIsDouble(prhs[245]) || mxIsComplex(prhs[245]) || !(mxGetM(prhs[245])==1 && mxGetN(prhs[245])==1) ) { 
      mexErrMsgTxt("Input 245 must be a noncomplex scalar double.");
    } 
    mexinput245_temp = mxGetPr(prhs[245]); 
    double mexinput245 = *mexinput245_temp; 

    double *mexinput246_temp = NULL; 
    if( !mxIsDouble(prhs[246]) || mxIsComplex(prhs[246]) || !(mxGetM(prhs[246])==1 && mxGetN(prhs[246])==1) ) { 
      mexErrMsgTxt("Input 246 must be a noncomplex scalar double.");
    } 
    mexinput246_temp = mxGetPr(prhs[246]); 
    double mexinput246 = *mexinput246_temp; 

    double *mexinput247_temp = NULL; 
    if( !mxIsDouble(prhs[247]) || mxIsComplex(prhs[247]) || !(mxGetM(prhs[247])==1 && mxGetN(prhs[247])==1) ) { 
      mexErrMsgTxt("Input 247 must be a noncomplex scalar double.");
    } 
    mexinput247_temp = mxGetPr(prhs[247]); 
    double mexinput247 = *mexinput247_temp; 

    double *mexinput248_temp = NULL; 
    if( !mxIsDouble(prhs[248]) || mxIsComplex(prhs[248]) || !(mxGetM(prhs[248])==1 && mxGetN(prhs[248])==1) ) { 
      mexErrMsgTxt("Input 248 must be a noncomplex scalar double.");
    } 
    mexinput248_temp = mxGetPr(prhs[248]); 
    double mexinput248 = *mexinput248_temp; 

    double *mexinput249_temp = NULL; 
    if( !mxIsDouble(prhs[249]) || mxIsComplex(prhs[249]) || !(mxGetM(prhs[249])==1 && mxGetN(prhs[249])==1) ) { 
      mexErrMsgTxt("Input 249 must be a noncomplex scalar double.");
    } 
    mexinput249_temp = mxGetPr(prhs[249]); 
    double mexinput249 = *mexinput249_temp; 

    double *mexinput250_temp = NULL; 
    if( !mxIsDouble(prhs[250]) || mxIsComplex(prhs[250]) || !(mxGetM(prhs[250])==1 && mxGetN(prhs[250])==1) ) { 
      mexErrMsgTxt("Input 250 must be a noncomplex scalar double.");
    } 
    mexinput250_temp = mxGetPr(prhs[250]); 
    double mexinput250 = *mexinput250_temp; 

    double *mexinput251_temp = NULL; 
    if( !mxIsDouble(prhs[251]) || mxIsComplex(prhs[251]) || !(mxGetM(prhs[251])==1 && mxGetN(prhs[251])==1) ) { 
      mexErrMsgTxt("Input 251 must be a noncomplex scalar double.");
    } 
    mexinput251_temp = mxGetPr(prhs[251]); 
    double mexinput251 = *mexinput251_temp; 

    double *mexinput252_temp = NULL; 
    if( !mxIsDouble(prhs[252]) || mxIsComplex(prhs[252]) || !(mxGetM(prhs[252])==1 && mxGetN(prhs[252])==1) ) { 
      mexErrMsgTxt("Input 252 must be a noncomplex scalar double.");
    } 
    mexinput252_temp = mxGetPr(prhs[252]); 
    double mexinput252 = *mexinput252_temp; 

    double *mexinput253_temp = NULL; 
    if( !mxIsDouble(prhs[253]) || mxIsComplex(prhs[253]) || !(mxGetM(prhs[253])==1 && mxGetN(prhs[253])==1) ) { 
      mexErrMsgTxt("Input 253 must be a noncomplex scalar double.");
    } 
    mexinput253_temp = mxGetPr(prhs[253]); 
    double mexinput253 = *mexinput253_temp; 

    double *mexinput254_temp = NULL; 
    if( !mxIsDouble(prhs[254]) || mxIsComplex(prhs[254]) || !(mxGetM(prhs[254])==1 && mxGetN(prhs[254])==1) ) { 
      mexErrMsgTxt("Input 254 must be a noncomplex scalar double.");
    } 
    mexinput254_temp = mxGetPr(prhs[254]); 
    double mexinput254 = *mexinput254_temp; 

    double *mexinput255_temp = NULL; 
    if( !mxIsDouble(prhs[255]) || mxIsComplex(prhs[255]) || !(mxGetM(prhs[255])==1 && mxGetN(prhs[255])==1) ) { 
      mexErrMsgTxt("Input 255 must be a noncomplex scalar double.");
    } 
    mexinput255_temp = mxGetPr(prhs[255]); 
    double mexinput255 = *mexinput255_temp; 

    double *mexinput256_temp = NULL; 
    if( !mxIsDouble(prhs[256]) || mxIsComplex(prhs[256]) || !(mxGetM(prhs[256])==1 && mxGetN(prhs[256])==1) ) { 
      mexErrMsgTxt("Input 256 must be a noncomplex scalar double.");
    } 
    mexinput256_temp = mxGetPr(prhs[256]); 
    double mexinput256 = *mexinput256_temp; 

    double *mexinput257_temp = NULL; 
    if( !mxIsDouble(prhs[257]) || mxIsComplex(prhs[257]) || !(mxGetM(prhs[257])==1 && mxGetN(prhs[257])==1) ) { 
      mexErrMsgTxt("Input 257 must be a noncomplex scalar double.");
    } 
    mexinput257_temp = mxGetPr(prhs[257]); 
    double mexinput257 = *mexinput257_temp; 

    double *mexinput258_temp = NULL; 
    if( !mxIsDouble(prhs[258]) || mxIsComplex(prhs[258]) || !(mxGetM(prhs[258])==1 && mxGetN(prhs[258])==1) ) { 
      mexErrMsgTxt("Input 258 must be a noncomplex scalar double.");
    } 
    mexinput258_temp = mxGetPr(prhs[258]); 
    double mexinput258 = *mexinput258_temp; 

    double *mexinput259_temp = NULL; 
    if( !mxIsDouble(prhs[259]) || mxIsComplex(prhs[259]) || !(mxGetM(prhs[259])==1 && mxGetN(prhs[259])==1) ) { 
      mexErrMsgTxt("Input 259 must be a noncomplex scalar double.");
    } 
    mexinput259_temp = mxGetPr(prhs[259]); 
    double mexinput259 = *mexinput259_temp; 

    double *mexinput260_temp = NULL; 
    if( !mxIsDouble(prhs[260]) || mxIsComplex(prhs[260]) || !(mxGetM(prhs[260])==1 && mxGetN(prhs[260])==1) ) { 
      mexErrMsgTxt("Input 260 must be a noncomplex scalar double.");
    } 
    mexinput260_temp = mxGetPr(prhs[260]); 
    double mexinput260 = *mexinput260_temp; 

    double *mexinput261_temp = NULL; 
    if( !mxIsDouble(prhs[261]) || mxIsComplex(prhs[261]) || !(mxGetM(prhs[261])==1 && mxGetN(prhs[261])==1) ) { 
      mexErrMsgTxt("Input 261 must be a noncomplex scalar double.");
    } 
    mexinput261_temp = mxGetPr(prhs[261]); 
    double mexinput261 = *mexinput261_temp; 

    double *mexinput262_temp = NULL; 
    if( !mxIsDouble(prhs[262]) || mxIsComplex(prhs[262]) || !(mxGetM(prhs[262])==1 && mxGetN(prhs[262])==1) ) { 
      mexErrMsgTxt("Input 262 must be a noncomplex scalar double.");
    } 
    mexinput262_temp = mxGetPr(prhs[262]); 
    double mexinput262 = *mexinput262_temp; 

    double *mexinput263_temp = NULL; 
    if( !mxIsDouble(prhs[263]) || mxIsComplex(prhs[263]) || !(mxGetM(prhs[263])==1 && mxGetN(prhs[263])==1) ) { 
      mexErrMsgTxt("Input 263 must be a noncomplex scalar double.");
    } 
    mexinput263_temp = mxGetPr(prhs[263]); 
    double mexinput263 = *mexinput263_temp; 

    double *mexinput264_temp = NULL; 
    if( !mxIsDouble(prhs[264]) || mxIsComplex(prhs[264]) || !(mxGetM(prhs[264])==1 && mxGetN(prhs[264])==1) ) { 
      mexErrMsgTxt("Input 264 must be a noncomplex scalar double.");
    } 
    mexinput264_temp = mxGetPr(prhs[264]); 
    double mexinput264 = *mexinput264_temp; 

    double *mexinput265_temp = NULL; 
    if( !mxIsDouble(prhs[265]) || mxIsComplex(prhs[265]) || !(mxGetM(prhs[265])==1 && mxGetN(prhs[265])==1) ) { 
      mexErrMsgTxt("Input 265 must be a noncomplex scalar double.");
    } 
    mexinput265_temp = mxGetPr(prhs[265]); 
    double mexinput265 = *mexinput265_temp; 

    double *mexinput266_temp = NULL; 
    if( !mxIsDouble(prhs[266]) || mxIsComplex(prhs[266]) || !(mxGetM(prhs[266])==1 && mxGetN(prhs[266])==1) ) { 
      mexErrMsgTxt("Input 266 must be a noncomplex scalar double.");
    } 
    mexinput266_temp = mxGetPr(prhs[266]); 
    double mexinput266 = *mexinput266_temp; 

    double *mexinput267_temp = NULL; 
    if( !mxIsDouble(prhs[267]) || mxIsComplex(prhs[267]) || !(mxGetM(prhs[267])==1 && mxGetN(prhs[267])==1) ) { 
      mexErrMsgTxt("Input 267 must be a noncomplex scalar double.");
    } 
    mexinput267_temp = mxGetPr(prhs[267]); 
    double mexinput267 = *mexinput267_temp; 

    double *mexinput268_temp = NULL; 
    if( !mxIsDouble(prhs[268]) || mxIsComplex(prhs[268]) || !(mxGetM(prhs[268])==1 && mxGetN(prhs[268])==1) ) { 
      mexErrMsgTxt("Input 268 must be a noncomplex scalar double.");
    } 
    mexinput268_temp = mxGetPr(prhs[268]); 
    double mexinput268 = *mexinput268_temp; 

    double *mexinput269_temp = NULL; 
    if( !mxIsDouble(prhs[269]) || mxIsComplex(prhs[269]) || !(mxGetM(prhs[269])==1 && mxGetN(prhs[269])==1) ) { 
      mexErrMsgTxt("Input 269 must be a noncomplex scalar double.");
    } 
    mexinput269_temp = mxGetPr(prhs[269]); 
    double mexinput269 = *mexinput269_temp; 

    double *mexinput270_temp = NULL; 
    if( !mxIsDouble(prhs[270]) || mxIsComplex(prhs[270]) || !(mxGetM(prhs[270])==1 && mxGetN(prhs[270])==1) ) { 
      mexErrMsgTxt("Input 270 must be a noncomplex scalar double.");
    } 
    mexinput270_temp = mxGetPr(prhs[270]); 
    double mexinput270 = *mexinput270_temp; 

    double *mexinput271_temp = NULL; 
    if( !mxIsDouble(prhs[271]) || mxIsComplex(prhs[271]) || !(mxGetM(prhs[271])==1 && mxGetN(prhs[271])==1) ) { 
      mexErrMsgTxt("Input 271 must be a noncomplex scalar double.");
    } 
    mexinput271_temp = mxGetPr(prhs[271]); 
    double mexinput271 = *mexinput271_temp; 

    double *mexinput272_temp = NULL; 
    if( !mxIsDouble(prhs[272]) || mxIsComplex(prhs[272]) || !(mxGetM(prhs[272])==1 && mxGetN(prhs[272])==1) ) { 
      mexErrMsgTxt("Input 272 must be a noncomplex scalar double.");
    } 
    mexinput272_temp = mxGetPr(prhs[272]); 
    double mexinput272 = *mexinput272_temp; 

    double *mexinput273_temp = NULL; 
    if( !mxIsDouble(prhs[273]) || mxIsComplex(prhs[273]) || !(mxGetM(prhs[273])==1 && mxGetN(prhs[273])==1) ) { 
      mexErrMsgTxt("Input 273 must be a noncomplex scalar double.");
    } 
    mexinput273_temp = mxGetPr(prhs[273]); 
    double mexinput273 = *mexinput273_temp; 

    double *mexinput274_temp = NULL; 
    if( !mxIsDouble(prhs[274]) || mxIsComplex(prhs[274]) || !(mxGetM(prhs[274])==1 && mxGetN(prhs[274])==1) ) { 
      mexErrMsgTxt("Input 274 must be a noncomplex scalar double.");
    } 
    mexinput274_temp = mxGetPr(prhs[274]); 
    double mexinput274 = *mexinput274_temp; 

    double *mexinput275_temp = NULL; 
    if( !mxIsDouble(prhs[275]) || mxIsComplex(prhs[275]) || !(mxGetM(prhs[275])==1 && mxGetN(prhs[275])==1) ) { 
      mexErrMsgTxt("Input 275 must be a noncomplex scalar double.");
    } 
    mexinput275_temp = mxGetPr(prhs[275]); 
    double mexinput275 = *mexinput275_temp; 

    double *mexinput276_temp = NULL; 
    if( !mxIsDouble(prhs[276]) || mxIsComplex(prhs[276]) || !(mxGetM(prhs[276])==1 && mxGetN(prhs[276])==1) ) { 
      mexErrMsgTxt("Input 276 must be a noncomplex scalar double.");
    } 
    mexinput276_temp = mxGetPr(prhs[276]); 
    double mexinput276 = *mexinput276_temp; 

    double *mexinput277_temp = NULL; 
    if( !mxIsDouble(prhs[277]) || mxIsComplex(prhs[277]) || !(mxGetM(prhs[277])==1 && mxGetN(prhs[277])==1) ) { 
      mexErrMsgTxt("Input 277 must be a noncomplex scalar double.");
    } 
    mexinput277_temp = mxGetPr(prhs[277]); 
    double mexinput277 = *mexinput277_temp; 

    double *mexinput278_temp = NULL; 
    if( !mxIsDouble(prhs[278]) || mxIsComplex(prhs[278]) || !(mxGetM(prhs[278])==1 && mxGetN(prhs[278])==1) ) { 
      mexErrMsgTxt("Input 278 must be a noncomplex scalar double.");
    } 
    mexinput278_temp = mxGetPr(prhs[278]); 
    double mexinput278 = *mexinput278_temp; 

    double *mexinput279_temp = NULL; 
    if( !mxIsDouble(prhs[279]) || mxIsComplex(prhs[279]) || !(mxGetM(prhs[279])==1 && mxGetN(prhs[279])==1) ) { 
      mexErrMsgTxt("Input 279 must be a noncomplex scalar double.");
    } 
    mexinput279_temp = mxGetPr(prhs[279]); 
    double mexinput279 = *mexinput279_temp; 

    double *mexinput280_temp = NULL; 
    if( !mxIsDouble(prhs[280]) || mxIsComplex(prhs[280]) || !(mxGetM(prhs[280])==1 && mxGetN(prhs[280])==1) ) { 
      mexErrMsgTxt("Input 280 must be a noncomplex scalar double.");
    } 
    mexinput280_temp = mxGetPr(prhs[280]); 
    double mexinput280 = *mexinput280_temp; 

    double *mexinput281_temp = NULL; 
    if( !mxIsDouble(prhs[281]) || mxIsComplex(prhs[281]) || !(mxGetM(prhs[281])==1 && mxGetN(prhs[281])==1) ) { 
      mexErrMsgTxt("Input 281 must be a noncomplex scalar double.");
    } 
    mexinput281_temp = mxGetPr(prhs[281]); 
    double mexinput281 = *mexinput281_temp; 

    double *mexinput282_temp = NULL; 
    if( !mxIsDouble(prhs[282]) || mxIsComplex(prhs[282]) || !(mxGetM(prhs[282])==1 && mxGetN(prhs[282])==1) ) { 
      mexErrMsgTxt("Input 282 must be a noncomplex scalar double.");
    } 
    mexinput282_temp = mxGetPr(prhs[282]); 
    double mexinput282 = *mexinput282_temp; 

    double *mexinput283_temp = NULL; 
    if( !mxIsDouble(prhs[283]) || mxIsComplex(prhs[283]) || !(mxGetM(prhs[283])==1 && mxGetN(prhs[283])==1) ) { 
      mexErrMsgTxt("Input 283 must be a noncomplex scalar double.");
    } 
    mexinput283_temp = mxGetPr(prhs[283]); 
    double mexinput283 = *mexinput283_temp; 

    double *mexinput284_temp = NULL; 
    if( !mxIsDouble(prhs[284]) || mxIsComplex(prhs[284]) || !(mxGetM(prhs[284])==1 && mxGetN(prhs[284])==1) ) { 
      mexErrMsgTxt("Input 284 must be a noncomplex scalar double.");
    } 
    mexinput284_temp = mxGetPr(prhs[284]); 
    double mexinput284 = *mexinput284_temp; 

    double *mexinput285_temp = NULL; 
    if( !mxIsDouble(prhs[285]) || mxIsComplex(prhs[285]) || !(mxGetM(prhs[285])==1 && mxGetN(prhs[285])==1) ) { 
      mexErrMsgTxt("Input 285 must be a noncomplex scalar double.");
    } 
    mexinput285_temp = mxGetPr(prhs[285]); 
    double mexinput285 = *mexinput285_temp; 

    double *mexinput286_temp = NULL; 
    if( !mxIsDouble(prhs[286]) || mxIsComplex(prhs[286]) || !(mxGetM(prhs[286])==1 && mxGetN(prhs[286])==1) ) { 
      mexErrMsgTxt("Input 286 must be a noncomplex scalar double.");
    } 
    mexinput286_temp = mxGetPr(prhs[286]); 
    double mexinput286 = *mexinput286_temp; 

    double *mexinput287_temp = NULL; 
    if( !mxIsDouble(prhs[287]) || mxIsComplex(prhs[287]) || !(mxGetM(prhs[287])==1 && mxGetN(prhs[287])==1) ) { 
      mexErrMsgTxt("Input 287 must be a noncomplex scalar double.");
    } 
    mexinput287_temp = mxGetPr(prhs[287]); 
    double mexinput287 = *mexinput287_temp; 

    double *mexinput288_temp = NULL; 
    if( !mxIsDouble(prhs[288]) || mxIsComplex(prhs[288]) || !(mxGetM(prhs[288])==1 && mxGetN(prhs[288])==1) ) { 
      mexErrMsgTxt("Input 288 must be a noncomplex scalar double.");
    } 
    mexinput288_temp = mxGetPr(prhs[288]); 
    double mexinput288 = *mexinput288_temp; 

    double *mexinput289_temp = NULL; 
    if( !mxIsDouble(prhs[289]) || mxIsComplex(prhs[289]) || !(mxGetM(prhs[289])==1 && mxGetN(prhs[289])==1) ) { 
      mexErrMsgTxt("Input 289 must be a noncomplex scalar double.");
    } 
    mexinput289_temp = mxGetPr(prhs[289]); 
    double mexinput289 = *mexinput289_temp; 

    double *mexinput290_temp = NULL; 
    if( !mxIsDouble(prhs[290]) || mxIsComplex(prhs[290]) || !(mxGetM(prhs[290])==1 && mxGetN(prhs[290])==1) ) { 
      mexErrMsgTxt("Input 290 must be a noncomplex scalar double.");
    } 
    mexinput290_temp = mxGetPr(prhs[290]); 
    double mexinput290 = *mexinput290_temp; 

    double *mexinput291_temp = NULL; 
    if( !mxIsDouble(prhs[291]) || mxIsComplex(prhs[291]) || !(mxGetM(prhs[291])==1 && mxGetN(prhs[291])==1) ) { 
      mexErrMsgTxt("Input 291 must be a noncomplex scalar double.");
    } 
    mexinput291_temp = mxGetPr(prhs[291]); 
    double mexinput291 = *mexinput291_temp; 

    double *mexinput292_temp = NULL; 
    if( !mxIsDouble(prhs[292]) || mxIsComplex(prhs[292]) || !(mxGetM(prhs[292])==1 && mxGetN(prhs[292])==1) ) { 
      mexErrMsgTxt("Input 292 must be a noncomplex scalar double.");
    } 
    mexinput292_temp = mxGetPr(prhs[292]); 
    double mexinput292 = *mexinput292_temp; 

    double *mexinput293_temp = NULL; 
    if( !mxIsDouble(prhs[293]) || mxIsComplex(prhs[293]) || !(mxGetM(prhs[293])==1 && mxGetN(prhs[293])==1) ) { 
      mexErrMsgTxt("Input 293 must be a noncomplex scalar double.");
    } 
    mexinput293_temp = mxGetPr(prhs[293]); 
    double mexinput293 = *mexinput293_temp; 

    double *mexinput294_temp = NULL; 
    if( !mxIsDouble(prhs[294]) || mxIsComplex(prhs[294]) || !(mxGetM(prhs[294])==1 && mxGetN(prhs[294])==1) ) { 
      mexErrMsgTxt("Input 294 must be a noncomplex scalar double.");
    } 
    mexinput294_temp = mxGetPr(prhs[294]); 
    double mexinput294 = *mexinput294_temp; 

    double *mexinput295_temp = NULL; 
    if( !mxIsDouble(prhs[295]) || mxIsComplex(prhs[295]) || !(mxGetM(prhs[295])==1 && mxGetN(prhs[295])==1) ) { 
      mexErrMsgTxt("Input 295 must be a noncomplex scalar double.");
    } 
    mexinput295_temp = mxGetPr(prhs[295]); 
    double mexinput295 = *mexinput295_temp; 

    double *mexinput296_temp = NULL; 
    if( !mxIsDouble(prhs[296]) || mxIsComplex(prhs[296]) || !(mxGetM(prhs[296])==1 && mxGetN(prhs[296])==1) ) { 
      mexErrMsgTxt("Input 296 must be a noncomplex scalar double.");
    } 
    mexinput296_temp = mxGetPr(prhs[296]); 
    double mexinput296 = *mexinput296_temp; 

    double *mexinput297_temp = NULL; 
    if( !mxIsDouble(prhs[297]) || mxIsComplex(prhs[297]) || !(mxGetM(prhs[297])==1 && mxGetN(prhs[297])==1) ) { 
      mexErrMsgTxt("Input 297 must be a noncomplex scalar double.");
    } 
    mexinput297_temp = mxGetPr(prhs[297]); 
    double mexinput297 = *mexinput297_temp; 

    double *mexinput298_temp = NULL; 
    if( !mxIsDouble(prhs[298]) || mxIsComplex(prhs[298]) || !(mxGetM(prhs[298])==1 && mxGetN(prhs[298])==1) ) { 
      mexErrMsgTxt("Input 298 must be a noncomplex scalar double.");
    } 
    mexinput298_temp = mxGetPr(prhs[298]); 
    double mexinput298 = *mexinput298_temp; 

    double *mexinput299_temp = NULL; 
    if( !mxIsDouble(prhs[299]) || mxIsComplex(prhs[299]) || !(mxGetM(prhs[299])==1 && mxGetN(prhs[299])==1) ) { 
      mexErrMsgTxt("Input 299 must be a noncomplex scalar double.");
    } 
    mexinput299_temp = mxGetPr(prhs[299]); 
    double mexinput299 = *mexinput299_temp; 

    double *mexinput300_temp = NULL; 
    if( !mxIsDouble(prhs[300]) || mxIsComplex(prhs[300]) || !(mxGetM(prhs[300])==1 && mxGetN(prhs[300])==1) ) { 
      mexErrMsgTxt("Input 300 must be a noncomplex scalar double.");
    } 
    mexinput300_temp = mxGetPr(prhs[300]); 
    double mexinput300 = *mexinput300_temp; 

    double *mexinput301_temp = NULL; 
    if( !mxIsDouble(prhs[301]) || mxIsComplex(prhs[301]) || !(mxGetM(prhs[301])==1 && mxGetN(prhs[301])==1) ) { 
      mexErrMsgTxt("Input 301 must be a noncomplex scalar double.");
    } 
    mexinput301_temp = mxGetPr(prhs[301]); 
    double mexinput301 = *mexinput301_temp; 

    double *mexinput302_temp = NULL; 
    if( !mxIsDouble(prhs[302]) || mxIsComplex(prhs[302]) || !(mxGetM(prhs[302])==1 && mxGetN(prhs[302])==1) ) { 
      mexErrMsgTxt("Input 302 must be a noncomplex scalar double.");
    } 
    mexinput302_temp = mxGetPr(prhs[302]); 
    double mexinput302 = *mexinput302_temp; 

    double *mexinput303_temp = NULL; 
    if( !mxIsDouble(prhs[303]) || mxIsComplex(prhs[303]) || !(mxGetM(prhs[303])==1 && mxGetN(prhs[303])==1) ) { 
      mexErrMsgTxt("Input 303 must be a noncomplex scalar double.");
    } 
    mexinput303_temp = mxGetPr(prhs[303]); 
    double mexinput303 = *mexinput303_temp; 

    double *mexinput304_temp = NULL; 
    if( !mxIsDouble(prhs[304]) || mxIsComplex(prhs[304]) || !(mxGetM(prhs[304])==1 && mxGetN(prhs[304])==1) ) { 
      mexErrMsgTxt("Input 304 must be a noncomplex scalar double.");
    } 
    mexinput304_temp = mxGetPr(prhs[304]); 
    double mexinput304 = *mexinput304_temp; 

    double *mexinput305_temp = NULL; 
    if( !mxIsDouble(prhs[305]) || mxIsComplex(prhs[305]) || !(mxGetM(prhs[305])==1 && mxGetN(prhs[305])==1) ) { 
      mexErrMsgTxt("Input 305 must be a noncomplex scalar double.");
    } 
    mexinput305_temp = mxGetPr(prhs[305]); 
    double mexinput305 = *mexinput305_temp; 

    double *mexinput306_temp = NULL; 
    if( !mxIsDouble(prhs[306]) || mxIsComplex(prhs[306]) || !(mxGetM(prhs[306])==1 && mxGetN(prhs[306])==1) ) { 
      mexErrMsgTxt("Input 306 must be a noncomplex scalar double.");
    } 
    mexinput306_temp = mxGetPr(prhs[306]); 
    double mexinput306 = *mexinput306_temp; 

    double *mexinput307_temp = NULL; 
    if( !mxIsDouble(prhs[307]) || mxIsComplex(prhs[307]) || !(mxGetM(prhs[307])==1 && mxGetN(prhs[307])==1) ) { 
      mexErrMsgTxt("Input 307 must be a noncomplex scalar double.");
    } 
    mexinput307_temp = mxGetPr(prhs[307]); 
    double mexinput307 = *mexinput307_temp; 

    double *mexinput308_temp = NULL; 
    if( !mxIsDouble(prhs[308]) || mxIsComplex(prhs[308]) || !(mxGetM(prhs[308])==1 && mxGetN(prhs[308])==1) ) { 
      mexErrMsgTxt("Input 308 must be a noncomplex scalar double.");
    } 
    mexinput308_temp = mxGetPr(prhs[308]); 
    double mexinput308 = *mexinput308_temp; 

    double *mexinput309_temp = NULL; 
    if( !mxIsDouble(prhs[309]) || mxIsComplex(prhs[309]) || !(mxGetM(prhs[309])==1 && mxGetN(prhs[309])==1) ) { 
      mexErrMsgTxt("Input 309 must be a noncomplex scalar double.");
    } 
    mexinput309_temp = mxGetPr(prhs[309]); 
    double mexinput309 = *mexinput309_temp; 

    double *mexinput310_temp = NULL; 
    if( !mxIsDouble(prhs[310]) || mxIsComplex(prhs[310]) || !(mxGetM(prhs[310])==1 && mxGetN(prhs[310])==1) ) { 
      mexErrMsgTxt("Input 310 must be a noncomplex scalar double.");
    } 
    mexinput310_temp = mxGetPr(prhs[310]); 
    double mexinput310 = *mexinput310_temp; 

    double *mexinput311_temp = NULL; 
    if( !mxIsDouble(prhs[311]) || mxIsComplex(prhs[311]) || !(mxGetM(prhs[311])==1 && mxGetN(prhs[311])==1) ) { 
      mexErrMsgTxt("Input 311 must be a noncomplex scalar double.");
    } 
    mexinput311_temp = mxGetPr(prhs[311]); 
    double mexinput311 = *mexinput311_temp; 

    double *mexinput312_temp = NULL; 
    if( !mxIsDouble(prhs[312]) || mxIsComplex(prhs[312]) || !(mxGetM(prhs[312])==1 && mxGetN(prhs[312])==1) ) { 
      mexErrMsgTxt("Input 312 must be a noncomplex scalar double.");
    } 
    mexinput312_temp = mxGetPr(prhs[312]); 
    double mexinput312 = *mexinput312_temp; 

    double *mexinput313_temp = NULL; 
    if( !mxIsDouble(prhs[313]) || mxIsComplex(prhs[313]) || !(mxGetM(prhs[313])==1 && mxGetN(prhs[313])==1) ) { 
      mexErrMsgTxt("Input 313 must be a noncomplex scalar double.");
    } 
    mexinput313_temp = mxGetPr(prhs[313]); 
    double mexinput313 = *mexinput313_temp; 

    double *mexinput314_temp = NULL; 
    if( !mxIsDouble(prhs[314]) || mxIsComplex(prhs[314]) || !(mxGetM(prhs[314])==1 && mxGetN(prhs[314])==1) ) { 
      mexErrMsgTxt("Input 314 must be a noncomplex scalar double.");
    } 
    mexinput314_temp = mxGetPr(prhs[314]); 
    double mexinput314 = *mexinput314_temp; 

    double *mexinput315_temp = NULL; 
    if( !mxIsDouble(prhs[315]) || mxIsComplex(prhs[315]) || !(mxGetM(prhs[315])==1 && mxGetN(prhs[315])==1) ) { 
      mexErrMsgTxt("Input 315 must be a noncomplex scalar double.");
    } 
    mexinput315_temp = mxGetPr(prhs[315]); 
    double mexinput315 = *mexinput315_temp; 

    double *mexinput316_temp = NULL; 
    if( !mxIsDouble(prhs[316]) || mxIsComplex(prhs[316]) || !(mxGetM(prhs[316])==1 && mxGetN(prhs[316])==1) ) { 
      mexErrMsgTxt("Input 316 must be a noncomplex scalar double.");
    } 
    mexinput316_temp = mxGetPr(prhs[316]); 
    double mexinput316 = *mexinput316_temp; 

    double *mexinput317_temp = NULL; 
    if( !mxIsDouble(prhs[317]) || mxIsComplex(prhs[317]) || !(mxGetM(prhs[317])==1 && mxGetN(prhs[317])==1) ) { 
      mexErrMsgTxt("Input 317 must be a noncomplex scalar double.");
    } 
    mexinput317_temp = mxGetPr(prhs[317]); 
    double mexinput317 = *mexinput317_temp; 

    double *mexinput318_temp = NULL; 
    if( !mxIsDouble(prhs[318]) || mxIsComplex(prhs[318]) || !(mxGetM(prhs[318])==1 && mxGetN(prhs[318])==1) ) { 
      mexErrMsgTxt("Input 318 must be a noncomplex scalar double.");
    } 
    mexinput318_temp = mxGetPr(prhs[318]); 
    double mexinput318 = *mexinput318_temp; 

    double *mexinput319_temp = NULL; 
    if( !mxIsDouble(prhs[319]) || mxIsComplex(prhs[319]) || !(mxGetM(prhs[319])==1 && mxGetN(prhs[319])==1) ) { 
      mexErrMsgTxt("Input 319 must be a noncomplex scalar double.");
    } 
    mexinput319_temp = mxGetPr(prhs[319]); 
    double mexinput319 = *mexinput319_temp; 

    double *mexinput320_temp = NULL; 
    if( !mxIsDouble(prhs[320]) || mxIsComplex(prhs[320]) || !(mxGetM(prhs[320])==1 && mxGetN(prhs[320])==1) ) { 
      mexErrMsgTxt("Input 320 must be a noncomplex scalar double.");
    } 
    mexinput320_temp = mxGetPr(prhs[320]); 
    double mexinput320 = *mexinput320_temp; 

    double *mexinput321_temp = NULL; 
    if( !mxIsDouble(prhs[321]) || mxIsComplex(prhs[321]) || !(mxGetM(prhs[321])==1 && mxGetN(prhs[321])==1) ) { 
      mexErrMsgTxt("Input 321 must be a noncomplex scalar double.");
    } 
    mexinput321_temp = mxGetPr(prhs[321]); 
    double mexinput321 = *mexinput321_temp; 

    double *mexinput322_temp = NULL; 
    if( !mxIsDouble(prhs[322]) || mxIsComplex(prhs[322]) || !(mxGetM(prhs[322])==1 && mxGetN(prhs[322])==1) ) { 
      mexErrMsgTxt("Input 322 must be a noncomplex scalar double.");
    } 
    mexinput322_temp = mxGetPr(prhs[322]); 
    double mexinput322 = *mexinput322_temp; 

    double *mexinput323_temp = NULL; 
    if( !mxIsDouble(prhs[323]) || mxIsComplex(prhs[323]) || !(mxGetM(prhs[323])==1 && mxGetN(prhs[323])==1) ) { 
      mexErrMsgTxt("Input 323 must be a noncomplex scalar double.");
    } 
    mexinput323_temp = mxGetPr(prhs[323]); 
    double mexinput323 = *mexinput323_temp; 

    double *mexinput324_temp = NULL; 
    if( !mxIsDouble(prhs[324]) || mxIsComplex(prhs[324]) || !(mxGetM(prhs[324])==1 && mxGetN(prhs[324])==1) ) { 
      mexErrMsgTxt("Input 324 must be a noncomplex scalar double.");
    } 
    mexinput324_temp = mxGetPr(prhs[324]); 
    double mexinput324 = *mexinput324_temp; 

    double *mexinput325_temp = NULL; 
    if( !mxIsDouble(prhs[325]) || mxIsComplex(prhs[325]) || !(mxGetM(prhs[325])==1 && mxGetN(prhs[325])==1) ) { 
      mexErrMsgTxt("Input 325 must be a noncomplex scalar double.");
    } 
    mexinput325_temp = mxGetPr(prhs[325]); 
    double mexinput325 = *mexinput325_temp; 

    double *mexinput326_temp = NULL; 
    if( !mxIsDouble(prhs[326]) || mxIsComplex(prhs[326]) || !(mxGetM(prhs[326])==1 && mxGetN(prhs[326])==1) ) { 
      mexErrMsgTxt("Input 326 must be a noncomplex scalar double.");
    } 
    mexinput326_temp = mxGetPr(prhs[326]); 
    double mexinput326 = *mexinput326_temp; 

    double *mexinput327_temp = NULL; 
    if( !mxIsDouble(prhs[327]) || mxIsComplex(prhs[327]) || !(mxGetM(prhs[327])==1 && mxGetN(prhs[327])==1) ) { 
      mexErrMsgTxt("Input 327 must be a noncomplex scalar double.");
    } 
    mexinput327_temp = mxGetPr(prhs[327]); 
    double mexinput327 = *mexinput327_temp; 

    double *mexinput328_temp = NULL; 
    if( !mxIsDouble(prhs[328]) || mxIsComplex(prhs[328]) || !(mxGetM(prhs[328])==1 && mxGetN(prhs[328])==1) ) { 
      mexErrMsgTxt("Input 328 must be a noncomplex scalar double.");
    } 
    mexinput328_temp = mxGetPr(prhs[328]); 
    double mexinput328 = *mexinput328_temp; 

    double *mexinput329_temp = NULL; 
    if( !mxIsDouble(prhs[329]) || mxIsComplex(prhs[329]) || !(mxGetM(prhs[329])==1 && mxGetN(prhs[329])==1) ) { 
      mexErrMsgTxt("Input 329 must be a noncomplex scalar double.");
    } 
    mexinput329_temp = mxGetPr(prhs[329]); 
    double mexinput329 = *mexinput329_temp; 

    double *mexinput330_temp = NULL; 
    if( !mxIsDouble(prhs[330]) || mxIsComplex(prhs[330]) || !(mxGetM(prhs[330])==1 && mxGetN(prhs[330])==1) ) { 
      mexErrMsgTxt("Input 330 must be a noncomplex scalar double.");
    } 
    mexinput330_temp = mxGetPr(prhs[330]); 
    double mexinput330 = *mexinput330_temp; 

    double *mexinput331_temp = NULL; 
    if( !mxIsDouble(prhs[331]) || mxIsComplex(prhs[331]) || !(mxGetM(prhs[331])==1 && mxGetN(prhs[331])==1) ) { 
      mexErrMsgTxt("Input 331 must be a noncomplex scalar double.");
    } 
    mexinput331_temp = mxGetPr(prhs[331]); 
    double mexinput331 = *mexinput331_temp; 

    double *mexinput332_temp = NULL; 
    if( !mxIsDouble(prhs[332]) || mxIsComplex(prhs[332]) || !(mxGetM(prhs[332])==1 && mxGetN(prhs[332])==1) ) { 
      mexErrMsgTxt("Input 332 must be a noncomplex scalar double.");
    } 
    mexinput332_temp = mxGetPr(prhs[332]); 
    double mexinput332 = *mexinput332_temp; 

    double *mexinput333_temp = NULL; 
    if( !mxIsDouble(prhs[333]) || mxIsComplex(prhs[333]) || !(mxGetM(prhs[333])==1 && mxGetN(prhs[333])==1) ) { 
      mexErrMsgTxt("Input 333 must be a noncomplex scalar double.");
    } 
    mexinput333_temp = mxGetPr(prhs[333]); 
    double mexinput333 = *mexinput333_temp; 

    double *mexinput334_temp = NULL; 
    if( !mxIsDouble(prhs[334]) || mxIsComplex(prhs[334]) || !(mxGetM(prhs[334])==1 && mxGetN(prhs[334])==1) ) { 
      mexErrMsgTxt("Input 334 must be a noncomplex scalar double.");
    } 
    mexinput334_temp = mxGetPr(prhs[334]); 
    double mexinput334 = *mexinput334_temp; 

    double *mexinput335_temp = NULL; 
    if( !mxIsDouble(prhs[335]) || mxIsComplex(prhs[335]) || !(mxGetM(prhs[335])==1 && mxGetN(prhs[335])==1) ) { 
      mexErrMsgTxt("Input 335 must be a noncomplex scalar double.");
    } 
    mexinput335_temp = mxGetPr(prhs[335]); 
    double mexinput335 = *mexinput335_temp; 

    double *mexinput336_temp = NULL; 
    if( !mxIsDouble(prhs[336]) || mxIsComplex(prhs[336]) || !(mxGetM(prhs[336])==1 && mxGetN(prhs[336])==1) ) { 
      mexErrMsgTxt("Input 336 must be a noncomplex scalar double.");
    } 
    mexinput336_temp = mxGetPr(prhs[336]); 
    double mexinput336 = *mexinput336_temp; 

    double *mexinput337_temp = NULL; 
    if( !mxIsDouble(prhs[337]) || mxIsComplex(prhs[337]) || !(mxGetM(prhs[337])==1 && mxGetN(prhs[337])==1) ) { 
      mexErrMsgTxt("Input 337 must be a noncomplex scalar double.");
    } 
    mexinput337_temp = mxGetPr(prhs[337]); 
    double mexinput337 = *mexinput337_temp; 

    double *mexinput338_temp = NULL; 
    if( !mxIsDouble(prhs[338]) || mxIsComplex(prhs[338]) || !(mxGetM(prhs[338])==1 && mxGetN(prhs[338])==1) ) { 
      mexErrMsgTxt("Input 338 must be a noncomplex scalar double.");
    } 
    mexinput338_temp = mxGetPr(prhs[338]); 
    double mexinput338 = *mexinput338_temp; 

    double *mexinput339_temp = NULL; 
    if( !mxIsDouble(prhs[339]) || mxIsComplex(prhs[339]) || !(mxGetM(prhs[339])==1 && mxGetN(prhs[339])==1) ) { 
      mexErrMsgTxt("Input 339 must be a noncomplex scalar double.");
    } 
    mexinput339_temp = mxGetPr(prhs[339]); 
    double mexinput339 = *mexinput339_temp; 

    double *mexinput340_temp = NULL; 
    if( !mxIsDouble(prhs[340]) || mxIsComplex(prhs[340]) || !(mxGetM(prhs[340])==1 && mxGetN(prhs[340])==1) ) { 
      mexErrMsgTxt("Input 340 must be a noncomplex scalar double.");
    } 
    mexinput340_temp = mxGetPr(prhs[340]); 
    double mexinput340 = *mexinput340_temp; 

    double *mexinput341_temp = NULL; 
    if( !mxIsDouble(prhs[341]) || mxIsComplex(prhs[341]) || !(mxGetM(prhs[341])==1 && mxGetN(prhs[341])==1) ) { 
      mexErrMsgTxt("Input 341 must be a noncomplex scalar double.");
    } 
    mexinput341_temp = mxGetPr(prhs[341]); 
    double mexinput341 = *mexinput341_temp; 

    double *mexinput342_temp = NULL; 
    if( !mxIsDouble(prhs[342]) || mxIsComplex(prhs[342]) || !(mxGetM(prhs[342])==1 && mxGetN(prhs[342])==1) ) { 
      mexErrMsgTxt("Input 342 must be a noncomplex scalar double.");
    } 
    mexinput342_temp = mxGetPr(prhs[342]); 
    double mexinput342 = *mexinput342_temp; 

    double *mexinput343_temp = NULL; 
    if( !mxIsDouble(prhs[343]) || mxIsComplex(prhs[343]) || !(mxGetM(prhs[343])==1 && mxGetN(prhs[343])==1) ) { 
      mexErrMsgTxt("Input 343 must be a noncomplex scalar double.");
    } 
    mexinput343_temp = mxGetPr(prhs[343]); 
    double mexinput343 = *mexinput343_temp; 

    double *mexinput344_temp = NULL; 
    if( !mxIsDouble(prhs[344]) || mxIsComplex(prhs[344]) || !(mxGetM(prhs[344])==1 && mxGetN(prhs[344])==1) ) { 
      mexErrMsgTxt("Input 344 must be a noncomplex scalar double.");
    } 
    mexinput344_temp = mxGetPr(prhs[344]); 
    double mexinput344 = *mexinput344_temp; 

    double *mexinput345_temp = NULL; 
    if( !mxIsDouble(prhs[345]) || mxIsComplex(prhs[345]) || !(mxGetM(prhs[345])==1 && mxGetN(prhs[345])==1) ) { 
      mexErrMsgTxt("Input 345 must be a noncomplex scalar double.");
    } 
    mexinput345_temp = mxGetPr(prhs[345]); 
    double mexinput345 = *mexinput345_temp; 

    double *mexinput346_temp = NULL; 
    if( !mxIsDouble(prhs[346]) || mxIsComplex(prhs[346]) || !(mxGetM(prhs[346])==1 && mxGetN(prhs[346])==1) ) { 
      mexErrMsgTxt("Input 346 must be a noncomplex scalar double.");
    } 
    mexinput346_temp = mxGetPr(prhs[346]); 
    double mexinput346 = *mexinput346_temp; 

    double *mexinput347_temp = NULL; 
    if( !mxIsDouble(prhs[347]) || mxIsComplex(prhs[347]) || !(mxGetM(prhs[347])==1 && mxGetN(prhs[347])==1) ) { 
      mexErrMsgTxt("Input 347 must be a noncomplex scalar double.");
    } 
    mexinput347_temp = mxGetPr(prhs[347]); 
    double mexinput347 = *mexinput347_temp; 

    double *mexinput348_temp = NULL; 
    if( !mxIsDouble(prhs[348]) || mxIsComplex(prhs[348]) || !(mxGetM(prhs[348])==1 && mxGetN(prhs[348])==1) ) { 
      mexErrMsgTxt("Input 348 must be a noncomplex scalar double.");
    } 
    mexinput348_temp = mxGetPr(prhs[348]); 
    double mexinput348 = *mexinput348_temp; 

    double *mexinput349_temp = NULL; 
    if( !mxIsDouble(prhs[349]) || mxIsComplex(prhs[349]) || !(mxGetM(prhs[349])==1 && mxGetN(prhs[349])==1) ) { 
      mexErrMsgTxt("Input 349 must be a noncomplex scalar double.");
    } 
    mexinput349_temp = mxGetPr(prhs[349]); 
    double mexinput349 = *mexinput349_temp; 

    double *mexinput350_temp = NULL; 
    if( !mxIsDouble(prhs[350]) || mxIsComplex(prhs[350]) || !(mxGetM(prhs[350])==1 && mxGetN(prhs[350])==1) ) { 
      mexErrMsgTxt("Input 350 must be a noncomplex scalar double.");
    } 
    mexinput350_temp = mxGetPr(prhs[350]); 
    double mexinput350 = *mexinput350_temp; 

    double *mexinput351_temp = NULL; 
    if( !mxIsDouble(prhs[351]) || mxIsComplex(prhs[351]) || !(mxGetM(prhs[351])==1 && mxGetN(prhs[351])==1) ) { 
      mexErrMsgTxt("Input 351 must be a noncomplex scalar double.");
    } 
    mexinput351_temp = mxGetPr(prhs[351]); 
    double mexinput351 = *mexinput351_temp; 

    double *mexinput352_temp = NULL; 
    if( !mxIsDouble(prhs[352]) || mxIsComplex(prhs[352]) || !(mxGetM(prhs[352])==1 && mxGetN(prhs[352])==1) ) { 
      mexErrMsgTxt("Input 352 must be a noncomplex scalar double.");
    } 
    mexinput352_temp = mxGetPr(prhs[352]); 
    double mexinput352 = *mexinput352_temp; 

    double *mexinput353_temp = NULL; 
    if( !mxIsDouble(prhs[353]) || mxIsComplex(prhs[353]) || !(mxGetM(prhs[353])==1 && mxGetN(prhs[353])==1) ) { 
      mexErrMsgTxt("Input 353 must be a noncomplex scalar double.");
    } 
    mexinput353_temp = mxGetPr(prhs[353]); 
    double mexinput353 = *mexinput353_temp; 

    double *mexinput354_temp = NULL; 
    if( !mxIsDouble(prhs[354]) || mxIsComplex(prhs[354]) || !(mxGetM(prhs[354])==1 && mxGetN(prhs[354])==1) ) { 
      mexErrMsgTxt("Input 354 must be a noncomplex scalar double.");
    } 
    mexinput354_temp = mxGetPr(prhs[354]); 
    double mexinput354 = *mexinput354_temp; 

    double *mexinput355_temp = NULL; 
    if( !mxIsDouble(prhs[355]) || mxIsComplex(prhs[355]) || !(mxGetM(prhs[355])==1 && mxGetN(prhs[355])==1) ) { 
      mexErrMsgTxt("Input 355 must be a noncomplex scalar double.");
    } 
    mexinput355_temp = mxGetPr(prhs[355]); 
    double mexinput355 = *mexinput355_temp; 

    double *mexinput356_temp = NULL; 
    if( !mxIsDouble(prhs[356]) || mxIsComplex(prhs[356]) || !(mxGetM(prhs[356])==1 && mxGetN(prhs[356])==1) ) { 
      mexErrMsgTxt("Input 356 must be a noncomplex scalar double.");
    } 
    mexinput356_temp = mxGetPr(prhs[356]); 
    double mexinput356 = *mexinput356_temp; 

    double *mexinput357_temp = NULL; 
    if( !mxIsDouble(prhs[357]) || mxIsComplex(prhs[357]) || !(mxGetM(prhs[357])==1 && mxGetN(prhs[357])==1) ) { 
      mexErrMsgTxt("Input 357 must be a noncomplex scalar double.");
    } 
    mexinput357_temp = mxGetPr(prhs[357]); 
    double mexinput357 = *mexinput357_temp; 

    double *mexinput358_temp = NULL; 
    if( !mxIsDouble(prhs[358]) || mxIsComplex(prhs[358]) || !(mxGetM(prhs[358])==1 && mxGetN(prhs[358])==1) ) { 
      mexErrMsgTxt("Input 358 must be a noncomplex scalar double.");
    } 
    mexinput358_temp = mxGetPr(prhs[358]); 
    double mexinput358 = *mexinput358_temp; 

    double *mexinput359_temp = NULL; 
    if( !mxIsDouble(prhs[359]) || mxIsComplex(prhs[359]) || !(mxGetM(prhs[359])==1 && mxGetN(prhs[359])==1) ) { 
      mexErrMsgTxt("Input 359 must be a noncomplex scalar double.");
    } 
    mexinput359_temp = mxGetPr(prhs[359]); 
    double mexinput359 = *mexinput359_temp; 

    double *mexinput360_temp = NULL; 
    if( !mxIsDouble(prhs[360]) || mxIsComplex(prhs[360]) || !(mxGetM(prhs[360])==1 && mxGetN(prhs[360])==1) ) { 
      mexErrMsgTxt("Input 360 must be a noncomplex scalar double.");
    } 
    mexinput360_temp = mxGetPr(prhs[360]); 
    double mexinput360 = *mexinput360_temp; 

    double *mexinput361_temp = NULL; 
    if( !mxIsDouble(prhs[361]) || mxIsComplex(prhs[361]) || !(mxGetM(prhs[361])==1 && mxGetN(prhs[361])==1) ) { 
      mexErrMsgTxt("Input 361 must be a noncomplex scalar double.");
    } 
    mexinput361_temp = mxGetPr(prhs[361]); 
    double mexinput361 = *mexinput361_temp; 

    double *mexinput362_temp = NULL; 
    if( !mxIsDouble(prhs[362]) || mxIsComplex(prhs[362]) || !(mxGetM(prhs[362])==1 && mxGetN(prhs[362])==1) ) { 
      mexErrMsgTxt("Input 362 must be a noncomplex scalar double.");
    } 
    mexinput362_temp = mxGetPr(prhs[362]); 
    double mexinput362 = *mexinput362_temp; 

    double *mexinput363_temp = NULL; 
    if( !mxIsDouble(prhs[363]) || mxIsComplex(prhs[363]) || !(mxGetM(prhs[363])==1 && mxGetN(prhs[363])==1) ) { 
      mexErrMsgTxt("Input 363 must be a noncomplex scalar double.");
    } 
    mexinput363_temp = mxGetPr(prhs[363]); 
    double mexinput363 = *mexinput363_temp; 

    double *mexinput364_temp = NULL; 
    if( !mxIsDouble(prhs[364]) || mxIsComplex(prhs[364]) || !(mxGetM(prhs[364])==1 && mxGetN(prhs[364])==1) ) { 
      mexErrMsgTxt("Input 364 must be a noncomplex scalar double.");
    } 
    mexinput364_temp = mxGetPr(prhs[364]); 
    double mexinput364 = *mexinput364_temp; 

    double *mexinput365_temp = NULL; 
    if( !mxIsDouble(prhs[365]) || mxIsComplex(prhs[365]) || !(mxGetM(prhs[365])==1 && mxGetN(prhs[365])==1) ) { 
      mexErrMsgTxt("Input 365 must be a noncomplex scalar double.");
    } 
    mexinput365_temp = mxGetPr(prhs[365]); 
    double mexinput365 = *mexinput365_temp; 

    double *mexinput366_temp = NULL; 
    if( !mxIsDouble(prhs[366]) || mxIsComplex(prhs[366]) || !(mxGetM(prhs[366])==1 && mxGetN(prhs[366])==1) ) { 
      mexErrMsgTxt("Input 366 must be a noncomplex scalar double.");
    } 
    mexinput366_temp = mxGetPr(prhs[366]); 
    double mexinput366 = *mexinput366_temp; 

    double *mexinput367_temp = NULL; 
    if( !mxIsDouble(prhs[367]) || mxIsComplex(prhs[367]) || !(mxGetM(prhs[367])==1 && mxGetN(prhs[367])==1) ) { 
      mexErrMsgTxt("Input 367 must be a noncomplex scalar double.");
    } 
    mexinput367_temp = mxGetPr(prhs[367]); 
    double mexinput367 = *mexinput367_temp; 

    double *mexinput368_temp = NULL; 
    if( !mxIsDouble(prhs[368]) || mxIsComplex(prhs[368]) || !(mxGetM(prhs[368])==1 && mxGetN(prhs[368])==1) ) { 
      mexErrMsgTxt("Input 368 must be a noncomplex scalar double.");
    } 
    mexinput368_temp = mxGetPr(prhs[368]); 
    double mexinput368 = *mexinput368_temp; 

    double *mexinput369_temp = NULL; 
    if( !mxIsDouble(prhs[369]) || mxIsComplex(prhs[369]) || !(mxGetM(prhs[369])==1 && mxGetN(prhs[369])==1) ) { 
      mexErrMsgTxt("Input 369 must be a noncomplex scalar double.");
    } 
    mexinput369_temp = mxGetPr(prhs[369]); 
    double mexinput369 = *mexinput369_temp; 

    double *mexinput370_temp = NULL; 
    if( !mxIsDouble(prhs[370]) || mxIsComplex(prhs[370]) || !(mxGetM(prhs[370])==1 && mxGetN(prhs[370])==1) ) { 
      mexErrMsgTxt("Input 370 must be a noncomplex scalar double.");
    } 
    mexinput370_temp = mxGetPr(prhs[370]); 
    double mexinput370 = *mexinput370_temp; 

    double *mexinput371_temp = NULL; 
    if( !mxIsDouble(prhs[371]) || mxIsComplex(prhs[371]) || !(mxGetM(prhs[371])==1 && mxGetN(prhs[371])==1) ) { 
      mexErrMsgTxt("Input 371 must be a noncomplex scalar double.");
    } 
    mexinput371_temp = mxGetPr(prhs[371]); 
    double mexinput371 = *mexinput371_temp; 

    double *mexinput372_temp = NULL; 
    if( !mxIsDouble(prhs[372]) || mxIsComplex(prhs[372]) || !(mxGetM(prhs[372])==1 && mxGetN(prhs[372])==1) ) { 
      mexErrMsgTxt("Input 372 must be a noncomplex scalar double.");
    } 
    mexinput372_temp = mxGetPr(prhs[372]); 
    double mexinput372 = *mexinput372_temp; 

    double *mexinput373_temp = NULL; 
    if( !mxIsDouble(prhs[373]) || mxIsComplex(prhs[373]) || !(mxGetM(prhs[373])==1 && mxGetN(prhs[373])==1) ) { 
      mexErrMsgTxt("Input 373 must be a noncomplex scalar double.");
    } 
    mexinput373_temp = mxGetPr(prhs[373]); 
    double mexinput373 = *mexinput373_temp; 

    double *mexinput374_temp = NULL; 
    if( !mxIsDouble(prhs[374]) || mxIsComplex(prhs[374]) || !(mxGetM(prhs[374])==1 && mxGetN(prhs[374])==1) ) { 
      mexErrMsgTxt("Input 374 must be a noncomplex scalar double.");
    } 
    mexinput374_temp = mxGetPr(prhs[374]); 
    double mexinput374 = *mexinput374_temp; 

    double *mexinput375_temp = NULL; 
    if( !mxIsDouble(prhs[375]) || mxIsComplex(prhs[375]) || !(mxGetM(prhs[375])==1 && mxGetN(prhs[375])==1) ) { 
      mexErrMsgTxt("Input 375 must be a noncomplex scalar double.");
    } 
    mexinput375_temp = mxGetPr(prhs[375]); 
    double mexinput375 = *mexinput375_temp; 

    double *mexinput376_temp = NULL; 
    if( !mxIsDouble(prhs[376]) || mxIsComplex(prhs[376]) || !(mxGetM(prhs[376])==1 && mxGetN(prhs[376])==1) ) { 
      mexErrMsgTxt("Input 376 must be a noncomplex scalar double.");
    } 
    mexinput376_temp = mxGetPr(prhs[376]); 
    double mexinput376 = *mexinput376_temp; 

    double *mexinput377_temp = NULL; 
    if( !mxIsDouble(prhs[377]) || mxIsComplex(prhs[377]) || !(mxGetM(prhs[377])==1 && mxGetN(prhs[377])==1) ) { 
      mexErrMsgTxt("Input 377 must be a noncomplex scalar double.");
    } 
    mexinput377_temp = mxGetPr(prhs[377]); 
    double mexinput377 = *mexinput377_temp; 

    double *mexinput378_temp = NULL; 
    if( !mxIsDouble(prhs[378]) || mxIsComplex(prhs[378]) || !(mxGetM(prhs[378])==1 && mxGetN(prhs[378])==1) ) { 
      mexErrMsgTxt("Input 378 must be a noncomplex scalar double.");
    } 
    mexinput378_temp = mxGetPr(prhs[378]); 
    double mexinput378 = *mexinput378_temp; 

    double *mexinput379_temp = NULL; 
    if( !mxIsDouble(prhs[379]) || mxIsComplex(prhs[379]) || !(mxGetM(prhs[379])==1 && mxGetN(prhs[379])==1) ) { 
      mexErrMsgTxt("Input 379 must be a noncomplex scalar double.");
    } 
    mexinput379_temp = mxGetPr(prhs[379]); 
    double mexinput379 = *mexinput379_temp; 

    double *mexinput380_temp = NULL; 
    if( !mxIsDouble(prhs[380]) || mxIsComplex(prhs[380]) || !(mxGetM(prhs[380])==1 && mxGetN(prhs[380])==1) ) { 
      mexErrMsgTxt("Input 380 must be a noncomplex scalar double.");
    } 
    mexinput380_temp = mxGetPr(prhs[380]); 
    double mexinput380 = *mexinput380_temp; 

    double *mexinput381_temp = NULL; 
    if( !mxIsDouble(prhs[381]) || mxIsComplex(prhs[381]) || !(mxGetM(prhs[381])==1 && mxGetN(prhs[381])==1) ) { 
      mexErrMsgTxt("Input 381 must be a noncomplex scalar double.");
    } 
    mexinput381_temp = mxGetPr(prhs[381]); 
    double mexinput381 = *mexinput381_temp; 

    double *mexinput382_temp = NULL; 
    if( !mxIsDouble(prhs[382]) || mxIsComplex(prhs[382]) || !(mxGetM(prhs[382])==1 && mxGetN(prhs[382])==1) ) { 
      mexErrMsgTxt("Input 382 must be a noncomplex scalar double.");
    } 
    mexinput382_temp = mxGetPr(prhs[382]); 
    double mexinput382 = *mexinput382_temp; 

    double *mexinput383_temp = NULL; 
    if( !mxIsDouble(prhs[383]) || mxIsComplex(prhs[383]) || !(mxGetM(prhs[383])==1 && mxGetN(prhs[383])==1) ) { 
      mexErrMsgTxt("Input 383 must be a noncomplex scalar double.");
    } 
    mexinput383_temp = mxGetPr(prhs[383]); 
    double mexinput383 = *mexinput383_temp; 

    double *mexinput384_temp = NULL; 
    if( !mxIsDouble(prhs[384]) || mxIsComplex(prhs[384]) || !(mxGetM(prhs[384])==1 && mxGetN(prhs[384])==1) ) { 
      mexErrMsgTxt("Input 384 must be a noncomplex scalar double.");
    } 
    mexinput384_temp = mxGetPr(prhs[384]); 
    double mexinput384 = *mexinput384_temp; 

    double *mexinput385_temp = NULL; 
    if( !mxIsDouble(prhs[385]) || mxIsComplex(prhs[385]) || !(mxGetM(prhs[385])==1 && mxGetN(prhs[385])==1) ) { 
      mexErrMsgTxt("Input 385 must be a noncomplex scalar double.");
    } 
    mexinput385_temp = mxGetPr(prhs[385]); 
    double mexinput385 = *mexinput385_temp; 

    double *mexinput386_temp = NULL; 
    if( !mxIsDouble(prhs[386]) || mxIsComplex(prhs[386]) || !(mxGetM(prhs[386])==1 && mxGetN(prhs[386])==1) ) { 
      mexErrMsgTxt("Input 386 must be a noncomplex scalar double.");
    } 
    mexinput386_temp = mxGetPr(prhs[386]); 
    double mexinput386 = *mexinput386_temp; 

    double *mexinput387_temp = NULL; 
    if( !mxIsDouble(prhs[387]) || mxIsComplex(prhs[387]) || !(mxGetM(prhs[387])==1 && mxGetN(prhs[387])==1) ) { 
      mexErrMsgTxt("Input 387 must be a noncomplex scalar double.");
    } 
    mexinput387_temp = mxGetPr(prhs[387]); 
    double mexinput387 = *mexinput387_temp; 

    double *mexinput388_temp = NULL; 
    if( !mxIsDouble(prhs[388]) || mxIsComplex(prhs[388]) || !(mxGetM(prhs[388])==1 && mxGetN(prhs[388])==1) ) { 
      mexErrMsgTxt("Input 388 must be a noncomplex scalar double.");
    } 
    mexinput388_temp = mxGetPr(prhs[388]); 
    double mexinput388 = *mexinput388_temp; 

    double *mexinput389_temp = NULL; 
    if( !mxIsDouble(prhs[389]) || mxIsComplex(prhs[389]) || !(mxGetM(prhs[389])==1 && mxGetN(prhs[389])==1) ) { 
      mexErrMsgTxt("Input 389 must be a noncomplex scalar double.");
    } 
    mexinput389_temp = mxGetPr(prhs[389]); 
    double mexinput389 = *mexinput389_temp; 

    double *mexinput390_temp = NULL; 
    if( !mxIsDouble(prhs[390]) || mxIsComplex(prhs[390]) || !(mxGetM(prhs[390])==1 && mxGetN(prhs[390])==1) ) { 
      mexErrMsgTxt("Input 390 must be a noncomplex scalar double.");
    } 
    mexinput390_temp = mxGetPr(prhs[390]); 
    double mexinput390 = *mexinput390_temp; 

    double *mexinput391_temp = NULL; 
    if( !mxIsDouble(prhs[391]) || mxIsComplex(prhs[391]) || !(mxGetM(prhs[391])==1 && mxGetN(prhs[391])==1) ) { 
      mexErrMsgTxt("Input 391 must be a noncomplex scalar double.");
    } 
    mexinput391_temp = mxGetPr(prhs[391]); 
    double mexinput391 = *mexinput391_temp; 

    double *mexinput392_temp = NULL; 
    if( !mxIsDouble(prhs[392]) || mxIsComplex(prhs[392]) || !(mxGetM(prhs[392])==1 && mxGetN(prhs[392])==1) ) { 
      mexErrMsgTxt("Input 392 must be a noncomplex scalar double.");
    } 
    mexinput392_temp = mxGetPr(prhs[392]); 
    double mexinput392 = *mexinput392_temp; 

    double *mexinput393_temp = NULL; 
    if( !mxIsDouble(prhs[393]) || mxIsComplex(prhs[393]) || !(mxGetM(prhs[393])==1 && mxGetN(prhs[393])==1) ) { 
      mexErrMsgTxt("Input 393 must be a noncomplex scalar double.");
    } 
    mexinput393_temp = mxGetPr(prhs[393]); 
    double mexinput393 = *mexinput393_temp; 

    double *mexinput394_temp = NULL; 
    if( !mxIsDouble(prhs[394]) || mxIsComplex(prhs[394]) || !(mxGetM(prhs[394])==1 && mxGetN(prhs[394])==1) ) { 
      mexErrMsgTxt("Input 394 must be a noncomplex scalar double.");
    } 
    mexinput394_temp = mxGetPr(prhs[394]); 
    double mexinput394 = *mexinput394_temp; 

    double *mexinput395_temp = NULL; 
    if( !mxIsDouble(prhs[395]) || mxIsComplex(prhs[395]) || !(mxGetM(prhs[395])==1 && mxGetN(prhs[395])==1) ) { 
      mexErrMsgTxt("Input 395 must be a noncomplex scalar double.");
    } 
    mexinput395_temp = mxGetPr(prhs[395]); 
    double mexinput395 = *mexinput395_temp; 

    double *mexinput396_temp = NULL; 
    if( !mxIsDouble(prhs[396]) || mxIsComplex(prhs[396]) || !(mxGetM(prhs[396])==1 && mxGetN(prhs[396])==1) ) { 
      mexErrMsgTxt("Input 396 must be a noncomplex scalar double.");
    } 
    mexinput396_temp = mxGetPr(prhs[396]); 
    double mexinput396 = *mexinput396_temp; 

    double *mexinput397_temp = NULL; 
    if( !mxIsDouble(prhs[397]) || mxIsComplex(prhs[397]) || !(mxGetM(prhs[397])==1 && mxGetN(prhs[397])==1) ) { 
      mexErrMsgTxt("Input 397 must be a noncomplex scalar double.");
    } 
    mexinput397_temp = mxGetPr(prhs[397]); 
    double mexinput397 = *mexinput397_temp; 

    double *mexinput398_temp = NULL; 
    if( !mxIsDouble(prhs[398]) || mxIsComplex(prhs[398]) || !(mxGetM(prhs[398])==1 && mxGetN(prhs[398])==1) ) { 
      mexErrMsgTxt("Input 398 must be a noncomplex scalar double.");
    } 
    mexinput398_temp = mxGetPr(prhs[398]); 
    double mexinput398 = *mexinput398_temp; 

    double *mexinput399_temp = NULL; 
    if( !mxIsDouble(prhs[399]) || mxIsComplex(prhs[399]) || !(mxGetM(prhs[399])==1 && mxGetN(prhs[399])==1) ) { 
      mexErrMsgTxt("Input 399 must be a noncomplex scalar double.");
    } 
    mexinput399_temp = mxGetPr(prhs[399]); 
    double mexinput399 = *mexinput399_temp; 

    double *mexinput400_temp = NULL; 
    if( !mxIsDouble(prhs[400]) || mxIsComplex(prhs[400]) || !(mxGetM(prhs[400])==1 && mxGetN(prhs[400])==1) ) { 
      mexErrMsgTxt("Input 400 must be a noncomplex scalar double.");
    } 
    mexinput400_temp = mxGetPr(prhs[400]); 
    double mexinput400 = *mexinput400_temp; 

    double *mexinput401_temp = NULL; 
    if( !mxIsDouble(prhs[401]) || mxIsComplex(prhs[401]) || !(mxGetM(prhs[401])==1 && mxGetN(prhs[401])==1) ) { 
      mexErrMsgTxt("Input 401 must be a noncomplex scalar double.");
    } 
    mexinput401_temp = mxGetPr(prhs[401]); 
    double mexinput401 = *mexinput401_temp; 

    double *mexinput402_temp = NULL; 
    if( !mxIsDouble(prhs[402]) || mxIsComplex(prhs[402]) || !(mxGetM(prhs[402])==1 && mxGetN(prhs[402])==1) ) { 
      mexErrMsgTxt("Input 402 must be a noncomplex scalar double.");
    } 
    mexinput402_temp = mxGetPr(prhs[402]); 
    double mexinput402 = *mexinput402_temp; 

    double *mexinput403_temp = NULL; 
    if( !mxIsDouble(prhs[403]) || mxIsComplex(prhs[403]) || !(mxGetM(prhs[403])==1 && mxGetN(prhs[403])==1) ) { 
      mexErrMsgTxt("Input 403 must be a noncomplex scalar double.");
    } 
    mexinput403_temp = mxGetPr(prhs[403]); 
    double mexinput403 = *mexinput403_temp; 

    double *mexinput404_temp = NULL; 
    if( !mxIsDouble(prhs[404]) || mxIsComplex(prhs[404]) || !(mxGetM(prhs[404])==1 && mxGetN(prhs[404])==1) ) { 
      mexErrMsgTxt("Input 404 must be a noncomplex scalar double.");
    } 
    mexinput404_temp = mxGetPr(prhs[404]); 
    double mexinput404 = *mexinput404_temp; 

    double *mexinput405_temp = NULL; 
    if( !mxIsDouble(prhs[405]) || mxIsComplex(prhs[405]) || !(mxGetM(prhs[405])==1 && mxGetN(prhs[405])==1) ) { 
      mexErrMsgTxt("Input 405 must be a noncomplex scalar double.");
    } 
    mexinput405_temp = mxGetPr(prhs[405]); 
    double mexinput405 = *mexinput405_temp; 

    double *mexinput406_temp = NULL; 
    if( !mxIsDouble(prhs[406]) || mxIsComplex(prhs[406]) || !(mxGetM(prhs[406])==1 && mxGetN(prhs[406])==1) ) { 
      mexErrMsgTxt("Input 406 must be a noncomplex scalar double.");
    } 
    mexinput406_temp = mxGetPr(prhs[406]); 
    double mexinput406 = *mexinput406_temp; 

    double *mexinput407_temp = NULL; 
    if( !mxIsDouble(prhs[407]) || mxIsComplex(prhs[407]) || !(mxGetM(prhs[407])==1 && mxGetN(prhs[407])==1) ) { 
      mexErrMsgTxt("Input 407 must be a noncomplex scalar double.");
    } 
    mexinput407_temp = mxGetPr(prhs[407]); 
    double mexinput407 = *mexinput407_temp; 

    double *mexinput408_temp = NULL; 
    if( !mxIsDouble(prhs[408]) || mxIsComplex(prhs[408]) || !(mxGetM(prhs[408])==1 && mxGetN(prhs[408])==1) ) { 
      mexErrMsgTxt("Input 408 must be a noncomplex scalar double.");
    } 
    mexinput408_temp = mxGetPr(prhs[408]); 
    double mexinput408 = *mexinput408_temp; 

    double *mexinput409_temp = NULL; 
    if( !mxIsDouble(prhs[409]) || mxIsComplex(prhs[409]) || !(mxGetM(prhs[409])==1 && mxGetN(prhs[409])==1) ) { 
      mexErrMsgTxt("Input 409 must be a noncomplex scalar double.");
    } 
    mexinput409_temp = mxGetPr(prhs[409]); 
    double mexinput409 = *mexinput409_temp; 

    double *mexinput410_temp = NULL; 
    if( !mxIsDouble(prhs[410]) || mxIsComplex(prhs[410]) || !(mxGetM(prhs[410])==1 && mxGetN(prhs[410])==1) ) { 
      mexErrMsgTxt("Input 410 must be a noncomplex scalar double.");
    } 
    mexinput410_temp = mxGetPr(prhs[410]); 
    double mexinput410 = *mexinput410_temp; 

    double *mexinput411_temp = NULL; 
    if( !mxIsDouble(prhs[411]) || mxIsComplex(prhs[411]) || !(mxGetM(prhs[411])==1 && mxGetN(prhs[411])==1) ) { 
      mexErrMsgTxt("Input 411 must be a noncomplex scalar double.");
    } 
    mexinput411_temp = mxGetPr(prhs[411]); 
    double mexinput411 = *mexinput411_temp; 

    double *mexinput412_temp = NULL; 
    if( !mxIsDouble(prhs[412]) || mxIsComplex(prhs[412]) || !(mxGetM(prhs[412])==1 && mxGetN(prhs[412])==1) ) { 
      mexErrMsgTxt("Input 412 must be a noncomplex scalar double.");
    } 
    mexinput412_temp = mxGetPr(prhs[412]); 
    double mexinput412 = *mexinput412_temp; 

    double *mexinput413_temp = NULL; 
    if( !mxIsDouble(prhs[413]) || mxIsComplex(prhs[413]) || !(mxGetM(prhs[413])==1 && mxGetN(prhs[413])==1) ) { 
      mexErrMsgTxt("Input 413 must be a noncomplex scalar double.");
    } 
    mexinput413_temp = mxGetPr(prhs[413]); 
    double mexinput413 = *mexinput413_temp; 

    double *mexinput414_temp = NULL; 
    if( !mxIsDouble(prhs[414]) || mxIsComplex(prhs[414]) || !(mxGetM(prhs[414])==1 && mxGetN(prhs[414])==1) ) { 
      mexErrMsgTxt("Input 414 must be a noncomplex scalar double.");
    } 
    mexinput414_temp = mxGetPr(prhs[414]); 
    double mexinput414 = *mexinput414_temp; 

    double *mexinput415_temp = NULL; 
    if( !mxIsDouble(prhs[415]) || mxIsComplex(prhs[415]) || !(mxGetM(prhs[415])==1 && mxGetN(prhs[415])==1) ) { 
      mexErrMsgTxt("Input 415 must be a noncomplex scalar double.");
    } 
    mexinput415_temp = mxGetPr(prhs[415]); 
    double mexinput415 = *mexinput415_temp; 

    double *mexinput416_temp = NULL; 
    if( !mxIsDouble(prhs[416]) || mxIsComplex(prhs[416]) || !(mxGetM(prhs[416])==1 && mxGetN(prhs[416])==1) ) { 
      mexErrMsgTxt("Input 416 must be a noncomplex scalar double.");
    } 
    mexinput416_temp = mxGetPr(prhs[416]); 
    double mexinput416 = *mexinput416_temp; 

    double *mexinput417_temp = NULL; 
    if( !mxIsDouble(prhs[417]) || mxIsComplex(prhs[417]) || !(mxGetM(prhs[417])==1 && mxGetN(prhs[417])==1) ) { 
      mexErrMsgTxt("Input 417 must be a noncomplex scalar double.");
    } 
    mexinput417_temp = mxGetPr(prhs[417]); 
    double mexinput417 = *mexinput417_temp; 

    double *mexinput418_temp = NULL; 
    if( !mxIsDouble(prhs[418]) || mxIsComplex(prhs[418]) || !(mxGetM(prhs[418])==1 && mxGetN(prhs[418])==1) ) { 
      mexErrMsgTxt("Input 418 must be a noncomplex scalar double.");
    } 
    mexinput418_temp = mxGetPr(prhs[418]); 
    double mexinput418 = *mexinput418_temp; 

    double *mexinput419_temp = NULL; 
    if( !mxIsDouble(prhs[419]) || mxIsComplex(prhs[419]) || !(mxGetM(prhs[419])==1 && mxGetN(prhs[419])==1) ) { 
      mexErrMsgTxt("Input 419 must be a noncomplex scalar double.");
    } 
    mexinput419_temp = mxGetPr(prhs[419]); 
    double mexinput419 = *mexinput419_temp; 

    double *mexinput420_temp = NULL; 
    if( !mxIsDouble(prhs[420]) || mxIsComplex(prhs[420]) || !(mxGetM(prhs[420])==1 && mxGetN(prhs[420])==1) ) { 
      mexErrMsgTxt("Input 420 must be a noncomplex scalar double.");
    } 
    mexinput420_temp = mxGetPr(prhs[420]); 
    double mexinput420 = *mexinput420_temp; 

    double *mexinput421_temp = NULL; 
    if( !mxIsDouble(prhs[421]) || mxIsComplex(prhs[421]) || !(mxGetM(prhs[421])==1 && mxGetN(prhs[421])==1) ) { 
      mexErrMsgTxt("Input 421 must be a noncomplex scalar double.");
    } 
    mexinput421_temp = mxGetPr(prhs[421]); 
    double mexinput421 = *mexinput421_temp; 

    double *mexinput422_temp = NULL; 
    if( !mxIsDouble(prhs[422]) || mxIsComplex(prhs[422]) || !(mxGetM(prhs[422])==1 && mxGetN(prhs[422])==1) ) { 
      mexErrMsgTxt("Input 422 must be a noncomplex scalar double.");
    } 
    mexinput422_temp = mxGetPr(prhs[422]); 
    double mexinput422 = *mexinput422_temp; 

    double *mexinput423_temp = NULL; 
    if( !mxIsDouble(prhs[423]) || mxIsComplex(prhs[423]) || !(mxGetM(prhs[423])==1 && mxGetN(prhs[423])==1) ) { 
      mexErrMsgTxt("Input 423 must be a noncomplex scalar double.");
    } 
    mexinput423_temp = mxGetPr(prhs[423]); 
    double mexinput423 = *mexinput423_temp; 

    double *mexinput424_temp = NULL; 
    if( !mxIsDouble(prhs[424]) || mxIsComplex(prhs[424]) || !(mxGetM(prhs[424])==1 && mxGetN(prhs[424])==1) ) { 
      mexErrMsgTxt("Input 424 must be a noncomplex scalar double.");
    } 
    mexinput424_temp = mxGetPr(prhs[424]); 
    double mexinput424 = *mexinput424_temp; 

    double *mexinput425_temp = NULL; 
    if( !mxIsDouble(prhs[425]) || mxIsComplex(prhs[425]) || !(mxGetM(prhs[425])==1 && mxGetN(prhs[425])==1) ) { 
      mexErrMsgTxt("Input 425 must be a noncomplex scalar double.");
    } 
    mexinput425_temp = mxGetPr(prhs[425]); 
    double mexinput425 = *mexinput425_temp; 

    double *mexinput426_temp = NULL; 
    if( !mxIsDouble(prhs[426]) || mxIsComplex(prhs[426]) || !(mxGetM(prhs[426])==1 && mxGetN(prhs[426])==1) ) { 
      mexErrMsgTxt("Input 426 must be a noncomplex scalar double.");
    } 
    mexinput426_temp = mxGetPr(prhs[426]); 
    double mexinput426 = *mexinput426_temp; 

    double *mexinput427_temp = NULL; 
    if( !mxIsDouble(prhs[427]) || mxIsComplex(prhs[427]) || !(mxGetM(prhs[427])==1 && mxGetN(prhs[427])==1) ) { 
      mexErrMsgTxt("Input 427 must be a noncomplex scalar double.");
    } 
    mexinput427_temp = mxGetPr(prhs[427]); 
    double mexinput427 = *mexinput427_temp; 

    double *mexinput428_temp = NULL; 
    if( !mxIsDouble(prhs[428]) || mxIsComplex(prhs[428]) || !(mxGetM(prhs[428])==1 && mxGetN(prhs[428])==1) ) { 
      mexErrMsgTxt("Input 428 must be a noncomplex scalar double.");
    } 
    mexinput428_temp = mxGetPr(prhs[428]); 
    double mexinput428 = *mexinput428_temp; 

    double *mexinput429_temp = NULL; 
    if( !mxIsDouble(prhs[429]) || mxIsComplex(prhs[429]) || !(mxGetM(prhs[429])==1 && mxGetN(prhs[429])==1) ) { 
      mexErrMsgTxt("Input 429 must be a noncomplex scalar double.");
    } 
    mexinput429_temp = mxGetPr(prhs[429]); 
    double mexinput429 = *mexinput429_temp; 

    double *mexinput430_temp = NULL; 
    if( !mxIsDouble(prhs[430]) || mxIsComplex(prhs[430]) || !(mxGetM(prhs[430])==1 && mxGetN(prhs[430])==1) ) { 
      mexErrMsgTxt("Input 430 must be a noncomplex scalar double.");
    } 
    mexinput430_temp = mxGetPr(prhs[430]); 
    double mexinput430 = *mexinput430_temp; 

    double *mexinput431_temp = NULL; 
    if( !mxIsDouble(prhs[431]) || mxIsComplex(prhs[431]) || !(mxGetM(prhs[431])==1 && mxGetN(prhs[431])==1) ) { 
      mexErrMsgTxt("Input 431 must be a noncomplex scalar double.");
    } 
    mexinput431_temp = mxGetPr(prhs[431]); 
    double mexinput431 = *mexinput431_temp; 

    double *mexinput432_temp = NULL; 
    if( !mxIsDouble(prhs[432]) || mxIsComplex(prhs[432]) || !(mxGetM(prhs[432])==1 && mxGetN(prhs[432])==1) ) { 
      mexErrMsgTxt("Input 432 must be a noncomplex scalar double.");
    } 
    mexinput432_temp = mxGetPr(prhs[432]); 
    double mexinput432 = *mexinput432_temp; 

    double *mexinput433_temp = NULL; 
    if( !mxIsDouble(prhs[433]) || mxIsComplex(prhs[433]) || !(mxGetM(prhs[433])==1 && mxGetN(prhs[433])==1) ) { 
      mexErrMsgTxt("Input 433 must be a noncomplex scalar double.");
    } 
    mexinput433_temp = mxGetPr(prhs[433]); 
    double mexinput433 = *mexinput433_temp; 

    double *mexinput434_temp = NULL; 
    if( !mxIsDouble(prhs[434]) || mxIsComplex(prhs[434]) || !(mxGetM(prhs[434])==1 && mxGetN(prhs[434])==1) ) { 
      mexErrMsgTxt("Input 434 must be a noncomplex scalar double.");
    } 
    mexinput434_temp = mxGetPr(prhs[434]); 
    double mexinput434 = *mexinput434_temp; 

    double *mexinput435_temp = NULL; 
    if( !mxIsDouble(prhs[435]) || mxIsComplex(prhs[435]) || !(mxGetM(prhs[435])==1 && mxGetN(prhs[435])==1) ) { 
      mexErrMsgTxt("Input 435 must be a noncomplex scalar double.");
    } 
    mexinput435_temp = mxGetPr(prhs[435]); 
    double mexinput435 = *mexinput435_temp; 

    double *mexinput436_temp = NULL; 
    if( !mxIsDouble(prhs[436]) || mxIsComplex(prhs[436]) || !(mxGetM(prhs[436])==1 && mxGetN(prhs[436])==1) ) { 
      mexErrMsgTxt("Input 436 must be a noncomplex scalar double.");
    } 
    mexinput436_temp = mxGetPr(prhs[436]); 
    double mexinput436 = *mexinput436_temp; 

    double *mexinput437_temp = NULL; 
    if( !mxIsDouble(prhs[437]) || mxIsComplex(prhs[437]) || !(mxGetM(prhs[437])==1 && mxGetN(prhs[437])==1) ) { 
      mexErrMsgTxt("Input 437 must be a noncomplex scalar double.");
    } 
    mexinput437_temp = mxGetPr(prhs[437]); 
    double mexinput437 = *mexinput437_temp; 

    double *mexinput438_temp = NULL; 
    if( !mxIsDouble(prhs[438]) || mxIsComplex(prhs[438]) || !(mxGetM(prhs[438])==1 && mxGetN(prhs[438])==1) ) { 
      mexErrMsgTxt("Input 438 must be a noncomplex scalar double.");
    } 
    mexinput438_temp = mxGetPr(prhs[438]); 
    double mexinput438 = *mexinput438_temp; 

    double *mexinput439_temp = NULL; 
    if( !mxIsDouble(prhs[439]) || mxIsComplex(prhs[439]) || !(mxGetM(prhs[439])==1 && mxGetN(prhs[439])==1) ) { 
      mexErrMsgTxt("Input 439 must be a noncomplex scalar double.");
    } 
    mexinput439_temp = mxGetPr(prhs[439]); 
    double mexinput439 = *mexinput439_temp; 

    double *mexinput440_temp = NULL; 
    if( !mxIsDouble(prhs[440]) || mxIsComplex(prhs[440]) || !(mxGetM(prhs[440])==1 && mxGetN(prhs[440])==1) ) { 
      mexErrMsgTxt("Input 440 must be a noncomplex scalar double.");
    } 
    mexinput440_temp = mxGetPr(prhs[440]); 
    double mexinput440 = *mexinput440_temp; 

    double *mexinput441_temp = NULL; 
    if( !mxIsDouble(prhs[441]) || mxIsComplex(prhs[441]) || !(mxGetM(prhs[441])==1 && mxGetN(prhs[441])==1) ) { 
      mexErrMsgTxt("Input 441 must be a noncomplex scalar double.");
    } 
    mexinput441_temp = mxGetPr(prhs[441]); 
    double mexinput441 = *mexinput441_temp; 

    double *mexinput442_temp = NULL; 
    if( !mxIsDouble(prhs[442]) || mxIsComplex(prhs[442]) || !(mxGetM(prhs[442])==1 && mxGetN(prhs[442])==1) ) { 
      mexErrMsgTxt("Input 442 must be a noncomplex scalar double.");
    } 
    mexinput442_temp = mxGetPr(prhs[442]); 
    double mexinput442 = *mexinput442_temp; 

    double *mexinput443_temp = NULL; 
    if( !mxIsDouble(prhs[443]) || mxIsComplex(prhs[443]) || !(mxGetM(prhs[443])==1 && mxGetN(prhs[443])==1) ) { 
      mexErrMsgTxt("Input 443 must be a noncomplex scalar double.");
    } 
    mexinput443_temp = mxGetPr(prhs[443]); 
    double mexinput443 = *mexinput443_temp; 

    double *mexinput444_temp = NULL; 
    if( !mxIsDouble(prhs[444]) || mxIsComplex(prhs[444]) || !(mxGetM(prhs[444])==1 && mxGetN(prhs[444])==1) ) { 
      mexErrMsgTxt("Input 444 must be a noncomplex scalar double.");
    } 
    mexinput444_temp = mxGetPr(prhs[444]); 
    double mexinput444 = *mexinput444_temp; 

    double *mexinput445_temp = NULL; 
    if( !mxIsDouble(prhs[445]) || mxIsComplex(prhs[445]) || !(mxGetM(prhs[445])==1 && mxGetN(prhs[445])==1) ) { 
      mexErrMsgTxt("Input 445 must be a noncomplex scalar double.");
    } 
    mexinput445_temp = mxGetPr(prhs[445]); 
    double mexinput445 = *mexinput445_temp; 

    double *mexinput446_temp = NULL; 
    if( !mxIsDouble(prhs[446]) || mxIsComplex(prhs[446]) || !(mxGetM(prhs[446])==1 && mxGetN(prhs[446])==1) ) { 
      mexErrMsgTxt("Input 446 must be a noncomplex scalar double.");
    } 
    mexinput446_temp = mxGetPr(prhs[446]); 
    double mexinput446 = *mexinput446_temp; 

    double *mexinput447_temp = NULL; 
    if( !mxIsDouble(prhs[447]) || mxIsComplex(prhs[447]) || !(mxGetM(prhs[447])==1 && mxGetN(prhs[447])==1) ) { 
      mexErrMsgTxt("Input 447 must be a noncomplex scalar double.");
    } 
    mexinput447_temp = mxGetPr(prhs[447]); 
    double mexinput447 = *mexinput447_temp; 

    double *mexinput448_temp = NULL; 
    if( !mxIsDouble(prhs[448]) || mxIsComplex(prhs[448]) || !(mxGetM(prhs[448])==1 && mxGetN(prhs[448])==1) ) { 
      mexErrMsgTxt("Input 448 must be a noncomplex scalar double.");
    } 
    mexinput448_temp = mxGetPr(prhs[448]); 
    double mexinput448 = *mexinput448_temp; 

    double *mexinput449_temp = NULL; 
    if( !mxIsDouble(prhs[449]) || mxIsComplex(prhs[449]) || !(mxGetM(prhs[449])==1 && mxGetN(prhs[449])==1) ) { 
      mexErrMsgTxt("Input 449 must be a noncomplex scalar double.");
    } 
    mexinput449_temp = mxGetPr(prhs[449]); 
    double mexinput449 = *mexinput449_temp; 

    double *mexinput450_temp = NULL; 
    if( !mxIsDouble(prhs[450]) || mxIsComplex(prhs[450]) || !(mxGetM(prhs[450])==1 && mxGetN(prhs[450])==1) ) { 
      mexErrMsgTxt("Input 450 must be a noncomplex scalar double.");
    } 
    mexinput450_temp = mxGetPr(prhs[450]); 
    double mexinput450 = *mexinput450_temp; 

    double *mexinput451_temp = NULL; 
    if( !mxIsDouble(prhs[451]) || mxIsComplex(prhs[451]) || !(mxGetM(prhs[451])==1 && mxGetN(prhs[451])==1) ) { 
      mexErrMsgTxt("Input 451 must be a noncomplex scalar double.");
    } 
    mexinput451_temp = mxGetPr(prhs[451]); 
    double mexinput451 = *mexinput451_temp; 

    double *mexinput452_temp = NULL; 
    if( !mxIsDouble(prhs[452]) || mxIsComplex(prhs[452]) || !(mxGetM(prhs[452])==1 && mxGetN(prhs[452])==1) ) { 
      mexErrMsgTxt("Input 452 must be a noncomplex scalar double.");
    } 
    mexinput452_temp = mxGetPr(prhs[452]); 
    double mexinput452 = *mexinput452_temp; 

    double *mexinput453_temp = NULL; 
    if( !mxIsDouble(prhs[453]) || mxIsComplex(prhs[453]) || !(mxGetM(prhs[453])==1 && mxGetN(prhs[453])==1) ) { 
      mexErrMsgTxt("Input 453 must be a noncomplex scalar double.");
    } 
    mexinput453_temp = mxGetPr(prhs[453]); 
    double mexinput453 = *mexinput453_temp; 

    double *mexinput454_temp = NULL; 
    if( !mxIsDouble(prhs[454]) || mxIsComplex(prhs[454]) || !(mxGetM(prhs[454])==1 && mxGetN(prhs[454])==1) ) { 
      mexErrMsgTxt("Input 454 must be a noncomplex scalar double.");
    } 
    mexinput454_temp = mxGetPr(prhs[454]); 
    double mexinput454 = *mexinput454_temp; 

    double *mexinput455_temp = NULL; 
    if( !mxIsDouble(prhs[455]) || mxIsComplex(prhs[455]) || !(mxGetM(prhs[455])==1 && mxGetN(prhs[455])==1) ) { 
      mexErrMsgTxt("Input 455 must be a noncomplex scalar double.");
    } 
    mexinput455_temp = mxGetPr(prhs[455]); 
    double mexinput455 = *mexinput455_temp; 

    double *mexinput456_temp = NULL; 
    if( !mxIsDouble(prhs[456]) || mxIsComplex(prhs[456]) || !(mxGetM(prhs[456])==1 && mxGetN(prhs[456])==1) ) { 
      mexErrMsgTxt("Input 456 must be a noncomplex scalar double.");
    } 
    mexinput456_temp = mxGetPr(prhs[456]); 
    double mexinput456 = *mexinput456_temp; 

    double *mexinput457_temp = NULL; 
    if( !mxIsDouble(prhs[457]) || mxIsComplex(prhs[457]) || !(mxGetM(prhs[457])==1 && mxGetN(prhs[457])==1) ) { 
      mexErrMsgTxt("Input 457 must be a noncomplex scalar double.");
    } 
    mexinput457_temp = mxGetPr(prhs[457]); 
    double mexinput457 = *mexinput457_temp; 

    double *mexinput458_temp = NULL; 
    if( !mxIsDouble(prhs[458]) || mxIsComplex(prhs[458]) || !(mxGetM(prhs[458])==1 && mxGetN(prhs[458])==1) ) { 
      mexErrMsgTxt("Input 458 must be a noncomplex scalar double.");
    } 
    mexinput458_temp = mxGetPr(prhs[458]); 
    double mexinput458 = *mexinput458_temp; 

    double *mexinput459_temp = NULL; 
    if( !mxIsDouble(prhs[459]) || mxIsComplex(prhs[459]) || !(mxGetM(prhs[459])==1 && mxGetN(prhs[459])==1) ) { 
      mexErrMsgTxt("Input 459 must be a noncomplex scalar double.");
    } 
    mexinput459_temp = mxGetPr(prhs[459]); 
    double mexinput459 = *mexinput459_temp; 

    double *mexinput460_temp = NULL; 
    if( !mxIsDouble(prhs[460]) || mxIsComplex(prhs[460]) || !(mxGetM(prhs[460])==1 && mxGetN(prhs[460])==1) ) { 
      mexErrMsgTxt("Input 460 must be a noncomplex scalar double.");
    } 
    mexinput460_temp = mxGetPr(prhs[460]); 
    double mexinput460 = *mexinput460_temp; 

    double *mexinput461_temp = NULL; 
    if( !mxIsDouble(prhs[461]) || mxIsComplex(prhs[461]) || !(mxGetM(prhs[461])==1 && mxGetN(prhs[461])==1) ) { 
      mexErrMsgTxt("Input 461 must be a noncomplex scalar double.");
    } 
    mexinput461_temp = mxGetPr(prhs[461]); 
    double mexinput461 = *mexinput461_temp; 

    double *mexinput462_temp = NULL; 
    if( !mxIsDouble(prhs[462]) || mxIsComplex(prhs[462]) || !(mxGetM(prhs[462])==1 && mxGetN(prhs[462])==1) ) { 
      mexErrMsgTxt("Input 462 must be a noncomplex scalar double.");
    } 
    mexinput462_temp = mxGetPr(prhs[462]); 
    double mexinput462 = *mexinput462_temp; 

    double *mexinput463_temp = NULL; 
    if( !mxIsDouble(prhs[463]) || mxIsComplex(prhs[463]) || !(mxGetM(prhs[463])==1 && mxGetN(prhs[463])==1) ) { 
      mexErrMsgTxt("Input 463 must be a noncomplex scalar double.");
    } 
    mexinput463_temp = mxGetPr(prhs[463]); 
    double mexinput463 = *mexinput463_temp; 

    double *mexinput464_temp = NULL; 
    if( !mxIsDouble(prhs[464]) || mxIsComplex(prhs[464]) || !(mxGetM(prhs[464])==1 && mxGetN(prhs[464])==1) ) { 
      mexErrMsgTxt("Input 464 must be a noncomplex scalar double.");
    } 
    mexinput464_temp = mxGetPr(prhs[464]); 
    double mexinput464 = *mexinput464_temp; 

    double *mexinput465_temp = NULL; 
    if( !mxIsDouble(prhs[465]) || mxIsComplex(prhs[465]) || !(mxGetM(prhs[465])==1 && mxGetN(prhs[465])==1) ) { 
      mexErrMsgTxt("Input 465 must be a noncomplex scalar double.");
    } 
    mexinput465_temp = mxGetPr(prhs[465]); 
    double mexinput465 = *mexinput465_temp; 

    double *mexinput466_temp = NULL; 
    if( !mxIsDouble(prhs[466]) || mxIsComplex(prhs[466]) || !(mxGetM(prhs[466])==1 && mxGetN(prhs[466])==1) ) { 
      mexErrMsgTxt("Input 466 must be a noncomplex scalar double.");
    } 
    mexinput466_temp = mxGetPr(prhs[466]); 
    double mexinput466 = *mexinput466_temp; 

    double *mexinput467_temp = NULL; 
    if( !mxIsDouble(prhs[467]) || mxIsComplex(prhs[467]) || !(mxGetM(prhs[467])==1 && mxGetN(prhs[467])==1) ) { 
      mexErrMsgTxt("Input 467 must be a noncomplex scalar double.");
    } 
    mexinput467_temp = mxGetPr(prhs[467]); 
    double mexinput467 = *mexinput467_temp; 

    double *mexinput468_temp = NULL; 
    if( !mxIsDouble(prhs[468]) || mxIsComplex(prhs[468]) || !(mxGetM(prhs[468])==1 && mxGetN(prhs[468])==1) ) { 
      mexErrMsgTxt("Input 468 must be a noncomplex scalar double.");
    } 
    mexinput468_temp = mxGetPr(prhs[468]); 
    double mexinput468 = *mexinput468_temp; 

    double *mexinput469_temp = NULL; 
    if( !mxIsDouble(prhs[469]) || mxIsComplex(prhs[469]) || !(mxGetM(prhs[469])==1 && mxGetN(prhs[469])==1) ) { 
      mexErrMsgTxt("Input 469 must be a noncomplex scalar double.");
    } 
    mexinput469_temp = mxGetPr(prhs[469]); 
    double mexinput469 = *mexinput469_temp; 

    double *mexinput470_temp = NULL; 
    if( !mxIsDouble(prhs[470]) || mxIsComplex(prhs[470]) || !(mxGetM(prhs[470])==1 && mxGetN(prhs[470])==1) ) { 
      mexErrMsgTxt("Input 470 must be a noncomplex scalar double.");
    } 
    mexinput470_temp = mxGetPr(prhs[470]); 
    double mexinput470 = *mexinput470_temp; 

    double *mexinput471_temp = NULL; 
    if( !mxIsDouble(prhs[471]) || mxIsComplex(prhs[471]) || !(mxGetM(prhs[471])==1 && mxGetN(prhs[471])==1) ) { 
      mexErrMsgTxt("Input 471 must be a noncomplex scalar double.");
    } 
    mexinput471_temp = mxGetPr(prhs[471]); 
    double mexinput471 = *mexinput471_temp; 

    double *mexinput472_temp = NULL; 
    if( !mxIsDouble(prhs[472]) || mxIsComplex(prhs[472]) || !(mxGetM(prhs[472])==1 && mxGetN(prhs[472])==1) ) { 
      mexErrMsgTxt("Input 472 must be a noncomplex scalar double.");
    } 
    mexinput472_temp = mxGetPr(prhs[472]); 
    double mexinput472 = *mexinput472_temp; 

    double *mexinput473_temp = NULL; 
    if( !mxIsDouble(prhs[473]) || mxIsComplex(prhs[473]) || !(mxGetM(prhs[473])==1 && mxGetN(prhs[473])==1) ) { 
      mexErrMsgTxt("Input 473 must be a noncomplex scalar double.");
    } 
    mexinput473_temp = mxGetPr(prhs[473]); 
    double mexinput473 = *mexinput473_temp; 

    double *mexinput474_temp = NULL; 
    if( !mxIsDouble(prhs[474]) || mxIsComplex(prhs[474]) || !(mxGetM(prhs[474])==1 && mxGetN(prhs[474])==1) ) { 
      mexErrMsgTxt("Input 474 must be a noncomplex scalar double.");
    } 
    mexinput474_temp = mxGetPr(prhs[474]); 
    double mexinput474 = *mexinput474_temp; 

    double *mexinput475_temp = NULL; 
    if( !mxIsDouble(prhs[475]) || mxIsComplex(prhs[475]) || !(mxGetM(prhs[475])==1 && mxGetN(prhs[475])==1) ) { 
      mexErrMsgTxt("Input 475 must be a noncomplex scalar double.");
    } 
    mexinput475_temp = mxGetPr(prhs[475]); 
    double mexinput475 = *mexinput475_temp; 

    double *mexinput476_temp = NULL; 
    if( !mxIsDouble(prhs[476]) || mxIsComplex(prhs[476]) || !(mxGetM(prhs[476])==1 && mxGetN(prhs[476])==1) ) { 
      mexErrMsgTxt("Input 476 must be a noncomplex scalar double.");
    } 
    mexinput476_temp = mxGetPr(prhs[476]); 
    double mexinput476 = *mexinput476_temp; 

    double *mexinput477_temp = NULL; 
    if( !mxIsDouble(prhs[477]) || mxIsComplex(prhs[477]) || !(mxGetM(prhs[477])==1 && mxGetN(prhs[477])==1) ) { 
      mexErrMsgTxt("Input 477 must be a noncomplex scalar double.");
    } 
    mexinput477_temp = mxGetPr(prhs[477]); 
    double mexinput477 = *mexinput477_temp; 

    double *mexinput478_temp = NULL; 
    if( !mxIsDouble(prhs[478]) || mxIsComplex(prhs[478]) || !(mxGetM(prhs[478])==1 && mxGetN(prhs[478])==1) ) { 
      mexErrMsgTxt("Input 478 must be a noncomplex scalar double.");
    } 
    mexinput478_temp = mxGetPr(prhs[478]); 
    double mexinput478 = *mexinput478_temp; 

    double *mexinput479_temp = NULL; 
    if( !mxIsDouble(prhs[479]) || mxIsComplex(prhs[479]) || !(mxGetM(prhs[479])==1 && mxGetN(prhs[479])==1) ) { 
      mexErrMsgTxt("Input 479 must be a noncomplex scalar double.");
    } 
    mexinput479_temp = mxGetPr(prhs[479]); 
    double mexinput479 = *mexinput479_temp; 

    double *mexinput480_temp = NULL; 
    if( !mxIsDouble(prhs[480]) || mxIsComplex(prhs[480]) || !(mxGetM(prhs[480])==1 && mxGetN(prhs[480])==1) ) { 
      mexErrMsgTxt("Input 480 must be a noncomplex scalar double.");
    } 
    mexinput480_temp = mxGetPr(prhs[480]); 
    double mexinput480 = *mexinput480_temp; 

    double *mexinput481_temp = NULL; 
    if( !mxIsDouble(prhs[481]) || mxIsComplex(prhs[481]) || !(mxGetM(prhs[481])==1 && mxGetN(prhs[481])==1) ) { 
      mexErrMsgTxt("Input 481 must be a noncomplex scalar double.");
    } 
    mexinput481_temp = mxGetPr(prhs[481]); 
    double mexinput481 = *mexinput481_temp; 

    double *mexinput482_temp = NULL; 
    if( !mxIsDouble(prhs[482]) || mxIsComplex(prhs[482]) || !(mxGetM(prhs[482])==1 && mxGetN(prhs[482])==1) ) { 
      mexErrMsgTxt("Input 482 must be a noncomplex scalar double.");
    } 
    mexinput482_temp = mxGetPr(prhs[482]); 
    double mexinput482 = *mexinput482_temp; 

    double *mexinput483_temp = NULL; 
    if( !mxIsDouble(prhs[483]) || mxIsComplex(prhs[483]) || !(mxGetM(prhs[483])==1 && mxGetN(prhs[483])==1) ) { 
      mexErrMsgTxt("Input 483 must be a noncomplex scalar double.");
    } 
    mexinput483_temp = mxGetPr(prhs[483]); 
    double mexinput483 = *mexinput483_temp; 

    double *mexinput484_temp = NULL; 
    if( !mxIsDouble(prhs[484]) || mxIsComplex(prhs[484]) || !(mxGetM(prhs[484])==1 && mxGetN(prhs[484])==1) ) { 
      mexErrMsgTxt("Input 484 must be a noncomplex scalar double.");
    } 
    mexinput484_temp = mxGetPr(prhs[484]); 
    double mexinput484 = *mexinput484_temp; 

    double *mexinput485_temp = NULL; 
    if( !mxIsDouble(prhs[485]) || mxIsComplex(prhs[485]) || !(mxGetM(prhs[485])==1 && mxGetN(prhs[485])==1) ) { 
      mexErrMsgTxt("Input 485 must be a noncomplex scalar double.");
    } 
    mexinput485_temp = mxGetPr(prhs[485]); 
    double mexinput485 = *mexinput485_temp; 

    double *mexinput486_temp = NULL; 
    if( !mxIsDouble(prhs[486]) || mxIsComplex(prhs[486]) || !(mxGetM(prhs[486])==1 && mxGetN(prhs[486])==1) ) { 
      mexErrMsgTxt("Input 486 must be a noncomplex scalar double.");
    } 
    mexinput486_temp = mxGetPr(prhs[486]); 
    double mexinput486 = *mexinput486_temp; 

    double *mexinput487_temp = NULL; 
    if( !mxIsDouble(prhs[487]) || mxIsComplex(prhs[487]) || !(mxGetM(prhs[487])==1 && mxGetN(prhs[487])==1) ) { 
      mexErrMsgTxt("Input 487 must be a noncomplex scalar double.");
    } 
    mexinput487_temp = mxGetPr(prhs[487]); 
    double mexinput487 = *mexinput487_temp; 

    double *mexinput488_temp = NULL; 
    if( !mxIsDouble(prhs[488]) || mxIsComplex(prhs[488]) || !(mxGetM(prhs[488])==1 && mxGetN(prhs[488])==1) ) { 
      mexErrMsgTxt("Input 488 must be a noncomplex scalar double.");
    } 
    mexinput488_temp = mxGetPr(prhs[488]); 
    double mexinput488 = *mexinput488_temp; 

    double *mexinput489_temp = NULL; 
    if( !mxIsDouble(prhs[489]) || mxIsComplex(prhs[489]) || !(mxGetM(prhs[489])==1 && mxGetN(prhs[489])==1) ) { 
      mexErrMsgTxt("Input 489 must be a noncomplex scalar double.");
    } 
    mexinput489_temp = mxGetPr(prhs[489]); 
    double mexinput489 = *mexinput489_temp; 

    double *mexinput490_temp = NULL; 
    if( !mxIsDouble(prhs[490]) || mxIsComplex(prhs[490]) || !(mxGetM(prhs[490])==1 && mxGetN(prhs[490])==1) ) { 
      mexErrMsgTxt("Input 490 must be a noncomplex scalar double.");
    } 
    mexinput490_temp = mxGetPr(prhs[490]); 
    double mexinput490 = *mexinput490_temp; 

    double *mexinput491_temp = NULL; 
    if( !mxIsDouble(prhs[491]) || mxIsComplex(prhs[491]) || !(mxGetM(prhs[491])==1 && mxGetN(prhs[491])==1) ) { 
      mexErrMsgTxt("Input 491 must be a noncomplex scalar double.");
    } 
    mexinput491_temp = mxGetPr(prhs[491]); 
    double mexinput491 = *mexinput491_temp; 

    double *mexinput492_temp = NULL; 
    if( !mxIsDouble(prhs[492]) || mxIsComplex(prhs[492]) || !(mxGetM(prhs[492])==1 && mxGetN(prhs[492])==1) ) { 
      mexErrMsgTxt("Input 492 must be a noncomplex scalar double.");
    } 
    mexinput492_temp = mxGetPr(prhs[492]); 
    double mexinput492 = *mexinput492_temp; 

    double *mexinput493_temp = NULL; 
    if( !mxIsDouble(prhs[493]) || mxIsComplex(prhs[493]) || !(mxGetM(prhs[493])==1 && mxGetN(prhs[493])==1) ) { 
      mexErrMsgTxt("Input 493 must be a noncomplex scalar double.");
    } 
    mexinput493_temp = mxGetPr(prhs[493]); 
    double mexinput493 = *mexinput493_temp; 

    double *mexinput494_temp = NULL; 
    if( !mxIsDouble(prhs[494]) || mxIsComplex(prhs[494]) || !(mxGetM(prhs[494])==1 && mxGetN(prhs[494])==1) ) { 
      mexErrMsgTxt("Input 494 must be a noncomplex scalar double.");
    } 
    mexinput494_temp = mxGetPr(prhs[494]); 
    double mexinput494 = *mexinput494_temp; 

    double *mexinput495_temp = NULL; 
    if( !mxIsDouble(prhs[495]) || mxIsComplex(prhs[495]) || !(mxGetM(prhs[495])==1 && mxGetN(prhs[495])==1) ) { 
      mexErrMsgTxt("Input 495 must be a noncomplex scalar double.");
    } 
    mexinput495_temp = mxGetPr(prhs[495]); 
    double mexinput495 = *mexinput495_temp; 

    double *mexinput496_temp = NULL; 
    if( !mxIsDouble(prhs[496]) || mxIsComplex(prhs[496]) || !(mxGetM(prhs[496])==1 && mxGetN(prhs[496])==1) ) { 
      mexErrMsgTxt("Input 496 must be a noncomplex scalar double.");
    } 
    mexinput496_temp = mxGetPr(prhs[496]); 
    double mexinput496 = *mexinput496_temp; 

    double *mexinput497_temp = NULL; 
    if( !mxIsDouble(prhs[497]) || mxIsComplex(prhs[497]) || !(mxGetM(prhs[497])==1 && mxGetN(prhs[497])==1) ) { 
      mexErrMsgTxt("Input 497 must be a noncomplex scalar double.");
    } 
    mexinput497_temp = mxGetPr(prhs[497]); 
    double mexinput497 = *mexinput497_temp; 

    double *mexinput498_temp = NULL; 
    if( !mxIsDouble(prhs[498]) || mxIsComplex(prhs[498]) || !(mxGetM(prhs[498])==1 && mxGetN(prhs[498])==1) ) { 
      mexErrMsgTxt("Input 498 must be a noncomplex scalar double.");
    } 
    mexinput498_temp = mxGetPr(prhs[498]); 
    double mexinput498 = *mexinput498_temp; 

    double *mexinput499_temp = NULL; 
    if( !mxIsDouble(prhs[499]) || mxIsComplex(prhs[499]) || !(mxGetM(prhs[499])==1 && mxGetN(prhs[499])==1) ) { 
      mexErrMsgTxt("Input 499 must be a noncomplex scalar double.");
    } 
    mexinput499_temp = mxGetPr(prhs[499]); 
    double mexinput499 = *mexinput499_temp; 

    double *mexinput500_temp = NULL; 
    if( !mxIsDouble(prhs[500]) || mxIsComplex(prhs[500]) || !(mxGetM(prhs[500])==1 && mxGetN(prhs[500])==1) ) { 
      mexErrMsgTxt("Input 500 must be a noncomplex scalar double.");
    } 
    mexinput500_temp = mxGetPr(prhs[500]); 
    double mexinput500 = *mexinput500_temp; 

    double *mexinput501_temp = NULL; 
    if( !mxIsDouble(prhs[501]) || mxIsComplex(prhs[501]) || !(mxGetM(prhs[501])==1 && mxGetN(prhs[501])==1) ) { 
      mexErrMsgTxt("Input 501 must be a noncomplex scalar double.");
    } 
    mexinput501_temp = mxGetPr(prhs[501]); 
    double mexinput501 = *mexinput501_temp; 

    double *mexinput502_temp = NULL; 
    if( !mxIsDouble(prhs[502]) || mxIsComplex(prhs[502]) || !(mxGetM(prhs[502])==1 && mxGetN(prhs[502])==1) ) { 
      mexErrMsgTxt("Input 502 must be a noncomplex scalar double.");
    } 
    mexinput502_temp = mxGetPr(prhs[502]); 
    double mexinput502 = *mexinput502_temp; 

    double *mexinput503_temp = NULL; 
    if( !mxIsDouble(prhs[503]) || mxIsComplex(prhs[503]) || !(mxGetM(prhs[503])==1 && mxGetN(prhs[503])==1) ) { 
      mexErrMsgTxt("Input 503 must be a noncomplex scalar double.");
    } 
    mexinput503_temp = mxGetPr(prhs[503]); 
    double mexinput503 = *mexinput503_temp; 

    double *mexinput504_temp = NULL; 
    if( !mxIsDouble(prhs[504]) || mxIsComplex(prhs[504]) || !(mxGetM(prhs[504])==1 && mxGetN(prhs[504])==1) ) { 
      mexErrMsgTxt("Input 504 must be a noncomplex scalar double.");
    } 
    mexinput504_temp = mxGetPr(prhs[504]); 
    double mexinput504 = *mexinput504_temp; 

    double *mexinput505_temp = NULL; 
    if( !mxIsDouble(prhs[505]) || mxIsComplex(prhs[505]) || !(mxGetM(prhs[505])==1 && mxGetN(prhs[505])==1) ) { 
      mexErrMsgTxt("Input 505 must be a noncomplex scalar double.");
    } 
    mexinput505_temp = mxGetPr(prhs[505]); 
    double mexinput505 = *mexinput505_temp; 

    double *mexinput506_temp = NULL; 
    if( !mxIsDouble(prhs[506]) || mxIsComplex(prhs[506]) || !(mxGetM(prhs[506])==1 && mxGetN(prhs[506])==1) ) { 
      mexErrMsgTxt("Input 506 must be a noncomplex scalar double.");
    } 
    mexinput506_temp = mxGetPr(prhs[506]); 
    double mexinput506 = *mexinput506_temp; 

    double *mexinput507_temp = NULL; 
    if( !mxIsDouble(prhs[507]) || mxIsComplex(prhs[507]) || !(mxGetM(prhs[507])==1 && mxGetN(prhs[507])==1) ) { 
      mexErrMsgTxt("Input 507 must be a noncomplex scalar double.");
    } 
    mexinput507_temp = mxGetPr(prhs[507]); 
    double mexinput507 = *mexinput507_temp; 

    double *mexinput508_temp = NULL; 
    if( !mxIsDouble(prhs[508]) || mxIsComplex(prhs[508]) || !(mxGetM(prhs[508])==1 && mxGetN(prhs[508])==1) ) { 
      mexErrMsgTxt("Input 508 must be a noncomplex scalar double.");
    } 
    mexinput508_temp = mxGetPr(prhs[508]); 
    double mexinput508 = *mexinput508_temp; 

    double *mexinput509_temp = NULL; 
    if( !mxIsDouble(prhs[509]) || mxIsComplex(prhs[509]) || !(mxGetM(prhs[509])==1 && mxGetN(prhs[509])==1) ) { 
      mexErrMsgTxt("Input 509 must be a noncomplex scalar double.");
    } 
    mexinput509_temp = mxGetPr(prhs[509]); 
    double mexinput509 = *mexinput509_temp; 

    double *mexinput510_temp = NULL; 
    if( !mxIsDouble(prhs[510]) || mxIsComplex(prhs[510]) || !(mxGetM(prhs[510])==1 && mxGetN(prhs[510])==1) ) { 
      mexErrMsgTxt("Input 510 must be a noncomplex scalar double.");
    } 
    mexinput510_temp = mxGetPr(prhs[510]); 
    double mexinput510 = *mexinput510_temp; 

    double *mexinput511_temp = NULL; 
    if( !mxIsDouble(prhs[511]) || mxIsComplex(prhs[511]) || !(mxGetM(prhs[511])==1 && mxGetN(prhs[511])==1) ) { 
      mexErrMsgTxt("Input 511 must be a noncomplex scalar double.");
    } 
    mexinput511_temp = mxGetPr(prhs[511]); 
    double mexinput511 = *mexinput511_temp; 

    double *mexinput512_temp = NULL; 
    if( !mxIsDouble(prhs[512]) || mxIsComplex(prhs[512]) || !(mxGetM(prhs[512])==1 && mxGetN(prhs[512])==1) ) { 
      mexErrMsgTxt("Input 512 must be a noncomplex scalar double.");
    } 
    mexinput512_temp = mxGetPr(prhs[512]); 
    double mexinput512 = *mexinput512_temp; 

    double *mexinput513_temp = NULL; 
    if( !mxIsDouble(prhs[513]) || mxIsComplex(prhs[513]) || !(mxGetM(prhs[513])==1 && mxGetN(prhs[513])==1) ) { 
      mexErrMsgTxt("Input 513 must be a noncomplex scalar double.");
    } 
    mexinput513_temp = mxGetPr(prhs[513]); 
    double mexinput513 = *mexinput513_temp; 

    double *mexinput514_temp = NULL; 
    if( !mxIsDouble(prhs[514]) || mxIsComplex(prhs[514]) || !(mxGetM(prhs[514])==1 && mxGetN(prhs[514])==1) ) { 
      mexErrMsgTxt("Input 514 must be a noncomplex scalar double.");
    } 
    mexinput514_temp = mxGetPr(prhs[514]); 
    double mexinput514 = *mexinput514_temp; 

    double *mexinput515_temp = NULL; 
    if( !mxIsDouble(prhs[515]) || mxIsComplex(prhs[515]) || !(mxGetM(prhs[515])==1 && mxGetN(prhs[515])==1) ) { 
      mexErrMsgTxt("Input 515 must be a noncomplex scalar double.");
    } 
    mexinput515_temp = mxGetPr(prhs[515]); 
    double mexinput515 = *mexinput515_temp; 

    double *mexinput516_temp = NULL; 
    if( !mxIsDouble(prhs[516]) || mxIsComplex(prhs[516]) || !(mxGetM(prhs[516])==1 && mxGetN(prhs[516])==1) ) { 
      mexErrMsgTxt("Input 516 must be a noncomplex scalar double.");
    } 
    mexinput516_temp = mxGetPr(prhs[516]); 
    double mexinput516 = *mexinput516_temp; 

    double *mexinput517_temp = NULL; 
    if( !mxIsDouble(prhs[517]) || mxIsComplex(prhs[517]) || !(mxGetM(prhs[517])==1 && mxGetN(prhs[517])==1) ) { 
      mexErrMsgTxt("Input 517 must be a noncomplex scalar double.");
    } 
    mexinput517_temp = mxGetPr(prhs[517]); 
    double mexinput517 = *mexinput517_temp; 

    double *mexinput518_temp = NULL; 
    if( !mxIsDouble(prhs[518]) || mxIsComplex(prhs[518]) || !(mxGetM(prhs[518])==1 && mxGetN(prhs[518])==1) ) { 
      mexErrMsgTxt("Input 518 must be a noncomplex scalar double.");
    } 
    mexinput518_temp = mxGetPr(prhs[518]); 
    double mexinput518 = *mexinput518_temp; 

    double *mexinput519_temp = NULL; 
    if( !mxIsDouble(prhs[519]) || mxIsComplex(prhs[519]) || !(mxGetM(prhs[519])==1 && mxGetN(prhs[519])==1) ) { 
      mexErrMsgTxt("Input 519 must be a noncomplex scalar double.");
    } 
    mexinput519_temp = mxGetPr(prhs[519]); 
    double mexinput519 = *mexinput519_temp; 

    double *mexinput520_temp = NULL; 
    if( !mxIsDouble(prhs[520]) || mxIsComplex(prhs[520]) || !(mxGetM(prhs[520])==1 && mxGetN(prhs[520])==1) ) { 
      mexErrMsgTxt("Input 520 must be a noncomplex scalar double.");
    } 
    mexinput520_temp = mxGetPr(prhs[520]); 
    double mexinput520 = *mexinput520_temp; 

    double *mexinput521_temp = NULL; 
    if( !mxIsDouble(prhs[521]) || mxIsComplex(prhs[521]) || !(mxGetM(prhs[521])==1 && mxGetN(prhs[521])==1) ) { 
      mexErrMsgTxt("Input 521 must be a noncomplex scalar double.");
    } 
    mexinput521_temp = mxGetPr(prhs[521]); 
    double mexinput521 = *mexinput521_temp; 

    double *mexinput522_temp = NULL; 
    if( !mxIsDouble(prhs[522]) || mxIsComplex(prhs[522]) || !(mxGetM(prhs[522])==1 && mxGetN(prhs[522])==1) ) { 
      mexErrMsgTxt("Input 522 must be a noncomplex scalar double.");
    } 
    mexinput522_temp = mxGetPr(prhs[522]); 
    double mexinput522 = *mexinput522_temp; 

    double *mexinput523_temp = NULL; 
    if( !mxIsDouble(prhs[523]) || mxIsComplex(prhs[523]) || !(mxGetM(prhs[523])==1 && mxGetN(prhs[523])==1) ) { 
      mexErrMsgTxt("Input 523 must be a noncomplex scalar double.");
    } 
    mexinput523_temp = mxGetPr(prhs[523]); 
    double mexinput523 = *mexinput523_temp; 

    double *mexinput524_temp = NULL; 
    if( !mxIsDouble(prhs[524]) || mxIsComplex(prhs[524]) || !(mxGetM(prhs[524])==1 && mxGetN(prhs[524])==1) ) { 
      mexErrMsgTxt("Input 524 must be a noncomplex scalar double.");
    } 
    mexinput524_temp = mxGetPr(prhs[524]); 
    double mexinput524 = *mexinput524_temp; 

    double *mexinput525_temp = NULL; 
    if( !mxIsDouble(prhs[525]) || mxIsComplex(prhs[525]) || !(mxGetM(prhs[525])==1 && mxGetN(prhs[525])==1) ) { 
      mexErrMsgTxt("Input 525 must be a noncomplex scalar double.");
    } 
    mexinput525_temp = mxGetPr(prhs[525]); 
    double mexinput525 = *mexinput525_temp; 

    double *mexinput526_temp = NULL; 
    if( !mxIsDouble(prhs[526]) || mxIsComplex(prhs[526]) || !(mxGetM(prhs[526])==1 && mxGetN(prhs[526])==1) ) { 
      mexErrMsgTxt("Input 526 must be a noncomplex scalar double.");
    } 
    mexinput526_temp = mxGetPr(prhs[526]); 
    double mexinput526 = *mexinput526_temp; 

    double *mexinput527_temp = NULL; 
    if( !mxIsDouble(prhs[527]) || mxIsComplex(prhs[527]) || !(mxGetM(prhs[527])==1 && mxGetN(prhs[527])==1) ) { 
      mexErrMsgTxt("Input 527 must be a noncomplex scalar double.");
    } 
    mexinput527_temp = mxGetPr(prhs[527]); 
    double mexinput527 = *mexinput527_temp; 

    double *mexinput528_temp = NULL; 
    if( !mxIsDouble(prhs[528]) || mxIsComplex(prhs[528]) || !(mxGetM(prhs[528])==1 && mxGetN(prhs[528])==1) ) { 
      mexErrMsgTxt("Input 528 must be a noncomplex scalar double.");
    } 
    mexinput528_temp = mxGetPr(prhs[528]); 
    double mexinput528 = *mexinput528_temp; 

    double *mexinput529_temp = NULL; 
    if( !mxIsDouble(prhs[529]) || mxIsComplex(prhs[529]) || !(mxGetM(prhs[529])==1 && mxGetN(prhs[529])==1) ) { 
      mexErrMsgTxt("Input 529 must be a noncomplex scalar double.");
    } 
    mexinput529_temp = mxGetPr(prhs[529]); 
    double mexinput529 = *mexinput529_temp; 

    double *mexinput530_temp = NULL; 
    if( !mxIsDouble(prhs[530]) || mxIsComplex(prhs[530]) || !(mxGetM(prhs[530])==1 && mxGetN(prhs[530])==1) ) { 
      mexErrMsgTxt("Input 530 must be a noncomplex scalar double.");
    } 
    mexinput530_temp = mxGetPr(prhs[530]); 
    double mexinput530 = *mexinput530_temp; 

    double *mexinput531_temp = NULL; 
    if( !mxIsDouble(prhs[531]) || mxIsComplex(prhs[531]) || !(mxGetM(prhs[531])==1 && mxGetN(prhs[531])==1) ) { 
      mexErrMsgTxt("Input 531 must be a noncomplex scalar double.");
    } 
    mexinput531_temp = mxGetPr(prhs[531]); 
    double mexinput531 = *mexinput531_temp; 

    double *mexinput532_temp = NULL; 
    if( !mxIsDouble(prhs[532]) || mxIsComplex(prhs[532]) || !(mxGetM(prhs[532])==1 && mxGetN(prhs[532])==1) ) { 
      mexErrMsgTxt("Input 532 must be a noncomplex scalar double.");
    } 
    mexinput532_temp = mxGetPr(prhs[532]); 
    double mexinput532 = *mexinput532_temp; 

    double *mexinput533_temp = NULL; 
    if( !mxIsDouble(prhs[533]) || mxIsComplex(prhs[533]) || !(mxGetM(prhs[533])==1 && mxGetN(prhs[533])==1) ) { 
      mexErrMsgTxt("Input 533 must be a noncomplex scalar double.");
    } 
    mexinput533_temp = mxGetPr(prhs[533]); 
    double mexinput533 = *mexinput533_temp; 

    double *mexinput534_temp = NULL; 
    if( !mxIsDouble(prhs[534]) || mxIsComplex(prhs[534]) || !(mxGetM(prhs[534])==1 && mxGetN(prhs[534])==1) ) { 
      mexErrMsgTxt("Input 534 must be a noncomplex scalar double.");
    } 
    mexinput534_temp = mxGetPr(prhs[534]); 
    double mexinput534 = *mexinput534_temp; 

    double *mexinput535_temp = NULL; 
    if( !mxIsDouble(prhs[535]) || mxIsComplex(prhs[535]) || !(mxGetM(prhs[535])==1 && mxGetN(prhs[535])==1) ) { 
      mexErrMsgTxt("Input 535 must be a noncomplex scalar double.");
    } 
    mexinput535_temp = mxGetPr(prhs[535]); 
    double mexinput535 = *mexinput535_temp; 

    double *mexinput536_temp = NULL; 
    if( !mxIsDouble(prhs[536]) || mxIsComplex(prhs[536]) || !(mxGetM(prhs[536])==1 && mxGetN(prhs[536])==1) ) { 
      mexErrMsgTxt("Input 536 must be a noncomplex scalar double.");
    } 
    mexinput536_temp = mxGetPr(prhs[536]); 
    double mexinput536 = *mexinput536_temp; 

    double *mexinput537_temp = NULL; 
    if( !mxIsDouble(prhs[537]) || mxIsComplex(prhs[537]) || !(mxGetM(prhs[537])==1 && mxGetN(prhs[537])==1) ) { 
      mexErrMsgTxt("Input 537 must be a noncomplex scalar double.");
    } 
    mexinput537_temp = mxGetPr(prhs[537]); 
    double mexinput537 = *mexinput537_temp; 

    double *mexinput538_temp = NULL; 
    if( !mxIsDouble(prhs[538]) || mxIsComplex(prhs[538]) || !(mxGetM(prhs[538])==1 && mxGetN(prhs[538])==1) ) { 
      mexErrMsgTxt("Input 538 must be a noncomplex scalar double.");
    } 
    mexinput538_temp = mxGetPr(prhs[538]); 
    double mexinput538 = *mexinput538_temp; 

    double *mexinput539_temp = NULL; 
    if( !mxIsDouble(prhs[539]) || mxIsComplex(prhs[539]) || !(mxGetM(prhs[539])==1 && mxGetN(prhs[539])==1) ) { 
      mexErrMsgTxt("Input 539 must be a noncomplex scalar double.");
    } 
    mexinput539_temp = mxGetPr(prhs[539]); 
    double mexinput539 = *mexinput539_temp; 

    double *mexinput540_temp = NULL; 
    if( !mxIsDouble(prhs[540]) || mxIsComplex(prhs[540]) || !(mxGetM(prhs[540])==1 && mxGetN(prhs[540])==1) ) { 
      mexErrMsgTxt("Input 540 must be a noncomplex scalar double.");
    } 
    mexinput540_temp = mxGetPr(prhs[540]); 
    double mexinput540 = *mexinput540_temp; 

    double *mexinput541_temp = NULL; 
    if( !mxIsDouble(prhs[541]) || mxIsComplex(prhs[541]) || !(mxGetM(prhs[541])==1 && mxGetN(prhs[541])==1) ) { 
      mexErrMsgTxt("Input 541 must be a noncomplex scalar double.");
    } 
    mexinput541_temp = mxGetPr(prhs[541]); 
    double mexinput541 = *mexinput541_temp; 

    double *mexinput542_temp = NULL; 
    if( !mxIsDouble(prhs[542]) || mxIsComplex(prhs[542]) || !(mxGetM(prhs[542])==1 && mxGetN(prhs[542])==1) ) { 
      mexErrMsgTxt("Input 542 must be a noncomplex scalar double.");
    } 
    mexinput542_temp = mxGetPr(prhs[542]); 
    double mexinput542 = *mexinput542_temp; 

    double *mexinput543_temp = NULL; 
    if( !mxIsDouble(prhs[543]) || mxIsComplex(prhs[543]) || !(mxGetM(prhs[543])==1 && mxGetN(prhs[543])==1) ) { 
      mexErrMsgTxt("Input 543 must be a noncomplex scalar double.");
    } 
    mexinput543_temp = mxGetPr(prhs[543]); 
    double mexinput543 = *mexinput543_temp; 

    double *mexinput544_temp = NULL; 
    if( !mxIsDouble(prhs[544]) || mxIsComplex(prhs[544]) || !(mxGetM(prhs[544])==1 && mxGetN(prhs[544])==1) ) { 
      mexErrMsgTxt("Input 544 must be a noncomplex scalar double.");
    } 
    mexinput544_temp = mxGetPr(prhs[544]); 
    double mexinput544 = *mexinput544_temp; 

    double *mexinput545_temp = NULL; 
    if( !mxIsDouble(prhs[545]) || mxIsComplex(prhs[545]) || !(mxGetM(prhs[545])==1 && mxGetN(prhs[545])==1) ) { 
      mexErrMsgTxt("Input 545 must be a noncomplex scalar double.");
    } 
    mexinput545_temp = mxGetPr(prhs[545]); 
    double mexinput545 = *mexinput545_temp; 

    double *mexinput546_temp = NULL; 
    if( !mxIsDouble(prhs[546]) || mxIsComplex(prhs[546]) || !(mxGetM(prhs[546])==1 && mxGetN(prhs[546])==1) ) { 
      mexErrMsgTxt("Input 546 must be a noncomplex scalar double.");
    } 
    mexinput546_temp = mxGetPr(prhs[546]); 
    double mexinput546 = *mexinput546_temp; 

    double *mexinput547_temp = NULL; 
    if( !mxIsDouble(prhs[547]) || mxIsComplex(prhs[547]) || !(mxGetM(prhs[547])==1 && mxGetN(prhs[547])==1) ) { 
      mexErrMsgTxt("Input 547 must be a noncomplex scalar double.");
    } 
    mexinput547_temp = mxGetPr(prhs[547]); 
    double mexinput547 = *mexinput547_temp; 

    double *mexinput548_temp = NULL; 
    if( !mxIsDouble(prhs[548]) || mxIsComplex(prhs[548]) || !(mxGetM(prhs[548])==1 && mxGetN(prhs[548])==1) ) { 
      mexErrMsgTxt("Input 548 must be a noncomplex scalar double.");
    } 
    mexinput548_temp = mxGetPr(prhs[548]); 
    double mexinput548 = *mexinput548_temp; 

    double *mexinput549_temp = NULL; 
    if( !mxIsDouble(prhs[549]) || mxIsComplex(prhs[549]) || !(mxGetM(prhs[549])==1 && mxGetN(prhs[549])==1) ) { 
      mexErrMsgTxt("Input 549 must be a noncomplex scalar double.");
    } 
    mexinput549_temp = mxGetPr(prhs[549]); 
    double mexinput549 = *mexinput549_temp; 

    double *mexinput550_temp = NULL; 
    if( !mxIsDouble(prhs[550]) || mxIsComplex(prhs[550]) || !(mxGetM(prhs[550])==1 && mxGetN(prhs[550])==1) ) { 
      mexErrMsgTxt("Input 550 must be a noncomplex scalar double.");
    } 
    mexinput550_temp = mxGetPr(prhs[550]); 
    double mexinput550 = *mexinput550_temp; 

    double *mexinput551_temp = NULL; 
    if( !mxIsDouble(prhs[551]) || mxIsComplex(prhs[551]) || !(mxGetM(prhs[551])==1 && mxGetN(prhs[551])==1) ) { 
      mexErrMsgTxt("Input 551 must be a noncomplex scalar double.");
    } 
    mexinput551_temp = mxGetPr(prhs[551]); 
    double mexinput551 = *mexinput551_temp; 

    double *mexinput552_temp = NULL; 
    if( !mxIsDouble(prhs[552]) || mxIsComplex(prhs[552]) || !(mxGetM(prhs[552])==1 && mxGetN(prhs[552])==1) ) { 
      mexErrMsgTxt("Input 552 must be a noncomplex scalar double.");
    } 
    mexinput552_temp = mxGetPr(prhs[552]); 
    double mexinput552 = *mexinput552_temp; 

    double *mexinput553_temp = NULL; 
    if( !mxIsDouble(prhs[553]) || mxIsComplex(prhs[553]) || !(mxGetM(prhs[553])==1 && mxGetN(prhs[553])==1) ) { 
      mexErrMsgTxt("Input 553 must be a noncomplex scalar double.");
    } 
    mexinput553_temp = mxGetPr(prhs[553]); 
    double mexinput553 = *mexinput553_temp; 

    double *mexinput554_temp = NULL; 
    if( !mxIsDouble(prhs[554]) || mxIsComplex(prhs[554]) || !(mxGetM(prhs[554])==1 && mxGetN(prhs[554])==1) ) { 
      mexErrMsgTxt("Input 554 must be a noncomplex scalar double.");
    } 
    mexinput554_temp = mxGetPr(prhs[554]); 
    double mexinput554 = *mexinput554_temp; 

    double *mexinput555_temp = NULL; 
    if( !mxIsDouble(prhs[555]) || mxIsComplex(prhs[555]) || !(mxGetM(prhs[555])==1 && mxGetN(prhs[555])==1) ) { 
      mexErrMsgTxt("Input 555 must be a noncomplex scalar double.");
    } 
    mexinput555_temp = mxGetPr(prhs[555]); 
    double mexinput555 = *mexinput555_temp; 

    double *mexinput556_temp = NULL; 
    if( !mxIsDouble(prhs[556]) || mxIsComplex(prhs[556]) || !(mxGetM(prhs[556])==1 && mxGetN(prhs[556])==1) ) { 
      mexErrMsgTxt("Input 556 must be a noncomplex scalar double.");
    } 
    mexinput556_temp = mxGetPr(prhs[556]); 
    double mexinput556 = *mexinput556_temp; 

    double *mexinput557_temp = NULL; 
    if( !mxIsDouble(prhs[557]) || mxIsComplex(prhs[557]) || !(mxGetM(prhs[557])==1 && mxGetN(prhs[557])==1) ) { 
      mexErrMsgTxt("Input 557 must be a noncomplex scalar double.");
    } 
    mexinput557_temp = mxGetPr(prhs[557]); 
    double mexinput557 = *mexinput557_temp; 

    double *mexinput558_temp = NULL; 
    if( !mxIsDouble(prhs[558]) || mxIsComplex(prhs[558]) || !(mxGetM(prhs[558])==1 && mxGetN(prhs[558])==1) ) { 
      mexErrMsgTxt("Input 558 must be a noncomplex scalar double.");
    } 
    mexinput558_temp = mxGetPr(prhs[558]); 
    double mexinput558 = *mexinput558_temp; 

    double *mexinput559_temp = NULL; 
    if( !mxIsDouble(prhs[559]) || mxIsComplex(prhs[559]) || !(mxGetM(prhs[559])==1 && mxGetN(prhs[559])==1) ) { 
      mexErrMsgTxt("Input 559 must be a noncomplex scalar double.");
    } 
    mexinput559_temp = mxGetPr(prhs[559]); 
    double mexinput559 = *mexinput559_temp; 

    double *mexinput560_temp = NULL; 
    if( !mxIsDouble(prhs[560]) || mxIsComplex(prhs[560]) || !(mxGetM(prhs[560])==1 && mxGetN(prhs[560])==1) ) { 
      mexErrMsgTxt("Input 560 must be a noncomplex scalar double.");
    } 
    mexinput560_temp = mxGetPr(prhs[560]); 
    double mexinput560 = *mexinput560_temp; 

    double *mexinput561_temp = NULL; 
    if( !mxIsDouble(prhs[561]) || mxIsComplex(prhs[561]) || !(mxGetM(prhs[561])==1 && mxGetN(prhs[561])==1) ) { 
      mexErrMsgTxt("Input 561 must be a noncomplex scalar double.");
    } 
    mexinput561_temp = mxGetPr(prhs[561]); 
    double mexinput561 = *mexinput561_temp; 

    double *mexinput562_temp = NULL; 
    if( !mxIsDouble(prhs[562]) || mxIsComplex(prhs[562]) || !(mxGetM(prhs[562])==1 && mxGetN(prhs[562])==1) ) { 
      mexErrMsgTxt("Input 562 must be a noncomplex scalar double.");
    } 
    mexinput562_temp = mxGetPr(prhs[562]); 
    double mexinput562 = *mexinput562_temp; 

    double *mexinput563_temp = NULL; 
    if( !mxIsDouble(prhs[563]) || mxIsComplex(prhs[563]) || !(mxGetM(prhs[563])==1 && mxGetN(prhs[563])==1) ) { 
      mexErrMsgTxt("Input 563 must be a noncomplex scalar double.");
    } 
    mexinput563_temp = mxGetPr(prhs[563]); 
    double mexinput563 = *mexinput563_temp; 

    double *mexinput564_temp = NULL; 
    if( !mxIsDouble(prhs[564]) || mxIsComplex(prhs[564]) || !(mxGetM(prhs[564])==1 && mxGetN(prhs[564])==1) ) { 
      mexErrMsgTxt("Input 564 must be a noncomplex scalar double.");
    } 
    mexinput564_temp = mxGetPr(prhs[564]); 
    double mexinput564 = *mexinput564_temp; 

    double *mexinput565_temp = NULL; 
    if( !mxIsDouble(prhs[565]) || mxIsComplex(prhs[565]) || !(mxGetM(prhs[565])==1 && mxGetN(prhs[565])==1) ) { 
      mexErrMsgTxt("Input 565 must be a noncomplex scalar double.");
    } 
    mexinput565_temp = mxGetPr(prhs[565]); 
    double mexinput565 = *mexinput565_temp; 

    double *mexinput566_temp = NULL; 
    if( !mxIsDouble(prhs[566]) || mxIsComplex(prhs[566]) || !(mxGetM(prhs[566])==1 && mxGetN(prhs[566])==1) ) { 
      mexErrMsgTxt("Input 566 must be a noncomplex scalar double.");
    } 
    mexinput566_temp = mxGetPr(prhs[566]); 
    double mexinput566 = *mexinput566_temp; 

    double *mexinput567_temp = NULL; 
    if( !mxIsDouble(prhs[567]) || mxIsComplex(prhs[567]) || !(mxGetM(prhs[567])==1 && mxGetN(prhs[567])==1) ) { 
      mexErrMsgTxt("Input 567 must be a noncomplex scalar double.");
    } 
    mexinput567_temp = mxGetPr(prhs[567]); 
    double mexinput567 = *mexinput567_temp; 

    double *mexinput568_temp = NULL; 
    if( !mxIsDouble(prhs[568]) || mxIsComplex(prhs[568]) || !(mxGetM(prhs[568])==1 && mxGetN(prhs[568])==1) ) { 
      mexErrMsgTxt("Input 568 must be a noncomplex scalar double.");
    } 
    mexinput568_temp = mxGetPr(prhs[568]); 
    double mexinput568 = *mexinput568_temp; 

    double *mexinput569_temp = NULL; 
    if( !mxIsDouble(prhs[569]) || mxIsComplex(prhs[569]) || !(mxGetM(prhs[569])==1 && mxGetN(prhs[569])==1) ) { 
      mexErrMsgTxt("Input 569 must be a noncomplex scalar double.");
    } 
    mexinput569_temp = mxGetPr(prhs[569]); 
    double mexinput569 = *mexinput569_temp; 

    double *mexinput570_temp = NULL; 
    if( !mxIsDouble(prhs[570]) || mxIsComplex(prhs[570]) || !(mxGetM(prhs[570])==1 && mxGetN(prhs[570])==1) ) { 
      mexErrMsgTxt("Input 570 must be a noncomplex scalar double.");
    } 
    mexinput570_temp = mxGetPr(prhs[570]); 
    double mexinput570 = *mexinput570_temp; 

    double *mexinput571_temp = NULL; 
    if( !mxIsDouble(prhs[571]) || mxIsComplex(prhs[571]) || !(mxGetM(prhs[571])==1 && mxGetN(prhs[571])==1) ) { 
      mexErrMsgTxt("Input 571 must be a noncomplex scalar double.");
    } 
    mexinput571_temp = mxGetPr(prhs[571]); 
    double mexinput571 = *mexinput571_temp; 

    double *mexinput572_temp = NULL; 
    if( !mxIsDouble(prhs[572]) || mxIsComplex(prhs[572]) || !(mxGetM(prhs[572])==1 && mxGetN(prhs[572])==1) ) { 
      mexErrMsgTxt("Input 572 must be a noncomplex scalar double.");
    } 
    mexinput572_temp = mxGetPr(prhs[572]); 
    double mexinput572 = *mexinput572_temp; 

    double *mexinput573_temp = NULL; 
    if( !mxIsDouble(prhs[573]) || mxIsComplex(prhs[573]) || !(mxGetM(prhs[573])==1 && mxGetN(prhs[573])==1) ) { 
      mexErrMsgTxt("Input 573 must be a noncomplex scalar double.");
    } 
    mexinput573_temp = mxGetPr(prhs[573]); 
    double mexinput573 = *mexinput573_temp; 

    double *mexinput574_temp = NULL; 
    if( !mxIsDouble(prhs[574]) || mxIsComplex(prhs[574]) || !(mxGetM(prhs[574])==1 && mxGetN(prhs[574])==1) ) { 
      mexErrMsgTxt("Input 574 must be a noncomplex scalar double.");
    } 
    mexinput574_temp = mxGetPr(prhs[574]); 
    double mexinput574 = *mexinput574_temp; 

    double *mexinput575_temp = NULL; 
    if( !mxIsDouble(prhs[575]) || mxIsComplex(prhs[575]) || !(mxGetM(prhs[575])==1 && mxGetN(prhs[575])==1) ) { 
      mexErrMsgTxt("Input 575 must be a noncomplex scalar double.");
    } 
    mexinput575_temp = mxGetPr(prhs[575]); 
    double mexinput575 = *mexinput575_temp; 

    double *mexinput576_temp = NULL; 
    if( !mxIsDouble(prhs[576]) || mxIsComplex(prhs[576]) || !(mxGetM(prhs[576])==1 && mxGetN(prhs[576])==1) ) { 
      mexErrMsgTxt("Input 576 must be a noncomplex scalar double.");
    } 
    mexinput576_temp = mxGetPr(prhs[576]); 
    double mexinput576 = *mexinput576_temp; 

    double *mexinput577_temp = NULL; 
    if( !mxIsDouble(prhs[577]) || mxIsComplex(prhs[577]) || !(mxGetM(prhs[577])==1 && mxGetN(prhs[577])==1) ) { 
      mexErrMsgTxt("Input 577 must be a noncomplex scalar double.");
    } 
    mexinput577_temp = mxGetPr(prhs[577]); 
    double mexinput577 = *mexinput577_temp; 

    double *mexinput578_temp = NULL; 
    if( !mxIsDouble(prhs[578]) || mxIsComplex(prhs[578]) || !(mxGetM(prhs[578])==1 && mxGetN(prhs[578])==1) ) { 
      mexErrMsgTxt("Input 578 must be a noncomplex scalar double.");
    } 
    mexinput578_temp = mxGetPr(prhs[578]); 
    double mexinput578 = *mexinput578_temp; 

    double *mexinput579_temp = NULL; 
    if( !mxIsDouble(prhs[579]) || mxIsComplex(prhs[579]) || !(mxGetM(prhs[579])==1 && mxGetN(prhs[579])==1) ) { 
      mexErrMsgTxt("Input 579 must be a noncomplex scalar double.");
    } 
    mexinput579_temp = mxGetPr(prhs[579]); 
    double mexinput579 = *mexinput579_temp; 

    double *mexinput580_temp = NULL; 
    if( !mxIsDouble(prhs[580]) || mxIsComplex(prhs[580]) || !(mxGetM(prhs[580])==1 && mxGetN(prhs[580])==1) ) { 
      mexErrMsgTxt("Input 580 must be a noncomplex scalar double.");
    } 
    mexinput580_temp = mxGetPr(prhs[580]); 
    double mexinput580 = *mexinput580_temp; 

    double *mexinput581_temp = NULL; 
    if( !mxIsDouble(prhs[581]) || mxIsComplex(prhs[581]) || !(mxGetM(prhs[581])==1 && mxGetN(prhs[581])==1) ) { 
      mexErrMsgTxt("Input 581 must be a noncomplex scalar double.");
    } 
    mexinput581_temp = mxGetPr(prhs[581]); 
    double mexinput581 = *mexinput581_temp; 

    double *mexinput582_temp = NULL; 
    if( !mxIsDouble(prhs[582]) || mxIsComplex(prhs[582]) || !(mxGetM(prhs[582])==1 && mxGetN(prhs[582])==1) ) { 
      mexErrMsgTxt("Input 582 must be a noncomplex scalar double.");
    } 
    mexinput582_temp = mxGetPr(prhs[582]); 
    double mexinput582 = *mexinput582_temp; 

    double *mexinput583_temp = NULL; 
    if( !mxIsDouble(prhs[583]) || mxIsComplex(prhs[583]) || !(mxGetM(prhs[583])==1 && mxGetN(prhs[583])==1) ) { 
      mexErrMsgTxt("Input 583 must be a noncomplex scalar double.");
    } 
    mexinput583_temp = mxGetPr(prhs[583]); 
    double mexinput583 = *mexinput583_temp; 

    double *mexinput584_temp = NULL; 
    if( !mxIsDouble(prhs[584]) || mxIsComplex(prhs[584]) || !(mxGetM(prhs[584])==1 && mxGetN(prhs[584])==1) ) { 
      mexErrMsgTxt("Input 584 must be a noncomplex scalar double.");
    } 
    mexinput584_temp = mxGetPr(prhs[584]); 
    double mexinput584 = *mexinput584_temp; 

    double *mexinput585_temp = NULL; 
    if( !mxIsDouble(prhs[585]) || mxIsComplex(prhs[585]) || !(mxGetM(prhs[585])==1 && mxGetN(prhs[585])==1) ) { 
      mexErrMsgTxt("Input 585 must be a noncomplex scalar double.");
    } 
    mexinput585_temp = mxGetPr(prhs[585]); 
    double mexinput585 = *mexinput585_temp; 

    double *mexinput586_temp = NULL; 
    if( !mxIsDouble(prhs[586]) || mxIsComplex(prhs[586]) || !(mxGetM(prhs[586])==1 && mxGetN(prhs[586])==1) ) { 
      mexErrMsgTxt("Input 586 must be a noncomplex scalar double.");
    } 
    mexinput586_temp = mxGetPr(prhs[586]); 
    double mexinput586 = *mexinput586_temp; 

    double *mexinput587_temp = NULL; 
    if( !mxIsDouble(prhs[587]) || mxIsComplex(prhs[587]) || !(mxGetM(prhs[587])==1 && mxGetN(prhs[587])==1) ) { 
      mexErrMsgTxt("Input 587 must be a noncomplex scalar double.");
    } 
    mexinput587_temp = mxGetPr(prhs[587]); 
    double mexinput587 = *mexinput587_temp; 

    double *mexinput588_temp = NULL; 
    if( !mxIsDouble(prhs[588]) || mxIsComplex(prhs[588]) || !(mxGetM(prhs[588])==1 && mxGetN(prhs[588])==1) ) { 
      mexErrMsgTxt("Input 588 must be a noncomplex scalar double.");
    } 
    mexinput588_temp = mxGetPr(prhs[588]); 
    double mexinput588 = *mexinput588_temp; 

    double *mexinput589_temp = NULL; 
    if( !mxIsDouble(prhs[589]) || mxIsComplex(prhs[589]) || !(mxGetM(prhs[589])==1 && mxGetN(prhs[589])==1) ) { 
      mexErrMsgTxt("Input 589 must be a noncomplex scalar double.");
    } 
    mexinput589_temp = mxGetPr(prhs[589]); 
    double mexinput589 = *mexinput589_temp; 

    double *mexinput590_temp = NULL; 
    if( !mxIsDouble(prhs[590]) || mxIsComplex(prhs[590]) || !(mxGetM(prhs[590])==1 && mxGetN(prhs[590])==1) ) { 
      mexErrMsgTxt("Input 590 must be a noncomplex scalar double.");
    } 
    mexinput590_temp = mxGetPr(prhs[590]); 
    double mexinput590 = *mexinput590_temp; 

    double *mexinput591_temp = NULL; 
    if( !mxIsDouble(prhs[591]) || mxIsComplex(prhs[591]) || !(mxGetM(prhs[591])==1 && mxGetN(prhs[591])==1) ) { 
      mexErrMsgTxt("Input 591 must be a noncomplex scalar double.");
    } 
    mexinput591_temp = mxGetPr(prhs[591]); 
    double mexinput591 = *mexinput591_temp; 

    double *mexinput592_temp = NULL; 
    if( !mxIsDouble(prhs[592]) || mxIsComplex(prhs[592]) || !(mxGetM(prhs[592])==1 && mxGetN(prhs[592])==1) ) { 
      mexErrMsgTxt("Input 592 must be a noncomplex scalar double.");
    } 
    mexinput592_temp = mxGetPr(prhs[592]); 
    double mexinput592 = *mexinput592_temp; 

    double *mexinput593_temp = NULL; 
    if( !mxIsDouble(prhs[593]) || mxIsComplex(prhs[593]) || !(mxGetM(prhs[593])==1 && mxGetN(prhs[593])==1) ) { 
      mexErrMsgTxt("Input 593 must be a noncomplex scalar double.");
    } 
    mexinput593_temp = mxGetPr(prhs[593]); 
    double mexinput593 = *mexinput593_temp; 

    double *mexinput594_temp = NULL; 
    if( !mxIsDouble(prhs[594]) || mxIsComplex(prhs[594]) || !(mxGetM(prhs[594])==1 && mxGetN(prhs[594])==1) ) { 
      mexErrMsgTxt("Input 594 must be a noncomplex scalar double.");
    } 
    mexinput594_temp = mxGetPr(prhs[594]); 
    double mexinput594 = *mexinput594_temp; 

    double *mexinput595_temp = NULL; 
    if( !mxIsDouble(prhs[595]) || mxIsComplex(prhs[595]) || !(mxGetM(prhs[595])==1 && mxGetN(prhs[595])==1) ) { 
      mexErrMsgTxt("Input 595 must be a noncomplex scalar double.");
    } 
    mexinput595_temp = mxGetPr(prhs[595]); 
    double mexinput595 = *mexinput595_temp; 

    double *mexinput596_temp = NULL; 
    if( !mxIsDouble(prhs[596]) || mxIsComplex(prhs[596]) || !(mxGetM(prhs[596])==1 && mxGetN(prhs[596])==1) ) { 
      mexErrMsgTxt("Input 596 must be a noncomplex scalar double.");
    } 
    mexinput596_temp = mxGetPr(prhs[596]); 
    double mexinput596 = *mexinput596_temp; 

    double *mexinput597_temp = NULL; 
    if( !mxIsDouble(prhs[597]) || mxIsComplex(prhs[597]) || !(mxGetM(prhs[597])==1 && mxGetN(prhs[597])==1) ) { 
      mexErrMsgTxt("Input 597 must be a noncomplex scalar double.");
    } 
    mexinput597_temp = mxGetPr(prhs[597]); 
    double mexinput597 = *mexinput597_temp; 

    double *mexinput598_temp = NULL; 
    if( !mxIsDouble(prhs[598]) || mxIsComplex(prhs[598]) || !(mxGetM(prhs[598])==1 && mxGetN(prhs[598])==1) ) { 
      mexErrMsgTxt("Input 598 must be a noncomplex scalar double.");
    } 
    mexinput598_temp = mxGetPr(prhs[598]); 
    double mexinput598 = *mexinput598_temp; 

    double *mexinput599_temp = NULL; 
    if( !mxIsDouble(prhs[599]) || mxIsComplex(prhs[599]) || !(mxGetM(prhs[599])==1 && mxGetN(prhs[599])==1) ) { 
      mexErrMsgTxt("Input 599 must be a noncomplex scalar double.");
    } 
    mexinput599_temp = mxGetPr(prhs[599]); 
    double mexinput599 = *mexinput599_temp; 

    double *mexinput600_temp = NULL; 
    if( !mxIsDouble(prhs[600]) || mxIsComplex(prhs[600]) || !(mxGetM(prhs[600])==1 && mxGetN(prhs[600])==1) ) { 
      mexErrMsgTxt("Input 600 must be a noncomplex scalar double.");
    } 
    mexinput600_temp = mxGetPr(prhs[600]); 
    double mexinput600 = *mexinput600_temp; 

    double *mexinput601_temp = NULL; 
    if( !mxIsDouble(prhs[601]) || mxIsComplex(prhs[601]) || !(mxGetM(prhs[601])==1 && mxGetN(prhs[601])==1) ) { 
      mexErrMsgTxt("Input 601 must be a noncomplex scalar double.");
    } 
    mexinput601_temp = mxGetPr(prhs[601]); 
    double mexinput601 = *mexinput601_temp; 

    double *mexinput602_temp = NULL; 
    if( !mxIsDouble(prhs[602]) || mxIsComplex(prhs[602]) || !(mxGetM(prhs[602])==1 && mxGetN(prhs[602])==1) ) { 
      mexErrMsgTxt("Input 602 must be a noncomplex scalar double.");
    } 
    mexinput602_temp = mxGetPr(prhs[602]); 
    double mexinput602 = *mexinput602_temp; 

    double *mexinput603_temp = NULL; 
    if( !mxIsDouble(prhs[603]) || mxIsComplex(prhs[603]) || !(mxGetM(prhs[603])==1 && mxGetN(prhs[603])==1) ) { 
      mexErrMsgTxt("Input 603 must be a noncomplex scalar double.");
    } 
    mexinput603_temp = mxGetPr(prhs[603]); 
    double mexinput603 = *mexinput603_temp; 

    double *mexinput604_temp = NULL; 
    if( !mxIsDouble(prhs[604]) || mxIsComplex(prhs[604]) || !(mxGetM(prhs[604])==1 && mxGetN(prhs[604])==1) ) { 
      mexErrMsgTxt("Input 604 must be a noncomplex scalar double.");
    } 
    mexinput604_temp = mxGetPr(prhs[604]); 
    double mexinput604 = *mexinput604_temp; 

    double *mexinput605_temp = NULL; 
    if( !mxIsDouble(prhs[605]) || mxIsComplex(prhs[605]) || !(mxGetM(prhs[605])==1 && mxGetN(prhs[605])==1) ) { 
      mexErrMsgTxt("Input 605 must be a noncomplex scalar double.");
    } 
    mexinput605_temp = mxGetPr(prhs[605]); 
    double mexinput605 = *mexinput605_temp; 

    double *mexinput606_temp = NULL; 
    if( !mxIsDouble(prhs[606]) || mxIsComplex(prhs[606]) || !(mxGetM(prhs[606])==1 && mxGetN(prhs[606])==1) ) { 
      mexErrMsgTxt("Input 606 must be a noncomplex scalar double.");
    } 
    mexinput606_temp = mxGetPr(prhs[606]); 
    double mexinput606 = *mexinput606_temp; 

    double *mexinput607_temp = NULL; 
    if( !mxIsDouble(prhs[607]) || mxIsComplex(prhs[607]) || !(mxGetM(prhs[607])==1 && mxGetN(prhs[607])==1) ) { 
      mexErrMsgTxt("Input 607 must be a noncomplex scalar double.");
    } 
    mexinput607_temp = mxGetPr(prhs[607]); 
    double mexinput607 = *mexinput607_temp; 

    double *mexinput608_temp = NULL; 
    if( !mxIsDouble(prhs[608]) || mxIsComplex(prhs[608]) || !(mxGetM(prhs[608])==1 && mxGetN(prhs[608])==1) ) { 
      mexErrMsgTxt("Input 608 must be a noncomplex scalar double.");
    } 
    mexinput608_temp = mxGetPr(prhs[608]); 
    double mexinput608 = *mexinput608_temp; 

    double *mexinput609_temp = NULL; 
    if( !mxIsDouble(prhs[609]) || mxIsComplex(prhs[609]) || !(mxGetM(prhs[609])==1 && mxGetN(prhs[609])==1) ) { 
      mexErrMsgTxt("Input 609 must be a noncomplex scalar double.");
    } 
    mexinput609_temp = mxGetPr(prhs[609]); 
    double mexinput609 = *mexinput609_temp; 

    double *mexinput610_temp = NULL; 
    if( !mxIsDouble(prhs[610]) || mxIsComplex(prhs[610]) || !(mxGetM(prhs[610])==1 && mxGetN(prhs[610])==1) ) { 
      mexErrMsgTxt("Input 610 must be a noncomplex scalar double.");
    } 
    mexinput610_temp = mxGetPr(prhs[610]); 
    double mexinput610 = *mexinput610_temp; 

    double *mexinput611_temp = NULL; 
    if( !mxIsDouble(prhs[611]) || mxIsComplex(prhs[611]) || !(mxGetM(prhs[611])==1 && mxGetN(prhs[611])==1) ) { 
      mexErrMsgTxt("Input 611 must be a noncomplex scalar double.");
    } 
    mexinput611_temp = mxGetPr(prhs[611]); 
    double mexinput611 = *mexinput611_temp; 

    double *mexinput612_temp = NULL; 
    if( !mxIsDouble(prhs[612]) || mxIsComplex(prhs[612]) || !(mxGetM(prhs[612])==1 && mxGetN(prhs[612])==1) ) { 
      mexErrMsgTxt("Input 612 must be a noncomplex scalar double.");
    } 
    mexinput612_temp = mxGetPr(prhs[612]); 
    double mexinput612 = *mexinput612_temp; 

    double *mexinput613_temp = NULL; 
    if( !mxIsDouble(prhs[613]) || mxIsComplex(prhs[613]) || !(mxGetM(prhs[613])==1 && mxGetN(prhs[613])==1) ) { 
      mexErrMsgTxt("Input 613 must be a noncomplex scalar double.");
    } 
    mexinput613_temp = mxGetPr(prhs[613]); 
    double mexinput613 = *mexinput613_temp; 

    double *mexinput614_temp = NULL; 
    if( !mxIsDouble(prhs[614]) || mxIsComplex(prhs[614]) || !(mxGetM(prhs[614])==1 && mxGetN(prhs[614])==1) ) { 
      mexErrMsgTxt("Input 614 must be a noncomplex scalar double.");
    } 
    mexinput614_temp = mxGetPr(prhs[614]); 
    double mexinput614 = *mexinput614_temp; 

    double *mexinput615_temp = NULL; 
    if( !mxIsDouble(prhs[615]) || mxIsComplex(prhs[615]) || !(mxGetM(prhs[615])==1 && mxGetN(prhs[615])==1) ) { 
      mexErrMsgTxt("Input 615 must be a noncomplex scalar double.");
    } 
    mexinput615_temp = mxGetPr(prhs[615]); 
    double mexinput615 = *mexinput615_temp; 

    double *mexinput616_temp = NULL; 
    if( !mxIsDouble(prhs[616]) || mxIsComplex(prhs[616]) || !(mxGetM(prhs[616])==1 && mxGetN(prhs[616])==1) ) { 
      mexErrMsgTxt("Input 616 must be a noncomplex scalar double.");
    } 
    mexinput616_temp = mxGetPr(prhs[616]); 
    double mexinput616 = *mexinput616_temp; 

    double *mexinput617_temp = NULL; 
    if( !mxIsDouble(prhs[617]) || mxIsComplex(prhs[617]) || !(mxGetM(prhs[617])==1 && mxGetN(prhs[617])==1) ) { 
      mexErrMsgTxt("Input 617 must be a noncomplex scalar double.");
    } 
    mexinput617_temp = mxGetPr(prhs[617]); 
    double mexinput617 = *mexinput617_temp; 

    double *mexinput618_temp = NULL; 
    if( !mxIsDouble(prhs[618]) || mxIsComplex(prhs[618]) || !(mxGetM(prhs[618])==1 && mxGetN(prhs[618])==1) ) { 
      mexErrMsgTxt("Input 618 must be a noncomplex scalar double.");
    } 
    mexinput618_temp = mxGetPr(prhs[618]); 
    double mexinput618 = *mexinput618_temp; 

    double *mexinput619_temp = NULL; 
    if( !mxIsDouble(prhs[619]) || mxIsComplex(prhs[619]) || !(mxGetM(prhs[619])==1 && mxGetN(prhs[619])==1) ) { 
      mexErrMsgTxt("Input 619 must be a noncomplex scalar double.");
    } 
    mexinput619_temp = mxGetPr(prhs[619]); 
    double mexinput619 = *mexinput619_temp; 

    double *mexinput620_temp = NULL; 
    if( !mxIsDouble(prhs[620]) || mxIsComplex(prhs[620]) || !(mxGetM(prhs[620])==1 && mxGetN(prhs[620])==1) ) { 
      mexErrMsgTxt("Input 620 must be a noncomplex scalar double.");
    } 
    mexinput620_temp = mxGetPr(prhs[620]); 
    double mexinput620 = *mexinput620_temp; 

    double *mexinput621_temp = NULL; 
    if( !mxIsDouble(prhs[621]) || mxIsComplex(prhs[621]) || !(mxGetM(prhs[621])==1 && mxGetN(prhs[621])==1) ) { 
      mexErrMsgTxt("Input 621 must be a noncomplex scalar double.");
    } 
    mexinput621_temp = mxGetPr(prhs[621]); 
    double mexinput621 = *mexinput621_temp; 

    double *mexinput622_temp = NULL; 
    if( !mxIsDouble(prhs[622]) || mxIsComplex(prhs[622]) || !(mxGetM(prhs[622])==1 && mxGetN(prhs[622])==1) ) { 
      mexErrMsgTxt("Input 622 must be a noncomplex scalar double.");
    } 
    mexinput622_temp = mxGetPr(prhs[622]); 
    double mexinput622 = *mexinput622_temp; 

    double *mexinput623_temp = NULL; 
    if( !mxIsDouble(prhs[623]) || mxIsComplex(prhs[623]) || !(mxGetM(prhs[623])==1 && mxGetN(prhs[623])==1) ) { 
      mexErrMsgTxt("Input 623 must be a noncomplex scalar double.");
    } 
    mexinput623_temp = mxGetPr(prhs[623]); 
    double mexinput623 = *mexinput623_temp; 

    double *mexinput624_temp = NULL; 
    if( !mxIsDouble(prhs[624]) || mxIsComplex(prhs[624]) || !(mxGetM(prhs[624])==1 && mxGetN(prhs[624])==1) ) { 
      mexErrMsgTxt("Input 624 must be a noncomplex scalar double.");
    } 
    mexinput624_temp = mxGetPr(prhs[624]); 
    double mexinput624 = *mexinput624_temp; 

    double *mexinput625_temp = NULL; 
    if( !mxIsDouble(prhs[625]) || mxIsComplex(prhs[625]) || !(mxGetM(prhs[625])==1 && mxGetN(prhs[625])==1) ) { 
      mexErrMsgTxt("Input 625 must be a noncomplex scalar double.");
    } 
    mexinput625_temp = mxGetPr(prhs[625]); 
    double mexinput625 = *mexinput625_temp; 

    double *mexinput626_temp = NULL; 
    if( !mxIsDouble(prhs[626]) || mxIsComplex(prhs[626]) || !(mxGetM(prhs[626])==1 && mxGetN(prhs[626])==1) ) { 
      mexErrMsgTxt("Input 626 must be a noncomplex scalar double.");
    } 
    mexinput626_temp = mxGetPr(prhs[626]); 
    double mexinput626 = *mexinput626_temp; 

    double *mexinput627_temp = NULL; 
    if( !mxIsDouble(prhs[627]) || mxIsComplex(prhs[627]) || !(mxGetM(prhs[627])==1 && mxGetN(prhs[627])==1) ) { 
      mexErrMsgTxt("Input 627 must be a noncomplex scalar double.");
    } 
    mexinput627_temp = mxGetPr(prhs[627]); 
    double mexinput627 = *mexinput627_temp; 

    double *mexinput628_temp = NULL; 
    if( !mxIsDouble(prhs[628]) || mxIsComplex(prhs[628]) || !(mxGetM(prhs[628])==1 && mxGetN(prhs[628])==1) ) { 
      mexErrMsgTxt("Input 628 must be a noncomplex scalar double.");
    } 
    mexinput628_temp = mxGetPr(prhs[628]); 
    double mexinput628 = *mexinput628_temp; 

    double *mexinput629_temp = NULL; 
    if( !mxIsDouble(prhs[629]) || mxIsComplex(prhs[629]) || !(mxGetM(prhs[629])==1 && mxGetN(prhs[629])==1) ) { 
      mexErrMsgTxt("Input 629 must be a noncomplex scalar double.");
    } 
    mexinput629_temp = mxGetPr(prhs[629]); 
    double mexinput629 = *mexinput629_temp; 

    double *mexinput630_temp = NULL; 
    if( !mxIsDouble(prhs[630]) || mxIsComplex(prhs[630]) || !(mxGetM(prhs[630])==1 && mxGetN(prhs[630])==1) ) { 
      mexErrMsgTxt("Input 630 must be a noncomplex scalar double.");
    } 
    mexinput630_temp = mxGetPr(prhs[630]); 
    double mexinput630 = *mexinput630_temp; 

    double *mexinput631_temp = NULL; 
    if( !mxIsDouble(prhs[631]) || mxIsComplex(prhs[631]) || !(mxGetM(prhs[631])==1 && mxGetN(prhs[631])==1) ) { 
      mexErrMsgTxt("Input 631 must be a noncomplex scalar double.");
    } 
    mexinput631_temp = mxGetPr(prhs[631]); 
    double mexinput631 = *mexinput631_temp; 

    double *mexinput632_temp = NULL; 
    if( !mxIsDouble(prhs[632]) || mxIsComplex(prhs[632]) || !(mxGetM(prhs[632])==1 && mxGetN(prhs[632])==1) ) { 
      mexErrMsgTxt("Input 632 must be a noncomplex scalar double.");
    } 
    mexinput632_temp = mxGetPr(prhs[632]); 
    double mexinput632 = *mexinput632_temp; 

    double *mexinput633_temp = NULL; 
    if( !mxIsDouble(prhs[633]) || mxIsComplex(prhs[633]) || !(mxGetM(prhs[633])==1 && mxGetN(prhs[633])==1) ) { 
      mexErrMsgTxt("Input 633 must be a noncomplex scalar double.");
    } 
    mexinput633_temp = mxGetPr(prhs[633]); 
    double mexinput633 = *mexinput633_temp; 

    double *mexinput634_temp = NULL; 
    if( !mxIsDouble(prhs[634]) || mxIsComplex(prhs[634]) || !(mxGetM(prhs[634])==1 && mxGetN(prhs[634])==1) ) { 
      mexErrMsgTxt("Input 634 must be a noncomplex scalar double.");
    } 
    mexinput634_temp = mxGetPr(prhs[634]); 
    double mexinput634 = *mexinput634_temp; 

    double *mexinput635_temp = NULL; 
    if( !mxIsDouble(prhs[635]) || mxIsComplex(prhs[635]) || !(mxGetM(prhs[635])==1 && mxGetN(prhs[635])==1) ) { 
      mexErrMsgTxt("Input 635 must be a noncomplex scalar double.");
    } 
    mexinput635_temp = mxGetPr(prhs[635]); 
    double mexinput635 = *mexinput635_temp; 

    double *mexinput636_temp = NULL; 
    if( !mxIsDouble(prhs[636]) || mxIsComplex(prhs[636]) || !(mxGetM(prhs[636])==1 && mxGetN(prhs[636])==1) ) { 
      mexErrMsgTxt("Input 636 must be a noncomplex scalar double.");
    } 
    mexinput636_temp = mxGetPr(prhs[636]); 
    double mexinput636 = *mexinput636_temp; 

    double *mexinput637_temp = NULL; 
    if( !mxIsDouble(prhs[637]) || mxIsComplex(prhs[637]) || !(mxGetM(prhs[637])==1 && mxGetN(prhs[637])==1) ) { 
      mexErrMsgTxt("Input 637 must be a noncomplex scalar double.");
    } 
    mexinput637_temp = mxGetPr(prhs[637]); 
    double mexinput637 = *mexinput637_temp; 

    double *mexinput638_temp = NULL; 
    if( !mxIsDouble(prhs[638]) || mxIsComplex(prhs[638]) || !(mxGetM(prhs[638])==1 && mxGetN(prhs[638])==1) ) { 
      mexErrMsgTxt("Input 638 must be a noncomplex scalar double.");
    } 
    mexinput638_temp = mxGetPr(prhs[638]); 
    double mexinput638 = *mexinput638_temp; 

    double *mexinput639_temp = NULL; 
    if( !mxIsDouble(prhs[639]) || mxIsComplex(prhs[639]) || !(mxGetM(prhs[639])==1 && mxGetN(prhs[639])==1) ) { 
      mexErrMsgTxt("Input 639 must be a noncomplex scalar double.");
    } 
    mexinput639_temp = mxGetPr(prhs[639]); 
    double mexinput639 = *mexinput639_temp; 

    double *mexinput640_temp = NULL; 
    if( !mxIsDouble(prhs[640]) || mxIsComplex(prhs[640]) || !(mxGetM(prhs[640])==1 && mxGetN(prhs[640])==1) ) { 
      mexErrMsgTxt("Input 640 must be a noncomplex scalar double.");
    } 
    mexinput640_temp = mxGetPr(prhs[640]); 
    double mexinput640 = *mexinput640_temp; 

    double *mexinput641_temp = NULL; 
    if( !mxIsDouble(prhs[641]) || mxIsComplex(prhs[641]) || !(mxGetM(prhs[641])==1 && mxGetN(prhs[641])==1) ) { 
      mexErrMsgTxt("Input 641 must be a noncomplex scalar double.");
    } 
    mexinput641_temp = mxGetPr(prhs[641]); 
    double mexinput641 = *mexinput641_temp; 

    double *mexinput642_temp = NULL; 
    if( !mxIsDouble(prhs[642]) || mxIsComplex(prhs[642]) || !(mxGetM(prhs[642])==1 && mxGetN(prhs[642])==1) ) { 
      mexErrMsgTxt("Input 642 must be a noncomplex scalar double.");
    } 
    mexinput642_temp = mxGetPr(prhs[642]); 
    double mexinput642 = *mexinput642_temp; 

    double *mexinput643_temp = NULL; 
    if( !mxIsDouble(prhs[643]) || mxIsComplex(prhs[643]) || !(mxGetM(prhs[643])==1 && mxGetN(prhs[643])==1) ) { 
      mexErrMsgTxt("Input 643 must be a noncomplex scalar double.");
    } 
    mexinput643_temp = mxGetPr(prhs[643]); 
    double mexinput643 = *mexinput643_temp; 

    double *mexinput644_temp = NULL; 
    if( !mxIsDouble(prhs[644]) || mxIsComplex(prhs[644]) || !(mxGetM(prhs[644])==1 && mxGetN(prhs[644])==1) ) { 
      mexErrMsgTxt("Input 644 must be a noncomplex scalar double.");
    } 
    mexinput644_temp = mxGetPr(prhs[644]); 
    double mexinput644 = *mexinput644_temp; 

    double *mexinput645_temp = NULL; 
    if( !mxIsDouble(prhs[645]) || mxIsComplex(prhs[645]) || !(mxGetM(prhs[645])==1 && mxGetN(prhs[645])==1) ) { 
      mexErrMsgTxt("Input 645 must be a noncomplex scalar double.");
    } 
    mexinput645_temp = mxGetPr(prhs[645]); 
    double mexinput645 = *mexinput645_temp; 

    double *mexinput646_temp = NULL; 
    if( !mxIsDouble(prhs[646]) || mxIsComplex(prhs[646]) || !(mxGetM(prhs[646])==1 && mxGetN(prhs[646])==1) ) { 
      mexErrMsgTxt("Input 646 must be a noncomplex scalar double.");
    } 
    mexinput646_temp = mxGetPr(prhs[646]); 
    double mexinput646 = *mexinput646_temp; 

    double *mexinput647_temp = NULL; 
    if( !mxIsDouble(prhs[647]) || mxIsComplex(prhs[647]) || !(mxGetM(prhs[647])==1 && mxGetN(prhs[647])==1) ) { 
      mexErrMsgTxt("Input 647 must be a noncomplex scalar double.");
    } 
    mexinput647_temp = mxGetPr(prhs[647]); 
    double mexinput647 = *mexinput647_temp; 

    double *mexinput648_temp = NULL; 
    if( !mxIsDouble(prhs[648]) || mxIsComplex(prhs[648]) || !(mxGetM(prhs[648])==1 && mxGetN(prhs[648])==1) ) { 
      mexErrMsgTxt("Input 648 must be a noncomplex scalar double.");
    } 
    mexinput648_temp = mxGetPr(prhs[648]); 
    double mexinput648 = *mexinput648_temp; 

    double *mexinput649_temp = NULL; 
    if( !mxIsDouble(prhs[649]) || mxIsComplex(prhs[649]) || !(mxGetM(prhs[649])==1 && mxGetN(prhs[649])==1) ) { 
      mexErrMsgTxt("Input 649 must be a noncomplex scalar double.");
    } 
    mexinput649_temp = mxGetPr(prhs[649]); 
    double mexinput649 = *mexinput649_temp; 

    double *mexinput650_temp = NULL; 
    if( !mxIsDouble(prhs[650]) || mxIsComplex(prhs[650]) || !(mxGetM(prhs[650])==1 && mxGetN(prhs[650])==1) ) { 
      mexErrMsgTxt("Input 650 must be a noncomplex scalar double.");
    } 
    mexinput650_temp = mxGetPr(prhs[650]); 
    double mexinput650 = *mexinput650_temp; 

    double *mexinput651_temp = NULL; 
    if( !mxIsDouble(prhs[651]) || mxIsComplex(prhs[651]) || !(mxGetM(prhs[651])==1 && mxGetN(prhs[651])==1) ) { 
      mexErrMsgTxt("Input 651 must be a noncomplex scalar double.");
    } 
    mexinput651_temp = mxGetPr(prhs[651]); 
    double mexinput651 = *mexinput651_temp; 

    double *mexinput652_temp = NULL; 
    if( !mxIsDouble(prhs[652]) || mxIsComplex(prhs[652]) || !(mxGetM(prhs[652])==1 && mxGetN(prhs[652])==1) ) { 
      mexErrMsgTxt("Input 652 must be a noncomplex scalar double.");
    } 
    mexinput652_temp = mxGetPr(prhs[652]); 
    double mexinput652 = *mexinput652_temp; 

    double *mexinput653_temp = NULL; 
    if( !mxIsDouble(prhs[653]) || mxIsComplex(prhs[653]) || !(mxGetM(prhs[653])==1 && mxGetN(prhs[653])==1) ) { 
      mexErrMsgTxt("Input 653 must be a noncomplex scalar double.");
    } 
    mexinput653_temp = mxGetPr(prhs[653]); 
    double mexinput653 = *mexinput653_temp; 

    double *mexinput654_temp = NULL; 
    if( !mxIsDouble(prhs[654]) || mxIsComplex(prhs[654]) || !(mxGetM(prhs[654])==1 && mxGetN(prhs[654])==1) ) { 
      mexErrMsgTxt("Input 654 must be a noncomplex scalar double.");
    } 
    mexinput654_temp = mxGetPr(prhs[654]); 
    double mexinput654 = *mexinput654_temp; 

    double *mexinput655_temp = NULL; 
    if( !mxIsDouble(prhs[655]) || mxIsComplex(prhs[655]) || !(mxGetM(prhs[655])==1 && mxGetN(prhs[655])==1) ) { 
      mexErrMsgTxt("Input 655 must be a noncomplex scalar double.");
    } 
    mexinput655_temp = mxGetPr(prhs[655]); 
    double mexinput655 = *mexinput655_temp; 

    double *mexinput656_temp = NULL; 
    if( !mxIsDouble(prhs[656]) || mxIsComplex(prhs[656]) || !(mxGetM(prhs[656])==1 && mxGetN(prhs[656])==1) ) { 
      mexErrMsgTxt("Input 656 must be a noncomplex scalar double.");
    } 
    mexinput656_temp = mxGetPr(prhs[656]); 
    double mexinput656 = *mexinput656_temp; 

    double *mexinput657_temp = NULL; 
    if( !mxIsDouble(prhs[657]) || mxIsComplex(prhs[657]) || !(mxGetM(prhs[657])==1 && mxGetN(prhs[657])==1) ) { 
      mexErrMsgTxt("Input 657 must be a noncomplex scalar double.");
    } 
    mexinput657_temp = mxGetPr(prhs[657]); 
    double mexinput657 = *mexinput657_temp; 

    double *mexinput658_temp = NULL; 
    if( !mxIsDouble(prhs[658]) || mxIsComplex(prhs[658]) || !(mxGetM(prhs[658])==1 && mxGetN(prhs[658])==1) ) { 
      mexErrMsgTxt("Input 658 must be a noncomplex scalar double.");
    } 
    mexinput658_temp = mxGetPr(prhs[658]); 
    double mexinput658 = *mexinput658_temp; 

    double *mexinput659_temp = NULL; 
    if( !mxIsDouble(prhs[659]) || mxIsComplex(prhs[659]) || !(mxGetM(prhs[659])==1 && mxGetN(prhs[659])==1) ) { 
      mexErrMsgTxt("Input 659 must be a noncomplex scalar double.");
    } 
    mexinput659_temp = mxGetPr(prhs[659]); 
    double mexinput659 = *mexinput659_temp; 

    double *mexinput660_temp = NULL; 
    if( !mxIsDouble(prhs[660]) || mxIsComplex(prhs[660]) || !(mxGetM(prhs[660])==1 && mxGetN(prhs[660])==1) ) { 
      mexErrMsgTxt("Input 660 must be a noncomplex scalar double.");
    } 
    mexinput660_temp = mxGetPr(prhs[660]); 
    double mexinput660 = *mexinput660_temp; 

    double *mexinput661_temp = NULL; 
    if( !mxIsDouble(prhs[661]) || mxIsComplex(prhs[661]) || !(mxGetM(prhs[661])==1 && mxGetN(prhs[661])==1) ) { 
      mexErrMsgTxt("Input 661 must be a noncomplex scalar double.");
    } 
    mexinput661_temp = mxGetPr(prhs[661]); 
    double mexinput661 = *mexinput661_temp; 

    double *mexinput662_temp = NULL; 
    if( !mxIsDouble(prhs[662]) || mxIsComplex(prhs[662]) || !(mxGetM(prhs[662])==1 && mxGetN(prhs[662])==1) ) { 
      mexErrMsgTxt("Input 662 must be a noncomplex scalar double.");
    } 
    mexinput662_temp = mxGetPr(prhs[662]); 
    double mexinput662 = *mexinput662_temp; 

    double *mexinput663_temp = NULL; 
    if( !mxIsDouble(prhs[663]) || mxIsComplex(prhs[663]) || !(mxGetM(prhs[663])==1 && mxGetN(prhs[663])==1) ) { 
      mexErrMsgTxt("Input 663 must be a noncomplex scalar double.");
    } 
    mexinput663_temp = mxGetPr(prhs[663]); 
    double mexinput663 = *mexinput663_temp; 

    double *mexinput664_temp = NULL; 
    if( !mxIsDouble(prhs[664]) || mxIsComplex(prhs[664]) || !(mxGetM(prhs[664])==1 && mxGetN(prhs[664])==1) ) { 
      mexErrMsgTxt("Input 664 must be a noncomplex scalar double.");
    } 
    mexinput664_temp = mxGetPr(prhs[664]); 
    double mexinput664 = *mexinput664_temp; 

    double *mexinput665_temp = NULL; 
    if( !mxIsDouble(prhs[665]) || mxIsComplex(prhs[665]) || !(mxGetM(prhs[665])==1 && mxGetN(prhs[665])==1) ) { 
      mexErrMsgTxt("Input 665 must be a noncomplex scalar double.");
    } 
    mexinput665_temp = mxGetPr(prhs[665]); 
    double mexinput665 = *mexinput665_temp; 

    double *mexinput666_temp = NULL; 
    if( !mxIsDouble(prhs[666]) || mxIsComplex(prhs[666]) || !(mxGetM(prhs[666])==1 && mxGetN(prhs[666])==1) ) { 
      mexErrMsgTxt("Input 666 must be a noncomplex scalar double.");
    } 
    mexinput666_temp = mxGetPr(prhs[666]); 
    double mexinput666 = *mexinput666_temp; 

    double *mexinput667_temp = NULL; 
    if( !mxIsDouble(prhs[667]) || mxIsComplex(prhs[667]) || !(mxGetM(prhs[667])==1 && mxGetN(prhs[667])==1) ) { 
      mexErrMsgTxt("Input 667 must be a noncomplex scalar double.");
    } 
    mexinput667_temp = mxGetPr(prhs[667]); 
    double mexinput667 = *mexinput667_temp; 

    double *mexinput668_temp = NULL; 
    if( !mxIsDouble(prhs[668]) || mxIsComplex(prhs[668]) || !(mxGetM(prhs[668])==1 && mxGetN(prhs[668])==1) ) { 
      mexErrMsgTxt("Input 668 must be a noncomplex scalar double.");
    } 
    mexinput668_temp = mxGetPr(prhs[668]); 
    double mexinput668 = *mexinput668_temp; 

    double *mexinput669_temp = NULL; 
    if( !mxIsDouble(prhs[669]) || mxIsComplex(prhs[669]) || !(mxGetM(prhs[669])==1 && mxGetN(prhs[669])==1) ) { 
      mexErrMsgTxt("Input 669 must be a noncomplex scalar double.");
    } 
    mexinput669_temp = mxGetPr(prhs[669]); 
    double mexinput669 = *mexinput669_temp; 

    double *mexinput670_temp = NULL; 
    if( !mxIsDouble(prhs[670]) || mxIsComplex(prhs[670]) || !(mxGetM(prhs[670])==1 && mxGetN(prhs[670])==1) ) { 
      mexErrMsgTxt("Input 670 must be a noncomplex scalar double.");
    } 
    mexinput670_temp = mxGetPr(prhs[670]); 
    double mexinput670 = *mexinput670_temp; 

    double *mexinput671_temp = NULL; 
    if( !mxIsDouble(prhs[671]) || mxIsComplex(prhs[671]) || !(mxGetM(prhs[671])==1 && mxGetN(prhs[671])==1) ) { 
      mexErrMsgTxt("Input 671 must be a noncomplex scalar double.");
    } 
    mexinput671_temp = mxGetPr(prhs[671]); 
    double mexinput671 = *mexinput671_temp; 

    double *mexinput672_temp = NULL; 
    if( !mxIsDouble(prhs[672]) || mxIsComplex(prhs[672]) || !(mxGetM(prhs[672])==1 && mxGetN(prhs[672])==1) ) { 
      mexErrMsgTxt("Input 672 must be a noncomplex scalar double.");
    } 
    mexinput672_temp = mxGetPr(prhs[672]); 
    double mexinput672 = *mexinput672_temp; 

    double *mexinput673_temp = NULL; 
    if( !mxIsDouble(prhs[673]) || mxIsComplex(prhs[673]) || !(mxGetM(prhs[673])==1 && mxGetN(prhs[673])==1) ) { 
      mexErrMsgTxt("Input 673 must be a noncomplex scalar double.");
    } 
    mexinput673_temp = mxGetPr(prhs[673]); 
    double mexinput673 = *mexinput673_temp; 

    double *mexinput674_temp = NULL; 
    if( !mxIsDouble(prhs[674]) || mxIsComplex(prhs[674]) || !(mxGetM(prhs[674])==1 && mxGetN(prhs[674])==1) ) { 
      mexErrMsgTxt("Input 674 must be a noncomplex scalar double.");
    } 
    mexinput674_temp = mxGetPr(prhs[674]); 
    double mexinput674 = *mexinput674_temp; 

    double *mexinput675_temp = NULL; 
    if( !mxIsDouble(prhs[675]) || mxIsComplex(prhs[675]) || !(mxGetM(prhs[675])==1 && mxGetN(prhs[675])==1) ) { 
      mexErrMsgTxt("Input 675 must be a noncomplex scalar double.");
    } 
    mexinput675_temp = mxGetPr(prhs[675]); 
    double mexinput675 = *mexinput675_temp; 

    double *mexinput676_temp = NULL; 
    if( !mxIsDouble(prhs[676]) || mxIsComplex(prhs[676]) || !(mxGetM(prhs[676])==1 && mxGetN(prhs[676])==1) ) { 
      mexErrMsgTxt("Input 676 must be a noncomplex scalar double.");
    } 
    mexinput676_temp = mxGetPr(prhs[676]); 
    double mexinput676 = *mexinput676_temp; 

    double *mexinput677_temp = NULL; 
    if( !mxIsDouble(prhs[677]) || mxIsComplex(prhs[677]) || !(mxGetM(prhs[677])==1 && mxGetN(prhs[677])==1) ) { 
      mexErrMsgTxt("Input 677 must be a noncomplex scalar double.");
    } 
    mexinput677_temp = mxGetPr(prhs[677]); 
    double mexinput677 = *mexinput677_temp; 

    double *mexinput678_temp = NULL; 
    if( !mxIsDouble(prhs[678]) || mxIsComplex(prhs[678]) || !(mxGetM(prhs[678])==1 && mxGetN(prhs[678])==1) ) { 
      mexErrMsgTxt("Input 678 must be a noncomplex scalar double.");
    } 
    mexinput678_temp = mxGetPr(prhs[678]); 
    double mexinput678 = *mexinput678_temp; 

    double *mexinput679_temp = NULL; 
    if( !mxIsDouble(prhs[679]) || mxIsComplex(prhs[679]) || !(mxGetM(prhs[679])==1 && mxGetN(prhs[679])==1) ) { 
      mexErrMsgTxt("Input 679 must be a noncomplex scalar double.");
    } 
    mexinput679_temp = mxGetPr(prhs[679]); 
    double mexinput679 = *mexinput679_temp; 

    double *mexinput680_temp = NULL; 
    if( !mxIsDouble(prhs[680]) || mxIsComplex(prhs[680]) || !(mxGetM(prhs[680])==1 && mxGetN(prhs[680])==1) ) { 
      mexErrMsgTxt("Input 680 must be a noncomplex scalar double.");
    } 
    mexinput680_temp = mxGetPr(prhs[680]); 
    double mexinput680 = *mexinput680_temp; 

    double *mexinput681_temp = NULL; 
    if( !mxIsDouble(prhs[681]) || mxIsComplex(prhs[681]) || !(mxGetM(prhs[681])==1 && mxGetN(prhs[681])==1) ) { 
      mexErrMsgTxt("Input 681 must be a noncomplex scalar double.");
    } 
    mexinput681_temp = mxGetPr(prhs[681]); 
    double mexinput681 = *mexinput681_temp; 

    double *mexinput682_temp = NULL; 
    if( !mxIsDouble(prhs[682]) || mxIsComplex(prhs[682]) || !(mxGetM(prhs[682])==1 && mxGetN(prhs[682])==1) ) { 
      mexErrMsgTxt("Input 682 must be a noncomplex scalar double.");
    } 
    mexinput682_temp = mxGetPr(prhs[682]); 
    double mexinput682 = *mexinput682_temp; 

    double *mexinput683_temp = NULL; 
    if( !mxIsDouble(prhs[683]) || mxIsComplex(prhs[683]) || !(mxGetM(prhs[683])==1 && mxGetN(prhs[683])==1) ) { 
      mexErrMsgTxt("Input 683 must be a noncomplex scalar double.");
    } 
    mexinput683_temp = mxGetPr(prhs[683]); 
    double mexinput683 = *mexinput683_temp; 

    double *mexinput684_temp = NULL; 
    if( !mxIsDouble(prhs[684]) || mxIsComplex(prhs[684]) || !(mxGetM(prhs[684])==1 && mxGetN(prhs[684])==1) ) { 
      mexErrMsgTxt("Input 684 must be a noncomplex scalar double.");
    } 
    mexinput684_temp = mxGetPr(prhs[684]); 
    double mexinput684 = *mexinput684_temp; 

    double *mexinput685_temp = NULL; 
    if( !mxIsDouble(prhs[685]) || mxIsComplex(prhs[685]) || !(mxGetM(prhs[685])==1 && mxGetN(prhs[685])==1) ) { 
      mexErrMsgTxt("Input 685 must be a noncomplex scalar double.");
    } 
    mexinput685_temp = mxGetPr(prhs[685]); 
    double mexinput685 = *mexinput685_temp; 

    double *mexinput686_temp = NULL; 
    if( !mxIsDouble(prhs[686]) || mxIsComplex(prhs[686]) || !(mxGetM(prhs[686])==1 && mxGetN(prhs[686])==1) ) { 
      mexErrMsgTxt("Input 686 must be a noncomplex scalar double.");
    } 
    mexinput686_temp = mxGetPr(prhs[686]); 
    double mexinput686 = *mexinput686_temp; 

    double *mexinput687_temp = NULL; 
    if( !mxIsDouble(prhs[687]) || mxIsComplex(prhs[687]) || !(mxGetM(prhs[687])==1 && mxGetN(prhs[687])==1) ) { 
      mexErrMsgTxt("Input 687 must be a noncomplex scalar double.");
    } 
    mexinput687_temp = mxGetPr(prhs[687]); 
    double mexinput687 = *mexinput687_temp; 

    double *mexinput688_temp = NULL; 
    if( !mxIsDouble(prhs[688]) || mxIsComplex(prhs[688]) || !(mxGetM(prhs[688])==1 && mxGetN(prhs[688])==1) ) { 
      mexErrMsgTxt("Input 688 must be a noncomplex scalar double.");
    } 
    mexinput688_temp = mxGetPr(prhs[688]); 
    double mexinput688 = *mexinput688_temp; 

    double *mexinput689_temp = NULL; 
    if( !mxIsDouble(prhs[689]) || mxIsComplex(prhs[689]) || !(mxGetM(prhs[689])==1 && mxGetN(prhs[689])==1) ) { 
      mexErrMsgTxt("Input 689 must be a noncomplex scalar double.");
    } 
    mexinput689_temp = mxGetPr(prhs[689]); 
    double mexinput689 = *mexinput689_temp; 

    double *mexinput690_temp = NULL; 
    if( !mxIsDouble(prhs[690]) || mxIsComplex(prhs[690]) || !(mxGetM(prhs[690])==1 && mxGetN(prhs[690])==1) ) { 
      mexErrMsgTxt("Input 690 must be a noncomplex scalar double.");
    } 
    mexinput690_temp = mxGetPr(prhs[690]); 
    double mexinput690 = *mexinput690_temp; 

    double *mexinput691_temp = NULL; 
    if( !mxIsDouble(prhs[691]) || mxIsComplex(prhs[691]) || !(mxGetM(prhs[691])==1 && mxGetN(prhs[691])==1) ) { 
      mexErrMsgTxt("Input 691 must be a noncomplex scalar double.");
    } 
    mexinput691_temp = mxGetPr(prhs[691]); 
    double mexinput691 = *mexinput691_temp; 

    double *mexinput692_temp = NULL; 
    if( !mxIsDouble(prhs[692]) || mxIsComplex(prhs[692]) || !(mxGetM(prhs[692])==1 && mxGetN(prhs[692])==1) ) { 
      mexErrMsgTxt("Input 692 must be a noncomplex scalar double.");
    } 
    mexinput692_temp = mxGetPr(prhs[692]); 
    double mexinput692 = *mexinput692_temp; 

    double *mexinput693_temp = NULL; 
    if( !mxIsDouble(prhs[693]) || mxIsComplex(prhs[693]) || !(mxGetM(prhs[693])==1 && mxGetN(prhs[693])==1) ) { 
      mexErrMsgTxt("Input 693 must be a noncomplex scalar double.");
    } 
    mexinput693_temp = mxGetPr(prhs[693]); 
    double mexinput693 = *mexinput693_temp; 

    double *mexinput694_temp = NULL; 
    if( !mxIsDouble(prhs[694]) || mxIsComplex(prhs[694]) || !(mxGetM(prhs[694])==1 && mxGetN(prhs[694])==1) ) { 
      mexErrMsgTxt("Input 694 must be a noncomplex scalar double.");
    } 
    mexinput694_temp = mxGetPr(prhs[694]); 
    double mexinput694 = *mexinput694_temp; 

    double *mexinput695_temp = NULL; 
    if( !mxIsDouble(prhs[695]) || mxIsComplex(prhs[695]) || !(mxGetM(prhs[695])==1 && mxGetN(prhs[695])==1) ) { 
      mexErrMsgTxt("Input 695 must be a noncomplex scalar double.");
    } 
    mexinput695_temp = mxGetPr(prhs[695]); 
    double mexinput695 = *mexinput695_temp; 

    double *mexinput696_temp = NULL; 
    if( !mxIsDouble(prhs[696]) || mxIsComplex(prhs[696]) || !(mxGetM(prhs[696])==1 && mxGetN(prhs[696])==1) ) { 
      mexErrMsgTxt("Input 696 must be a noncomplex scalar double.");
    } 
    mexinput696_temp = mxGetPr(prhs[696]); 
    double mexinput696 = *mexinput696_temp; 

    double *mexinput697_temp = NULL; 
    if( !mxIsDouble(prhs[697]) || mxIsComplex(prhs[697]) || !(mxGetM(prhs[697])==1 && mxGetN(prhs[697])==1) ) { 
      mexErrMsgTxt("Input 697 must be a noncomplex scalar double.");
    } 
    mexinput697_temp = mxGetPr(prhs[697]); 
    double mexinput697 = *mexinput697_temp; 

    double *mexinput698_temp = NULL; 
    if( !mxIsDouble(prhs[698]) || mxIsComplex(prhs[698]) || !(mxGetM(prhs[698])==1 && mxGetN(prhs[698])==1) ) { 
      mexErrMsgTxt("Input 698 must be a noncomplex scalar double.");
    } 
    mexinput698_temp = mxGetPr(prhs[698]); 
    double mexinput698 = *mexinput698_temp; 

    double *mexinput699_temp = NULL; 
    if( !mxIsDouble(prhs[699]) || mxIsComplex(prhs[699]) || !(mxGetM(prhs[699])==1 && mxGetN(prhs[699])==1) ) { 
      mexErrMsgTxt("Input 699 must be a noncomplex scalar double.");
    } 
    mexinput699_temp = mxGetPr(prhs[699]); 
    double mexinput699 = *mexinput699_temp; 

    double *mexinput700_temp = NULL; 
    if( !mxIsDouble(prhs[700]) || mxIsComplex(prhs[700]) || !(mxGetM(prhs[700])==1 && mxGetN(prhs[700])==1) ) { 
      mexErrMsgTxt("Input 700 must be a noncomplex scalar double.");
    } 
    mexinput700_temp = mxGetPr(prhs[700]); 
    double mexinput700 = *mexinput700_temp; 

    double *mexinput701_temp = NULL; 
    if( !mxIsDouble(prhs[701]) || mxIsComplex(prhs[701]) || !(mxGetM(prhs[701])==1 && mxGetN(prhs[701])==1) ) { 
      mexErrMsgTxt("Input 701 must be a noncomplex scalar double.");
    } 
    mexinput701_temp = mxGetPr(prhs[701]); 
    double mexinput701 = *mexinput701_temp; 

    double *mexinput702_temp = NULL; 
    if( !mxIsDouble(prhs[702]) || mxIsComplex(prhs[702]) || !(mxGetM(prhs[702])==1 && mxGetN(prhs[702])==1) ) { 
      mexErrMsgTxt("Input 702 must be a noncomplex scalar double.");
    } 
    mexinput702_temp = mxGetPr(prhs[702]); 
    double mexinput702 = *mexinput702_temp; 

    double *mexinput703_temp = NULL; 
    if( !mxIsDouble(prhs[703]) || mxIsComplex(prhs[703]) || !(mxGetM(prhs[703])==1 && mxGetN(prhs[703])==1) ) { 
      mexErrMsgTxt("Input 703 must be a noncomplex scalar double.");
    } 
    mexinput703_temp = mxGetPr(prhs[703]); 
    double mexinput703 = *mexinput703_temp; 

    double *mexinput704_temp = NULL; 
    if( !mxIsDouble(prhs[704]) || mxIsComplex(prhs[704]) || !(mxGetM(prhs[704])==1 && mxGetN(prhs[704])==1) ) { 
      mexErrMsgTxt("Input 704 must be a noncomplex scalar double.");
    } 
    mexinput704_temp = mxGetPr(prhs[704]); 
    double mexinput704 = *mexinput704_temp; 

    double *mexinput705_temp = NULL; 
    if( !mxIsDouble(prhs[705]) || mxIsComplex(prhs[705]) || !(mxGetM(prhs[705])==1 && mxGetN(prhs[705])==1) ) { 
      mexErrMsgTxt("Input 705 must be a noncomplex scalar double.");
    } 
    mexinput705_temp = mxGetPr(prhs[705]); 
    double mexinput705 = *mexinput705_temp; 

    double *mexinput706_temp = NULL; 
    if( !mxIsDouble(prhs[706]) || mxIsComplex(prhs[706]) || !(mxGetM(prhs[706])==1 && mxGetN(prhs[706])==1) ) { 
      mexErrMsgTxt("Input 706 must be a noncomplex scalar double.");
    } 
    mexinput706_temp = mxGetPr(prhs[706]); 
    double mexinput706 = *mexinput706_temp; 

    double *mexinput707_temp = NULL; 
    if( !mxIsDouble(prhs[707]) || mxIsComplex(prhs[707]) || !(mxGetM(prhs[707])==1 && mxGetN(prhs[707])==1) ) { 
      mexErrMsgTxt("Input 707 must be a noncomplex scalar double.");
    } 
    mexinput707_temp = mxGetPr(prhs[707]); 
    double mexinput707 = *mexinput707_temp; 

    double *mexinput708_temp = NULL; 
    if( !mxIsDouble(prhs[708]) || mxIsComplex(prhs[708]) || !(mxGetM(prhs[708])==1 && mxGetN(prhs[708])==1) ) { 
      mexErrMsgTxt("Input 708 must be a noncomplex scalar double.");
    } 
    mexinput708_temp = mxGetPr(prhs[708]); 
    double mexinput708 = *mexinput708_temp; 

    double *mexinput709_temp = NULL; 
    if( !mxIsDouble(prhs[709]) || mxIsComplex(prhs[709]) || !(mxGetM(prhs[709])==1 && mxGetN(prhs[709])==1) ) { 
      mexErrMsgTxt("Input 709 must be a noncomplex scalar double.");
    } 
    mexinput709_temp = mxGetPr(prhs[709]); 
    double mexinput709 = *mexinput709_temp; 

    double *mexinput710_temp = NULL; 
    if( !mxIsDouble(prhs[710]) || mxIsComplex(prhs[710]) || !(mxGetM(prhs[710])==1 && mxGetN(prhs[710])==1) ) { 
      mexErrMsgTxt("Input 710 must be a noncomplex scalar double.");
    } 
    mexinput710_temp = mxGetPr(prhs[710]); 
    double mexinput710 = *mexinput710_temp; 

    double *mexinput711_temp = NULL; 
    if( !mxIsDouble(prhs[711]) || mxIsComplex(prhs[711]) || !(mxGetM(prhs[711])==1 && mxGetN(prhs[711])==1) ) { 
      mexErrMsgTxt("Input 711 must be a noncomplex scalar double.");
    } 
    mexinput711_temp = mxGetPr(prhs[711]); 
    double mexinput711 = *mexinput711_temp; 

    double *mexinput712_temp = NULL; 
    if( !mxIsDouble(prhs[712]) || mxIsComplex(prhs[712]) || !(mxGetM(prhs[712])==1 && mxGetN(prhs[712])==1) ) { 
      mexErrMsgTxt("Input 712 must be a noncomplex scalar double.");
    } 
    mexinput712_temp = mxGetPr(prhs[712]); 
    double mexinput712 = *mexinput712_temp; 

    double *mexinput713_temp = NULL; 
    if( !mxIsDouble(prhs[713]) || mxIsComplex(prhs[713]) || !(mxGetM(prhs[713])==1 && mxGetN(prhs[713])==1) ) { 
      mexErrMsgTxt("Input 713 must be a noncomplex scalar double.");
    } 
    mexinput713_temp = mxGetPr(prhs[713]); 
    double mexinput713 = *mexinput713_temp; 

    double *mexinput714_temp = NULL; 
    if( !mxIsDouble(prhs[714]) || mxIsComplex(prhs[714]) || !(mxGetM(prhs[714])==1 && mxGetN(prhs[714])==1) ) { 
      mexErrMsgTxt("Input 714 must be a noncomplex scalar double.");
    } 
    mexinput714_temp = mxGetPr(prhs[714]); 
    double mexinput714 = *mexinput714_temp; 

    double *mexinput715_temp = NULL; 
    if( !mxIsDouble(prhs[715]) || mxIsComplex(prhs[715]) || !(mxGetM(prhs[715])==1 && mxGetN(prhs[715])==1) ) { 
      mexErrMsgTxt("Input 715 must be a noncomplex scalar double.");
    } 
    mexinput715_temp = mxGetPr(prhs[715]); 
    double mexinput715 = *mexinput715_temp; 

    double *mexinput716_temp = NULL; 
    if( !mxIsDouble(prhs[716]) || mxIsComplex(prhs[716]) || !(mxGetM(prhs[716])==1 && mxGetN(prhs[716])==1) ) { 
      mexErrMsgTxt("Input 716 must be a noncomplex scalar double.");
    } 
    mexinput716_temp = mxGetPr(prhs[716]); 
    double mexinput716 = *mexinput716_temp; 

    double *mexinput717_temp = NULL; 
    if( !mxIsDouble(prhs[717]) || mxIsComplex(prhs[717]) || !(mxGetM(prhs[717])==1 && mxGetN(prhs[717])==1) ) { 
      mexErrMsgTxt("Input 717 must be a noncomplex scalar double.");
    } 
    mexinput717_temp = mxGetPr(prhs[717]); 
    double mexinput717 = *mexinput717_temp; 

    double *mexinput718_temp = NULL; 
    if( !mxIsDouble(prhs[718]) || mxIsComplex(prhs[718]) || !(mxGetM(prhs[718])==1 && mxGetN(prhs[718])==1) ) { 
      mexErrMsgTxt("Input 718 must be a noncomplex scalar double.");
    } 
    mexinput718_temp = mxGetPr(prhs[718]); 
    double mexinput718 = *mexinput718_temp; 

    double *mexinput719_temp = NULL; 
    if( !mxIsDouble(prhs[719]) || mxIsComplex(prhs[719]) || !(mxGetM(prhs[719])==1 && mxGetN(prhs[719])==1) ) { 
      mexErrMsgTxt("Input 719 must be a noncomplex scalar double.");
    } 
    mexinput719_temp = mxGetPr(prhs[719]); 
    double mexinput719 = *mexinput719_temp; 

    double *mexinput720_temp = NULL; 
    if( !mxIsDouble(prhs[720]) || mxIsComplex(prhs[720]) || !(mxGetM(prhs[720])==1 && mxGetN(prhs[720])==1) ) { 
      mexErrMsgTxt("Input 720 must be a noncomplex scalar double.");
    } 
    mexinput720_temp = mxGetPr(prhs[720]); 
    double mexinput720 = *mexinput720_temp; 

    double *mexinput721_temp = NULL; 
    if( !mxIsDouble(prhs[721]) || mxIsComplex(prhs[721]) || !(mxGetM(prhs[721])==1 && mxGetN(prhs[721])==1) ) { 
      mexErrMsgTxt("Input 721 must be a noncomplex scalar double.");
    } 
    mexinput721_temp = mxGetPr(prhs[721]); 
    double mexinput721 = *mexinput721_temp; 

    double *mexinput722_temp = NULL; 
    if( !mxIsDouble(prhs[722]) || mxIsComplex(prhs[722]) || !(mxGetM(prhs[722])==1 && mxGetN(prhs[722])==1) ) { 
      mexErrMsgTxt("Input 722 must be a noncomplex scalar double.");
    } 
    mexinput722_temp = mxGetPr(prhs[722]); 
    double mexinput722 = *mexinput722_temp; 

    double *mexinput723_temp = NULL; 
    if( !mxIsDouble(prhs[723]) || mxIsComplex(prhs[723]) || !(mxGetM(prhs[723])==1 && mxGetN(prhs[723])==1) ) { 
      mexErrMsgTxt("Input 723 must be a noncomplex scalar double.");
    } 
    mexinput723_temp = mxGetPr(prhs[723]); 
    double mexinput723 = *mexinput723_temp; 

    double *mexinput724_temp = NULL; 
    if( !mxIsDouble(prhs[724]) || mxIsComplex(prhs[724]) || !(mxGetM(prhs[724])==1 && mxGetN(prhs[724])==1) ) { 
      mexErrMsgTxt("Input 724 must be a noncomplex scalar double.");
    } 
    mexinput724_temp = mxGetPr(prhs[724]); 
    double mexinput724 = *mexinput724_temp; 

    double *mexinput725_temp = NULL; 
    if( !mxIsDouble(prhs[725]) || mxIsComplex(prhs[725]) || !(mxGetM(prhs[725])==1 && mxGetN(prhs[725])==1) ) { 
      mexErrMsgTxt("Input 725 must be a noncomplex scalar double.");
    } 
    mexinput725_temp = mxGetPr(prhs[725]); 
    double mexinput725 = *mexinput725_temp; 

    double *mexinput726_temp = NULL; 
    if( !mxIsDouble(prhs[726]) || mxIsComplex(prhs[726]) || !(mxGetM(prhs[726])==1 && mxGetN(prhs[726])==1) ) { 
      mexErrMsgTxt("Input 726 must be a noncomplex scalar double.");
    } 
    mexinput726_temp = mxGetPr(prhs[726]); 
    double mexinput726 = *mexinput726_temp; 

    double *mexinput727_temp = NULL; 
    if( !mxIsDouble(prhs[727]) || mxIsComplex(prhs[727]) || !(mxGetM(prhs[727])==1 && mxGetN(prhs[727])==1) ) { 
      mexErrMsgTxt("Input 727 must be a noncomplex scalar double.");
    } 
    mexinput727_temp = mxGetPr(prhs[727]); 
    double mexinput727 = *mexinput727_temp; 

    double *mexinput728_temp = NULL; 
    if( !mxIsDouble(prhs[728]) || mxIsComplex(prhs[728]) || !(mxGetM(prhs[728])==1 && mxGetN(prhs[728])==1) ) { 
      mexErrMsgTxt("Input 728 must be a noncomplex scalar double.");
    } 
    mexinput728_temp = mxGetPr(prhs[728]); 
    double mexinput728 = *mexinput728_temp; 

    double *mexinput729_temp = NULL; 
    if( !mxIsDouble(prhs[729]) || mxIsComplex(prhs[729]) || !(mxGetM(prhs[729])==1 && mxGetN(prhs[729])==1) ) { 
      mexErrMsgTxt("Input 729 must be a noncomplex scalar double.");
    } 
    mexinput729_temp = mxGetPr(prhs[729]); 
    double mexinput729 = *mexinput729_temp; 

    double *mexinput730_temp = NULL; 
    if( !mxIsDouble(prhs[730]) || mxIsComplex(prhs[730]) || !(mxGetM(prhs[730])==1 && mxGetN(prhs[730])==1) ) { 
      mexErrMsgTxt("Input 730 must be a noncomplex scalar double.");
    } 
    mexinput730_temp = mxGetPr(prhs[730]); 
    double mexinput730 = *mexinput730_temp; 

    double *mexinput731_temp = NULL; 
    if( !mxIsDouble(prhs[731]) || mxIsComplex(prhs[731]) || !(mxGetM(prhs[731])==1 && mxGetN(prhs[731])==1) ) { 
      mexErrMsgTxt("Input 731 must be a noncomplex scalar double.");
    } 
    mexinput731_temp = mxGetPr(prhs[731]); 
    double mexinput731 = *mexinput731_temp; 

    double *mexinput732_temp = NULL; 
    if( !mxIsDouble(prhs[732]) || mxIsComplex(prhs[732]) || !(mxGetM(prhs[732])==1 && mxGetN(prhs[732])==1) ) { 
      mexErrMsgTxt("Input 732 must be a noncomplex scalar double.");
    } 
    mexinput732_temp = mxGetPr(prhs[732]); 
    double mexinput732 = *mexinput732_temp; 

    double *mexinput733_temp = NULL; 
    if( !mxIsDouble(prhs[733]) || mxIsComplex(prhs[733]) || !(mxGetM(prhs[733])==1 && mxGetN(prhs[733])==1) ) { 
      mexErrMsgTxt("Input 733 must be a noncomplex scalar double.");
    } 
    mexinput733_temp = mxGetPr(prhs[733]); 
    double mexinput733 = *mexinput733_temp; 

    double *mexinput734_temp = NULL; 
    if( !mxIsDouble(prhs[734]) || mxIsComplex(prhs[734]) || !(mxGetM(prhs[734])==1 && mxGetN(prhs[734])==1) ) { 
      mexErrMsgTxt("Input 734 must be a noncomplex scalar double.");
    } 
    mexinput734_temp = mxGetPr(prhs[734]); 
    double mexinput734 = *mexinput734_temp; 

    double *mexinput735_temp = NULL; 
    if( !mxIsDouble(prhs[735]) || mxIsComplex(prhs[735]) || !(mxGetM(prhs[735])==1 && mxGetN(prhs[735])==1) ) { 
      mexErrMsgTxt("Input 735 must be a noncomplex scalar double.");
    } 
    mexinput735_temp = mxGetPr(prhs[735]); 
    double mexinput735 = *mexinput735_temp; 

    double *mexinput736_temp = NULL; 
    if( !mxIsDouble(prhs[736]) || mxIsComplex(prhs[736]) || !(mxGetM(prhs[736])==1 && mxGetN(prhs[736])==1) ) { 
      mexErrMsgTxt("Input 736 must be a noncomplex scalar double.");
    } 
    mexinput736_temp = mxGetPr(prhs[736]); 
    double mexinput736 = *mexinput736_temp; 

    double *mexinput737_temp = NULL; 
    if( !mxIsDouble(prhs[737]) || mxIsComplex(prhs[737]) || !(mxGetM(prhs[737])==1 && mxGetN(prhs[737])==1) ) { 
      mexErrMsgTxt("Input 737 must be a noncomplex scalar double.");
    } 
    mexinput737_temp = mxGetPr(prhs[737]); 
    double mexinput737 = *mexinput737_temp; 

    double *mexinput738_temp = NULL; 
    if( !mxIsDouble(prhs[738]) || mxIsComplex(prhs[738]) || !(mxGetM(prhs[738])==1 && mxGetN(prhs[738])==1) ) { 
      mexErrMsgTxt("Input 738 must be a noncomplex scalar double.");
    } 
    mexinput738_temp = mxGetPr(prhs[738]); 
    double mexinput738 = *mexinput738_temp; 

    double *mexinput739_temp = NULL; 
    if( !mxIsDouble(prhs[739]) || mxIsComplex(prhs[739]) || !(mxGetM(prhs[739])==1 && mxGetN(prhs[739])==1) ) { 
      mexErrMsgTxt("Input 739 must be a noncomplex scalar double.");
    } 
    mexinput739_temp = mxGetPr(prhs[739]); 
    double mexinput739 = *mexinput739_temp; 

    double *mexinput740_temp = NULL; 
    if( !mxIsDouble(prhs[740]) || mxIsComplex(prhs[740]) || !(mxGetM(prhs[740])==1 && mxGetN(prhs[740])==1) ) { 
      mexErrMsgTxt("Input 740 must be a noncomplex scalar double.");
    } 
    mexinput740_temp = mxGetPr(prhs[740]); 
    double mexinput740 = *mexinput740_temp; 

    double *mexinput741_temp = NULL; 
    if( !mxIsDouble(prhs[741]) || mxIsComplex(prhs[741]) || !(mxGetM(prhs[741])==1 && mxGetN(prhs[741])==1) ) { 
      mexErrMsgTxt("Input 741 must be a noncomplex scalar double.");
    } 
    mexinput741_temp = mxGetPr(prhs[741]); 
    double mexinput741 = *mexinput741_temp; 

    double *mexinput742_temp = NULL; 
    if( !mxIsDouble(prhs[742]) || mxIsComplex(prhs[742]) || !(mxGetM(prhs[742])==1 && mxGetN(prhs[742])==1) ) { 
      mexErrMsgTxt("Input 742 must be a noncomplex scalar double.");
    } 
    mexinput742_temp = mxGetPr(prhs[742]); 
    double mexinput742 = *mexinput742_temp; 

    double *mexinput743_temp = NULL; 
    if( !mxIsDouble(prhs[743]) || mxIsComplex(prhs[743]) || !(mxGetM(prhs[743])==1 && mxGetN(prhs[743])==1) ) { 
      mexErrMsgTxt("Input 743 must be a noncomplex scalar double.");
    } 
    mexinput743_temp = mxGetPr(prhs[743]); 
    double mexinput743 = *mexinput743_temp; 

    double *mexinput744_temp = NULL; 
    if( !mxIsDouble(prhs[744]) || mxIsComplex(prhs[744]) || !(mxGetM(prhs[744])==1 && mxGetN(prhs[744])==1) ) { 
      mexErrMsgTxt("Input 744 must be a noncomplex scalar double.");
    } 
    mexinput744_temp = mxGetPr(prhs[744]); 
    double mexinput744 = *mexinput744_temp; 

    double *mexinput745_temp = NULL; 
    if( !mxIsDouble(prhs[745]) || mxIsComplex(prhs[745]) || !(mxGetM(prhs[745])==1 && mxGetN(prhs[745])==1) ) { 
      mexErrMsgTxt("Input 745 must be a noncomplex scalar double.");
    } 
    mexinput745_temp = mxGetPr(prhs[745]); 
    double mexinput745 = *mexinput745_temp; 

    double *mexinput746_temp = NULL; 
    if( !mxIsDouble(prhs[746]) || mxIsComplex(prhs[746]) || !(mxGetM(prhs[746])==1 && mxGetN(prhs[746])==1) ) { 
      mexErrMsgTxt("Input 746 must be a noncomplex scalar double.");
    } 
    mexinput746_temp = mxGetPr(prhs[746]); 
    double mexinput746 = *mexinput746_temp; 

    double *mexinput747_temp = NULL; 
    if( !mxIsDouble(prhs[747]) || mxIsComplex(prhs[747]) || !(mxGetM(prhs[747])==1 && mxGetN(prhs[747])==1) ) { 
      mexErrMsgTxt("Input 747 must be a noncomplex scalar double.");
    } 
    mexinput747_temp = mxGetPr(prhs[747]); 
    double mexinput747 = *mexinput747_temp; 

    double *mexinput748_temp = NULL; 
    if( !mxIsDouble(prhs[748]) || mxIsComplex(prhs[748]) || !(mxGetM(prhs[748])==1 && mxGetN(prhs[748])==1) ) { 
      mexErrMsgTxt("Input 748 must be a noncomplex scalar double.");
    } 
    mexinput748_temp = mxGetPr(prhs[748]); 
    double mexinput748 = *mexinput748_temp; 

    double *mexinput749_temp = NULL; 
    if( !mxIsDouble(prhs[749]) || mxIsComplex(prhs[749]) || !(mxGetM(prhs[749])==1 && mxGetN(prhs[749])==1) ) { 
      mexErrMsgTxt("Input 749 must be a noncomplex scalar double.");
    } 
    mexinput749_temp = mxGetPr(prhs[749]); 
    double mexinput749 = *mexinput749_temp; 

    double *mexinput750_temp = NULL; 
    if( !mxIsDouble(prhs[750]) || mxIsComplex(prhs[750]) || !(mxGetM(prhs[750])==1 && mxGetN(prhs[750])==1) ) { 
      mexErrMsgTxt("Input 750 must be a noncomplex scalar double.");
    } 
    mexinput750_temp = mxGetPr(prhs[750]); 
    double mexinput750 = *mexinput750_temp; 

    double *mexinput751_temp = NULL; 
    if( !mxIsDouble(prhs[751]) || mxIsComplex(prhs[751]) || !(mxGetM(prhs[751])==1 && mxGetN(prhs[751])==1) ) { 
      mexErrMsgTxt("Input 751 must be a noncomplex scalar double.");
    } 
    mexinput751_temp = mxGetPr(prhs[751]); 
    double mexinput751 = *mexinput751_temp; 

    double *mexinput752_temp = NULL; 
    if( !mxIsDouble(prhs[752]) || mxIsComplex(prhs[752]) || !(mxGetM(prhs[752])==1 && mxGetN(prhs[752])==1) ) { 
      mexErrMsgTxt("Input 752 must be a noncomplex scalar double.");
    } 
    mexinput752_temp = mxGetPr(prhs[752]); 
    double mexinput752 = *mexinput752_temp; 

    double *mexinput753_temp = NULL; 
    if( !mxIsDouble(prhs[753]) || mxIsComplex(prhs[753]) || !(mxGetM(prhs[753])==1 && mxGetN(prhs[753])==1) ) { 
      mexErrMsgTxt("Input 753 must be a noncomplex scalar double.");
    } 
    mexinput753_temp = mxGetPr(prhs[753]); 
    double mexinput753 = *mexinput753_temp; 

    double *mexinput754_temp = NULL; 
    if( !mxIsDouble(prhs[754]) || mxIsComplex(prhs[754]) || !(mxGetM(prhs[754])==1 && mxGetN(prhs[754])==1) ) { 
      mexErrMsgTxt("Input 754 must be a noncomplex scalar double.");
    } 
    mexinput754_temp = mxGetPr(prhs[754]); 
    double mexinput754 = *mexinput754_temp; 

    double *mexinput755_temp = NULL; 
    if( !mxIsDouble(prhs[755]) || mxIsComplex(prhs[755]) || !(mxGetM(prhs[755])==1 && mxGetN(prhs[755])==1) ) { 
      mexErrMsgTxt("Input 755 must be a noncomplex scalar double.");
    } 
    mexinput755_temp = mxGetPr(prhs[755]); 
    double mexinput755 = *mexinput755_temp; 

    double *mexinput756_temp = NULL; 
    if( !mxIsDouble(prhs[756]) || mxIsComplex(prhs[756]) || !(mxGetM(prhs[756])==1 && mxGetN(prhs[756])==1) ) { 
      mexErrMsgTxt("Input 756 must be a noncomplex scalar double.");
    } 
    mexinput756_temp = mxGetPr(prhs[756]); 
    double mexinput756 = *mexinput756_temp; 

    double *mexinput757_temp = NULL; 
    if( !mxIsDouble(prhs[757]) || mxIsComplex(prhs[757]) || !(mxGetM(prhs[757])==1 && mxGetN(prhs[757])==1) ) { 
      mexErrMsgTxt("Input 757 must be a noncomplex scalar double.");
    } 
    mexinput757_temp = mxGetPr(prhs[757]); 
    double mexinput757 = *mexinput757_temp; 

    double *mexinput758_temp = NULL; 
    if( !mxIsDouble(prhs[758]) || mxIsComplex(prhs[758]) || !(mxGetM(prhs[758])==1 && mxGetN(prhs[758])==1) ) { 
      mexErrMsgTxt("Input 758 must be a noncomplex scalar double.");
    } 
    mexinput758_temp = mxGetPr(prhs[758]); 
    double mexinput758 = *mexinput758_temp; 

    double *mexinput759_temp = NULL; 
    if( !mxIsDouble(prhs[759]) || mxIsComplex(prhs[759]) || !(mxGetM(prhs[759])==1 && mxGetN(prhs[759])==1) ) { 
      mexErrMsgTxt("Input 759 must be a noncomplex scalar double.");
    } 
    mexinput759_temp = mxGetPr(prhs[759]); 
    double mexinput759 = *mexinput759_temp; 

    double *mexinput760_temp = NULL; 
    if( !mxIsDouble(prhs[760]) || mxIsComplex(prhs[760]) || !(mxGetM(prhs[760])==1 && mxGetN(prhs[760])==1) ) { 
      mexErrMsgTxt("Input 760 must be a noncomplex scalar double.");
    } 
    mexinput760_temp = mxGetPr(prhs[760]); 
    double mexinput760 = *mexinput760_temp; 

    double *mexinput761_temp = NULL; 
    if( !mxIsDouble(prhs[761]) || mxIsComplex(prhs[761]) || !(mxGetM(prhs[761])==1 && mxGetN(prhs[761])==1) ) { 
      mexErrMsgTxt("Input 761 must be a noncomplex scalar double.");
    } 
    mexinput761_temp = mxGetPr(prhs[761]); 
    double mexinput761 = *mexinput761_temp; 

    double *mexinput762_temp = NULL; 
    if( !mxIsDouble(prhs[762]) || mxIsComplex(prhs[762]) || !(mxGetM(prhs[762])==1 && mxGetN(prhs[762])==1) ) { 
      mexErrMsgTxt("Input 762 must be a noncomplex scalar double.");
    } 
    mexinput762_temp = mxGetPr(prhs[762]); 
    double mexinput762 = *mexinput762_temp; 

    double *mexinput763_temp = NULL; 
    if( !mxIsDouble(prhs[763]) || mxIsComplex(prhs[763]) || !(mxGetM(prhs[763])==1 && mxGetN(prhs[763])==1) ) { 
      mexErrMsgTxt("Input 763 must be a noncomplex scalar double.");
    } 
    mexinput763_temp = mxGetPr(prhs[763]); 
    double mexinput763 = *mexinput763_temp; 

    double *mexinput764_temp = NULL; 
    if( !mxIsDouble(prhs[764]) || mxIsComplex(prhs[764]) || !(mxGetM(prhs[764])==1 && mxGetN(prhs[764])==1) ) { 
      mexErrMsgTxt("Input 764 must be a noncomplex scalar double.");
    } 
    mexinput764_temp = mxGetPr(prhs[764]); 
    double mexinput764 = *mexinput764_temp; 

    double *mexinput765_temp = NULL; 
    if( !mxIsDouble(prhs[765]) || mxIsComplex(prhs[765]) || !(mxGetM(prhs[765])==1 && mxGetN(prhs[765])==1) ) { 
      mexErrMsgTxt("Input 765 must be a noncomplex scalar double.");
    } 
    mexinput765_temp = mxGetPr(prhs[765]); 
    double mexinput765 = *mexinput765_temp; 

    double *mexinput766_temp = NULL; 
    if( !mxIsDouble(prhs[766]) || mxIsComplex(prhs[766]) || !(mxGetM(prhs[766])==1 && mxGetN(prhs[766])==1) ) { 
      mexErrMsgTxt("Input 766 must be a noncomplex scalar double.");
    } 
    mexinput766_temp = mxGetPr(prhs[766]); 
    double mexinput766 = *mexinput766_temp; 

    double *mexinput767_temp = NULL; 
    if( !mxIsDouble(prhs[767]) || mxIsComplex(prhs[767]) || !(mxGetM(prhs[767])==1 && mxGetN(prhs[767])==1) ) { 
      mexErrMsgTxt("Input 767 must be a noncomplex scalar double.");
    } 
    mexinput767_temp = mxGetPr(prhs[767]); 
    double mexinput767 = *mexinput767_temp; 

    double *mexinput768_temp = NULL; 
    if( !mxIsDouble(prhs[768]) || mxIsComplex(prhs[768]) || !(mxGetM(prhs[768])==1 && mxGetN(prhs[768])==1) ) { 
      mexErrMsgTxt("Input 768 must be a noncomplex scalar double.");
    } 
    mexinput768_temp = mxGetPr(prhs[768]); 
    double mexinput768 = *mexinput768_temp; 

    double *mexinput769_temp = NULL; 
    if( !mxIsDouble(prhs[769]) || mxIsComplex(prhs[769]) || !(mxGetM(prhs[769])==1 && mxGetN(prhs[769])==1) ) { 
      mexErrMsgTxt("Input 769 must be a noncomplex scalar double.");
    } 
    mexinput769_temp = mxGetPr(prhs[769]); 
    double mexinput769 = *mexinput769_temp; 

    double *mexinput770_temp = NULL; 
    if( !mxIsDouble(prhs[770]) || mxIsComplex(prhs[770]) || !(mxGetM(prhs[770])==1 && mxGetN(prhs[770])==1) ) { 
      mexErrMsgTxt("Input 770 must be a noncomplex scalar double.");
    } 
    mexinput770_temp = mxGetPr(prhs[770]); 
    double mexinput770 = *mexinput770_temp; 

    double *mexinput771_temp = NULL; 
    if( !mxIsDouble(prhs[771]) || mxIsComplex(prhs[771]) || !(mxGetM(prhs[771])==1 && mxGetN(prhs[771])==1) ) { 
      mexErrMsgTxt("Input 771 must be a noncomplex scalar double.");
    } 
    mexinput771_temp = mxGetPr(prhs[771]); 
    double mexinput771 = *mexinput771_temp; 

    double *mexinput772_temp = NULL; 
    if( !mxIsDouble(prhs[772]) || mxIsComplex(prhs[772]) || !(mxGetM(prhs[772])==1 && mxGetN(prhs[772])==1) ) { 
      mexErrMsgTxt("Input 772 must be a noncomplex scalar double.");
    } 
    mexinput772_temp = mxGetPr(prhs[772]); 
    double mexinput772 = *mexinput772_temp; 

    double *mexinput773_temp = NULL; 
    if( !mxIsDouble(prhs[773]) || mxIsComplex(prhs[773]) || !(mxGetM(prhs[773])==1 && mxGetN(prhs[773])==1) ) { 
      mexErrMsgTxt("Input 773 must be a noncomplex scalar double.");
    } 
    mexinput773_temp = mxGetPr(prhs[773]); 
    double mexinput773 = *mexinput773_temp; 

    double *mexinput774_temp = NULL; 
    if( !mxIsDouble(prhs[774]) || mxIsComplex(prhs[774]) || !(mxGetM(prhs[774])==1 && mxGetN(prhs[774])==1) ) { 
      mexErrMsgTxt("Input 774 must be a noncomplex scalar double.");
    } 
    mexinput774_temp = mxGetPr(prhs[774]); 
    double mexinput774 = *mexinput774_temp; 

    double *mexinput775_temp = NULL; 
    if( !mxIsDouble(prhs[775]) || mxIsComplex(prhs[775]) || !(mxGetM(prhs[775])==1 && mxGetN(prhs[775])==1) ) { 
      mexErrMsgTxt("Input 775 must be a noncomplex scalar double.");
    } 
    mexinput775_temp = mxGetPr(prhs[775]); 
    double mexinput775 = *mexinput775_temp; 

    double *mexinput776_temp = NULL; 
    if( !mxIsDouble(prhs[776]) || mxIsComplex(prhs[776]) || !(mxGetM(prhs[776])==1 && mxGetN(prhs[776])==1) ) { 
      mexErrMsgTxt("Input 776 must be a noncomplex scalar double.");
    } 
    mexinput776_temp = mxGetPr(prhs[776]); 
    double mexinput776 = *mexinput776_temp; 

    double *mexinput777_temp = NULL; 
    if( !mxIsDouble(prhs[777]) || mxIsComplex(prhs[777]) || !(mxGetM(prhs[777])==1 && mxGetN(prhs[777])==1) ) { 
      mexErrMsgTxt("Input 777 must be a noncomplex scalar double.");
    } 
    mexinput777_temp = mxGetPr(prhs[777]); 
    double mexinput777 = *mexinput777_temp; 

    double *mexinput778_temp = NULL; 
    if( !mxIsDouble(prhs[778]) || mxIsComplex(prhs[778]) || !(mxGetM(prhs[778])==1 && mxGetN(prhs[778])==1) ) { 
      mexErrMsgTxt("Input 778 must be a noncomplex scalar double.");
    } 
    mexinput778_temp = mxGetPr(prhs[778]); 
    double mexinput778 = *mexinput778_temp; 

    double *mexinput779_temp = NULL; 
    if( !mxIsDouble(prhs[779]) || mxIsComplex(prhs[779]) || !(mxGetM(prhs[779])==1 && mxGetN(prhs[779])==1) ) { 
      mexErrMsgTxt("Input 779 must be a noncomplex scalar double.");
    } 
    mexinput779_temp = mxGetPr(prhs[779]); 
    double mexinput779 = *mexinput779_temp; 

    double *mexinput780_temp = NULL; 
    if( !mxIsDouble(prhs[780]) || mxIsComplex(prhs[780]) || !(mxGetM(prhs[780])==1 && mxGetN(prhs[780])==1) ) { 
      mexErrMsgTxt("Input 780 must be a noncomplex scalar double.");
    } 
    mexinput780_temp = mxGetPr(prhs[780]); 
    double mexinput780 = *mexinput780_temp; 

    double *mexinput781_temp = NULL; 
    if( !mxIsDouble(prhs[781]) || mxIsComplex(prhs[781]) || !(mxGetM(prhs[781])==1 && mxGetN(prhs[781])==1) ) { 
      mexErrMsgTxt("Input 781 must be a noncomplex scalar double.");
    } 
    mexinput781_temp = mxGetPr(prhs[781]); 
    double mexinput781 = *mexinput781_temp; 

    double *mexinput782_temp = NULL; 
    if( !mxIsDouble(prhs[782]) || mxIsComplex(prhs[782]) || !(mxGetM(prhs[782])==1 && mxGetN(prhs[782])==1) ) { 
      mexErrMsgTxt("Input 782 must be a noncomplex scalar double.");
    } 
    mexinput782_temp = mxGetPr(prhs[782]); 
    double mexinput782 = *mexinput782_temp; 

    double *mexinput783_temp = NULL; 
    if( !mxIsDouble(prhs[783]) || mxIsComplex(prhs[783]) || !(mxGetM(prhs[783])==1 && mxGetN(prhs[783])==1) ) { 
      mexErrMsgTxt("Input 783 must be a noncomplex scalar double.");
    } 
    mexinput783_temp = mxGetPr(prhs[783]); 
    double mexinput783 = *mexinput783_temp; 

    double *mexinput784_temp = NULL; 
    if( !mxIsDouble(prhs[784]) || mxIsComplex(prhs[784]) || !(mxGetM(prhs[784])==1 && mxGetN(prhs[784])==1) ) { 
      mexErrMsgTxt("Input 784 must be a noncomplex scalar double.");
    } 
    mexinput784_temp = mxGetPr(prhs[784]); 
    double mexinput784 = *mexinput784_temp; 

    double *mexinput785_temp = NULL; 
    if( !mxIsDouble(prhs[785]) || mxIsComplex(prhs[785]) || !(mxGetM(prhs[785])==1 && mxGetN(prhs[785])==1) ) { 
      mexErrMsgTxt("Input 785 must be a noncomplex scalar double.");
    } 
    mexinput785_temp = mxGetPr(prhs[785]); 
    double mexinput785 = *mexinput785_temp; 

    double *mexinput786_temp = NULL; 
    if( !mxIsDouble(prhs[786]) || mxIsComplex(prhs[786]) || !(mxGetM(prhs[786])==1 && mxGetN(prhs[786])==1) ) { 
      mexErrMsgTxt("Input 786 must be a noncomplex scalar double.");
    } 
    mexinput786_temp = mxGetPr(prhs[786]); 
    double mexinput786 = *mexinput786_temp; 

    double *mexinput787_temp = NULL; 
    if( !mxIsDouble(prhs[787]) || mxIsComplex(prhs[787]) || !(mxGetM(prhs[787])==1 && mxGetN(prhs[787])==1) ) { 
      mexErrMsgTxt("Input 787 must be a noncomplex scalar double.");
    } 
    mexinput787_temp = mxGetPr(prhs[787]); 
    double mexinput787 = *mexinput787_temp; 

    double *mexinput788_temp = NULL; 
    if( !mxIsDouble(prhs[788]) || mxIsComplex(prhs[788]) || !(mxGetM(prhs[788])==1 && mxGetN(prhs[788])==1) ) { 
      mexErrMsgTxt("Input 788 must be a noncomplex scalar double.");
    } 
    mexinput788_temp = mxGetPr(prhs[788]); 
    double mexinput788 = *mexinput788_temp; 

    double *mexinput789_temp = NULL; 
    if( !mxIsDouble(prhs[789]) || mxIsComplex(prhs[789]) || !(mxGetM(prhs[789])==1 && mxGetN(prhs[789])==1) ) { 
      mexErrMsgTxt("Input 789 must be a noncomplex scalar double.");
    } 
    mexinput789_temp = mxGetPr(prhs[789]); 
    double mexinput789 = *mexinput789_temp; 

    double *mexinput790_temp = NULL; 
    if( !mxIsDouble(prhs[790]) || mxIsComplex(prhs[790]) || !(mxGetM(prhs[790])==1 && mxGetN(prhs[790])==1) ) { 
      mexErrMsgTxt("Input 790 must be a noncomplex scalar double.");
    } 
    mexinput790_temp = mxGetPr(prhs[790]); 
    double mexinput790 = *mexinput790_temp; 

    double *mexinput791_temp = NULL; 
    if( !mxIsDouble(prhs[791]) || mxIsComplex(prhs[791]) || !(mxGetM(prhs[791])==1 && mxGetN(prhs[791])==1) ) { 
      mexErrMsgTxt("Input 791 must be a noncomplex scalar double.");
    } 
    mexinput791_temp = mxGetPr(prhs[791]); 
    double mexinput791 = *mexinput791_temp; 

    double *mexinput792_temp = NULL; 
    if( !mxIsDouble(prhs[792]) || mxIsComplex(prhs[792]) || !(mxGetM(prhs[792])==1 && mxGetN(prhs[792])==1) ) { 
      mexErrMsgTxt("Input 792 must be a noncomplex scalar double.");
    } 
    mexinput792_temp = mxGetPr(prhs[792]); 
    double mexinput792 = *mexinput792_temp; 

    double *mexinput793_temp = NULL; 
    if( !mxIsDouble(prhs[793]) || mxIsComplex(prhs[793]) || !(mxGetM(prhs[793])==1 && mxGetN(prhs[793])==1) ) { 
      mexErrMsgTxt("Input 793 must be a noncomplex scalar double.");
    } 
    mexinput793_temp = mxGetPr(prhs[793]); 
    double mexinput793 = *mexinput793_temp; 

    double *mexinput794_temp = NULL; 
    if( !mxIsDouble(prhs[794]) || mxIsComplex(prhs[794]) || !(mxGetM(prhs[794])==1 && mxGetN(prhs[794])==1) ) { 
      mexErrMsgTxt("Input 794 must be a noncomplex scalar double.");
    } 
    mexinput794_temp = mxGetPr(prhs[794]); 
    double mexinput794 = *mexinput794_temp; 

    double *mexinput795_temp = NULL; 
    if( !mxIsDouble(prhs[795]) || mxIsComplex(prhs[795]) || !(mxGetM(prhs[795])==1 && mxGetN(prhs[795])==1) ) { 
      mexErrMsgTxt("Input 795 must be a noncomplex scalar double.");
    } 
    mexinput795_temp = mxGetPr(prhs[795]); 
    double mexinput795 = *mexinput795_temp; 

    double *mexinput796_temp = NULL; 
    if( !mxIsDouble(prhs[796]) || mxIsComplex(prhs[796]) || !(mxGetM(prhs[796])==1 && mxGetN(prhs[796])==1) ) { 
      mexErrMsgTxt("Input 796 must be a noncomplex scalar double.");
    } 
    mexinput796_temp = mxGetPr(prhs[796]); 
    double mexinput796 = *mexinput796_temp; 

    double *mexinput797_temp = NULL; 
    if( !mxIsDouble(prhs[797]) || mxIsComplex(prhs[797]) || !(mxGetM(prhs[797])==1 && mxGetN(prhs[797])==1) ) { 
      mexErrMsgTxt("Input 797 must be a noncomplex scalar double.");
    } 
    mexinput797_temp = mxGetPr(prhs[797]); 
    double mexinput797 = *mexinput797_temp; 

    double *mexinput798_temp = NULL; 
    if( !mxIsDouble(prhs[798]) || mxIsComplex(prhs[798]) || !(mxGetM(prhs[798])==1 && mxGetN(prhs[798])==1) ) { 
      mexErrMsgTxt("Input 798 must be a noncomplex scalar double.");
    } 
    mexinput798_temp = mxGetPr(prhs[798]); 
    double mexinput798 = *mexinput798_temp; 

    double *mexinput799_temp = NULL; 
    if( !mxIsDouble(prhs[799]) || mxIsComplex(prhs[799]) || !(mxGetM(prhs[799])==1 && mxGetN(prhs[799])==1) ) { 
      mexErrMsgTxt("Input 799 must be a noncomplex scalar double.");
    } 
    mexinput799_temp = mxGetPr(prhs[799]); 
    double mexinput799 = *mexinput799_temp; 

    double *mexinput800_temp = NULL; 
    if( !mxIsDouble(prhs[800]) || mxIsComplex(prhs[800]) || !(mxGetM(prhs[800])==1 && mxGetN(prhs[800])==1) ) { 
      mexErrMsgTxt("Input 800 must be a noncomplex scalar double.");
    } 
    mexinput800_temp = mxGetPr(prhs[800]); 
    double mexinput800 = *mexinput800_temp; 

    double *mexinput801_temp = NULL; 
    if( !mxIsDouble(prhs[801]) || mxIsComplex(prhs[801]) || !(mxGetM(prhs[801])==1 && mxGetN(prhs[801])==1) ) { 
      mexErrMsgTxt("Input 801 must be a noncomplex scalar double.");
    } 
    mexinput801_temp = mxGetPr(prhs[801]); 
    double mexinput801 = *mexinput801_temp; 

    double *mexinput802_temp = NULL; 
    if( !mxIsDouble(prhs[802]) || mxIsComplex(prhs[802]) || !(mxGetM(prhs[802])==1 && mxGetN(prhs[802])==1) ) { 
      mexErrMsgTxt("Input 802 must be a noncomplex scalar double.");
    } 
    mexinput802_temp = mxGetPr(prhs[802]); 
    double mexinput802 = *mexinput802_temp; 

    double *mexinput803_temp = NULL; 
    if( !mxIsDouble(prhs[803]) || mxIsComplex(prhs[803]) || !(mxGetM(prhs[803])==1 && mxGetN(prhs[803])==1) ) { 
      mexErrMsgTxt("Input 803 must be a noncomplex scalar double.");
    } 
    mexinput803_temp = mxGetPr(prhs[803]); 
    double mexinput803 = *mexinput803_temp; 

    double *mexinput804_temp = NULL; 
    if( !mxIsDouble(prhs[804]) || mxIsComplex(prhs[804]) || !(mxGetM(prhs[804])==1 && mxGetN(prhs[804])==1) ) { 
      mexErrMsgTxt("Input 804 must be a noncomplex scalar double.");
    } 
    mexinput804_temp = mxGetPr(prhs[804]); 
    double mexinput804 = *mexinput804_temp; 

    double *mexinput805_temp = NULL; 
    if( !mxIsDouble(prhs[805]) || mxIsComplex(prhs[805]) || !(mxGetM(prhs[805])==1 && mxGetN(prhs[805])==1) ) { 
      mexErrMsgTxt("Input 805 must be a noncomplex scalar double.");
    } 
    mexinput805_temp = mxGetPr(prhs[805]); 
    double mexinput805 = *mexinput805_temp; 

    double *mexinput806_temp = NULL; 
    if( !mxIsDouble(prhs[806]) || mxIsComplex(prhs[806]) || !(mxGetM(prhs[806])==1 && mxGetN(prhs[806])==1) ) { 
      mexErrMsgTxt("Input 806 must be a noncomplex scalar double.");
    } 
    mexinput806_temp = mxGetPr(prhs[806]); 
    double mexinput806 = *mexinput806_temp; 

    double *mexinput807_temp = NULL; 
    if( !mxIsDouble(prhs[807]) || mxIsComplex(prhs[807]) || !(mxGetM(prhs[807])==1 && mxGetN(prhs[807])==1) ) { 
      mexErrMsgTxt("Input 807 must be a noncomplex scalar double.");
    } 
    mexinput807_temp = mxGetPr(prhs[807]); 
    double mexinput807 = *mexinput807_temp; 

    double *mexinput808_temp = NULL; 
    if( !mxIsDouble(prhs[808]) || mxIsComplex(prhs[808]) || !(mxGetM(prhs[808])==1 && mxGetN(prhs[808])==1) ) { 
      mexErrMsgTxt("Input 808 must be a noncomplex scalar double.");
    } 
    mexinput808_temp = mxGetPr(prhs[808]); 
    double mexinput808 = *mexinput808_temp; 

    double *mexinput809_temp = NULL; 
    if( !mxIsDouble(prhs[809]) || mxIsComplex(prhs[809]) || !(mxGetM(prhs[809])==1 && mxGetN(prhs[809])==1) ) { 
      mexErrMsgTxt("Input 809 must be a noncomplex scalar double.");
    } 
    mexinput809_temp = mxGetPr(prhs[809]); 
    double mexinput809 = *mexinput809_temp; 

    double *mexinput810_temp = NULL; 
    if( !mxIsDouble(prhs[810]) || mxIsComplex(prhs[810]) || !(mxGetM(prhs[810])==1 && mxGetN(prhs[810])==1) ) { 
      mexErrMsgTxt("Input 810 must be a noncomplex scalar double.");
    } 
    mexinput810_temp = mxGetPr(prhs[810]); 
    double mexinput810 = *mexinput810_temp; 

    double *mexinput811_temp = NULL; 
    if( !mxIsDouble(prhs[811]) || mxIsComplex(prhs[811]) || !(mxGetM(prhs[811])==1 && mxGetN(prhs[811])==1) ) { 
      mexErrMsgTxt("Input 811 must be a noncomplex scalar double.");
    } 
    mexinput811_temp = mxGetPr(prhs[811]); 
    double mexinput811 = *mexinput811_temp; 

    double *mexinput812_temp = NULL; 
    if( !mxIsDouble(prhs[812]) || mxIsComplex(prhs[812]) || !(mxGetM(prhs[812])==1 && mxGetN(prhs[812])==1) ) { 
      mexErrMsgTxt("Input 812 must be a noncomplex scalar double.");
    } 
    mexinput812_temp = mxGetPr(prhs[812]); 
    double mexinput812 = *mexinput812_temp; 

    double *mexinput813_temp = NULL; 
    if( !mxIsDouble(prhs[813]) || mxIsComplex(prhs[813]) || !(mxGetM(prhs[813])==1 && mxGetN(prhs[813])==1) ) { 
      mexErrMsgTxt("Input 813 must be a noncomplex scalar double.");
    } 
    mexinput813_temp = mxGetPr(prhs[813]); 
    double mexinput813 = *mexinput813_temp; 

    double *mexinput814_temp = NULL; 
    if( !mxIsDouble(prhs[814]) || mxIsComplex(prhs[814]) || !(mxGetM(prhs[814])==1 && mxGetN(prhs[814])==1) ) { 
      mexErrMsgTxt("Input 814 must be a noncomplex scalar double.");
    } 
    mexinput814_temp = mxGetPr(prhs[814]); 
    double mexinput814 = *mexinput814_temp; 

    double *mexinput815_temp = NULL; 
    if( !mxIsDouble(prhs[815]) || mxIsComplex(prhs[815]) || !(mxGetM(prhs[815])==1 && mxGetN(prhs[815])==1) ) { 
      mexErrMsgTxt("Input 815 must be a noncomplex scalar double.");
    } 
    mexinput815_temp = mxGetPr(prhs[815]); 
    double mexinput815 = *mexinput815_temp; 

    double *mexinput816_temp = NULL; 
    if( !mxIsDouble(prhs[816]) || mxIsComplex(prhs[816]) || !(mxGetM(prhs[816])==1 && mxGetN(prhs[816])==1) ) { 
      mexErrMsgTxt("Input 816 must be a noncomplex scalar double.");
    } 
    mexinput816_temp = mxGetPr(prhs[816]); 
    double mexinput816 = *mexinput816_temp; 

    double *mexinput817_temp = NULL; 
    if( !mxIsDouble(prhs[817]) || mxIsComplex(prhs[817]) || !(mxGetM(prhs[817])==1 && mxGetN(prhs[817])==1) ) { 
      mexErrMsgTxt("Input 817 must be a noncomplex scalar double.");
    } 
    mexinput817_temp = mxGetPr(prhs[817]); 
    double mexinput817 = *mexinput817_temp; 

    double *mexinput818_temp = NULL; 
    if( !mxIsDouble(prhs[818]) || mxIsComplex(prhs[818]) || !(mxGetM(prhs[818])==1 && mxGetN(prhs[818])==1) ) { 
      mexErrMsgTxt("Input 818 must be a noncomplex scalar double.");
    } 
    mexinput818_temp = mxGetPr(prhs[818]); 
    double mexinput818 = *mexinput818_temp; 

    double *mexinput819_temp = NULL; 
    if( !mxIsDouble(prhs[819]) || mxIsComplex(prhs[819]) || !(mxGetM(prhs[819])==1 && mxGetN(prhs[819])==1) ) { 
      mexErrMsgTxt("Input 819 must be a noncomplex scalar double.");
    } 
    mexinput819_temp = mxGetPr(prhs[819]); 
    double mexinput819 = *mexinput819_temp; 

    double *mexinput820_temp = NULL; 
    if( !mxIsDouble(prhs[820]) || mxIsComplex(prhs[820]) || !(mxGetM(prhs[820])==1 && mxGetN(prhs[820])==1) ) { 
      mexErrMsgTxt("Input 820 must be a noncomplex scalar double.");
    } 
    mexinput820_temp = mxGetPr(prhs[820]); 
    double mexinput820 = *mexinput820_temp; 

    double *mexinput821_temp = NULL; 
    if( !mxIsDouble(prhs[821]) || mxIsComplex(prhs[821]) || !(mxGetM(prhs[821])==1 && mxGetN(prhs[821])==1) ) { 
      mexErrMsgTxt("Input 821 must be a noncomplex scalar double.");
    } 
    mexinput821_temp = mxGetPr(prhs[821]); 
    double mexinput821 = *mexinput821_temp; 

    double *mexinput822_temp = NULL; 
    if( !mxIsDouble(prhs[822]) || mxIsComplex(prhs[822]) || !(mxGetM(prhs[822])==1 && mxGetN(prhs[822])==1) ) { 
      mexErrMsgTxt("Input 822 must be a noncomplex scalar double.");
    } 
    mexinput822_temp = mxGetPr(prhs[822]); 
    double mexinput822 = *mexinput822_temp; 

    double *mexinput823_temp = NULL; 
    if( !mxIsDouble(prhs[823]) || mxIsComplex(prhs[823]) || !(mxGetM(prhs[823])==1 && mxGetN(prhs[823])==1) ) { 
      mexErrMsgTxt("Input 823 must be a noncomplex scalar double.");
    } 
    mexinput823_temp = mxGetPr(prhs[823]); 
    double mexinput823 = *mexinput823_temp; 

    double *mexinput824_temp = NULL; 
    if( !mxIsDouble(prhs[824]) || mxIsComplex(prhs[824]) || !(mxGetM(prhs[824])==1 && mxGetN(prhs[824])==1) ) { 
      mexErrMsgTxt("Input 824 must be a noncomplex scalar double.");
    } 
    mexinput824_temp = mxGetPr(prhs[824]); 
    double mexinput824 = *mexinput824_temp; 

    double *mexinput825_temp = NULL; 
    if( !mxIsDouble(prhs[825]) || mxIsComplex(prhs[825]) || !(mxGetM(prhs[825])==1 && mxGetN(prhs[825])==1) ) { 
      mexErrMsgTxt("Input 825 must be a noncomplex scalar double.");
    } 
    mexinput825_temp = mxGetPr(prhs[825]); 
    double mexinput825 = *mexinput825_temp; 

    double *mexinput826_temp = NULL; 
    if( !mxIsDouble(prhs[826]) || mxIsComplex(prhs[826]) || !(mxGetM(prhs[826])==1 && mxGetN(prhs[826])==1) ) { 
      mexErrMsgTxt("Input 826 must be a noncomplex scalar double.");
    } 
    mexinput826_temp = mxGetPr(prhs[826]); 
    double mexinput826 = *mexinput826_temp; 

    double *mexinput827_temp = NULL; 
    if( !mxIsDouble(prhs[827]) || mxIsComplex(prhs[827]) || !(mxGetM(prhs[827])==1 && mxGetN(prhs[827])==1) ) { 
      mexErrMsgTxt("Input 827 must be a noncomplex scalar double.");
    } 
    mexinput827_temp = mxGetPr(prhs[827]); 
    double mexinput827 = *mexinput827_temp; 

    double *mexinput828_temp = NULL; 
    if( !mxIsDouble(prhs[828]) || mxIsComplex(prhs[828]) || !(mxGetM(prhs[828])==1 && mxGetN(prhs[828])==1) ) { 
      mexErrMsgTxt("Input 828 must be a noncomplex scalar double.");
    } 
    mexinput828_temp = mxGetPr(prhs[828]); 
    double mexinput828 = *mexinput828_temp; 

    double *mexinput829_temp = NULL; 
    if( !mxIsDouble(prhs[829]) || mxIsComplex(prhs[829]) || !(mxGetM(prhs[829])==1 && mxGetN(prhs[829])==1) ) { 
      mexErrMsgTxt("Input 829 must be a noncomplex scalar double.");
    } 
    mexinput829_temp = mxGetPr(prhs[829]); 
    double mexinput829 = *mexinput829_temp; 

    double *mexinput830_temp = NULL; 
    if( !mxIsDouble(prhs[830]) || mxIsComplex(prhs[830]) || !(mxGetM(prhs[830])==1 && mxGetN(prhs[830])==1) ) { 
      mexErrMsgTxt("Input 830 must be a noncomplex scalar double.");
    } 
    mexinput830_temp = mxGetPr(prhs[830]); 
    double mexinput830 = *mexinput830_temp; 

    double *mexinput831_temp = NULL; 
    if( !mxIsDouble(prhs[831]) || mxIsComplex(prhs[831]) || !(mxGetM(prhs[831])==1 && mxGetN(prhs[831])==1) ) { 
      mexErrMsgTxt("Input 831 must be a noncomplex scalar double.");
    } 
    mexinput831_temp = mxGetPr(prhs[831]); 
    double mexinput831 = *mexinput831_temp; 

    double *mexinput832_temp = NULL; 
    if( !mxIsDouble(prhs[832]) || mxIsComplex(prhs[832]) || !(mxGetM(prhs[832])==1 && mxGetN(prhs[832])==1) ) { 
      mexErrMsgTxt("Input 832 must be a noncomplex scalar double.");
    } 
    mexinput832_temp = mxGetPr(prhs[832]); 
    double mexinput832 = *mexinput832_temp; 

    double *mexinput833_temp = NULL; 
    if( !mxIsDouble(prhs[833]) || mxIsComplex(prhs[833]) || !(mxGetM(prhs[833])==1 && mxGetN(prhs[833])==1) ) { 
      mexErrMsgTxt("Input 833 must be a noncomplex scalar double.");
    } 
    mexinput833_temp = mxGetPr(prhs[833]); 
    double mexinput833 = *mexinput833_temp; 

    double *mexinput834_temp = NULL; 
    if( !mxIsDouble(prhs[834]) || mxIsComplex(prhs[834]) || !(mxGetM(prhs[834])==1 && mxGetN(prhs[834])==1) ) { 
      mexErrMsgTxt("Input 834 must be a noncomplex scalar double.");
    } 
    mexinput834_temp = mxGetPr(prhs[834]); 
    double mexinput834 = *mexinput834_temp; 

    double *mexinput835_temp = NULL; 
    if( !mxIsDouble(prhs[835]) || mxIsComplex(prhs[835]) || !(mxGetM(prhs[835])==1 && mxGetN(prhs[835])==1) ) { 
      mexErrMsgTxt("Input 835 must be a noncomplex scalar double.");
    } 
    mexinput835_temp = mxGetPr(prhs[835]); 
    double mexinput835 = *mexinput835_temp; 

    double *mexinput836_temp = NULL; 
    if( !mxIsDouble(prhs[836]) || mxIsComplex(prhs[836]) || !(mxGetM(prhs[836])==1 && mxGetN(prhs[836])==1) ) { 
      mexErrMsgTxt("Input 836 must be a noncomplex scalar double.");
    } 
    mexinput836_temp = mxGetPr(prhs[836]); 
    double mexinput836 = *mexinput836_temp; 

    double *mexinput837_temp = NULL; 
    if( !mxIsDouble(prhs[837]) || mxIsComplex(prhs[837]) || !(mxGetM(prhs[837])==1 && mxGetN(prhs[837])==1) ) { 
      mexErrMsgTxt("Input 837 must be a noncomplex scalar double.");
    } 
    mexinput837_temp = mxGetPr(prhs[837]); 
    double mexinput837 = *mexinput837_temp; 

    double *mexinput838_temp = NULL; 
    if( !mxIsDouble(prhs[838]) || mxIsComplex(prhs[838]) || !(mxGetM(prhs[838])==1 && mxGetN(prhs[838])==1) ) { 
      mexErrMsgTxt("Input 838 must be a noncomplex scalar double.");
    } 
    mexinput838_temp = mxGetPr(prhs[838]); 
    double mexinput838 = *mexinput838_temp; 

    double *mexinput839_temp = NULL; 
    if( !mxIsDouble(prhs[839]) || mxIsComplex(prhs[839]) || !(mxGetM(prhs[839])==1 && mxGetN(prhs[839])==1) ) { 
      mexErrMsgTxt("Input 839 must be a noncomplex scalar double.");
    } 
    mexinput839_temp = mxGetPr(prhs[839]); 
    double mexinput839 = *mexinput839_temp; 

    double *mexinput840_temp = NULL; 
    if( !mxIsDouble(prhs[840]) || mxIsComplex(prhs[840]) || !(mxGetM(prhs[840])==1 && mxGetN(prhs[840])==1) ) { 
      mexErrMsgTxt("Input 840 must be a noncomplex scalar double.");
    } 
    mexinput840_temp = mxGetPr(prhs[840]); 
    double mexinput840 = *mexinput840_temp; 

    double *mexinput841_temp = NULL; 
    if( !mxIsDouble(prhs[841]) || mxIsComplex(prhs[841]) || !(mxGetM(prhs[841])==1 && mxGetN(prhs[841])==1) ) { 
      mexErrMsgTxt("Input 841 must be a noncomplex scalar double.");
    } 
    mexinput841_temp = mxGetPr(prhs[841]); 
    double mexinput841 = *mexinput841_temp; 

    double *mexinput842_temp = NULL; 
    if( !mxIsDouble(prhs[842]) || mxIsComplex(prhs[842]) || !(mxGetM(prhs[842])==1 && mxGetN(prhs[842])==1) ) { 
      mexErrMsgTxt("Input 842 must be a noncomplex scalar double.");
    } 
    mexinput842_temp = mxGetPr(prhs[842]); 
    double mexinput842 = *mexinput842_temp; 

    double *mexinput843_temp = NULL; 
    if( !mxIsDouble(prhs[843]) || mxIsComplex(prhs[843]) || !(mxGetM(prhs[843])==1 && mxGetN(prhs[843])==1) ) { 
      mexErrMsgTxt("Input 843 must be a noncomplex scalar double.");
    } 
    mexinput843_temp = mxGetPr(prhs[843]); 
    double mexinput843 = *mexinput843_temp; 

    double *mexinput844_temp = NULL; 
    if( !mxIsDouble(prhs[844]) || mxIsComplex(prhs[844]) || !(mxGetM(prhs[844])==1 && mxGetN(prhs[844])==1) ) { 
      mexErrMsgTxt("Input 844 must be a noncomplex scalar double.");
    } 
    mexinput844_temp = mxGetPr(prhs[844]); 
    double mexinput844 = *mexinput844_temp; 

    double *mexinput845_temp = NULL; 
    if( !mxIsDouble(prhs[845]) || mxIsComplex(prhs[845]) || !(mxGetM(prhs[845])==1 && mxGetN(prhs[845])==1) ) { 
      mexErrMsgTxt("Input 845 must be a noncomplex scalar double.");
    } 
    mexinput845_temp = mxGetPr(prhs[845]); 
    double mexinput845 = *mexinput845_temp; 

    double *mexinput846_temp = NULL; 
    if( !mxIsDouble(prhs[846]) || mxIsComplex(prhs[846]) || !(mxGetM(prhs[846])==1 && mxGetN(prhs[846])==1) ) { 
      mexErrMsgTxt("Input 846 must be a noncomplex scalar double.");
    } 
    mexinput846_temp = mxGetPr(prhs[846]); 
    double mexinput846 = *mexinput846_temp; 

    double *mexinput847_temp = NULL; 
    if( !mxIsDouble(prhs[847]) || mxIsComplex(prhs[847]) || !(mxGetM(prhs[847])==1 && mxGetN(prhs[847])==1) ) { 
      mexErrMsgTxt("Input 847 must be a noncomplex scalar double.");
    } 
    mexinput847_temp = mxGetPr(prhs[847]); 
    double mexinput847 = *mexinput847_temp; 

    double *mexinput848_temp = NULL; 
    if( !mxIsDouble(prhs[848]) || mxIsComplex(prhs[848]) || !(mxGetM(prhs[848])==1 && mxGetN(prhs[848])==1) ) { 
      mexErrMsgTxt("Input 848 must be a noncomplex scalar double.");
    } 
    mexinput848_temp = mxGetPr(prhs[848]); 
    double mexinput848 = *mexinput848_temp; 

    double *mexinput849_temp = NULL; 
    if( !mxIsDouble(prhs[849]) || mxIsComplex(prhs[849]) || !(mxGetM(prhs[849])==1 && mxGetN(prhs[849])==1) ) { 
      mexErrMsgTxt("Input 849 must be a noncomplex scalar double.");
    } 
    mexinput849_temp = mxGetPr(prhs[849]); 
    double mexinput849 = *mexinput849_temp; 

    double *mexinput850_temp = NULL; 
    if( !mxIsDouble(prhs[850]) || mxIsComplex(prhs[850]) || !(mxGetM(prhs[850])==1 && mxGetN(prhs[850])==1) ) { 
      mexErrMsgTxt("Input 850 must be a noncomplex scalar double.");
    } 
    mexinput850_temp = mxGetPr(prhs[850]); 
    double mexinput850 = *mexinput850_temp; 

    double *mexinput851_temp = NULL; 
    if( !mxIsDouble(prhs[851]) || mxIsComplex(prhs[851]) || !(mxGetM(prhs[851])==1 && mxGetN(prhs[851])==1) ) { 
      mexErrMsgTxt("Input 851 must be a noncomplex scalar double.");
    } 
    mexinput851_temp = mxGetPr(prhs[851]); 
    double mexinput851 = *mexinput851_temp; 

    double *mexinput852_temp = NULL; 
    if( !mxIsDouble(prhs[852]) || mxIsComplex(prhs[852]) || !(mxGetM(prhs[852])==1 && mxGetN(prhs[852])==1) ) { 
      mexErrMsgTxt("Input 852 must be a noncomplex scalar double.");
    } 
    mexinput852_temp = mxGetPr(prhs[852]); 
    double mexinput852 = *mexinput852_temp; 

    double *mexinput853_temp = NULL; 
    if( !mxIsDouble(prhs[853]) || mxIsComplex(prhs[853]) || !(mxGetM(prhs[853])==1 && mxGetN(prhs[853])==1) ) { 
      mexErrMsgTxt("Input 853 must be a noncomplex scalar double.");
    } 
    mexinput853_temp = mxGetPr(prhs[853]); 
    double mexinput853 = *mexinput853_temp; 

    double *mexinput854_temp = NULL; 
    if( !mxIsDouble(prhs[854]) || mxIsComplex(prhs[854]) || !(mxGetM(prhs[854])==1 && mxGetN(prhs[854])==1) ) { 
      mexErrMsgTxt("Input 854 must be a noncomplex scalar double.");
    } 
    mexinput854_temp = mxGetPr(prhs[854]); 
    double mexinput854 = *mexinput854_temp; 

    double *mexinput855_temp = NULL; 
    if( !mxIsDouble(prhs[855]) || mxIsComplex(prhs[855]) || !(mxGetM(prhs[855])==1 && mxGetN(prhs[855])==1) ) { 
      mexErrMsgTxt("Input 855 must be a noncomplex scalar double.");
    } 
    mexinput855_temp = mxGetPr(prhs[855]); 
    double mexinput855 = *mexinput855_temp; 

    double *mexinput856_temp = NULL; 
    if( !mxIsDouble(prhs[856]) || mxIsComplex(prhs[856]) || !(mxGetM(prhs[856])==1 && mxGetN(prhs[856])==1) ) { 
      mexErrMsgTxt("Input 856 must be a noncomplex scalar double.");
    } 
    mexinput856_temp = mxGetPr(prhs[856]); 
    double mexinput856 = *mexinput856_temp; 

    double *mexinput857_temp = NULL; 
    if( !mxIsDouble(prhs[857]) || mxIsComplex(prhs[857]) || !(mxGetM(prhs[857])==1 && mxGetN(prhs[857])==1) ) { 
      mexErrMsgTxt("Input 857 must be a noncomplex scalar double.");
    } 
    mexinput857_temp = mxGetPr(prhs[857]); 
    double mexinput857 = *mexinput857_temp; 

    double *mexinput858_temp = NULL; 
    if( !mxIsDouble(prhs[858]) || mxIsComplex(prhs[858]) || !(mxGetM(prhs[858])==1 && mxGetN(prhs[858])==1) ) { 
      mexErrMsgTxt("Input 858 must be a noncomplex scalar double.");
    } 
    mexinput858_temp = mxGetPr(prhs[858]); 
    double mexinput858 = *mexinput858_temp; 

    double *mexinput859_temp = NULL; 
    if( !mxIsDouble(prhs[859]) || mxIsComplex(prhs[859]) || !(mxGetM(prhs[859])==1 && mxGetN(prhs[859])==1) ) { 
      mexErrMsgTxt("Input 859 must be a noncomplex scalar double.");
    } 
    mexinput859_temp = mxGetPr(prhs[859]); 
    double mexinput859 = *mexinput859_temp; 

    double *mexinput860_temp = NULL; 
    if( !mxIsDouble(prhs[860]) || mxIsComplex(prhs[860]) || !(mxGetM(prhs[860])==1 && mxGetN(prhs[860])==1) ) { 
      mexErrMsgTxt("Input 860 must be a noncomplex scalar double.");
    } 
    mexinput860_temp = mxGetPr(prhs[860]); 
    double mexinput860 = *mexinput860_temp; 

    double *mexinput861_temp = NULL; 
    if( !mxIsDouble(prhs[861]) || mxIsComplex(prhs[861]) || !(mxGetM(prhs[861])==1 && mxGetN(prhs[861])==1) ) { 
      mexErrMsgTxt("Input 861 must be a noncomplex scalar double.");
    } 
    mexinput861_temp = mxGetPr(prhs[861]); 
    double mexinput861 = *mexinput861_temp; 

    double *mexinput862_temp = NULL; 
    if( !mxIsDouble(prhs[862]) || mxIsComplex(prhs[862]) || !(mxGetM(prhs[862])==1 && mxGetN(prhs[862])==1) ) { 
      mexErrMsgTxt("Input 862 must be a noncomplex scalar double.");
    } 
    mexinput862_temp = mxGetPr(prhs[862]); 
    double mexinput862 = *mexinput862_temp; 

    double *mexinput863_temp = NULL; 
    if( !mxIsDouble(prhs[863]) || mxIsComplex(prhs[863]) || !(mxGetM(prhs[863])==1 && mxGetN(prhs[863])==1) ) { 
      mexErrMsgTxt("Input 863 must be a noncomplex scalar double.");
    } 
    mexinput863_temp = mxGetPr(prhs[863]); 
    double mexinput863 = *mexinput863_temp; 

    double *mexinput864_temp = NULL; 
    if( !mxIsDouble(prhs[864]) || mxIsComplex(prhs[864]) || !(mxGetM(prhs[864])==1 && mxGetN(prhs[864])==1) ) { 
      mexErrMsgTxt("Input 864 must be a noncomplex scalar double.");
    } 
    mexinput864_temp = mxGetPr(prhs[864]); 
    double mexinput864 = *mexinput864_temp; 

    double *mexinput865_temp = NULL; 
    if( !mxIsDouble(prhs[865]) || mxIsComplex(prhs[865]) || !(mxGetM(prhs[865])==1 && mxGetN(prhs[865])==1) ) { 
      mexErrMsgTxt("Input 865 must be a noncomplex scalar double.");
    } 
    mexinput865_temp = mxGetPr(prhs[865]); 
    double mexinput865 = *mexinput865_temp; 

    double *mexinput866_temp = NULL; 
    if( !mxIsDouble(prhs[866]) || mxIsComplex(prhs[866]) || !(mxGetM(prhs[866])==1 && mxGetN(prhs[866])==1) ) { 
      mexErrMsgTxt("Input 866 must be a noncomplex scalar double.");
    } 
    mexinput866_temp = mxGetPr(prhs[866]); 
    double mexinput866 = *mexinput866_temp; 

    double *mexinput867_temp = NULL; 
    if( !mxIsDouble(prhs[867]) || mxIsComplex(prhs[867]) || !(mxGetM(prhs[867])==1 && mxGetN(prhs[867])==1) ) { 
      mexErrMsgTxt("Input 867 must be a noncomplex scalar double.");
    } 
    mexinput867_temp = mxGetPr(prhs[867]); 
    double mexinput867 = *mexinput867_temp; 

    double *mexinput868_temp = NULL; 
    if( !mxIsDouble(prhs[868]) || mxIsComplex(prhs[868]) || !(mxGetM(prhs[868])==1 && mxGetN(prhs[868])==1) ) { 
      mexErrMsgTxt("Input 868 must be a noncomplex scalar double.");
    } 
    mexinput868_temp = mxGetPr(prhs[868]); 
    double mexinput868 = *mexinput868_temp; 

    double *mexinput869_temp = NULL; 
    if( !mxIsDouble(prhs[869]) || mxIsComplex(prhs[869]) || !(mxGetM(prhs[869])==1 && mxGetN(prhs[869])==1) ) { 
      mexErrMsgTxt("Input 869 must be a noncomplex scalar double.");
    } 
    mexinput869_temp = mxGetPr(prhs[869]); 
    double mexinput869 = *mexinput869_temp; 

    double *mexinput870_temp = NULL; 
    if( !mxIsDouble(prhs[870]) || mxIsComplex(prhs[870]) || !(mxGetM(prhs[870])==1 && mxGetN(prhs[870])==1) ) { 
      mexErrMsgTxt("Input 870 must be a noncomplex scalar double.");
    } 
    mexinput870_temp = mxGetPr(prhs[870]); 
    double mexinput870 = *mexinput870_temp; 

    double *mexinput871_temp = NULL; 
    if( !mxIsDouble(prhs[871]) || mxIsComplex(prhs[871]) || !(mxGetM(prhs[871])==1 && mxGetN(prhs[871])==1) ) { 
      mexErrMsgTxt("Input 871 must be a noncomplex scalar double.");
    } 
    mexinput871_temp = mxGetPr(prhs[871]); 
    double mexinput871 = *mexinput871_temp; 

    double *mexinput872_temp = NULL; 
    if( !mxIsDouble(prhs[872]) || mxIsComplex(prhs[872]) || !(mxGetM(prhs[872])==1 && mxGetN(prhs[872])==1) ) { 
      mexErrMsgTxt("Input 872 must be a noncomplex scalar double.");
    } 
    mexinput872_temp = mxGetPr(prhs[872]); 
    double mexinput872 = *mexinput872_temp; 

    double *mexinput873_temp = NULL; 
    if( !mxIsDouble(prhs[873]) || mxIsComplex(prhs[873]) || !(mxGetM(prhs[873])==1 && mxGetN(prhs[873])==1) ) { 
      mexErrMsgTxt("Input 873 must be a noncomplex scalar double.");
    } 
    mexinput873_temp = mxGetPr(prhs[873]); 
    double mexinput873 = *mexinput873_temp; 

    double *mexinput874_temp = NULL; 
    if( !mxIsDouble(prhs[874]) || mxIsComplex(prhs[874]) || !(mxGetM(prhs[874])==1 && mxGetN(prhs[874])==1) ) { 
      mexErrMsgTxt("Input 874 must be a noncomplex scalar double.");
    } 
    mexinput874_temp = mxGetPr(prhs[874]); 
    double mexinput874 = *mexinput874_temp; 

    double *mexinput875_temp = NULL; 
    if( !mxIsDouble(prhs[875]) || mxIsComplex(prhs[875]) || !(mxGetM(prhs[875])==1 && mxGetN(prhs[875])==1) ) { 
      mexErrMsgTxt("Input 875 must be a noncomplex scalar double.");
    } 
    mexinput875_temp = mxGetPr(prhs[875]); 
    double mexinput875 = *mexinput875_temp; 

    double *mexinput876_temp = NULL; 
    if( !mxIsDouble(prhs[876]) || mxIsComplex(prhs[876]) || !(mxGetM(prhs[876])==1 && mxGetN(prhs[876])==1) ) { 
      mexErrMsgTxt("Input 876 must be a noncomplex scalar double.");
    } 
    mexinput876_temp = mxGetPr(prhs[876]); 
    double mexinput876 = *mexinput876_temp; 

    double *mexinput877_temp = NULL; 
    if( !mxIsDouble(prhs[877]) || mxIsComplex(prhs[877]) || !(mxGetM(prhs[877])==1 && mxGetN(prhs[877])==1) ) { 
      mexErrMsgTxt("Input 877 must be a noncomplex scalar double.");
    } 
    mexinput877_temp = mxGetPr(prhs[877]); 
    double mexinput877 = *mexinput877_temp; 

    double *mexinput878_temp = NULL; 
    if( !mxIsDouble(prhs[878]) || mxIsComplex(prhs[878]) || !(mxGetM(prhs[878])==1 && mxGetN(prhs[878])==1) ) { 
      mexErrMsgTxt("Input 878 must be a noncomplex scalar double.");
    } 
    mexinput878_temp = mxGetPr(prhs[878]); 
    double mexinput878 = *mexinput878_temp; 

    double *mexinput879_temp = NULL; 
    if( !mxIsDouble(prhs[879]) || mxIsComplex(prhs[879]) || !(mxGetM(prhs[879])==1 && mxGetN(prhs[879])==1) ) { 
      mexErrMsgTxt("Input 879 must be a noncomplex scalar double.");
    } 
    mexinput879_temp = mxGetPr(prhs[879]); 
    double mexinput879 = *mexinput879_temp; 

    double *mexinput880_temp = NULL; 
    if( !mxIsDouble(prhs[880]) || mxIsComplex(prhs[880]) || !(mxGetM(prhs[880])==1 && mxGetN(prhs[880])==1) ) { 
      mexErrMsgTxt("Input 880 must be a noncomplex scalar double.");
    } 
    mexinput880_temp = mxGetPr(prhs[880]); 
    double mexinput880 = *mexinput880_temp; 

    double *mexinput881_temp = NULL; 
    if( !mxIsDouble(prhs[881]) || mxIsComplex(prhs[881]) || !(mxGetM(prhs[881])==1 && mxGetN(prhs[881])==1) ) { 
      mexErrMsgTxt("Input 881 must be a noncomplex scalar double.");
    } 
    mexinput881_temp = mxGetPr(prhs[881]); 
    double mexinput881 = *mexinput881_temp; 

    double *mexinput882_temp = NULL; 
    if( !mxIsDouble(prhs[882]) || mxIsComplex(prhs[882]) || !(mxGetM(prhs[882])==1 && mxGetN(prhs[882])==1) ) { 
      mexErrMsgTxt("Input 882 must be a noncomplex scalar double.");
    } 
    mexinput882_temp = mxGetPr(prhs[882]); 
    double mexinput882 = *mexinput882_temp; 

    double *mexinput883_temp = NULL; 
    if( !mxIsDouble(prhs[883]) || mxIsComplex(prhs[883]) || !(mxGetM(prhs[883])==1 && mxGetN(prhs[883])==1) ) { 
      mexErrMsgTxt("Input 883 must be a noncomplex scalar double.");
    } 
    mexinput883_temp = mxGetPr(prhs[883]); 
    double mexinput883 = *mexinput883_temp; 

    double *mexinput884_temp = NULL; 
    if( !mxIsDouble(prhs[884]) || mxIsComplex(prhs[884]) || !(mxGetM(prhs[884])==1 && mxGetN(prhs[884])==1) ) { 
      mexErrMsgTxt("Input 884 must be a noncomplex scalar double.");
    } 
    mexinput884_temp = mxGetPr(prhs[884]); 
    double mexinput884 = *mexinput884_temp; 

    double *mexinput885_temp = NULL; 
    if( !mxIsDouble(prhs[885]) || mxIsComplex(prhs[885]) || !(mxGetM(prhs[885])==1 && mxGetN(prhs[885])==1) ) { 
      mexErrMsgTxt("Input 885 must be a noncomplex scalar double.");
    } 
    mexinput885_temp = mxGetPr(prhs[885]); 
    double mexinput885 = *mexinput885_temp; 

    double *mexinput886_temp = NULL; 
    if( !mxIsDouble(prhs[886]) || mxIsComplex(prhs[886]) || !(mxGetM(prhs[886])==1 && mxGetN(prhs[886])==1) ) { 
      mexErrMsgTxt("Input 886 must be a noncomplex scalar double.");
    } 
    mexinput886_temp = mxGetPr(prhs[886]); 
    double mexinput886 = *mexinput886_temp; 

    double *mexinput887_temp = NULL; 
    if( !mxIsDouble(prhs[887]) || mxIsComplex(prhs[887]) || !(mxGetM(prhs[887])==1 && mxGetN(prhs[887])==1) ) { 
      mexErrMsgTxt("Input 887 must be a noncomplex scalar double.");
    } 
    mexinput887_temp = mxGetPr(prhs[887]); 
    double mexinput887 = *mexinput887_temp; 

    double *mexinput888_temp = NULL; 
    if( !mxIsDouble(prhs[888]) || mxIsComplex(prhs[888]) || !(mxGetM(prhs[888])==1 && mxGetN(prhs[888])==1) ) { 
      mexErrMsgTxt("Input 888 must be a noncomplex scalar double.");
    } 
    mexinput888_temp = mxGetPr(prhs[888]); 
    double mexinput888 = *mexinput888_temp; 

    double *mexinput889_temp = NULL; 
    if( !mxIsDouble(prhs[889]) || mxIsComplex(prhs[889]) || !(mxGetM(prhs[889])==1 && mxGetN(prhs[889])==1) ) { 
      mexErrMsgTxt("Input 889 must be a noncomplex scalar double.");
    } 
    mexinput889_temp = mxGetPr(prhs[889]); 
    double mexinput889 = *mexinput889_temp; 

    double *mexinput890_temp = NULL; 
    if( !mxIsDouble(prhs[890]) || mxIsComplex(prhs[890]) || !(mxGetM(prhs[890])==1 && mxGetN(prhs[890])==1) ) { 
      mexErrMsgTxt("Input 890 must be a noncomplex scalar double.");
    } 
    mexinput890_temp = mxGetPr(prhs[890]); 
    double mexinput890 = *mexinput890_temp; 

    double *mexinput891_temp = NULL; 
    if( !mxIsDouble(prhs[891]) || mxIsComplex(prhs[891]) || !(mxGetM(prhs[891])==1 && mxGetN(prhs[891])==1) ) { 
      mexErrMsgTxt("Input 891 must be a noncomplex scalar double.");
    } 
    mexinput891_temp = mxGetPr(prhs[891]); 
    double mexinput891 = *mexinput891_temp; 

    double *mexinput892_temp = NULL; 
    if( !mxIsDouble(prhs[892]) || mxIsComplex(prhs[892]) || !(mxGetM(prhs[892])==1 && mxGetN(prhs[892])==1) ) { 
      mexErrMsgTxt("Input 892 must be a noncomplex scalar double.");
    } 
    mexinput892_temp = mxGetPr(prhs[892]); 
    double mexinput892 = *mexinput892_temp; 

    double *mexinput893_temp = NULL; 
    if( !mxIsDouble(prhs[893]) || mxIsComplex(prhs[893]) || !(mxGetM(prhs[893])==1 && mxGetN(prhs[893])==1) ) { 
      mexErrMsgTxt("Input 893 must be a noncomplex scalar double.");
    } 
    mexinput893_temp = mxGetPr(prhs[893]); 
    double mexinput893 = *mexinput893_temp; 

    double *mexinput894_temp = NULL; 
    if( !mxIsDouble(prhs[894]) || mxIsComplex(prhs[894]) || !(mxGetM(prhs[894])==1 && mxGetN(prhs[894])==1) ) { 
      mexErrMsgTxt("Input 894 must be a noncomplex scalar double.");
    } 
    mexinput894_temp = mxGetPr(prhs[894]); 
    double mexinput894 = *mexinput894_temp; 

    double *mexinput895_temp = NULL; 
    if( !mxIsDouble(prhs[895]) || mxIsComplex(prhs[895]) || !(mxGetM(prhs[895])==1 && mxGetN(prhs[895])==1) ) { 
      mexErrMsgTxt("Input 895 must be a noncomplex scalar double.");
    } 
    mexinput895_temp = mxGetPr(prhs[895]); 
    double mexinput895 = *mexinput895_temp; 

    double *mexinput896_temp = NULL; 
    if( !mxIsDouble(prhs[896]) || mxIsComplex(prhs[896]) || !(mxGetM(prhs[896])==1 && mxGetN(prhs[896])==1) ) { 
      mexErrMsgTxt("Input 896 must be a noncomplex scalar double.");
    } 
    mexinput896_temp = mxGetPr(prhs[896]); 
    double mexinput896 = *mexinput896_temp; 

    double *mexinput897_temp = NULL; 
    if( !mxIsDouble(prhs[897]) || mxIsComplex(prhs[897]) || !(mxGetM(prhs[897])==1 && mxGetN(prhs[897])==1) ) { 
      mexErrMsgTxt("Input 897 must be a noncomplex scalar double.");
    } 
    mexinput897_temp = mxGetPr(prhs[897]); 
    double mexinput897 = *mexinput897_temp; 

    double *mexinput898_temp = NULL; 
    if( !mxIsDouble(prhs[898]) || mxIsComplex(prhs[898]) || !(mxGetM(prhs[898])==1 && mxGetN(prhs[898])==1) ) { 
      mexErrMsgTxt("Input 898 must be a noncomplex scalar double.");
    } 
    mexinput898_temp = mxGetPr(prhs[898]); 
    double mexinput898 = *mexinput898_temp; 

    double *mexinput899_temp = NULL; 
    if( !mxIsDouble(prhs[899]) || mxIsComplex(prhs[899]) || !(mxGetM(prhs[899])==1 && mxGetN(prhs[899])==1) ) { 
      mexErrMsgTxt("Input 899 must be a noncomplex scalar double.");
    } 
    mexinput899_temp = mxGetPr(prhs[899]); 
    double mexinput899 = *mexinput899_temp; 

    double *mexinput900_temp = NULL; 
    if( !mxIsDouble(prhs[900]) || mxIsComplex(prhs[900]) || !(mxGetM(prhs[900])==1 && mxGetN(prhs[900])==1) ) { 
      mexErrMsgTxt("Input 900 must be a noncomplex scalar double.");
    } 
    mexinput900_temp = mxGetPr(prhs[900]); 
    double mexinput900 = *mexinput900_temp; 

    double *mexinput901_temp = NULL; 
    if( !mxIsDouble(prhs[901]) || mxIsComplex(prhs[901]) || !(mxGetM(prhs[901])==1 && mxGetN(prhs[901])==1) ) { 
      mexErrMsgTxt("Input 901 must be a noncomplex scalar double.");
    } 
    mexinput901_temp = mxGetPr(prhs[901]); 
    double mexinput901 = *mexinput901_temp; 

    double *mexinput902_temp = NULL; 
    if( !mxIsDouble(prhs[902]) || mxIsComplex(prhs[902]) || !(mxGetM(prhs[902])==1 && mxGetN(prhs[902])==1) ) { 
      mexErrMsgTxt("Input 902 must be a noncomplex scalar double.");
    } 
    mexinput902_temp = mxGetPr(prhs[902]); 
    double mexinput902 = *mexinput902_temp; 

    double *mexinput903_temp = NULL; 
    if( !mxIsDouble(prhs[903]) || mxIsComplex(prhs[903]) || !(mxGetM(prhs[903])==1 && mxGetN(prhs[903])==1) ) { 
      mexErrMsgTxt("Input 903 must be a noncomplex scalar double.");
    } 
    mexinput903_temp = mxGetPr(prhs[903]); 
    double mexinput903 = *mexinput903_temp; 

    double *mexinput904_temp = NULL; 
    if( !mxIsDouble(prhs[904]) || mxIsComplex(prhs[904]) || !(mxGetM(prhs[904])==1 && mxGetN(prhs[904])==1) ) { 
      mexErrMsgTxt("Input 904 must be a noncomplex scalar double.");
    } 
    mexinput904_temp = mxGetPr(prhs[904]); 
    double mexinput904 = *mexinput904_temp; 

    double *mexinput905_temp = NULL; 
    if( !mxIsDouble(prhs[905]) || mxIsComplex(prhs[905]) || !(mxGetM(prhs[905])==1 && mxGetN(prhs[905])==1) ) { 
      mexErrMsgTxt("Input 905 must be a noncomplex scalar double.");
    } 
    mexinput905_temp = mxGetPr(prhs[905]); 
    double mexinput905 = *mexinput905_temp; 

    double *mexinput906_temp = NULL; 
    if( !mxIsDouble(prhs[906]) || mxIsComplex(prhs[906]) || !(mxGetM(prhs[906])==1 && mxGetN(prhs[906])==1) ) { 
      mexErrMsgTxt("Input 906 must be a noncomplex scalar double.");
    } 
    mexinput906_temp = mxGetPr(prhs[906]); 
    double mexinput906 = *mexinput906_temp; 

    double *mexinput907_temp = NULL; 
    if( !mxIsDouble(prhs[907]) || mxIsComplex(prhs[907]) || !(mxGetM(prhs[907])==1 && mxGetN(prhs[907])==1) ) { 
      mexErrMsgTxt("Input 907 must be a noncomplex scalar double.");
    } 
    mexinput907_temp = mxGetPr(prhs[907]); 
    double mexinput907 = *mexinput907_temp; 

    double *mexinput908_temp = NULL; 
    if( !mxIsDouble(prhs[908]) || mxIsComplex(prhs[908]) || !(mxGetM(prhs[908])==1 && mxGetN(prhs[908])==1) ) { 
      mexErrMsgTxt("Input 908 must be a noncomplex scalar double.");
    } 
    mexinput908_temp = mxGetPr(prhs[908]); 
    double mexinput908 = *mexinput908_temp; 

    double *mexinput909_temp = NULL; 
    if( !mxIsDouble(prhs[909]) || mxIsComplex(prhs[909]) || !(mxGetM(prhs[909])==1 && mxGetN(prhs[909])==1) ) { 
      mexErrMsgTxt("Input 909 must be a noncomplex scalar double.");
    } 
    mexinput909_temp = mxGetPr(prhs[909]); 
    double mexinput909 = *mexinput909_temp; 

    double *mexinput910_temp = NULL; 
    if( !mxIsDouble(prhs[910]) || mxIsComplex(prhs[910]) || !(mxGetM(prhs[910])==1 && mxGetN(prhs[910])==1) ) { 
      mexErrMsgTxt("Input 910 must be a noncomplex scalar double.");
    } 
    mexinput910_temp = mxGetPr(prhs[910]); 
    double mexinput910 = *mexinput910_temp; 

    double *mexinput911_temp = NULL; 
    if( !mxIsDouble(prhs[911]) || mxIsComplex(prhs[911]) || !(mxGetM(prhs[911])==1 && mxGetN(prhs[911])==1) ) { 
      mexErrMsgTxt("Input 911 must be a noncomplex scalar double.");
    } 
    mexinput911_temp = mxGetPr(prhs[911]); 
    double mexinput911 = *mexinput911_temp; 

    double *mexinput912_temp = NULL; 
    if( !mxIsDouble(prhs[912]) || mxIsComplex(prhs[912]) || !(mxGetM(prhs[912])==1 && mxGetN(prhs[912])==1) ) { 
      mexErrMsgTxt("Input 912 must be a noncomplex scalar double.");
    } 
    mexinput912_temp = mxGetPr(prhs[912]); 
    double mexinput912 = *mexinput912_temp; 

    double *mexinput913_temp = NULL; 
    if( !mxIsDouble(prhs[913]) || mxIsComplex(prhs[913]) || !(mxGetM(prhs[913])==1 && mxGetN(prhs[913])==1) ) { 
      mexErrMsgTxt("Input 913 must be a noncomplex scalar double.");
    } 
    mexinput913_temp = mxGetPr(prhs[913]); 
    double mexinput913 = *mexinput913_temp; 

    double *mexinput914_temp = NULL; 
    if( !mxIsDouble(prhs[914]) || mxIsComplex(prhs[914]) || !(mxGetM(prhs[914])==1 && mxGetN(prhs[914])==1) ) { 
      mexErrMsgTxt("Input 914 must be a noncomplex scalar double.");
    } 
    mexinput914_temp = mxGetPr(prhs[914]); 
    double mexinput914 = *mexinput914_temp; 

    double *mexinput915_temp = NULL; 
    if( !mxIsDouble(prhs[915]) || mxIsComplex(prhs[915]) || !(mxGetM(prhs[915])==1 && mxGetN(prhs[915])==1) ) { 
      mexErrMsgTxt("Input 915 must be a noncomplex scalar double.");
    } 
    mexinput915_temp = mxGetPr(prhs[915]); 
    double mexinput915 = *mexinput915_temp; 

    double *mexinput916_temp = NULL; 
    if( !mxIsDouble(prhs[916]) || mxIsComplex(prhs[916]) || !(mxGetM(prhs[916])==1 && mxGetN(prhs[916])==1) ) { 
      mexErrMsgTxt("Input 916 must be a noncomplex scalar double.");
    } 
    mexinput916_temp = mxGetPr(prhs[916]); 
    double mexinput916 = *mexinput916_temp; 

    double *mexinput917_temp = NULL; 
    if( !mxIsDouble(prhs[917]) || mxIsComplex(prhs[917]) || !(mxGetM(prhs[917])==1 && mxGetN(prhs[917])==1) ) { 
      mexErrMsgTxt("Input 917 must be a noncomplex scalar double.");
    } 
    mexinput917_temp = mxGetPr(prhs[917]); 
    double mexinput917 = *mexinput917_temp; 

    double *mexinput918_temp = NULL; 
    if( !mxIsDouble(prhs[918]) || mxIsComplex(prhs[918]) || !(mxGetM(prhs[918])==1 && mxGetN(prhs[918])==1) ) { 
      mexErrMsgTxt("Input 918 must be a noncomplex scalar double.");
    } 
    mexinput918_temp = mxGetPr(prhs[918]); 
    double mexinput918 = *mexinput918_temp; 

    double *mexinput919_temp = NULL; 
    if( !mxIsDouble(prhs[919]) || mxIsComplex(prhs[919]) || !(mxGetM(prhs[919])==1 && mxGetN(prhs[919])==1) ) { 
      mexErrMsgTxt("Input 919 must be a noncomplex scalar double.");
    } 
    mexinput919_temp = mxGetPr(prhs[919]); 
    double mexinput919 = *mexinput919_temp; 

    double *mexinput920_temp = NULL; 
    if( !mxIsDouble(prhs[920]) || mxIsComplex(prhs[920]) || !(mxGetM(prhs[920])==1 && mxGetN(prhs[920])==1) ) { 
      mexErrMsgTxt("Input 920 must be a noncomplex scalar double.");
    } 
    mexinput920_temp = mxGetPr(prhs[920]); 
    double mexinput920 = *mexinput920_temp; 

    double *mexinput921_temp = NULL; 
    if( !mxIsDouble(prhs[921]) || mxIsComplex(prhs[921]) || !(mxGetM(prhs[921])==1 && mxGetN(prhs[921])==1) ) { 
      mexErrMsgTxt("Input 921 must be a noncomplex scalar double.");
    } 
    mexinput921_temp = mxGetPr(prhs[921]); 
    double mexinput921 = *mexinput921_temp; 

    double *mexinput922_temp = NULL; 
    if( !mxIsDouble(prhs[922]) || mxIsComplex(prhs[922]) || !(mxGetM(prhs[922])==1 && mxGetN(prhs[922])==1) ) { 
      mexErrMsgTxt("Input 922 must be a noncomplex scalar double.");
    } 
    mexinput922_temp = mxGetPr(prhs[922]); 
    double mexinput922 = *mexinput922_temp; 

    double *mexinput923_temp = NULL; 
    if( !mxIsDouble(prhs[923]) || mxIsComplex(prhs[923]) || !(mxGetM(prhs[923])==1 && mxGetN(prhs[923])==1) ) { 
      mexErrMsgTxt("Input 923 must be a noncomplex scalar double.");
    } 
    mexinput923_temp = mxGetPr(prhs[923]); 
    double mexinput923 = *mexinput923_temp; 

    double *mexinput924_temp = NULL; 
    if( !mxIsDouble(prhs[924]) || mxIsComplex(prhs[924]) || !(mxGetM(prhs[924])==1 && mxGetN(prhs[924])==1) ) { 
      mexErrMsgTxt("Input 924 must be a noncomplex scalar double.");
    } 
    mexinput924_temp = mxGetPr(prhs[924]); 
    double mexinput924 = *mexinput924_temp; 

    double *mexinput925_temp = NULL; 
    if( !mxIsDouble(prhs[925]) || mxIsComplex(prhs[925]) || !(mxGetM(prhs[925])==1 && mxGetN(prhs[925])==1) ) { 
      mexErrMsgTxt("Input 925 must be a noncomplex scalar double.");
    } 
    mexinput925_temp = mxGetPr(prhs[925]); 
    double mexinput925 = *mexinput925_temp; 

    double *mexinput926_temp = NULL; 
    if( !mxIsDouble(prhs[926]) || mxIsComplex(prhs[926]) || !(mxGetM(prhs[926])==1 && mxGetN(prhs[926])==1) ) { 
      mexErrMsgTxt("Input 926 must be a noncomplex scalar double.");
    } 
    mexinput926_temp = mxGetPr(prhs[926]); 
    double mexinput926 = *mexinput926_temp; 

    double *mexinput927_temp = NULL; 
    if( !mxIsDouble(prhs[927]) || mxIsComplex(prhs[927]) || !(mxGetM(prhs[927])==1 && mxGetN(prhs[927])==1) ) { 
      mexErrMsgTxt("Input 927 must be a noncomplex scalar double.");
    } 
    mexinput927_temp = mxGetPr(prhs[927]); 
    double mexinput927 = *mexinput927_temp; 

    double *mexinput928_temp = NULL; 
    if( !mxIsDouble(prhs[928]) || mxIsComplex(prhs[928]) || !(mxGetM(prhs[928])==1 && mxGetN(prhs[928])==1) ) { 
      mexErrMsgTxt("Input 928 must be a noncomplex scalar double.");
    } 
    mexinput928_temp = mxGetPr(prhs[928]); 
    double mexinput928 = *mexinput928_temp; 

    double *mexinput929_temp = NULL; 
    if( !mxIsDouble(prhs[929]) || mxIsComplex(prhs[929]) || !(mxGetM(prhs[929])==1 && mxGetN(prhs[929])==1) ) { 
      mexErrMsgTxt("Input 929 must be a noncomplex scalar double.");
    } 
    mexinput929_temp = mxGetPr(prhs[929]); 
    double mexinput929 = *mexinput929_temp; 

    double *mexinput930_temp = NULL; 
    if( !mxIsDouble(prhs[930]) || mxIsComplex(prhs[930]) || !(mxGetM(prhs[930])==1 && mxGetN(prhs[930])==1) ) { 
      mexErrMsgTxt("Input 930 must be a noncomplex scalar double.");
    } 
    mexinput930_temp = mxGetPr(prhs[930]); 
    double mexinput930 = *mexinput930_temp; 

    double *mexinput931_temp = NULL; 
    if( !mxIsDouble(prhs[931]) || mxIsComplex(prhs[931]) || !(mxGetM(prhs[931])==1 && mxGetN(prhs[931])==1) ) { 
      mexErrMsgTxt("Input 931 must be a noncomplex scalar double.");
    } 
    mexinput931_temp = mxGetPr(prhs[931]); 
    double mexinput931 = *mexinput931_temp; 

    double *mexinput932_temp = NULL; 
    if( !mxIsDouble(prhs[932]) || mxIsComplex(prhs[932]) || !(mxGetM(prhs[932])==1 && mxGetN(prhs[932])==1) ) { 
      mexErrMsgTxt("Input 932 must be a noncomplex scalar double.");
    } 
    mexinput932_temp = mxGetPr(prhs[932]); 
    double mexinput932 = *mexinput932_temp; 

    double *mexinput933_temp = NULL; 
    if( !mxIsDouble(prhs[933]) || mxIsComplex(prhs[933]) || !(mxGetM(prhs[933])==1 && mxGetN(prhs[933])==1) ) { 
      mexErrMsgTxt("Input 933 must be a noncomplex scalar double.");
    } 
    mexinput933_temp = mxGetPr(prhs[933]); 
    double mexinput933 = *mexinput933_temp; 

    double *mexinput934_temp = NULL; 
    if( !mxIsDouble(prhs[934]) || mxIsComplex(prhs[934]) || !(mxGetM(prhs[934])==1 && mxGetN(prhs[934])==1) ) { 
      mexErrMsgTxt("Input 934 must be a noncomplex scalar double.");
    } 
    mexinput934_temp = mxGetPr(prhs[934]); 
    double mexinput934 = *mexinput934_temp; 

    double *mexinput935_temp = NULL; 
    if( !mxIsDouble(prhs[935]) || mxIsComplex(prhs[935]) || !(mxGetM(prhs[935])==1 && mxGetN(prhs[935])==1) ) { 
      mexErrMsgTxt("Input 935 must be a noncomplex scalar double.");
    } 
    mexinput935_temp = mxGetPr(prhs[935]); 
    double mexinput935 = *mexinput935_temp; 

    double *mexinput936_temp = NULL; 
    if( !mxIsDouble(prhs[936]) || mxIsComplex(prhs[936]) || !(mxGetM(prhs[936])==1 && mxGetN(prhs[936])==1) ) { 
      mexErrMsgTxt("Input 936 must be a noncomplex scalar double.");
    } 
    mexinput936_temp = mxGetPr(prhs[936]); 
    double mexinput936 = *mexinput936_temp; 

    double *mexinput937_temp = NULL; 
    if( !mxIsDouble(prhs[937]) || mxIsComplex(prhs[937]) || !(mxGetM(prhs[937])==1 && mxGetN(prhs[937])==1) ) { 
      mexErrMsgTxt("Input 937 must be a noncomplex scalar double.");
    } 
    mexinput937_temp = mxGetPr(prhs[937]); 
    double mexinput937 = *mexinput937_temp; 

    double *mexinput938_temp = NULL; 
    if( !mxIsDouble(prhs[938]) || mxIsComplex(prhs[938]) || !(mxGetM(prhs[938])==1 && mxGetN(prhs[938])==1) ) { 
      mexErrMsgTxt("Input 938 must be a noncomplex scalar double.");
    } 
    mexinput938_temp = mxGetPr(prhs[938]); 
    double mexinput938 = *mexinput938_temp; 

    double *mexinput939_temp = NULL; 
    if( !mxIsDouble(prhs[939]) || mxIsComplex(prhs[939]) || !(mxGetM(prhs[939])==1 && mxGetN(prhs[939])==1) ) { 
      mexErrMsgTxt("Input 939 must be a noncomplex scalar double.");
    } 
    mexinput939_temp = mxGetPr(prhs[939]); 
    double mexinput939 = *mexinput939_temp; 

    double *mexinput940_temp = NULL; 
    if( !mxIsDouble(prhs[940]) || mxIsComplex(prhs[940]) || !(mxGetM(prhs[940])==1 && mxGetN(prhs[940])==1) ) { 
      mexErrMsgTxt("Input 940 must be a noncomplex scalar double.");
    } 
    mexinput940_temp = mxGetPr(prhs[940]); 
    double mexinput940 = *mexinput940_temp; 

    double *mexinput941_temp = NULL; 
    if( !mxIsDouble(prhs[941]) || mxIsComplex(prhs[941]) || !(mxGetM(prhs[941])==1 && mxGetN(prhs[941])==1) ) { 
      mexErrMsgTxt("Input 941 must be a noncomplex scalar double.");
    } 
    mexinput941_temp = mxGetPr(prhs[941]); 
    double mexinput941 = *mexinput941_temp; 

    double *mexinput942_temp = NULL; 
    if( !mxIsDouble(prhs[942]) || mxIsComplex(prhs[942]) || !(mxGetM(prhs[942])==1 && mxGetN(prhs[942])==1) ) { 
      mexErrMsgTxt("Input 942 must be a noncomplex scalar double.");
    } 
    mexinput942_temp = mxGetPr(prhs[942]); 
    double mexinput942 = *mexinput942_temp; 

    double *mexinput943_temp = NULL; 
    if( !mxIsDouble(prhs[943]) || mxIsComplex(prhs[943]) || !(mxGetM(prhs[943])==1 && mxGetN(prhs[943])==1) ) { 
      mexErrMsgTxt("Input 943 must be a noncomplex scalar double.");
    } 
    mexinput943_temp = mxGetPr(prhs[943]); 
    double mexinput943 = *mexinput943_temp; 

    double *mexinput944_temp = NULL; 
    if( !mxIsDouble(prhs[944]) || mxIsComplex(prhs[944]) || !(mxGetM(prhs[944])==1 && mxGetN(prhs[944])==1) ) { 
      mexErrMsgTxt("Input 944 must be a noncomplex scalar double.");
    } 
    mexinput944_temp = mxGetPr(prhs[944]); 
    double mexinput944 = *mexinput944_temp; 

    double *mexinput945_temp = NULL; 
    if( !mxIsDouble(prhs[945]) || mxIsComplex(prhs[945]) || !(mxGetM(prhs[945])==1 && mxGetN(prhs[945])==1) ) { 
      mexErrMsgTxt("Input 945 must be a noncomplex scalar double.");
    } 
    mexinput945_temp = mxGetPr(prhs[945]); 
    double mexinput945 = *mexinput945_temp; 

    double *mexinput946_temp = NULL; 
    if( !mxIsDouble(prhs[946]) || mxIsComplex(prhs[946]) || !(mxGetM(prhs[946])==1 && mxGetN(prhs[946])==1) ) { 
      mexErrMsgTxt("Input 946 must be a noncomplex scalar double.");
    } 
    mexinput946_temp = mxGetPr(prhs[946]); 
    double mexinput946 = *mexinput946_temp; 

    double *mexinput947_temp = NULL; 
    if( !mxIsDouble(prhs[947]) || mxIsComplex(prhs[947]) || !(mxGetM(prhs[947])==1 && mxGetN(prhs[947])==1) ) { 
      mexErrMsgTxt("Input 947 must be a noncomplex scalar double.");
    } 
    mexinput947_temp = mxGetPr(prhs[947]); 
    double mexinput947 = *mexinput947_temp; 

    double *mexinput948_temp = NULL; 
    if( !mxIsDouble(prhs[948]) || mxIsComplex(prhs[948]) || !(mxGetM(prhs[948])==1 && mxGetN(prhs[948])==1) ) { 
      mexErrMsgTxt("Input 948 must be a noncomplex scalar double.");
    } 
    mexinput948_temp = mxGetPr(prhs[948]); 
    double mexinput948 = *mexinput948_temp; 

    double *mexinput949_temp = NULL; 
    if( !mxIsDouble(prhs[949]) || mxIsComplex(prhs[949]) || !(mxGetM(prhs[949])==1 && mxGetN(prhs[949])==1) ) { 
      mexErrMsgTxt("Input 949 must be a noncomplex scalar double.");
    } 
    mexinput949_temp = mxGetPr(prhs[949]); 
    double mexinput949 = *mexinput949_temp; 

    double *mexinput950_temp = NULL; 
    if( !mxIsDouble(prhs[950]) || mxIsComplex(prhs[950]) || !(mxGetM(prhs[950])==1 && mxGetN(prhs[950])==1) ) { 
      mexErrMsgTxt("Input 950 must be a noncomplex scalar double.");
    } 
    mexinput950_temp = mxGetPr(prhs[950]); 
    double mexinput950 = *mexinput950_temp; 

    double *mexinput951_temp = NULL; 
    if( !mxIsDouble(prhs[951]) || mxIsComplex(prhs[951]) || !(mxGetM(prhs[951])==1 && mxGetN(prhs[951])==1) ) { 
      mexErrMsgTxt("Input 951 must be a noncomplex scalar double.");
    } 
    mexinput951_temp = mxGetPr(prhs[951]); 
    double mexinput951 = *mexinput951_temp; 

    double *mexinput952_temp = NULL; 
    if( !mxIsDouble(prhs[952]) || mxIsComplex(prhs[952]) || !(mxGetM(prhs[952])==1 && mxGetN(prhs[952])==1) ) { 
      mexErrMsgTxt("Input 952 must be a noncomplex scalar double.");
    } 
    mexinput952_temp = mxGetPr(prhs[952]); 
    double mexinput952 = *mexinput952_temp; 

    double *mexinput953_temp = NULL; 
    if( !mxIsDouble(prhs[953]) || mxIsComplex(prhs[953]) || !(mxGetM(prhs[953])==1 && mxGetN(prhs[953])==1) ) { 
      mexErrMsgTxt("Input 953 must be a noncomplex scalar double.");
    } 
    mexinput953_temp = mxGetPr(prhs[953]); 
    double mexinput953 = *mexinput953_temp; 

    double *mexinput954_temp = NULL; 
    if( !mxIsDouble(prhs[954]) || mxIsComplex(prhs[954]) || !(mxGetM(prhs[954])==1 && mxGetN(prhs[954])==1) ) { 
      mexErrMsgTxt("Input 954 must be a noncomplex scalar double.");
    } 
    mexinput954_temp = mxGetPr(prhs[954]); 
    double mexinput954 = *mexinput954_temp; 

    double *mexinput955_temp = NULL; 
    if( !mxIsDouble(prhs[955]) || mxIsComplex(prhs[955]) || !(mxGetM(prhs[955])==1 && mxGetN(prhs[955])==1) ) { 
      mexErrMsgTxt("Input 955 must be a noncomplex scalar double.");
    } 
    mexinput955_temp = mxGetPr(prhs[955]); 
    double mexinput955 = *mexinput955_temp; 

    double *mexinput956_temp = NULL; 
    if( !mxIsDouble(prhs[956]) || mxIsComplex(prhs[956]) || !(mxGetM(prhs[956])==1 && mxGetN(prhs[956])==1) ) { 
      mexErrMsgTxt("Input 956 must be a noncomplex scalar double.");
    } 
    mexinput956_temp = mxGetPr(prhs[956]); 
    double mexinput956 = *mexinput956_temp; 

    double *mexinput957_temp = NULL; 
    if( !mxIsDouble(prhs[957]) || mxIsComplex(prhs[957]) || !(mxGetM(prhs[957])==1 && mxGetN(prhs[957])==1) ) { 
      mexErrMsgTxt("Input 957 must be a noncomplex scalar double.");
    } 
    mexinput957_temp = mxGetPr(prhs[957]); 
    double mexinput957 = *mexinput957_temp; 

    double *mexinput958_temp = NULL; 
    if( !mxIsDouble(prhs[958]) || mxIsComplex(prhs[958]) || !(mxGetM(prhs[958])==1 && mxGetN(prhs[958])==1) ) { 
      mexErrMsgTxt("Input 958 must be a noncomplex scalar double.");
    } 
    mexinput958_temp = mxGetPr(prhs[958]); 
    double mexinput958 = *mexinput958_temp; 

    double *mexinput959_temp = NULL; 
    if( !mxIsDouble(prhs[959]) || mxIsComplex(prhs[959]) || !(mxGetM(prhs[959])==1 && mxGetN(prhs[959])==1) ) { 
      mexErrMsgTxt("Input 959 must be a noncomplex scalar double.");
    } 
    mexinput959_temp = mxGetPr(prhs[959]); 
    double mexinput959 = *mexinput959_temp; 

    double *mexinput960_temp = NULL; 
    if( !mxIsDouble(prhs[960]) || mxIsComplex(prhs[960]) || !(mxGetM(prhs[960])==1 && mxGetN(prhs[960])==1) ) { 
      mexErrMsgTxt("Input 960 must be a noncomplex scalar double.");
    } 
    mexinput960_temp = mxGetPr(prhs[960]); 
    double mexinput960 = *mexinput960_temp; 

    double *mexinput961_temp = NULL; 
    if( !mxIsDouble(prhs[961]) || mxIsComplex(prhs[961]) || !(mxGetM(prhs[961])==1 && mxGetN(prhs[961])==1) ) { 
      mexErrMsgTxt("Input 961 must be a noncomplex scalar double.");
    } 
    mexinput961_temp = mxGetPr(prhs[961]); 
    double mexinput961 = *mexinput961_temp; 

    double *mexinput962_temp = NULL; 
    if( !mxIsDouble(prhs[962]) || mxIsComplex(prhs[962]) || !(mxGetM(prhs[962])==1 && mxGetN(prhs[962])==1) ) { 
      mexErrMsgTxt("Input 962 must be a noncomplex scalar double.");
    } 
    mexinput962_temp = mxGetPr(prhs[962]); 
    double mexinput962 = *mexinput962_temp; 

    double *mexinput963_temp = NULL; 
    if( !mxIsDouble(prhs[963]) || mxIsComplex(prhs[963]) || !(mxGetM(prhs[963])==1 && mxGetN(prhs[963])==1) ) { 
      mexErrMsgTxt("Input 963 must be a noncomplex scalar double.");
    } 
    mexinput963_temp = mxGetPr(prhs[963]); 
    double mexinput963 = *mexinput963_temp; 

    double *mexinput964_temp = NULL; 
    if( !mxIsDouble(prhs[964]) || mxIsComplex(prhs[964]) || !(mxGetM(prhs[964])==1 && mxGetN(prhs[964])==1) ) { 
      mexErrMsgTxt("Input 964 must be a noncomplex scalar double.");
    } 
    mexinput964_temp = mxGetPr(prhs[964]); 
    double mexinput964 = *mexinput964_temp; 

    double *mexinput965_temp = NULL; 
    if( !mxIsDouble(prhs[965]) || mxIsComplex(prhs[965]) || !(mxGetM(prhs[965])==1 && mxGetN(prhs[965])==1) ) { 
      mexErrMsgTxt("Input 965 must be a noncomplex scalar double.");
    } 
    mexinput965_temp = mxGetPr(prhs[965]); 
    double mexinput965 = *mexinput965_temp; 

    double *mexinput966_temp = NULL; 
    if( !mxIsDouble(prhs[966]) || mxIsComplex(prhs[966]) || !(mxGetM(prhs[966])==1 && mxGetN(prhs[966])==1) ) { 
      mexErrMsgTxt("Input 966 must be a noncomplex scalar double.");
    } 
    mexinput966_temp = mxGetPr(prhs[966]); 
    double mexinput966 = *mexinput966_temp; 

    double *mexinput967_temp = NULL; 
    if( !mxIsDouble(prhs[967]) || mxIsComplex(prhs[967]) || !(mxGetM(prhs[967])==1 && mxGetN(prhs[967])==1) ) { 
      mexErrMsgTxt("Input 967 must be a noncomplex scalar double.");
    } 
    mexinput967_temp = mxGetPr(prhs[967]); 
    double mexinput967 = *mexinput967_temp; 

    double *mexinput968_temp = NULL; 
    if( !mxIsDouble(prhs[968]) || mxIsComplex(prhs[968]) || !(mxGetM(prhs[968])==1 && mxGetN(prhs[968])==1) ) { 
      mexErrMsgTxt("Input 968 must be a noncomplex scalar double.");
    } 
    mexinput968_temp = mxGetPr(prhs[968]); 
    double mexinput968 = *mexinput968_temp; 

    double *mexinput969_temp = NULL; 
    if( !mxIsDouble(prhs[969]) || mxIsComplex(prhs[969]) || !(mxGetM(prhs[969])==1 && mxGetN(prhs[969])==1) ) { 
      mexErrMsgTxt("Input 969 must be a noncomplex scalar double.");
    } 
    mexinput969_temp = mxGetPr(prhs[969]); 
    double mexinput969 = *mexinput969_temp; 

    double *mexinput970_temp = NULL; 
    if( !mxIsDouble(prhs[970]) || mxIsComplex(prhs[970]) || !(mxGetM(prhs[970])==1 && mxGetN(prhs[970])==1) ) { 
      mexErrMsgTxt("Input 970 must be a noncomplex scalar double.");
    } 
    mexinput970_temp = mxGetPr(prhs[970]); 
    double mexinput970 = *mexinput970_temp; 

    double *mexinput971_temp = NULL; 
    if( !mxIsDouble(prhs[971]) || mxIsComplex(prhs[971]) || !(mxGetM(prhs[971])==1 && mxGetN(prhs[971])==1) ) { 
      mexErrMsgTxt("Input 971 must be a noncomplex scalar double.");
    } 
    mexinput971_temp = mxGetPr(prhs[971]); 
    double mexinput971 = *mexinput971_temp; 

    double *mexinput972_temp = NULL; 
    if( !mxIsDouble(prhs[972]) || mxIsComplex(prhs[972]) || !(mxGetM(prhs[972])==1 && mxGetN(prhs[972])==1) ) { 
      mexErrMsgTxt("Input 972 must be a noncomplex scalar double.");
    } 
    mexinput972_temp = mxGetPr(prhs[972]); 
    double mexinput972 = *mexinput972_temp; 

    double *mexinput973_temp = NULL; 
    if( !mxIsDouble(prhs[973]) || mxIsComplex(prhs[973]) || !(mxGetM(prhs[973])==1 && mxGetN(prhs[973])==1) ) { 
      mexErrMsgTxt("Input 973 must be a noncomplex scalar double.");
    } 
    mexinput973_temp = mxGetPr(prhs[973]); 
    double mexinput973 = *mexinput973_temp; 

    double *mexinput974_temp = NULL; 
    if( !mxIsDouble(prhs[974]) || mxIsComplex(prhs[974]) || !(mxGetM(prhs[974])==1 && mxGetN(prhs[974])==1) ) { 
      mexErrMsgTxt("Input 974 must be a noncomplex scalar double.");
    } 
    mexinput974_temp = mxGetPr(prhs[974]); 
    double mexinput974 = *mexinput974_temp; 

    double *mexinput975_temp = NULL; 
    if( !mxIsDouble(prhs[975]) || mxIsComplex(prhs[975]) || !(mxGetM(prhs[975])==1 && mxGetN(prhs[975])==1) ) { 
      mexErrMsgTxt("Input 975 must be a noncomplex scalar double.");
    } 
    mexinput975_temp = mxGetPr(prhs[975]); 
    double mexinput975 = *mexinput975_temp; 

    double *mexinput976_temp = NULL; 
    if( !mxIsDouble(prhs[976]) || mxIsComplex(prhs[976]) || !(mxGetM(prhs[976])==1 && mxGetN(prhs[976])==1) ) { 
      mexErrMsgTxt("Input 976 must be a noncomplex scalar double.");
    } 
    mexinput976_temp = mxGetPr(prhs[976]); 
    double mexinput976 = *mexinput976_temp; 

    double *mexinput977_temp = NULL; 
    if( !mxIsDouble(prhs[977]) || mxIsComplex(prhs[977]) || !(mxGetM(prhs[977])==1 && mxGetN(prhs[977])==1) ) { 
      mexErrMsgTxt("Input 977 must be a noncomplex scalar double.");
    } 
    mexinput977_temp = mxGetPr(prhs[977]); 
    double mexinput977 = *mexinput977_temp; 

    double *mexinput978_temp = NULL; 
    if( !mxIsDouble(prhs[978]) || mxIsComplex(prhs[978]) || !(mxGetM(prhs[978])==1 && mxGetN(prhs[978])==1) ) { 
      mexErrMsgTxt("Input 978 must be a noncomplex scalar double.");
    } 
    mexinput978_temp = mxGetPr(prhs[978]); 
    double mexinput978 = *mexinput978_temp; 

    double *mexinput979_temp = NULL; 
    if( !mxIsDouble(prhs[979]) || mxIsComplex(prhs[979]) || !(mxGetM(prhs[979])==1 && mxGetN(prhs[979])==1) ) { 
      mexErrMsgTxt("Input 979 must be a noncomplex scalar double.");
    } 
    mexinput979_temp = mxGetPr(prhs[979]); 
    double mexinput979 = *mexinput979_temp; 

    double *mexinput980_temp = NULL; 
    if( !mxIsDouble(prhs[980]) || mxIsComplex(prhs[980]) || !(mxGetM(prhs[980])==1 && mxGetN(prhs[980])==1) ) { 
      mexErrMsgTxt("Input 980 must be a noncomplex scalar double.");
    } 
    mexinput980_temp = mxGetPr(prhs[980]); 
    double mexinput980 = *mexinput980_temp; 

    double *mexinput981_temp = NULL; 
    if( !mxIsDouble(prhs[981]) || mxIsComplex(prhs[981]) || !(mxGetM(prhs[981])==1 && mxGetN(prhs[981])==1) ) { 
      mexErrMsgTxt("Input 981 must be a noncomplex scalar double.");
    } 
    mexinput981_temp = mxGetPr(prhs[981]); 
    double mexinput981 = *mexinput981_temp; 

    double *mexinput982_temp = NULL; 
    if( !mxIsDouble(prhs[982]) || mxIsComplex(prhs[982]) || !(mxGetM(prhs[982])==1 && mxGetN(prhs[982])==1) ) { 
      mexErrMsgTxt("Input 982 must be a noncomplex scalar double.");
    } 
    mexinput982_temp = mxGetPr(prhs[982]); 
    double mexinput982 = *mexinput982_temp; 

    double *mexinput983_temp = NULL; 
    if( !mxIsDouble(prhs[983]) || mxIsComplex(prhs[983]) || !(mxGetM(prhs[983])==1 && mxGetN(prhs[983])==1) ) { 
      mexErrMsgTxt("Input 983 must be a noncomplex scalar double.");
    } 
    mexinput983_temp = mxGetPr(prhs[983]); 
    double mexinput983 = *mexinput983_temp; 

    double *mexinput984_temp = NULL; 
    if( !mxIsDouble(prhs[984]) || mxIsComplex(prhs[984]) || !(mxGetM(prhs[984])==1 && mxGetN(prhs[984])==1) ) { 
      mexErrMsgTxt("Input 984 must be a noncomplex scalar double.");
    } 
    mexinput984_temp = mxGetPr(prhs[984]); 
    double mexinput984 = *mexinput984_temp; 

    double *mexinput985_temp = NULL; 
    if( !mxIsDouble(prhs[985]) || mxIsComplex(prhs[985]) || !(mxGetM(prhs[985])==1 && mxGetN(prhs[985])==1) ) { 
      mexErrMsgTxt("Input 985 must be a noncomplex scalar double.");
    } 
    mexinput985_temp = mxGetPr(prhs[985]); 
    double mexinput985 = *mexinput985_temp; 

    double *mexinput986_temp = NULL; 
    if( !mxIsDouble(prhs[986]) || mxIsComplex(prhs[986]) || !(mxGetM(prhs[986])==1 && mxGetN(prhs[986])==1) ) { 
      mexErrMsgTxt("Input 986 must be a noncomplex scalar double.");
    } 
    mexinput986_temp = mxGetPr(prhs[986]); 
    double mexinput986 = *mexinput986_temp; 

    double *mexinput987_temp = NULL; 
    if( !mxIsDouble(prhs[987]) || mxIsComplex(prhs[987]) || !(mxGetM(prhs[987])==1 && mxGetN(prhs[987])==1) ) { 
      mexErrMsgTxt("Input 987 must be a noncomplex scalar double.");
    } 
    mexinput987_temp = mxGetPr(prhs[987]); 
    double mexinput987 = *mexinput987_temp; 

    double *mexinput988_temp = NULL; 
    if( !mxIsDouble(prhs[988]) || mxIsComplex(prhs[988]) || !(mxGetM(prhs[988])==1 && mxGetN(prhs[988])==1) ) { 
      mexErrMsgTxt("Input 988 must be a noncomplex scalar double.");
    } 
    mexinput988_temp = mxGetPr(prhs[988]); 
    double mexinput988 = *mexinput988_temp; 

    double *mexinput989_temp = NULL; 
    if( !mxIsDouble(prhs[989]) || mxIsComplex(prhs[989]) || !(mxGetM(prhs[989])==1 && mxGetN(prhs[989])==1) ) { 
      mexErrMsgTxt("Input 989 must be a noncomplex scalar double.");
    } 
    mexinput989_temp = mxGetPr(prhs[989]); 
    double mexinput989 = *mexinput989_temp; 

    double *mexinput990_temp = NULL; 
    if( !mxIsDouble(prhs[990]) || mxIsComplex(prhs[990]) || !(mxGetM(prhs[990])==1 && mxGetN(prhs[990])==1) ) { 
      mexErrMsgTxt("Input 990 must be a noncomplex scalar double.");
    } 
    mexinput990_temp = mxGetPr(prhs[990]); 
    double mexinput990 = *mexinput990_temp; 

    double *mexinput991_temp = NULL; 
    if( !mxIsDouble(prhs[991]) || mxIsComplex(prhs[991]) || !(mxGetM(prhs[991])==1 && mxGetN(prhs[991])==1) ) { 
      mexErrMsgTxt("Input 991 must be a noncomplex scalar double.");
    } 
    mexinput991_temp = mxGetPr(prhs[991]); 
    double mexinput991 = *mexinput991_temp; 

    double *mexinput992_temp = NULL; 
    if( !mxIsDouble(prhs[992]) || mxIsComplex(prhs[992]) || !(mxGetM(prhs[992])==1 && mxGetN(prhs[992])==1) ) { 
      mexErrMsgTxt("Input 992 must be a noncomplex scalar double.");
    } 
    mexinput992_temp = mxGetPr(prhs[992]); 
    double mexinput992 = *mexinput992_temp; 

    double *mexinput993_temp = NULL; 
    if( !mxIsDouble(prhs[993]) || mxIsComplex(prhs[993]) || !(mxGetM(prhs[993])==1 && mxGetN(prhs[993])==1) ) { 
      mexErrMsgTxt("Input 993 must be a noncomplex scalar double.");
    } 
    mexinput993_temp = mxGetPr(prhs[993]); 
    double mexinput993 = *mexinput993_temp; 

    double *mexinput994_temp = NULL; 
    if( !mxIsDouble(prhs[994]) || mxIsComplex(prhs[994]) || !(mxGetM(prhs[994])==1 && mxGetN(prhs[994])==1) ) { 
      mexErrMsgTxt("Input 994 must be a noncomplex scalar double.");
    } 
    mexinput994_temp = mxGetPr(prhs[994]); 
    double mexinput994 = *mexinput994_temp; 

    double *mexinput995_temp = NULL; 
    if( !mxIsDouble(prhs[995]) || mxIsComplex(prhs[995]) || !(mxGetM(prhs[995])==1 && mxGetN(prhs[995])==1) ) { 
      mexErrMsgTxt("Input 995 must be a noncomplex scalar double.");
    } 
    mexinput995_temp = mxGetPr(prhs[995]); 
    double mexinput995 = *mexinput995_temp; 

    double *mexinput996_temp = NULL; 
    if( !mxIsDouble(prhs[996]) || mxIsComplex(prhs[996]) || !(mxGetM(prhs[996])==1 && mxGetN(prhs[996])==1) ) { 
      mexErrMsgTxt("Input 996 must be a noncomplex scalar double.");
    } 
    mexinput996_temp = mxGetPr(prhs[996]); 
    double mexinput996 = *mexinput996_temp; 

    double *mexinput997_temp = NULL; 
    if( !mxIsDouble(prhs[997]) || mxIsComplex(prhs[997]) || !(mxGetM(prhs[997])==1 && mxGetN(prhs[997])==1) ) { 
      mexErrMsgTxt("Input 997 must be a noncomplex scalar double.");
    } 
    mexinput997_temp = mxGetPr(prhs[997]); 
    double mexinput997 = *mexinput997_temp; 

    double *mexinput998_temp = NULL; 
    if( !mxIsDouble(prhs[998]) || mxIsComplex(prhs[998]) || !(mxGetM(prhs[998])==1 && mxGetN(prhs[998])==1) ) { 
      mexErrMsgTxt("Input 998 must be a noncomplex scalar double.");
    } 
    mexinput998_temp = mxGetPr(prhs[998]); 
    double mexinput998 = *mexinput998_temp; 

    double *mexinput999_temp = NULL; 
    if( !mxIsDouble(prhs[999]) || mxIsComplex(prhs[999]) || !(mxGetM(prhs[999])==1 && mxGetN(prhs[999])==1) ) { 
      mexErrMsgTxt("Input 999 must be a noncomplex scalar double.");
    } 
    mexinput999_temp = mxGetPr(prhs[999]); 
    double mexinput999 = *mexinput999_temp; 

    double *mexinput1000_temp = NULL; 
    if( !mxIsDouble(prhs[1000]) || mxIsComplex(prhs[1000]) || !(mxGetM(prhs[1000])==1 && mxGetN(prhs[1000])==1) ) { 
      mexErrMsgTxt("Input 1000 must be a noncomplex scalar double.");
    } 
    mexinput1000_temp = mxGetPr(prhs[1000]); 
    double mexinput1000 = *mexinput1000_temp; 

    double *mexinput1001_temp = NULL; 
    if( !mxIsDouble(prhs[1001]) || mxIsComplex(prhs[1001]) || !(mxGetM(prhs[1001])==1 && mxGetN(prhs[1001])==1) ) { 
      mexErrMsgTxt("Input 1001 must be a noncomplex scalar double.");
    } 
    mexinput1001_temp = mxGetPr(prhs[1001]); 
    double mexinput1001 = *mexinput1001_temp; 

    double *mexinput1002_temp = NULL; 
    if( !mxIsDouble(prhs[1002]) || mxIsComplex(prhs[1002]) || !(mxGetM(prhs[1002])==1 && mxGetN(prhs[1002])==1) ) { 
      mexErrMsgTxt("Input 1002 must be a noncomplex scalar double.");
    } 
    mexinput1002_temp = mxGetPr(prhs[1002]); 
    double mexinput1002 = *mexinput1002_temp; 

    double *mexinput1003_temp = NULL; 
    if( !mxIsDouble(prhs[1003]) || mxIsComplex(prhs[1003]) || !(mxGetM(prhs[1003])==1 && mxGetN(prhs[1003])==1) ) { 
      mexErrMsgTxt("Input 1003 must be a noncomplex scalar double.");
    } 
    mexinput1003_temp = mxGetPr(prhs[1003]); 
    double mexinput1003 = *mexinput1003_temp; 

    double *mexinput1004_temp = NULL; 
    if( !mxIsDouble(prhs[1004]) || mxIsComplex(prhs[1004]) || !(mxGetM(prhs[1004])==1 && mxGetN(prhs[1004])==1) ) { 
      mexErrMsgTxt("Input 1004 must be a noncomplex scalar double.");
    } 
    mexinput1004_temp = mxGetPr(prhs[1004]); 
    double mexinput1004 = *mexinput1004_temp; 

    double *mexinput1005_temp = NULL; 
    if( !mxIsDouble(prhs[1005]) || mxIsComplex(prhs[1005]) || !(mxGetM(prhs[1005])==1 && mxGetN(prhs[1005])==1) ) { 
      mexErrMsgTxt("Input 1005 must be a noncomplex scalar double.");
    } 
    mexinput1005_temp = mxGetPr(prhs[1005]); 
    double mexinput1005 = *mexinput1005_temp; 

    double *mexinput1006_temp = NULL; 
    if( !mxIsDouble(prhs[1006]) || mxIsComplex(prhs[1006]) || !(mxGetM(prhs[1006])==1 && mxGetN(prhs[1006])==1) ) { 
      mexErrMsgTxt("Input 1006 must be a noncomplex scalar double.");
    } 
    mexinput1006_temp = mxGetPr(prhs[1006]); 
    double mexinput1006 = *mexinput1006_temp; 

    double *mexinput1007_temp = NULL; 
    if( !mxIsDouble(prhs[1007]) || mxIsComplex(prhs[1007]) || !(mxGetM(prhs[1007])==1 && mxGetN(prhs[1007])==1) ) { 
      mexErrMsgTxt("Input 1007 must be a noncomplex scalar double.");
    } 
    mexinput1007_temp = mxGetPr(prhs[1007]); 
    double mexinput1007 = *mexinput1007_temp; 

    double *mexinput1008_temp = NULL; 
    if( !mxIsDouble(prhs[1008]) || mxIsComplex(prhs[1008]) || !(mxGetM(prhs[1008])==1 && mxGetN(prhs[1008])==1) ) { 
      mexErrMsgTxt("Input 1008 must be a noncomplex scalar double.");
    } 
    mexinput1008_temp = mxGetPr(prhs[1008]); 
    double mexinput1008 = *mexinput1008_temp; 

    double *mexinput1009_temp = NULL; 
    if( !mxIsDouble(prhs[1009]) || mxIsComplex(prhs[1009]) || !(mxGetM(prhs[1009])==1 && mxGetN(prhs[1009])==1) ) { 
      mexErrMsgTxt("Input 1009 must be a noncomplex scalar double.");
    } 
    mexinput1009_temp = mxGetPr(prhs[1009]); 
    double mexinput1009 = *mexinput1009_temp; 

    double *mexinput1010_temp = NULL; 
    if( !mxIsDouble(prhs[1010]) || mxIsComplex(prhs[1010]) || !(mxGetM(prhs[1010])==1 && mxGetN(prhs[1010])==1) ) { 
      mexErrMsgTxt("Input 1010 must be a noncomplex scalar double.");
    } 
    mexinput1010_temp = mxGetPr(prhs[1010]); 
    double mexinput1010 = *mexinput1010_temp; 

    double *mexinput1011_temp = NULL; 
    if( !mxIsDouble(prhs[1011]) || mxIsComplex(prhs[1011]) || !(mxGetM(prhs[1011])==1 && mxGetN(prhs[1011])==1) ) { 
      mexErrMsgTxt("Input 1011 must be a noncomplex scalar double.");
    } 
    mexinput1011_temp = mxGetPr(prhs[1011]); 
    double mexinput1011 = *mexinput1011_temp; 

    double *mexinput1012_temp = NULL; 
    if( !mxIsDouble(prhs[1012]) || mxIsComplex(prhs[1012]) || !(mxGetM(prhs[1012])==1 && mxGetN(prhs[1012])==1) ) { 
      mexErrMsgTxt("Input 1012 must be a noncomplex scalar double.");
    } 
    mexinput1012_temp = mxGetPr(prhs[1012]); 
    double mexinput1012 = *mexinput1012_temp; 

    double *mexinput1013_temp = NULL; 
    if( !mxIsDouble(prhs[1013]) || mxIsComplex(prhs[1013]) || !(mxGetM(prhs[1013])==1 && mxGetN(prhs[1013])==1) ) { 
      mexErrMsgTxt("Input 1013 must be a noncomplex scalar double.");
    } 
    mexinput1013_temp = mxGetPr(prhs[1013]); 
    double mexinput1013 = *mexinput1013_temp; 

    double *mexinput1014_temp = NULL; 
    if( !mxIsDouble(prhs[1014]) || mxIsComplex(prhs[1014]) || !(mxGetM(prhs[1014])==1 && mxGetN(prhs[1014])==1) ) { 
      mexErrMsgTxt("Input 1014 must be a noncomplex scalar double.");
    } 
    mexinput1014_temp = mxGetPr(prhs[1014]); 
    double mexinput1014 = *mexinput1014_temp; 

    double *mexinput1015_temp = NULL; 
    if( !mxIsDouble(prhs[1015]) || mxIsComplex(prhs[1015]) || !(mxGetM(prhs[1015])==1 && mxGetN(prhs[1015])==1) ) { 
      mexErrMsgTxt("Input 1015 must be a noncomplex scalar double.");
    } 
    mexinput1015_temp = mxGetPr(prhs[1015]); 
    double mexinput1015 = *mexinput1015_temp; 

    double *mexinput1016_temp = NULL; 
    if( !mxIsDouble(prhs[1016]) || mxIsComplex(prhs[1016]) || !(mxGetM(prhs[1016])==1 && mxGetN(prhs[1016])==1) ) { 
      mexErrMsgTxt("Input 1016 must be a noncomplex scalar double.");
    } 
    mexinput1016_temp = mxGetPr(prhs[1016]); 
    double mexinput1016 = *mexinput1016_temp; 

    double *mexinput1017_temp = NULL; 
    if( !mxIsDouble(prhs[1017]) || mxIsComplex(prhs[1017]) || !(mxGetM(prhs[1017])==1 && mxGetN(prhs[1017])==1) ) { 
      mexErrMsgTxt("Input 1017 must be a noncomplex scalar double.");
    } 
    mexinput1017_temp = mxGetPr(prhs[1017]); 
    double mexinput1017 = *mexinput1017_temp; 

    double *mexinput1018_temp = NULL; 
    if( !mxIsDouble(prhs[1018]) || mxIsComplex(prhs[1018]) || !(mxGetM(prhs[1018])==1 && mxGetN(prhs[1018])==1) ) { 
      mexErrMsgTxt("Input 1018 must be a noncomplex scalar double.");
    } 
    mexinput1018_temp = mxGetPr(prhs[1018]); 
    double mexinput1018 = *mexinput1018_temp; 

    double *mexinput1019_temp = NULL; 
    if( !mxIsDouble(prhs[1019]) || mxIsComplex(prhs[1019]) || !(mxGetM(prhs[1019])==1 && mxGetN(prhs[1019])==1) ) { 
      mexErrMsgTxt("Input 1019 must be a noncomplex scalar double.");
    } 
    mexinput1019_temp = mxGetPr(prhs[1019]); 
    double mexinput1019 = *mexinput1019_temp; 

    double *mexinput1020_temp = NULL; 
    if( !mxIsDouble(prhs[1020]) || mxIsComplex(prhs[1020]) || !(mxGetM(prhs[1020])==1 && mxGetN(prhs[1020])==1) ) { 
      mexErrMsgTxt("Input 1020 must be a noncomplex scalar double.");
    } 
    mexinput1020_temp = mxGetPr(prhs[1020]); 
    double mexinput1020 = *mexinput1020_temp; 

    double *mexinput1021_temp = NULL; 
    if( !mxIsDouble(prhs[1021]) || mxIsComplex(prhs[1021]) || !(mxGetM(prhs[1021])==1 && mxGetN(prhs[1021])==1) ) { 
      mexErrMsgTxt("Input 1021 must be a noncomplex scalar double.");
    } 
    mexinput1021_temp = mxGetPr(prhs[1021]); 
    double mexinput1021 = *mexinput1021_temp; 

    double *mexinput1022_temp = NULL; 
    if( !mxIsDouble(prhs[1022]) || mxIsComplex(prhs[1022]) || !(mxGetM(prhs[1022])==1 && mxGetN(prhs[1022])==1) ) { 
      mexErrMsgTxt("Input 1022 must be a noncomplex scalar double.");
    } 
    mexinput1022_temp = mxGetPr(prhs[1022]); 
    double mexinput1022 = *mexinput1022_temp; 

    double *mexinput1023_temp = NULL; 
    if( !mxIsDouble(prhs[1023]) || mxIsComplex(prhs[1023]) || !(mxGetM(prhs[1023])==1 && mxGetN(prhs[1023])==1) ) { 
      mexErrMsgTxt("Input 1023 must be a noncomplex scalar double.");
    } 
    mexinput1023_temp = mxGetPr(prhs[1023]); 
    double mexinput1023 = *mexinput1023_temp; 

    double *mexinput1024_temp = NULL; 
    if( !mxIsDouble(prhs[1024]) || mxIsComplex(prhs[1024]) || !(mxGetM(prhs[1024])==1 && mxGetN(prhs[1024])==1) ) { 
      mexErrMsgTxt("Input 1024 must be a noncomplex scalar double.");
    } 
    mexinput1024_temp = mxGetPr(prhs[1024]); 
    double mexinput1024 = *mexinput1024_temp; 

    double *mexinput1025_temp = NULL; 
    if( !mxIsDouble(prhs[1025]) || mxIsComplex(prhs[1025]) || !(mxGetM(prhs[1025])==1 && mxGetN(prhs[1025])==1) ) { 
      mexErrMsgTxt("Input 1025 must be a noncomplex scalar double.");
    } 
    mexinput1025_temp = mxGetPr(prhs[1025]); 
    double mexinput1025 = *mexinput1025_temp; 

    double *mexinput1026_temp = NULL; 
    if( !mxIsDouble(prhs[1026]) || mxIsComplex(prhs[1026]) || !(mxGetM(prhs[1026])==1 && mxGetN(prhs[1026])==1) ) { 
      mexErrMsgTxt("Input 1026 must be a noncomplex scalar double.");
    } 
    mexinput1026_temp = mxGetPr(prhs[1026]); 
    double mexinput1026 = *mexinput1026_temp; 

    double *mexinput1027_temp = NULL; 
    if( !mxIsDouble(prhs[1027]) || mxIsComplex(prhs[1027]) || !(mxGetM(prhs[1027])==1 && mxGetN(prhs[1027])==1) ) { 
      mexErrMsgTxt("Input 1027 must be a noncomplex scalar double.");
    } 
    mexinput1027_temp = mxGetPr(prhs[1027]); 
    double mexinput1027 = *mexinput1027_temp; 

    double *mexinput1028_temp = NULL; 
    if( !mxIsDouble(prhs[1028]) || mxIsComplex(prhs[1028]) || !(mxGetM(prhs[1028])==1 && mxGetN(prhs[1028])==1) ) { 
      mexErrMsgTxt("Input 1028 must be a noncomplex scalar double.");
    } 
    mexinput1028_temp = mxGetPr(prhs[1028]); 
    double mexinput1028 = *mexinput1028_temp; 

    double *mexinput1029_temp = NULL; 
    if( !mxIsDouble(prhs[1029]) || mxIsComplex(prhs[1029]) || !(mxGetM(prhs[1029])==1 && mxGetN(prhs[1029])==1) ) { 
      mexErrMsgTxt("Input 1029 must be a noncomplex scalar double.");
    } 
    mexinput1029_temp = mxGetPr(prhs[1029]); 
    double mexinput1029 = *mexinput1029_temp; 

    double *mexinput1030_temp = NULL; 
    if( !mxIsDouble(prhs[1030]) || mxIsComplex(prhs[1030]) || !(mxGetM(prhs[1030])==1 && mxGetN(prhs[1030])==1) ) { 
      mexErrMsgTxt("Input 1030 must be a noncomplex scalar double.");
    } 
    mexinput1030_temp = mxGetPr(prhs[1030]); 
    double mexinput1030 = *mexinput1030_temp; 

    double *mexinput1031_temp = NULL; 
    if( !mxIsDouble(prhs[1031]) || mxIsComplex(prhs[1031]) || !(mxGetM(prhs[1031])==1 && mxGetN(prhs[1031])==1) ) { 
      mexErrMsgTxt("Input 1031 must be a noncomplex scalar double.");
    } 
    mexinput1031_temp = mxGetPr(prhs[1031]); 
    double mexinput1031 = *mexinput1031_temp; 

    double *mexinput1032_temp = NULL; 
    if( !mxIsDouble(prhs[1032]) || mxIsComplex(prhs[1032]) || !(mxGetM(prhs[1032])==1 && mxGetN(prhs[1032])==1) ) { 
      mexErrMsgTxt("Input 1032 must be a noncomplex scalar double.");
    } 
    mexinput1032_temp = mxGetPr(prhs[1032]); 
    double mexinput1032 = *mexinput1032_temp; 

    double *mexinput1033_temp = NULL; 
    if( !mxIsDouble(prhs[1033]) || mxIsComplex(prhs[1033]) || !(mxGetM(prhs[1033])==1 && mxGetN(prhs[1033])==1) ) { 
      mexErrMsgTxt("Input 1033 must be a noncomplex scalar double.");
    } 
    mexinput1033_temp = mxGetPr(prhs[1033]); 
    double mexinput1033 = *mexinput1033_temp; 

    double *mexinput1034_temp = NULL; 
    if( !mxIsDouble(prhs[1034]) || mxIsComplex(prhs[1034]) || !(mxGetM(prhs[1034])==1 && mxGetN(prhs[1034])==1) ) { 
      mexErrMsgTxt("Input 1034 must be a noncomplex scalar double.");
    } 
    mexinput1034_temp = mxGetPr(prhs[1034]); 
    double mexinput1034 = *mexinput1034_temp; 

    double *mexinput1035_temp = NULL; 
    if( !mxIsDouble(prhs[1035]) || mxIsComplex(prhs[1035]) || !(mxGetM(prhs[1035])==1 && mxGetN(prhs[1035])==1) ) { 
      mexErrMsgTxt("Input 1035 must be a noncomplex scalar double.");
    } 
    mexinput1035_temp = mxGetPr(prhs[1035]); 
    double mexinput1035 = *mexinput1035_temp; 

    double *mexinput1036_temp = NULL; 
    if( !mxIsDouble(prhs[1036]) || mxIsComplex(prhs[1036]) || !(mxGetM(prhs[1036])==1 && mxGetN(prhs[1036])==1) ) { 
      mexErrMsgTxt("Input 1036 must be a noncomplex scalar double.");
    } 
    mexinput1036_temp = mxGetPr(prhs[1036]); 
    double mexinput1036 = *mexinput1036_temp; 

    double *mexinput1037_temp = NULL; 
    if( !mxIsDouble(prhs[1037]) || mxIsComplex(prhs[1037]) || !(mxGetM(prhs[1037])==1 && mxGetN(prhs[1037])==1) ) { 
      mexErrMsgTxt("Input 1037 must be a noncomplex scalar double.");
    } 
    mexinput1037_temp = mxGetPr(prhs[1037]); 
    double mexinput1037 = *mexinput1037_temp; 

    double *mexinput1038_temp = NULL; 
    if( !mxIsDouble(prhs[1038]) || mxIsComplex(prhs[1038]) || !(mxGetM(prhs[1038])==1 && mxGetN(prhs[1038])==1) ) { 
      mexErrMsgTxt("Input 1038 must be a noncomplex scalar double.");
    } 
    mexinput1038_temp = mxGetPr(prhs[1038]); 
    double mexinput1038 = *mexinput1038_temp; 

    double *mexinput1039_temp = NULL; 
    if( !mxIsDouble(prhs[1039]) || mxIsComplex(prhs[1039]) || !(mxGetM(prhs[1039])==1 && mxGetN(prhs[1039])==1) ) { 
      mexErrMsgTxt("Input 1039 must be a noncomplex scalar double.");
    } 
    mexinput1039_temp = mxGetPr(prhs[1039]); 
    double mexinput1039 = *mexinput1039_temp; 

    double *mexinput1040_temp = NULL; 
    if( !mxIsDouble(prhs[1040]) || mxIsComplex(prhs[1040]) || !(mxGetM(prhs[1040])==1 && mxGetN(prhs[1040])==1) ) { 
      mexErrMsgTxt("Input 1040 must be a noncomplex scalar double.");
    } 
    mexinput1040_temp = mxGetPr(prhs[1040]); 
    double mexinput1040 = *mexinput1040_temp; 

    double *mexinput1041_temp = NULL; 
    if( !mxIsDouble(prhs[1041]) || mxIsComplex(prhs[1041]) || !(mxGetM(prhs[1041])==1 && mxGetN(prhs[1041])==1) ) { 
      mexErrMsgTxt("Input 1041 must be a noncomplex scalar double.");
    } 
    mexinput1041_temp = mxGetPr(prhs[1041]); 
    double mexinput1041 = *mexinput1041_temp; 

    double *mexinput1042_temp = NULL; 
    if( !mxIsDouble(prhs[1042]) || mxIsComplex(prhs[1042]) || !(mxGetM(prhs[1042])==1 && mxGetN(prhs[1042])==1) ) { 
      mexErrMsgTxt("Input 1042 must be a noncomplex scalar double.");
    } 
    mexinput1042_temp = mxGetPr(prhs[1042]); 
    double mexinput1042 = *mexinput1042_temp; 

    double *mexinput1043_temp = NULL; 
    if( !mxIsDouble(prhs[1043]) || mxIsComplex(prhs[1043]) || !(mxGetM(prhs[1043])==1 && mxGetN(prhs[1043])==1) ) { 
      mexErrMsgTxt("Input 1043 must be a noncomplex scalar double.");
    } 
    mexinput1043_temp = mxGetPr(prhs[1043]); 
    double mexinput1043 = *mexinput1043_temp; 

    double *mexinput1044_temp = NULL; 
    if( !mxIsDouble(prhs[1044]) || mxIsComplex(prhs[1044]) || !(mxGetM(prhs[1044])==1 && mxGetN(prhs[1044])==1) ) { 
      mexErrMsgTxt("Input 1044 must be a noncomplex scalar double.");
    } 
    mexinput1044_temp = mxGetPr(prhs[1044]); 
    double mexinput1044 = *mexinput1044_temp; 

    double *mexinput1045_temp = NULL; 
    if( !mxIsDouble(prhs[1045]) || mxIsComplex(prhs[1045]) || !(mxGetM(prhs[1045])==1 && mxGetN(prhs[1045])==1) ) { 
      mexErrMsgTxt("Input 1045 must be a noncomplex scalar double.");
    } 
    mexinput1045_temp = mxGetPr(prhs[1045]); 
    double mexinput1045 = *mexinput1045_temp; 

    double *mexinput1046_temp = NULL; 
    if( !mxIsDouble(prhs[1046]) || mxIsComplex(prhs[1046]) || !(mxGetM(prhs[1046])==1 && mxGetN(prhs[1046])==1) ) { 
      mexErrMsgTxt("Input 1046 must be a noncomplex scalar double.");
    } 
    mexinput1046_temp = mxGetPr(prhs[1046]); 
    double mexinput1046 = *mexinput1046_temp; 

    double *mexinput1047_temp = NULL; 
    if( !mxIsDouble(prhs[1047]) || mxIsComplex(prhs[1047]) || !(mxGetM(prhs[1047])==1 && mxGetN(prhs[1047])==1) ) { 
      mexErrMsgTxt("Input 1047 must be a noncomplex scalar double.");
    } 
    mexinput1047_temp = mxGetPr(prhs[1047]); 
    double mexinput1047 = *mexinput1047_temp; 

    double *mexinput1048_temp = NULL; 
    if( !mxIsDouble(prhs[1048]) || mxIsComplex(prhs[1048]) || !(mxGetM(prhs[1048])==1 && mxGetN(prhs[1048])==1) ) { 
      mexErrMsgTxt("Input 1048 must be a noncomplex scalar double.");
    } 
    mexinput1048_temp = mxGetPr(prhs[1048]); 
    double mexinput1048 = *mexinput1048_temp; 

    double *mexinput1049_temp = NULL; 
    if( !mxIsDouble(prhs[1049]) || mxIsComplex(prhs[1049]) || !(mxGetM(prhs[1049])==1 && mxGetN(prhs[1049])==1) ) { 
      mexErrMsgTxt("Input 1049 must be a noncomplex scalar double.");
    } 
    mexinput1049_temp = mxGetPr(prhs[1049]); 
    double mexinput1049 = *mexinput1049_temp; 

    double *mexinput1050_temp = NULL; 
    if( !mxIsDouble(prhs[1050]) || mxIsComplex(prhs[1050]) || !(mxGetM(prhs[1050])==1 && mxGetN(prhs[1050])==1) ) { 
      mexErrMsgTxt("Input 1050 must be a noncomplex scalar double.");
    } 
    mexinput1050_temp = mxGetPr(prhs[1050]); 
    double mexinput1050 = *mexinput1050_temp; 

    double *mexinput1051_temp = NULL; 
    if( !mxIsDouble(prhs[1051]) || mxIsComplex(prhs[1051]) || !(mxGetM(prhs[1051])==1 && mxGetN(prhs[1051])==1) ) { 
      mexErrMsgTxt("Input 1051 must be a noncomplex scalar double.");
    } 
    mexinput1051_temp = mxGetPr(prhs[1051]); 
    double mexinput1051 = *mexinput1051_temp; 

    double *mexinput1052_temp = NULL; 
    if( !mxIsDouble(prhs[1052]) || mxIsComplex(prhs[1052]) || !(mxGetM(prhs[1052])==1 && mxGetN(prhs[1052])==1) ) { 
      mexErrMsgTxt("Input 1052 must be a noncomplex scalar double.");
    } 
    mexinput1052_temp = mxGetPr(prhs[1052]); 
    double mexinput1052 = *mexinput1052_temp; 

    double *mexinput1053_temp = NULL; 
    if( !mxIsDouble(prhs[1053]) || mxIsComplex(prhs[1053]) || !(mxGetM(prhs[1053])==1 && mxGetN(prhs[1053])==1) ) { 
      mexErrMsgTxt("Input 1053 must be a noncomplex scalar double.");
    } 
    mexinput1053_temp = mxGetPr(prhs[1053]); 
    double mexinput1053 = *mexinput1053_temp; 

    double *mexinput1054_temp = NULL; 
    if( !mxIsDouble(prhs[1054]) || mxIsComplex(prhs[1054]) || !(mxGetM(prhs[1054])==1 && mxGetN(prhs[1054])==1) ) { 
      mexErrMsgTxt("Input 1054 must be a noncomplex scalar double.");
    } 
    mexinput1054_temp = mxGetPr(prhs[1054]); 
    double mexinput1054 = *mexinput1054_temp; 

    double *mexinput1055_temp = NULL; 
    if( !mxIsDouble(prhs[1055]) || mxIsComplex(prhs[1055]) || !(mxGetM(prhs[1055])==1 && mxGetN(prhs[1055])==1) ) { 
      mexErrMsgTxt("Input 1055 must be a noncomplex scalar double.");
    } 
    mexinput1055_temp = mxGetPr(prhs[1055]); 
    double mexinput1055 = *mexinput1055_temp; 

    double *mexinput1056_temp = NULL; 
    if( !mxIsDouble(prhs[1056]) || mxIsComplex(prhs[1056]) || !(mxGetM(prhs[1056])==1 && mxGetN(prhs[1056])==1) ) { 
      mexErrMsgTxt("Input 1056 must be a noncomplex scalar double.");
    } 
    mexinput1056_temp = mxGetPr(prhs[1056]); 
    double mexinput1056 = *mexinput1056_temp; 

    double *mexinput1057_temp = NULL; 
    if( !mxIsDouble(prhs[1057]) || mxIsComplex(prhs[1057]) || !(mxGetM(prhs[1057])==1 && mxGetN(prhs[1057])==1) ) { 
      mexErrMsgTxt("Input 1057 must be a noncomplex scalar double.");
    } 
    mexinput1057_temp = mxGetPr(prhs[1057]); 
    double mexinput1057 = *mexinput1057_temp; 

    double *mexinput1058_temp = NULL; 
    if( !mxIsDouble(prhs[1058]) || mxIsComplex(prhs[1058]) || !(mxGetM(prhs[1058])==1 && mxGetN(prhs[1058])==1) ) { 
      mexErrMsgTxt("Input 1058 must be a noncomplex scalar double.");
    } 
    mexinput1058_temp = mxGetPr(prhs[1058]); 
    double mexinput1058 = *mexinput1058_temp; 

    double *mexinput1059_temp = NULL; 
    if( !mxIsDouble(prhs[1059]) || mxIsComplex(prhs[1059]) || !(mxGetM(prhs[1059])==1 && mxGetN(prhs[1059])==1) ) { 
      mexErrMsgTxt("Input 1059 must be a noncomplex scalar double.");
    } 
    mexinput1059_temp = mxGetPr(prhs[1059]); 
    double mexinput1059 = *mexinput1059_temp; 

    double *mexinput1060_temp = NULL; 
    if( !mxIsDouble(prhs[1060]) || mxIsComplex(prhs[1060]) || !(mxGetM(prhs[1060])==1 && mxGetN(prhs[1060])==1) ) { 
      mexErrMsgTxt("Input 1060 must be a noncomplex scalar double.");
    } 
    mexinput1060_temp = mxGetPr(prhs[1060]); 
    double mexinput1060 = *mexinput1060_temp; 

    double *mexinput1061_temp = NULL; 
    if( !mxIsDouble(prhs[1061]) || mxIsComplex(prhs[1061]) || !(mxGetM(prhs[1061])==1 && mxGetN(prhs[1061])==1) ) { 
      mexErrMsgTxt("Input 1061 must be a noncomplex scalar double.");
    } 
    mexinput1061_temp = mxGetPr(prhs[1061]); 
    double mexinput1061 = *mexinput1061_temp; 

    double *mexinput1062_temp = NULL; 
    if( !mxIsDouble(prhs[1062]) || mxIsComplex(prhs[1062]) || !(mxGetM(prhs[1062])==1 && mxGetN(prhs[1062])==1) ) { 
      mexErrMsgTxt("Input 1062 must be a noncomplex scalar double.");
    } 
    mexinput1062_temp = mxGetPr(prhs[1062]); 
    double mexinput1062 = *mexinput1062_temp; 

    double *mexinput1063_temp = NULL; 
    if( !mxIsDouble(prhs[1063]) || mxIsComplex(prhs[1063]) || !(mxGetM(prhs[1063])==1 && mxGetN(prhs[1063])==1) ) { 
      mexErrMsgTxt("Input 1063 must be a noncomplex scalar double.");
    } 
    mexinput1063_temp = mxGetPr(prhs[1063]); 
    double mexinput1063 = *mexinput1063_temp; 

    double *mexinput1064_temp = NULL; 
    if( !mxIsDouble(prhs[1064]) || mxIsComplex(prhs[1064]) || !(mxGetM(prhs[1064])==1 && mxGetN(prhs[1064])==1) ) { 
      mexErrMsgTxt("Input 1064 must be a noncomplex scalar double.");
    } 
    mexinput1064_temp = mxGetPr(prhs[1064]); 
    double mexinput1064 = *mexinput1064_temp; 

    double *mexinput1065_temp = NULL; 
    if( !mxIsDouble(prhs[1065]) || mxIsComplex(prhs[1065]) || !(mxGetM(prhs[1065])==1 && mxGetN(prhs[1065])==1) ) { 
      mexErrMsgTxt("Input 1065 must be a noncomplex scalar double.");
    } 
    mexinput1065_temp = mxGetPr(prhs[1065]); 
    double mexinput1065 = *mexinput1065_temp; 

    double *mexinput1066_temp = NULL; 
    if( !mxIsDouble(prhs[1066]) || mxIsComplex(prhs[1066]) || !(mxGetM(prhs[1066])==1 && mxGetN(prhs[1066])==1) ) { 
      mexErrMsgTxt("Input 1066 must be a noncomplex scalar double.");
    } 
    mexinput1066_temp = mxGetPr(prhs[1066]); 
    double mexinput1066 = *mexinput1066_temp; 

    double *mexinput1067_temp = NULL; 
    if( !mxIsDouble(prhs[1067]) || mxIsComplex(prhs[1067]) || !(mxGetM(prhs[1067])==1 && mxGetN(prhs[1067])==1) ) { 
      mexErrMsgTxt("Input 1067 must be a noncomplex scalar double.");
    } 
    mexinput1067_temp = mxGetPr(prhs[1067]); 
    double mexinput1067 = *mexinput1067_temp; 

    double *mexinput1068_temp = NULL; 
    if( !mxIsDouble(prhs[1068]) || mxIsComplex(prhs[1068]) || !(mxGetM(prhs[1068])==1 && mxGetN(prhs[1068])==1) ) { 
      mexErrMsgTxt("Input 1068 must be a noncomplex scalar double.");
    } 
    mexinput1068_temp = mxGetPr(prhs[1068]); 
    double mexinput1068 = *mexinput1068_temp; 

    double *mexinput1069_temp = NULL; 
    if( !mxIsDouble(prhs[1069]) || mxIsComplex(prhs[1069]) || !(mxGetM(prhs[1069])==1 && mxGetN(prhs[1069])==1) ) { 
      mexErrMsgTxt("Input 1069 must be a noncomplex scalar double.");
    } 
    mexinput1069_temp = mxGetPr(prhs[1069]); 
    double mexinput1069 = *mexinput1069_temp; 

    double *mexinput1070_temp = NULL; 
    if( !mxIsDouble(prhs[1070]) || mxIsComplex(prhs[1070]) || !(mxGetM(prhs[1070])==1 && mxGetN(prhs[1070])==1) ) { 
      mexErrMsgTxt("Input 1070 must be a noncomplex scalar double.");
    } 
    mexinput1070_temp = mxGetPr(prhs[1070]); 
    double mexinput1070 = *mexinput1070_temp; 

    double *mexinput1071_temp = NULL; 
    if( !mxIsDouble(prhs[1071]) || mxIsComplex(prhs[1071]) || !(mxGetM(prhs[1071])==1 && mxGetN(prhs[1071])==1) ) { 
      mexErrMsgTxt("Input 1071 must be a noncomplex scalar double.");
    } 
    mexinput1071_temp = mxGetPr(prhs[1071]); 
    double mexinput1071 = *mexinput1071_temp; 

    double *mexinput1072_temp = NULL; 
    if( !mxIsDouble(prhs[1072]) || mxIsComplex(prhs[1072]) || !(mxGetM(prhs[1072])==1 && mxGetN(prhs[1072])==1) ) { 
      mexErrMsgTxt("Input 1072 must be a noncomplex scalar double.");
    } 
    mexinput1072_temp = mxGetPr(prhs[1072]); 
    double mexinput1072 = *mexinput1072_temp; 

    double *mexinput1073_temp = NULL; 
    if( !mxIsDouble(prhs[1073]) || mxIsComplex(prhs[1073]) || !(mxGetM(prhs[1073])==1 && mxGetN(prhs[1073])==1) ) { 
      mexErrMsgTxt("Input 1073 must be a noncomplex scalar double.");
    } 
    mexinput1073_temp = mxGetPr(prhs[1073]); 
    double mexinput1073 = *mexinput1073_temp; 

    double *mexinput1074_temp = NULL; 
    if( !mxIsDouble(prhs[1074]) || mxIsComplex(prhs[1074]) || !(mxGetM(prhs[1074])==1 && mxGetN(prhs[1074])==1) ) { 
      mexErrMsgTxt("Input 1074 must be a noncomplex scalar double.");
    } 
    mexinput1074_temp = mxGetPr(prhs[1074]); 
    double mexinput1074 = *mexinput1074_temp; 

    double *mexinput1075_temp = NULL; 
    if( !mxIsDouble(prhs[1075]) || mxIsComplex(prhs[1075]) || !(mxGetM(prhs[1075])==1 && mxGetN(prhs[1075])==1) ) { 
      mexErrMsgTxt("Input 1075 must be a noncomplex scalar double.");
    } 
    mexinput1075_temp = mxGetPr(prhs[1075]); 
    double mexinput1075 = *mexinput1075_temp; 

    double *mexinput1076_temp = NULL; 
    if( !mxIsDouble(prhs[1076]) || mxIsComplex(prhs[1076]) || !(mxGetM(prhs[1076])==1 && mxGetN(prhs[1076])==1) ) { 
      mexErrMsgTxt("Input 1076 must be a noncomplex scalar double.");
    } 
    mexinput1076_temp = mxGetPr(prhs[1076]); 
    double mexinput1076 = *mexinput1076_temp; 

    double *mexinput1077_temp = NULL; 
    if( !mxIsDouble(prhs[1077]) || mxIsComplex(prhs[1077]) || !(mxGetM(prhs[1077])==1 && mxGetN(prhs[1077])==1) ) { 
      mexErrMsgTxt("Input 1077 must be a noncomplex scalar double.");
    } 
    mexinput1077_temp = mxGetPr(prhs[1077]); 
    double mexinput1077 = *mexinput1077_temp; 

    double *mexinput1078_temp = NULL; 
    if( !mxIsDouble(prhs[1078]) || mxIsComplex(prhs[1078]) || !(mxGetM(prhs[1078])==1 && mxGetN(prhs[1078])==1) ) { 
      mexErrMsgTxt("Input 1078 must be a noncomplex scalar double.");
    } 
    mexinput1078_temp = mxGetPr(prhs[1078]); 
    double mexinput1078 = *mexinput1078_temp; 

    double *mexinput1079_temp = NULL; 
    if( !mxIsDouble(prhs[1079]) || mxIsComplex(prhs[1079]) || !(mxGetM(prhs[1079])==1 && mxGetN(prhs[1079])==1) ) { 
      mexErrMsgTxt("Input 1079 must be a noncomplex scalar double.");
    } 
    mexinput1079_temp = mxGetPr(prhs[1079]); 
    double mexinput1079 = *mexinput1079_temp; 

    double *mexinput1080_temp = NULL; 
    if( !mxIsDouble(prhs[1080]) || mxIsComplex(prhs[1080]) || !(mxGetM(prhs[1080])==1 && mxGetN(prhs[1080])==1) ) { 
      mexErrMsgTxt("Input 1080 must be a noncomplex scalar double.");
    } 
    mexinput1080_temp = mxGetPr(prhs[1080]); 
    double mexinput1080 = *mexinput1080_temp; 

    double *mexinput1081_temp = NULL; 
    if( !mxIsDouble(prhs[1081]) || mxIsComplex(prhs[1081]) || !(mxGetM(prhs[1081])==1 && mxGetN(prhs[1081])==1) ) { 
      mexErrMsgTxt("Input 1081 must be a noncomplex scalar double.");
    } 
    mexinput1081_temp = mxGetPr(prhs[1081]); 
    double mexinput1081 = *mexinput1081_temp; 

    double *mexinput1082_temp = NULL; 
    if( !mxIsDouble(prhs[1082]) || mxIsComplex(prhs[1082]) || !(mxGetM(prhs[1082])==1 && mxGetN(prhs[1082])==1) ) { 
      mexErrMsgTxt("Input 1082 must be a noncomplex scalar double.");
    } 
    mexinput1082_temp = mxGetPr(prhs[1082]); 
    double mexinput1082 = *mexinput1082_temp; 

    double *mexinput1083_temp = NULL; 
    if( !mxIsDouble(prhs[1083]) || mxIsComplex(prhs[1083]) || !(mxGetM(prhs[1083])==1 && mxGetN(prhs[1083])==1) ) { 
      mexErrMsgTxt("Input 1083 must be a noncomplex scalar double.");
    } 
    mexinput1083_temp = mxGetPr(prhs[1083]); 
    double mexinput1083 = *mexinput1083_temp; 

    double *mexinput1084_temp = NULL; 
    if( !mxIsDouble(prhs[1084]) || mxIsComplex(prhs[1084]) || !(mxGetM(prhs[1084])==1 && mxGetN(prhs[1084])==1) ) { 
      mexErrMsgTxt("Input 1084 must be a noncomplex scalar double.");
    } 
    mexinput1084_temp = mxGetPr(prhs[1084]); 
    double mexinput1084 = *mexinput1084_temp; 

    double *mexinput1085_temp = NULL; 
    if( !mxIsDouble(prhs[1085]) || mxIsComplex(prhs[1085]) || !(mxGetM(prhs[1085])==1 && mxGetN(prhs[1085])==1) ) { 
      mexErrMsgTxt("Input 1085 must be a noncomplex scalar double.");
    } 
    mexinput1085_temp = mxGetPr(prhs[1085]); 
    double mexinput1085 = *mexinput1085_temp; 

    double *mexinput1086_temp = NULL; 
    if( !mxIsDouble(prhs[1086]) || mxIsComplex(prhs[1086]) || !(mxGetM(prhs[1086])==1 && mxGetN(prhs[1086])==1) ) { 
      mexErrMsgTxt("Input 1086 must be a noncomplex scalar double.");
    } 
    mexinput1086_temp = mxGetPr(prhs[1086]); 
    double mexinput1086 = *mexinput1086_temp; 

    double *mexinput1087_temp = NULL; 
    if( !mxIsDouble(prhs[1087]) || mxIsComplex(prhs[1087]) || !(mxGetM(prhs[1087])==1 && mxGetN(prhs[1087])==1) ) { 
      mexErrMsgTxt("Input 1087 must be a noncomplex scalar double.");
    } 
    mexinput1087_temp = mxGetPr(prhs[1087]); 
    double mexinput1087 = *mexinput1087_temp; 

    double *mexinput1088_temp = NULL; 
    if( !mxIsDouble(prhs[1088]) || mxIsComplex(prhs[1088]) || !(mxGetM(prhs[1088])==1 && mxGetN(prhs[1088])==1) ) { 
      mexErrMsgTxt("Input 1088 must be a noncomplex scalar double.");
    } 
    mexinput1088_temp = mxGetPr(prhs[1088]); 
    double mexinput1088 = *mexinput1088_temp; 

    double *mexinput1089_temp = NULL; 
    if( !mxIsDouble(prhs[1089]) || mxIsComplex(prhs[1089]) || !(mxGetM(prhs[1089])==1 && mxGetN(prhs[1089])==1) ) { 
      mexErrMsgTxt("Input 1089 must be a noncomplex scalar double.");
    } 
    mexinput1089_temp = mxGetPr(prhs[1089]); 
    double mexinput1089 = *mexinput1089_temp; 

    double *mexinput1090_temp = NULL; 
    if( !mxIsDouble(prhs[1090]) || mxIsComplex(prhs[1090]) || !(mxGetM(prhs[1090])==1 && mxGetN(prhs[1090])==1) ) { 
      mexErrMsgTxt("Input 1090 must be a noncomplex scalar double.");
    } 
    mexinput1090_temp = mxGetPr(prhs[1090]); 
    double mexinput1090 = *mexinput1090_temp; 

    double *mexinput1091_temp = NULL; 
    if( !mxIsDouble(prhs[1091]) || mxIsComplex(prhs[1091]) || !(mxGetM(prhs[1091])==1 && mxGetN(prhs[1091])==1) ) { 
      mexErrMsgTxt("Input 1091 must be a noncomplex scalar double.");
    } 
    mexinput1091_temp = mxGetPr(prhs[1091]); 
    double mexinput1091 = *mexinput1091_temp; 

    double *mexinput1092_temp = NULL; 
    if( !mxIsDouble(prhs[1092]) || mxIsComplex(prhs[1092]) || !(mxGetM(prhs[1092])==1 && mxGetN(prhs[1092])==1) ) { 
      mexErrMsgTxt("Input 1092 must be a noncomplex scalar double.");
    } 
    mexinput1092_temp = mxGetPr(prhs[1092]); 
    double mexinput1092 = *mexinput1092_temp; 

    double *mexinput1093_temp = NULL; 
    if( !mxIsDouble(prhs[1093]) || mxIsComplex(prhs[1093]) || !(mxGetM(prhs[1093])==1 && mxGetN(prhs[1093])==1) ) { 
      mexErrMsgTxt("Input 1093 must be a noncomplex scalar double.");
    } 
    mexinput1093_temp = mxGetPr(prhs[1093]); 
    double mexinput1093 = *mexinput1093_temp; 

    double *mexinput1094_temp = NULL; 
    if( !mxIsDouble(prhs[1094]) || mxIsComplex(prhs[1094]) || !(mxGetM(prhs[1094])==1 && mxGetN(prhs[1094])==1) ) { 
      mexErrMsgTxt("Input 1094 must be a noncomplex scalar double.");
    } 
    mexinput1094_temp = mxGetPr(prhs[1094]); 
    double mexinput1094 = *mexinput1094_temp; 

    double *mexinput1095_temp = NULL; 
    if( !mxIsDouble(prhs[1095]) || mxIsComplex(prhs[1095]) || !(mxGetM(prhs[1095])==1 && mxGetN(prhs[1095])==1) ) { 
      mexErrMsgTxt("Input 1095 must be a noncomplex scalar double.");
    } 
    mexinput1095_temp = mxGetPr(prhs[1095]); 
    double mexinput1095 = *mexinput1095_temp; 

    double *mexinput1096_temp = NULL; 
    if( !mxIsDouble(prhs[1096]) || mxIsComplex(prhs[1096]) || !(mxGetM(prhs[1096])==1 && mxGetN(prhs[1096])==1) ) { 
      mexErrMsgTxt("Input 1096 must be a noncomplex scalar double.");
    } 
    mexinput1096_temp = mxGetPr(prhs[1096]); 
    double mexinput1096 = *mexinput1096_temp; 

    double *mexinput1097_temp = NULL; 
    if( !mxIsDouble(prhs[1097]) || mxIsComplex(prhs[1097]) || !(mxGetM(prhs[1097])==1 && mxGetN(prhs[1097])==1) ) { 
      mexErrMsgTxt("Input 1097 must be a noncomplex scalar double.");
    } 
    mexinput1097_temp = mxGetPr(prhs[1097]); 
    double mexinput1097 = *mexinput1097_temp; 

    double *mexinput1098_temp = NULL; 
    if( !mxIsDouble(prhs[1098]) || mxIsComplex(prhs[1098]) || !(mxGetM(prhs[1098])==1 && mxGetN(prhs[1098])==1) ) { 
      mexErrMsgTxt("Input 1098 must be a noncomplex scalar double.");
    } 
    mexinput1098_temp = mxGetPr(prhs[1098]); 
    double mexinput1098 = *mexinput1098_temp; 

    double *mexinput1099_temp = NULL; 
    if( !mxIsDouble(prhs[1099]) || mxIsComplex(prhs[1099]) || !(mxGetM(prhs[1099])==1 && mxGetN(prhs[1099])==1) ) { 
      mexErrMsgTxt("Input 1099 must be a noncomplex scalar double.");
    } 
    mexinput1099_temp = mxGetPr(prhs[1099]); 
    double mexinput1099 = *mexinput1099_temp; 

    double *mexinput1100_temp = NULL; 
    if( !mxIsDouble(prhs[1100]) || mxIsComplex(prhs[1100]) || !(mxGetM(prhs[1100])==1 && mxGetN(prhs[1100])==1) ) { 
      mexErrMsgTxt("Input 1100 must be a noncomplex scalar double.");
    } 
    mexinput1100_temp = mxGetPr(prhs[1100]); 
    double mexinput1100 = *mexinput1100_temp; 

    double *mexinput1101_temp = NULL; 
    if( !mxIsDouble(prhs[1101]) || mxIsComplex(prhs[1101]) || !(mxGetM(prhs[1101])==1 && mxGetN(prhs[1101])==1) ) { 
      mexErrMsgTxt("Input 1101 must be a noncomplex scalar double.");
    } 
    mexinput1101_temp = mxGetPr(prhs[1101]); 
    double mexinput1101 = *mexinput1101_temp; 

    double *mexinput1102_temp = NULL; 
    if( !mxIsDouble(prhs[1102]) || mxIsComplex(prhs[1102]) || !(mxGetM(prhs[1102])==1 && mxGetN(prhs[1102])==1) ) { 
      mexErrMsgTxt("Input 1102 must be a noncomplex scalar double.");
    } 
    mexinput1102_temp = mxGetPr(prhs[1102]); 
    double mexinput1102 = *mexinput1102_temp; 

    double *mexinput1103_temp = NULL; 
    if( !mxIsDouble(prhs[1103]) || mxIsComplex(prhs[1103]) || !(mxGetM(prhs[1103])==1 && mxGetN(prhs[1103])==1) ) { 
      mexErrMsgTxt("Input 1103 must be a noncomplex scalar double.");
    } 
    mexinput1103_temp = mxGetPr(prhs[1103]); 
    double mexinput1103 = *mexinput1103_temp; 

    double *mexinput1104_temp = NULL; 
    if( !mxIsDouble(prhs[1104]) || mxIsComplex(prhs[1104]) || !(mxGetM(prhs[1104])==1 && mxGetN(prhs[1104])==1) ) { 
      mexErrMsgTxt("Input 1104 must be a noncomplex scalar double.");
    } 
    mexinput1104_temp = mxGetPr(prhs[1104]); 
    double mexinput1104 = *mexinput1104_temp; 

    double *mexinput1105_temp = NULL; 
    if( !mxIsDouble(prhs[1105]) || mxIsComplex(prhs[1105]) || !(mxGetM(prhs[1105])==1 && mxGetN(prhs[1105])==1) ) { 
      mexErrMsgTxt("Input 1105 must be a noncomplex scalar double.");
    } 
    mexinput1105_temp = mxGetPr(prhs[1105]); 
    double mexinput1105 = *mexinput1105_temp; 

    double *mexinput1106_temp = NULL; 
    if( !mxIsDouble(prhs[1106]) || mxIsComplex(prhs[1106]) || !(mxGetM(prhs[1106])==1 && mxGetN(prhs[1106])==1) ) { 
      mexErrMsgTxt("Input 1106 must be a noncomplex scalar double.");
    } 
    mexinput1106_temp = mxGetPr(prhs[1106]); 
    double mexinput1106 = *mexinput1106_temp; 

    double *mexinput1107_temp = NULL; 
    if( !mxIsDouble(prhs[1107]) || mxIsComplex(prhs[1107]) || !(mxGetM(prhs[1107])==1 && mxGetN(prhs[1107])==1) ) { 
      mexErrMsgTxt("Input 1107 must be a noncomplex scalar double.");
    } 
    mexinput1107_temp = mxGetPr(prhs[1107]); 
    double mexinput1107 = *mexinput1107_temp; 

    double *mexinput1108_temp = NULL; 
    if( !mxIsDouble(prhs[1108]) || mxIsComplex(prhs[1108]) || !(mxGetM(prhs[1108])==1 && mxGetN(prhs[1108])==1) ) { 
      mexErrMsgTxt("Input 1108 must be a noncomplex scalar double.");
    } 
    mexinput1108_temp = mxGetPr(prhs[1108]); 
    double mexinput1108 = *mexinput1108_temp; 

    double *mexinput1109_temp = NULL; 
    if( !mxIsDouble(prhs[1109]) || mxIsComplex(prhs[1109]) || !(mxGetM(prhs[1109])==1 && mxGetN(prhs[1109])==1) ) { 
      mexErrMsgTxt("Input 1109 must be a noncomplex scalar double.");
    } 
    mexinput1109_temp = mxGetPr(prhs[1109]); 
    double mexinput1109 = *mexinput1109_temp; 

    double *mexinput1110_temp = NULL; 
    if( !mxIsDouble(prhs[1110]) || mxIsComplex(prhs[1110]) || !(mxGetM(prhs[1110])==1 && mxGetN(prhs[1110])==1) ) { 
      mexErrMsgTxt("Input 1110 must be a noncomplex scalar double.");
    } 
    mexinput1110_temp = mxGetPr(prhs[1110]); 
    double mexinput1110 = *mexinput1110_temp; 

    double *mexinput1111_temp = NULL; 
    if( !mxIsDouble(prhs[1111]) || mxIsComplex(prhs[1111]) || !(mxGetM(prhs[1111])==1 && mxGetN(prhs[1111])==1) ) { 
      mexErrMsgTxt("Input 1111 must be a noncomplex scalar double.");
    } 
    mexinput1111_temp = mxGetPr(prhs[1111]); 
    double mexinput1111 = *mexinput1111_temp; 

    double *mexinput1112_temp = NULL; 
    if( !mxIsDouble(prhs[1112]) || mxIsComplex(prhs[1112]) || !(mxGetM(prhs[1112])==1 && mxGetN(prhs[1112])==1) ) { 
      mexErrMsgTxt("Input 1112 must be a noncomplex scalar double.");
    } 
    mexinput1112_temp = mxGetPr(prhs[1112]); 
    double mexinput1112 = *mexinput1112_temp; 

    double *mexinput1113_temp = NULL; 
    if( !mxIsDouble(prhs[1113]) || mxIsComplex(prhs[1113]) || !(mxGetM(prhs[1113])==1 && mxGetN(prhs[1113])==1) ) { 
      mexErrMsgTxt("Input 1113 must be a noncomplex scalar double.");
    } 
    mexinput1113_temp = mxGetPr(prhs[1113]); 
    double mexinput1113 = *mexinput1113_temp; 

    double *mexinput1114_temp = NULL; 
    if( !mxIsDouble(prhs[1114]) || mxIsComplex(prhs[1114]) || !(mxGetM(prhs[1114])==1 && mxGetN(prhs[1114])==1) ) { 
      mexErrMsgTxt("Input 1114 must be a noncomplex scalar double.");
    } 
    mexinput1114_temp = mxGetPr(prhs[1114]); 
    double mexinput1114 = *mexinput1114_temp; 

    double *mexinput1115_temp = NULL; 
    if( !mxIsDouble(prhs[1115]) || mxIsComplex(prhs[1115]) || !(mxGetM(prhs[1115])==1 && mxGetN(prhs[1115])==1) ) { 
      mexErrMsgTxt("Input 1115 must be a noncomplex scalar double.");
    } 
    mexinput1115_temp = mxGetPr(prhs[1115]); 
    double mexinput1115 = *mexinput1115_temp; 

    double *mexinput1116_temp = NULL; 
    if( !mxIsDouble(prhs[1116]) || mxIsComplex(prhs[1116]) || !(mxGetM(prhs[1116])==1 && mxGetN(prhs[1116])==1) ) { 
      mexErrMsgTxt("Input 1116 must be a noncomplex scalar double.");
    } 
    mexinput1116_temp = mxGetPr(prhs[1116]); 
    double mexinput1116 = *mexinput1116_temp; 

    double *mexinput1117_temp = NULL; 
    if( !mxIsDouble(prhs[1117]) || mxIsComplex(prhs[1117]) || !(mxGetM(prhs[1117])==1 && mxGetN(prhs[1117])==1) ) { 
      mexErrMsgTxt("Input 1117 must be a noncomplex scalar double.");
    } 
    mexinput1117_temp = mxGetPr(prhs[1117]); 
    double mexinput1117 = *mexinput1117_temp; 

    double *mexinput1118_temp = NULL; 
    if( !mxIsDouble(prhs[1118]) || mxIsComplex(prhs[1118]) || !(mxGetM(prhs[1118])==1 && mxGetN(prhs[1118])==1) ) { 
      mexErrMsgTxt("Input 1118 must be a noncomplex scalar double.");
    } 
    mexinput1118_temp = mxGetPr(prhs[1118]); 
    double mexinput1118 = *mexinput1118_temp; 

    double *mexinput1119_temp = NULL; 
    if( !mxIsDouble(prhs[1119]) || mxIsComplex(prhs[1119]) || !(mxGetM(prhs[1119])==1 && mxGetN(prhs[1119])==1) ) { 
      mexErrMsgTxt("Input 1119 must be a noncomplex scalar double.");
    } 
    mexinput1119_temp = mxGetPr(prhs[1119]); 
    double mexinput1119 = *mexinput1119_temp; 

    double *mexinput1120_temp = NULL; 
    if( !mxIsDouble(prhs[1120]) || mxIsComplex(prhs[1120]) || !(mxGetM(prhs[1120])==1 && mxGetN(prhs[1120])==1) ) { 
      mexErrMsgTxt("Input 1120 must be a noncomplex scalar double.");
    } 
    mexinput1120_temp = mxGetPr(prhs[1120]); 
    double mexinput1120 = *mexinput1120_temp; 

    double *mexinput1121_temp = NULL; 
    if( !mxIsDouble(prhs[1121]) || mxIsComplex(prhs[1121]) || !(mxGetM(prhs[1121])==1 && mxGetN(prhs[1121])==1) ) { 
      mexErrMsgTxt("Input 1121 must be a noncomplex scalar double.");
    } 
    mexinput1121_temp = mxGetPr(prhs[1121]); 
    double mexinput1121 = *mexinput1121_temp; 

    double *mexinput1122_temp = NULL; 
    if( !mxIsDouble(prhs[1122]) || mxIsComplex(prhs[1122]) || !(mxGetM(prhs[1122])==1 && mxGetN(prhs[1122])==1) ) { 
      mexErrMsgTxt("Input 1122 must be a noncomplex scalar double.");
    } 
    mexinput1122_temp = mxGetPr(prhs[1122]); 
    double mexinput1122 = *mexinput1122_temp; 

    double *mexinput1123_temp = NULL; 
    if( !mxIsDouble(prhs[1123]) || mxIsComplex(prhs[1123]) || !(mxGetM(prhs[1123])==1 && mxGetN(prhs[1123])==1) ) { 
      mexErrMsgTxt("Input 1123 must be a noncomplex scalar double.");
    } 
    mexinput1123_temp = mxGetPr(prhs[1123]); 
    double mexinput1123 = *mexinput1123_temp; 

    double *mexinput1124_temp = NULL; 
    if( !mxIsDouble(prhs[1124]) || mxIsComplex(prhs[1124]) || !(mxGetM(prhs[1124])==1 && mxGetN(prhs[1124])==1) ) { 
      mexErrMsgTxt("Input 1124 must be a noncomplex scalar double.");
    } 
    mexinput1124_temp = mxGetPr(prhs[1124]); 
    double mexinput1124 = *mexinput1124_temp; 

    double *mexinput1125_temp = NULL; 
    if( !mxIsDouble(prhs[1125]) || mxIsComplex(prhs[1125]) || !(mxGetM(prhs[1125])==1 && mxGetN(prhs[1125])==1) ) { 
      mexErrMsgTxt("Input 1125 must be a noncomplex scalar double.");
    } 
    mexinput1125_temp = mxGetPr(prhs[1125]); 
    double mexinput1125 = *mexinput1125_temp; 

    double *mexinput1126_temp = NULL; 
    if( !mxIsDouble(prhs[1126]) || mxIsComplex(prhs[1126]) || !(mxGetM(prhs[1126])==1 && mxGetN(prhs[1126])==1) ) { 
      mexErrMsgTxt("Input 1126 must be a noncomplex scalar double.");
    } 
    mexinput1126_temp = mxGetPr(prhs[1126]); 
    double mexinput1126 = *mexinput1126_temp; 

    double *mexinput1127_temp = NULL; 
    if( !mxIsDouble(prhs[1127]) || mxIsComplex(prhs[1127]) || !(mxGetM(prhs[1127])==1 && mxGetN(prhs[1127])==1) ) { 
      mexErrMsgTxt("Input 1127 must be a noncomplex scalar double.");
    } 
    mexinput1127_temp = mxGetPr(prhs[1127]); 
    double mexinput1127 = *mexinput1127_temp; 

    double *mexinput1128_temp = NULL; 
    if( !mxIsDouble(prhs[1128]) || mxIsComplex(prhs[1128]) || !(mxGetM(prhs[1128])==1 && mxGetN(prhs[1128])==1) ) { 
      mexErrMsgTxt("Input 1128 must be a noncomplex scalar double.");
    } 
    mexinput1128_temp = mxGetPr(prhs[1128]); 
    double mexinput1128 = *mexinput1128_temp; 

    double *mexinput1129_temp = NULL; 
    if( !mxIsDouble(prhs[1129]) || mxIsComplex(prhs[1129]) || !(mxGetM(prhs[1129])==1 && mxGetN(prhs[1129])==1) ) { 
      mexErrMsgTxt("Input 1129 must be a noncomplex scalar double.");
    } 
    mexinput1129_temp = mxGetPr(prhs[1129]); 
    double mexinput1129 = *mexinput1129_temp; 

    double *mexinput1130_temp = NULL; 
    if( !mxIsDouble(prhs[1130]) || mxIsComplex(prhs[1130]) || !(mxGetM(prhs[1130])==1 && mxGetN(prhs[1130])==1) ) { 
      mexErrMsgTxt("Input 1130 must be a noncomplex scalar double.");
    } 
    mexinput1130_temp = mxGetPr(prhs[1130]); 
    double mexinput1130 = *mexinput1130_temp; 

    double *mexinput1131_temp = NULL; 
    if( !mxIsDouble(prhs[1131]) || mxIsComplex(prhs[1131]) || !(mxGetM(prhs[1131])==1 && mxGetN(prhs[1131])==1) ) { 
      mexErrMsgTxt("Input 1131 must be a noncomplex scalar double.");
    } 
    mexinput1131_temp = mxGetPr(prhs[1131]); 
    double mexinput1131 = *mexinput1131_temp; 

    double *mexinput1132_temp = NULL; 
    if( !mxIsDouble(prhs[1132]) || mxIsComplex(prhs[1132]) || !(mxGetM(prhs[1132])==1 && mxGetN(prhs[1132])==1) ) { 
      mexErrMsgTxt("Input 1132 must be a noncomplex scalar double.");
    } 
    mexinput1132_temp = mxGetPr(prhs[1132]); 
    double mexinput1132 = *mexinput1132_temp; 

    double *mexinput1133_temp = NULL; 
    if( !mxIsDouble(prhs[1133]) || mxIsComplex(prhs[1133]) || !(mxGetM(prhs[1133])==1 && mxGetN(prhs[1133])==1) ) { 
      mexErrMsgTxt("Input 1133 must be a noncomplex scalar double.");
    } 
    mexinput1133_temp = mxGetPr(prhs[1133]); 
    double mexinput1133 = *mexinput1133_temp; 

    double *mexinput1134_temp = NULL; 
    if( !mxIsDouble(prhs[1134]) || mxIsComplex(prhs[1134]) || !(mxGetM(prhs[1134])==1 && mxGetN(prhs[1134])==1) ) { 
      mexErrMsgTxt("Input 1134 must be a noncomplex scalar double.");
    } 
    mexinput1134_temp = mxGetPr(prhs[1134]); 
    double mexinput1134 = *mexinput1134_temp; 

    double *mexinput1135_temp = NULL; 
    if( !mxIsDouble(prhs[1135]) || mxIsComplex(prhs[1135]) || !(mxGetM(prhs[1135])==1 && mxGetN(prhs[1135])==1) ) { 
      mexErrMsgTxt("Input 1135 must be a noncomplex scalar double.");
    } 
    mexinput1135_temp = mxGetPr(prhs[1135]); 
    double mexinput1135 = *mexinput1135_temp; 

    double *mexinput1136_temp = NULL; 
    if( !mxIsDouble(prhs[1136]) || mxIsComplex(prhs[1136]) || !(mxGetM(prhs[1136])==1 && mxGetN(prhs[1136])==1) ) { 
      mexErrMsgTxt("Input 1136 must be a noncomplex scalar double.");
    } 
    mexinput1136_temp = mxGetPr(prhs[1136]); 
    double mexinput1136 = *mexinput1136_temp; 

    double *mexinput1137_temp = NULL; 
    if( !mxIsDouble(prhs[1137]) || mxIsComplex(prhs[1137]) || !(mxGetM(prhs[1137])==1 && mxGetN(prhs[1137])==1) ) { 
      mexErrMsgTxt("Input 1137 must be a noncomplex scalar double.");
    } 
    mexinput1137_temp = mxGetPr(prhs[1137]); 
    double mexinput1137 = *mexinput1137_temp; 

    double *mexinput1138_temp = NULL; 
    if( !mxIsDouble(prhs[1138]) || mxIsComplex(prhs[1138]) || !(mxGetM(prhs[1138])==1 && mxGetN(prhs[1138])==1) ) { 
      mexErrMsgTxt("Input 1138 must be a noncomplex scalar double.");
    } 
    mexinput1138_temp = mxGetPr(prhs[1138]); 
    double mexinput1138 = *mexinput1138_temp; 

    double *mexinput1139_temp = NULL; 
    if( !mxIsDouble(prhs[1139]) || mxIsComplex(prhs[1139]) || !(mxGetM(prhs[1139])==1 && mxGetN(prhs[1139])==1) ) { 
      mexErrMsgTxt("Input 1139 must be a noncomplex scalar double.");
    } 
    mexinput1139_temp = mxGetPr(prhs[1139]); 
    double mexinput1139 = *mexinput1139_temp; 

    double *mexinput1140_temp = NULL; 
    if( !mxIsDouble(prhs[1140]) || mxIsComplex(prhs[1140]) || !(mxGetM(prhs[1140])==1 && mxGetN(prhs[1140])==1) ) { 
      mexErrMsgTxt("Input 1140 must be a noncomplex scalar double.");
    } 
    mexinput1140_temp = mxGetPr(prhs[1140]); 
    double mexinput1140 = *mexinput1140_temp; 

    double *mexinput1141_temp = NULL; 
    if( !mxIsDouble(prhs[1141]) || mxIsComplex(prhs[1141]) || !(mxGetM(prhs[1141])==1 && mxGetN(prhs[1141])==1) ) { 
      mexErrMsgTxt("Input 1141 must be a noncomplex scalar double.");
    } 
    mexinput1141_temp = mxGetPr(prhs[1141]); 
    double mexinput1141 = *mexinput1141_temp; 

    double *mexinput1142_temp = NULL; 
    if( !mxIsDouble(prhs[1142]) || mxIsComplex(prhs[1142]) || !(mxGetM(prhs[1142])==1 && mxGetN(prhs[1142])==1) ) { 
      mexErrMsgTxt("Input 1142 must be a noncomplex scalar double.");
    } 
    mexinput1142_temp = mxGetPr(prhs[1142]); 
    double mexinput1142 = *mexinput1142_temp; 

    double *mexinput1143_temp = NULL; 
    if( !mxIsDouble(prhs[1143]) || mxIsComplex(prhs[1143]) || !(mxGetM(prhs[1143])==1 && mxGetN(prhs[1143])==1) ) { 
      mexErrMsgTxt("Input 1143 must be a noncomplex scalar double.");
    } 
    mexinput1143_temp = mxGetPr(prhs[1143]); 
    double mexinput1143 = *mexinput1143_temp; 

    double *mexinput1144_temp = NULL; 
    if( !mxIsDouble(prhs[1144]) || mxIsComplex(prhs[1144]) || !(mxGetM(prhs[1144])==1 && mxGetN(prhs[1144])==1) ) { 
      mexErrMsgTxt("Input 1144 must be a noncomplex scalar double.");
    } 
    mexinput1144_temp = mxGetPr(prhs[1144]); 
    double mexinput1144 = *mexinput1144_temp; 

    double *mexinput1145_temp = NULL; 
    if( !mxIsDouble(prhs[1145]) || mxIsComplex(prhs[1145]) || !(mxGetM(prhs[1145])==1 && mxGetN(prhs[1145])==1) ) { 
      mexErrMsgTxt("Input 1145 must be a noncomplex scalar double.");
    } 
    mexinput1145_temp = mxGetPr(prhs[1145]); 
    double mexinput1145 = *mexinput1145_temp; 

    double *mexinput1146_temp = NULL; 
    if( !mxIsDouble(prhs[1146]) || mxIsComplex(prhs[1146]) || !(mxGetM(prhs[1146])==1 && mxGetN(prhs[1146])==1) ) { 
      mexErrMsgTxt("Input 1146 must be a noncomplex scalar double.");
    } 
    mexinput1146_temp = mxGetPr(prhs[1146]); 
    double mexinput1146 = *mexinput1146_temp; 

    double *mexinput1147_temp = NULL; 
    if( !mxIsDouble(prhs[1147]) || mxIsComplex(prhs[1147]) || !(mxGetM(prhs[1147])==1 && mxGetN(prhs[1147])==1) ) { 
      mexErrMsgTxt("Input 1147 must be a noncomplex scalar double.");
    } 
    mexinput1147_temp = mxGetPr(prhs[1147]); 
    double mexinput1147 = *mexinput1147_temp; 

    double *mexinput1148_temp = NULL; 
    if( !mxIsDouble(prhs[1148]) || mxIsComplex(prhs[1148]) || !(mxGetM(prhs[1148])==1 && mxGetN(prhs[1148])==1) ) { 
      mexErrMsgTxt("Input 1148 must be a noncomplex scalar double.");
    } 
    mexinput1148_temp = mxGetPr(prhs[1148]); 
    double mexinput1148 = *mexinput1148_temp; 

    double *mexinput1149_temp = NULL; 
    if( !mxIsDouble(prhs[1149]) || mxIsComplex(prhs[1149]) || !(mxGetM(prhs[1149])==1 && mxGetN(prhs[1149])==1) ) { 
      mexErrMsgTxt("Input 1149 must be a noncomplex scalar double.");
    } 
    mexinput1149_temp = mxGetPr(prhs[1149]); 
    double mexinput1149 = *mexinput1149_temp; 

    double *mexinput1150_temp = NULL; 
    if( !mxIsDouble(prhs[1150]) || mxIsComplex(prhs[1150]) || !(mxGetM(prhs[1150])==1 && mxGetN(prhs[1150])==1) ) { 
      mexErrMsgTxt("Input 1150 must be a noncomplex scalar double.");
    } 
    mexinput1150_temp = mxGetPr(prhs[1150]); 
    double mexinput1150 = *mexinput1150_temp; 

    double *mexinput1151_temp = NULL; 
    if( !mxIsDouble(prhs[1151]) || mxIsComplex(prhs[1151]) || !(mxGetM(prhs[1151])==1 && mxGetN(prhs[1151])==1) ) { 
      mexErrMsgTxt("Input 1151 must be a noncomplex scalar double.");
    } 
    mexinput1151_temp = mxGetPr(prhs[1151]); 
    double mexinput1151 = *mexinput1151_temp; 

    double *mexinput1152_temp = NULL; 
    if( !mxIsDouble(prhs[1152]) || mxIsComplex(prhs[1152]) || !(mxGetM(prhs[1152])==1 && mxGetN(prhs[1152])==1) ) { 
      mexErrMsgTxt("Input 1152 must be a noncomplex scalar double.");
    } 
    mexinput1152_temp = mxGetPr(prhs[1152]); 
    double mexinput1152 = *mexinput1152_temp; 

    double *mexinput1153_temp = NULL; 
    if( !mxIsDouble(prhs[1153]) || mxIsComplex(prhs[1153]) || !(mxGetM(prhs[1153])==1 && mxGetN(prhs[1153])==1) ) { 
      mexErrMsgTxt("Input 1153 must be a noncomplex scalar double.");
    } 
    mexinput1153_temp = mxGetPr(prhs[1153]); 
    double mexinput1153 = *mexinput1153_temp; 

    double *mexinput1154_temp = NULL; 
    if( !mxIsDouble(prhs[1154]) || mxIsComplex(prhs[1154]) || !(mxGetM(prhs[1154])==1 && mxGetN(prhs[1154])==1) ) { 
      mexErrMsgTxt("Input 1154 must be a noncomplex scalar double.");
    } 
    mexinput1154_temp = mxGetPr(prhs[1154]); 
    double mexinput1154 = *mexinput1154_temp; 

    double *mexinput1155_temp = NULL; 
    if( !mxIsDouble(prhs[1155]) || mxIsComplex(prhs[1155]) || !(mxGetM(prhs[1155])==1 && mxGetN(prhs[1155])==1) ) { 
      mexErrMsgTxt("Input 1155 must be a noncomplex scalar double.");
    } 
    mexinput1155_temp = mxGetPr(prhs[1155]); 
    double mexinput1155 = *mexinput1155_temp; 

    double *mexinput1156_temp = NULL; 
    if( !mxIsDouble(prhs[1156]) || mxIsComplex(prhs[1156]) || !(mxGetM(prhs[1156])==1 && mxGetN(prhs[1156])==1) ) { 
      mexErrMsgTxt("Input 1156 must be a noncomplex scalar double.");
    } 
    mexinput1156_temp = mxGetPr(prhs[1156]); 
    double mexinput1156 = *mexinput1156_temp; 

    double *mexinput1157_temp = NULL; 
    if( !mxIsDouble(prhs[1157]) || mxIsComplex(prhs[1157]) || !(mxGetM(prhs[1157])==1 && mxGetN(prhs[1157])==1) ) { 
      mexErrMsgTxt("Input 1157 must be a noncomplex scalar double.");
    } 
    mexinput1157_temp = mxGetPr(prhs[1157]); 
    double mexinput1157 = *mexinput1157_temp; 

    double *mexinput1158_temp = NULL; 
    if( !mxIsDouble(prhs[1158]) || mxIsComplex(prhs[1158]) || !(mxGetM(prhs[1158])==1 && mxGetN(prhs[1158])==1) ) { 
      mexErrMsgTxt("Input 1158 must be a noncomplex scalar double.");
    } 
    mexinput1158_temp = mxGetPr(prhs[1158]); 
    double mexinput1158 = *mexinput1158_temp; 

    double *mexinput1159_temp = NULL; 
    if( !mxIsDouble(prhs[1159]) || mxIsComplex(prhs[1159]) || !(mxGetM(prhs[1159])==1 && mxGetN(prhs[1159])==1) ) { 
      mexErrMsgTxt("Input 1159 must be a noncomplex scalar double.");
    } 
    mexinput1159_temp = mxGetPr(prhs[1159]); 
    double mexinput1159 = *mexinput1159_temp; 

    double *mexinput1160_temp = NULL; 
    if( !mxIsDouble(prhs[1160]) || mxIsComplex(prhs[1160]) || !(mxGetM(prhs[1160])==1 && mxGetN(prhs[1160])==1) ) { 
      mexErrMsgTxt("Input 1160 must be a noncomplex scalar double.");
    } 
    mexinput1160_temp = mxGetPr(prhs[1160]); 
    double mexinput1160 = *mexinput1160_temp; 

    double *mexinput1161_temp = NULL; 
    if( !mxIsDouble(prhs[1161]) || mxIsComplex(prhs[1161]) || !(mxGetM(prhs[1161])==1 && mxGetN(prhs[1161])==1) ) { 
      mexErrMsgTxt("Input 1161 must be a noncomplex scalar double.");
    } 
    mexinput1161_temp = mxGetPr(prhs[1161]); 
    double mexinput1161 = *mexinput1161_temp; 

    double *mexinput1162_temp = NULL; 
    if( !mxIsDouble(prhs[1162]) || mxIsComplex(prhs[1162]) || !(mxGetM(prhs[1162])==1 && mxGetN(prhs[1162])==1) ) { 
      mexErrMsgTxt("Input 1162 must be a noncomplex scalar double.");
    } 
    mexinput1162_temp = mxGetPr(prhs[1162]); 
    double mexinput1162 = *mexinput1162_temp; 

    double *mexinput1163_temp = NULL; 
    if( !mxIsDouble(prhs[1163]) || mxIsComplex(prhs[1163]) || !(mxGetM(prhs[1163])==1 && mxGetN(prhs[1163])==1) ) { 
      mexErrMsgTxt("Input 1163 must be a noncomplex scalar double.");
    } 
    mexinput1163_temp = mxGetPr(prhs[1163]); 
    double mexinput1163 = *mexinput1163_temp; 

    double *mexinput1164_temp = NULL; 
    if( !mxIsDouble(prhs[1164]) || mxIsComplex(prhs[1164]) || !(mxGetM(prhs[1164])==1 && mxGetN(prhs[1164])==1) ) { 
      mexErrMsgTxt("Input 1164 must be a noncomplex scalar double.");
    } 
    mexinput1164_temp = mxGetPr(prhs[1164]); 
    double mexinput1164 = *mexinput1164_temp; 

    double *mexinput1165_temp = NULL; 
    if( !mxIsDouble(prhs[1165]) || mxIsComplex(prhs[1165]) || !(mxGetM(prhs[1165])==1 && mxGetN(prhs[1165])==1) ) { 
      mexErrMsgTxt("Input 1165 must be a noncomplex scalar double.");
    } 
    mexinput1165_temp = mxGetPr(prhs[1165]); 
    double mexinput1165 = *mexinput1165_temp; 

    double *mexinput1166_temp = NULL; 
    if( !mxIsDouble(prhs[1166]) || mxIsComplex(prhs[1166]) || !(mxGetM(prhs[1166])==1 && mxGetN(prhs[1166])==1) ) { 
      mexErrMsgTxt("Input 1166 must be a noncomplex scalar double.");
    } 
    mexinput1166_temp = mxGetPr(prhs[1166]); 
    double mexinput1166 = *mexinput1166_temp; 

    double *mexinput1167_temp = NULL; 
    if( !mxIsDouble(prhs[1167]) || mxIsComplex(prhs[1167]) || !(mxGetM(prhs[1167])==1 && mxGetN(prhs[1167])==1) ) { 
      mexErrMsgTxt("Input 1167 must be a noncomplex scalar double.");
    } 
    mexinput1167_temp = mxGetPr(prhs[1167]); 
    double mexinput1167 = *mexinput1167_temp; 

    double *mexinput1168_temp = NULL; 
    if( !mxIsDouble(prhs[1168]) || mxIsComplex(prhs[1168]) || !(mxGetM(prhs[1168])==1 && mxGetN(prhs[1168])==1) ) { 
      mexErrMsgTxt("Input 1168 must be a noncomplex scalar double.");
    } 
    mexinput1168_temp = mxGetPr(prhs[1168]); 
    double mexinput1168 = *mexinput1168_temp; 

    double *mexinput1169_temp = NULL; 
    if( !mxIsDouble(prhs[1169]) || mxIsComplex(prhs[1169]) || !(mxGetM(prhs[1169])==1 && mxGetN(prhs[1169])==1) ) { 
      mexErrMsgTxt("Input 1169 must be a noncomplex scalar double.");
    } 
    mexinput1169_temp = mxGetPr(prhs[1169]); 
    double mexinput1169 = *mexinput1169_temp; 

    double *mexinput1170_temp = NULL; 
    if( !mxIsDouble(prhs[1170]) || mxIsComplex(prhs[1170]) || !(mxGetM(prhs[1170])==1 && mxGetN(prhs[1170])==1) ) { 
      mexErrMsgTxt("Input 1170 must be a noncomplex scalar double.");
    } 
    mexinput1170_temp = mxGetPr(prhs[1170]); 
    double mexinput1170 = *mexinput1170_temp; 

    double *mexinput1171_temp = NULL; 
    if( !mxIsDouble(prhs[1171]) || mxIsComplex(prhs[1171]) || !(mxGetM(prhs[1171])==1 && mxGetN(prhs[1171])==1) ) { 
      mexErrMsgTxt("Input 1171 must be a noncomplex scalar double.");
    } 
    mexinput1171_temp = mxGetPr(prhs[1171]); 
    double mexinput1171 = *mexinput1171_temp; 

    double *mexinput1172_temp = NULL; 
    if( !mxIsDouble(prhs[1172]) || mxIsComplex(prhs[1172]) || !(mxGetM(prhs[1172])==1 && mxGetN(prhs[1172])==1) ) { 
      mexErrMsgTxt("Input 1172 must be a noncomplex scalar double.");
    } 
    mexinput1172_temp = mxGetPr(prhs[1172]); 
    double mexinput1172 = *mexinput1172_temp; 

    double *mexinput1173_temp = NULL; 
    if( !mxIsDouble(prhs[1173]) || mxIsComplex(prhs[1173]) || !(mxGetM(prhs[1173])==1 && mxGetN(prhs[1173])==1) ) { 
      mexErrMsgTxt("Input 1173 must be a noncomplex scalar double.");
    } 
    mexinput1173_temp = mxGetPr(prhs[1173]); 
    double mexinput1173 = *mexinput1173_temp; 

    double *mexinput1174_temp = NULL; 
    if( !mxIsDouble(prhs[1174]) || mxIsComplex(prhs[1174]) || !(mxGetM(prhs[1174])==1 && mxGetN(prhs[1174])==1) ) { 
      mexErrMsgTxt("Input 1174 must be a noncomplex scalar double.");
    } 
    mexinput1174_temp = mxGetPr(prhs[1174]); 
    double mexinput1174 = *mexinput1174_temp; 

    double *mexinput1175_temp = NULL; 
    if( !mxIsDouble(prhs[1175]) || mxIsComplex(prhs[1175]) || !(mxGetM(prhs[1175])==1 && mxGetN(prhs[1175])==1) ) { 
      mexErrMsgTxt("Input 1175 must be a noncomplex scalar double.");
    } 
    mexinput1175_temp = mxGetPr(prhs[1175]); 
    double mexinput1175 = *mexinput1175_temp; 

    double *mexinput1176_temp = NULL; 
    if( !mxIsDouble(prhs[1176]) || mxIsComplex(prhs[1176]) || !(mxGetM(prhs[1176])==1 && mxGetN(prhs[1176])==1) ) { 
      mexErrMsgTxt("Input 1176 must be a noncomplex scalar double.");
    } 
    mexinput1176_temp = mxGetPr(prhs[1176]); 
    double mexinput1176 = *mexinput1176_temp; 

    double *mexinput1177_temp = NULL; 
    if( !mxIsDouble(prhs[1177]) || mxIsComplex(prhs[1177]) || !(mxGetM(prhs[1177])==1 && mxGetN(prhs[1177])==1) ) { 
      mexErrMsgTxt("Input 1177 must be a noncomplex scalar double.");
    } 
    mexinput1177_temp = mxGetPr(prhs[1177]); 
    double mexinput1177 = *mexinput1177_temp; 

    double *mexinput1178_temp = NULL; 
    if( !mxIsDouble(prhs[1178]) || mxIsComplex(prhs[1178]) || !(mxGetM(prhs[1178])==1 && mxGetN(prhs[1178])==1) ) { 
      mexErrMsgTxt("Input 1178 must be a noncomplex scalar double.");
    } 
    mexinput1178_temp = mxGetPr(prhs[1178]); 
    double mexinput1178 = *mexinput1178_temp; 

    double *mexinput1179_temp = NULL; 
    if( !mxIsDouble(prhs[1179]) || mxIsComplex(prhs[1179]) || !(mxGetM(prhs[1179])==1 && mxGetN(prhs[1179])==1) ) { 
      mexErrMsgTxt("Input 1179 must be a noncomplex scalar double.");
    } 
    mexinput1179_temp = mxGetPr(prhs[1179]); 
    double mexinput1179 = *mexinput1179_temp; 

    double *mexinput1180_temp = NULL; 
    if( !mxIsDouble(prhs[1180]) || mxIsComplex(prhs[1180]) || !(mxGetM(prhs[1180])==1 && mxGetN(prhs[1180])==1) ) { 
      mexErrMsgTxt("Input 1180 must be a noncomplex scalar double.");
    } 
    mexinput1180_temp = mxGetPr(prhs[1180]); 
    double mexinput1180 = *mexinput1180_temp; 

    double *mexinput1181_temp = NULL; 
    if( !mxIsDouble(prhs[1181]) || mxIsComplex(prhs[1181]) || !(mxGetM(prhs[1181])==1 && mxGetN(prhs[1181])==1) ) { 
      mexErrMsgTxt("Input 1181 must be a noncomplex scalar double.");
    } 
    mexinput1181_temp = mxGetPr(prhs[1181]); 
    double mexinput1181 = *mexinput1181_temp; 

    double *mexinput1182_temp = NULL; 
    if( !mxIsDouble(prhs[1182]) || mxIsComplex(prhs[1182]) || !(mxGetM(prhs[1182])==1 && mxGetN(prhs[1182])==1) ) { 
      mexErrMsgTxt("Input 1182 must be a noncomplex scalar double.");
    } 
    mexinput1182_temp = mxGetPr(prhs[1182]); 
    double mexinput1182 = *mexinput1182_temp; 

    double *mexinput1183_temp = NULL; 
    if( !mxIsDouble(prhs[1183]) || mxIsComplex(prhs[1183]) || !(mxGetM(prhs[1183])==1 && mxGetN(prhs[1183])==1) ) { 
      mexErrMsgTxt("Input 1183 must be a noncomplex scalar double.");
    } 
    mexinput1183_temp = mxGetPr(prhs[1183]); 
    double mexinput1183 = *mexinput1183_temp; 

    double *mexinput1184_temp = NULL; 
    if( !mxIsDouble(prhs[1184]) || mxIsComplex(prhs[1184]) || !(mxGetM(prhs[1184])==1 && mxGetN(prhs[1184])==1) ) { 
      mexErrMsgTxt("Input 1184 must be a noncomplex scalar double.");
    } 
    mexinput1184_temp = mxGetPr(prhs[1184]); 
    double mexinput1184 = *mexinput1184_temp; 

    double *mexinput1185_temp = NULL; 
    if( !mxIsDouble(prhs[1185]) || mxIsComplex(prhs[1185]) || !(mxGetM(prhs[1185])==1 && mxGetN(prhs[1185])==1) ) { 
      mexErrMsgTxt("Input 1185 must be a noncomplex scalar double.");
    } 
    mexinput1185_temp = mxGetPr(prhs[1185]); 
    double mexinput1185 = *mexinput1185_temp; 

    double *mexinput1186_temp = NULL; 
    if( !mxIsDouble(prhs[1186]) || mxIsComplex(prhs[1186]) || !(mxGetM(prhs[1186])==1 && mxGetN(prhs[1186])==1) ) { 
      mexErrMsgTxt("Input 1186 must be a noncomplex scalar double.");
    } 
    mexinput1186_temp = mxGetPr(prhs[1186]); 
    double mexinput1186 = *mexinput1186_temp; 

    double *mexinput1187_temp = NULL; 
    if( !mxIsDouble(prhs[1187]) || mxIsComplex(prhs[1187]) || !(mxGetM(prhs[1187])==1 && mxGetN(prhs[1187])==1) ) { 
      mexErrMsgTxt("Input 1187 must be a noncomplex scalar double.");
    } 
    mexinput1187_temp = mxGetPr(prhs[1187]); 
    double mexinput1187 = *mexinput1187_temp; 

    double *mexinput1188_temp = NULL; 
    if( !mxIsDouble(prhs[1188]) || mxIsComplex(prhs[1188]) || !(mxGetM(prhs[1188])==1 && mxGetN(prhs[1188])==1) ) { 
      mexErrMsgTxt("Input 1188 must be a noncomplex scalar double.");
    } 
    mexinput1188_temp = mxGetPr(prhs[1188]); 
    double mexinput1188 = *mexinput1188_temp; 

    double *mexinput1189_temp = NULL; 
    if( !mxIsDouble(prhs[1189]) || mxIsComplex(prhs[1189]) || !(mxGetM(prhs[1189])==1 && mxGetN(prhs[1189])==1) ) { 
      mexErrMsgTxt("Input 1189 must be a noncomplex scalar double.");
    } 
    mexinput1189_temp = mxGetPr(prhs[1189]); 
    double mexinput1189 = *mexinput1189_temp; 

    double *mexinput1190_temp = NULL; 
    if( !mxIsDouble(prhs[1190]) || mxIsComplex(prhs[1190]) || !(mxGetM(prhs[1190])==1 && mxGetN(prhs[1190])==1) ) { 
      mexErrMsgTxt("Input 1190 must be a noncomplex scalar double.");
    } 
    mexinput1190_temp = mxGetPr(prhs[1190]); 
    double mexinput1190 = *mexinput1190_temp; 

    double *mexinput1191_temp = NULL; 
    if( !mxIsDouble(prhs[1191]) || mxIsComplex(prhs[1191]) || !(mxGetM(prhs[1191])==1 && mxGetN(prhs[1191])==1) ) { 
      mexErrMsgTxt("Input 1191 must be a noncomplex scalar double.");
    } 
    mexinput1191_temp = mxGetPr(prhs[1191]); 
    double mexinput1191 = *mexinput1191_temp; 

    double *mexinput1192_temp = NULL; 
    if( !mxIsDouble(prhs[1192]) || mxIsComplex(prhs[1192]) || !(mxGetM(prhs[1192])==1 && mxGetN(prhs[1192])==1) ) { 
      mexErrMsgTxt("Input 1192 must be a noncomplex scalar double.");
    } 
    mexinput1192_temp = mxGetPr(prhs[1192]); 
    double mexinput1192 = *mexinput1192_temp; 

    double *mexinput1193_temp = NULL; 
    if( !mxIsDouble(prhs[1193]) || mxIsComplex(prhs[1193]) || !(mxGetM(prhs[1193])==1 && mxGetN(prhs[1193])==1) ) { 
      mexErrMsgTxt("Input 1193 must be a noncomplex scalar double.");
    } 
    mexinput1193_temp = mxGetPr(prhs[1193]); 
    double mexinput1193 = *mexinput1193_temp; 

    double *mexinput1194_temp = NULL; 
    if( !mxIsDouble(prhs[1194]) || mxIsComplex(prhs[1194]) || !(mxGetM(prhs[1194])==1 && mxGetN(prhs[1194])==1) ) { 
      mexErrMsgTxt("Input 1194 must be a noncomplex scalar double.");
    } 
    mexinput1194_temp = mxGetPr(prhs[1194]); 
    double mexinput1194 = *mexinput1194_temp; 

    double *mexinput1195_temp = NULL; 
    if( !mxIsDouble(prhs[1195]) || mxIsComplex(prhs[1195]) || !(mxGetM(prhs[1195])==1 && mxGetN(prhs[1195])==1) ) { 
      mexErrMsgTxt("Input 1195 must be a noncomplex scalar double.");
    } 
    mexinput1195_temp = mxGetPr(prhs[1195]); 
    double mexinput1195 = *mexinput1195_temp; 

    double *mexinput1196_temp = NULL; 
    if( !mxIsDouble(prhs[1196]) || mxIsComplex(prhs[1196]) || !(mxGetM(prhs[1196])==1 && mxGetN(prhs[1196])==1) ) { 
      mexErrMsgTxt("Input 1196 must be a noncomplex scalar double.");
    } 
    mexinput1196_temp = mxGetPr(prhs[1196]); 
    double mexinput1196 = *mexinput1196_temp; 

    double *mexinput1197_temp = NULL; 
    if( !mxIsDouble(prhs[1197]) || mxIsComplex(prhs[1197]) || !(mxGetM(prhs[1197])==1 && mxGetN(prhs[1197])==1) ) { 
      mexErrMsgTxt("Input 1197 must be a noncomplex scalar double.");
    } 
    mexinput1197_temp = mxGetPr(prhs[1197]); 
    double mexinput1197 = *mexinput1197_temp; 

    double *mexinput1198_temp = NULL; 
    if( !mxIsDouble(prhs[1198]) || mxIsComplex(prhs[1198]) || !(mxGetM(prhs[1198])==1 && mxGetN(prhs[1198])==1) ) { 
      mexErrMsgTxt("Input 1198 must be a noncomplex scalar double.");
    } 
    mexinput1198_temp = mxGetPr(prhs[1198]); 
    double mexinput1198 = *mexinput1198_temp; 

    double *mexinput1199_temp = NULL; 
    if( !mxIsDouble(prhs[1199]) || mxIsComplex(prhs[1199]) || !(mxGetM(prhs[1199])==1 && mxGetN(prhs[1199])==1) ) { 
      mexErrMsgTxt("Input 1199 must be a noncomplex scalar double.");
    } 
    mexinput1199_temp = mxGetPr(prhs[1199]); 
    double mexinput1199 = *mexinput1199_temp; 

    double *mexinput1200_temp = NULL; 
    if( !mxIsDouble(prhs[1200]) || mxIsComplex(prhs[1200]) || !(mxGetM(prhs[1200])==1 && mxGetN(prhs[1200])==1) ) { 
      mexErrMsgTxt("Input 1200 must be a noncomplex scalar double.");
    } 
    mexinput1200_temp = mxGetPr(prhs[1200]); 
    double mexinput1200 = *mexinput1200_temp; 

    double *mexinput1201_temp = NULL; 
    if( !mxIsDouble(prhs[1201]) || mxIsComplex(prhs[1201]) || !(mxGetM(prhs[1201])==1 && mxGetN(prhs[1201])==1) ) { 
      mexErrMsgTxt("Input 1201 must be a noncomplex scalar double.");
    } 
    mexinput1201_temp = mxGetPr(prhs[1201]); 
    double mexinput1201 = *mexinput1201_temp; 

    double *mexinput1202_temp = NULL; 
    if( !mxIsDouble(prhs[1202]) || mxIsComplex(prhs[1202]) || !(mxGetM(prhs[1202])==1 && mxGetN(prhs[1202])==1) ) { 
      mexErrMsgTxt("Input 1202 must be a noncomplex scalar double.");
    } 
    mexinput1202_temp = mxGetPr(prhs[1202]); 
    double mexinput1202 = *mexinput1202_temp; 

    double *mexinput1203_temp = NULL; 
    if( !mxIsDouble(prhs[1203]) || mxIsComplex(prhs[1203]) || !(mxGetM(prhs[1203])==1 && mxGetN(prhs[1203])==1) ) { 
      mexErrMsgTxt("Input 1203 must be a noncomplex scalar double.");
    } 
    mexinput1203_temp = mxGetPr(prhs[1203]); 
    double mexinput1203 = *mexinput1203_temp; 

    double *mexinput1204_temp = NULL; 
    if( !mxIsDouble(prhs[1204]) || mxIsComplex(prhs[1204]) || !(mxGetM(prhs[1204])==1 && mxGetN(prhs[1204])==1) ) { 
      mexErrMsgTxt("Input 1204 must be a noncomplex scalar double.");
    } 
    mexinput1204_temp = mxGetPr(prhs[1204]); 
    double mexinput1204 = *mexinput1204_temp; 

    double *mexinput1205_temp = NULL; 
    if( !mxIsDouble(prhs[1205]) || mxIsComplex(prhs[1205]) || !(mxGetM(prhs[1205])==1 && mxGetN(prhs[1205])==1) ) { 
      mexErrMsgTxt("Input 1205 must be a noncomplex scalar double.");
    } 
    mexinput1205_temp = mxGetPr(prhs[1205]); 
    double mexinput1205 = *mexinput1205_temp; 

    double *mexinput1206_temp = NULL; 
    if( !mxIsDouble(prhs[1206]) || mxIsComplex(prhs[1206]) || !(mxGetM(prhs[1206])==1 && mxGetN(prhs[1206])==1) ) { 
      mexErrMsgTxt("Input 1206 must be a noncomplex scalar double.");
    } 
    mexinput1206_temp = mxGetPr(prhs[1206]); 
    double mexinput1206 = *mexinput1206_temp; 

    double *mexinput1207_temp = NULL; 
    if( !mxIsDouble(prhs[1207]) || mxIsComplex(prhs[1207]) || !(mxGetM(prhs[1207])==1 && mxGetN(prhs[1207])==1) ) { 
      mexErrMsgTxt("Input 1207 must be a noncomplex scalar double.");
    } 
    mexinput1207_temp = mxGetPr(prhs[1207]); 
    double mexinput1207 = *mexinput1207_temp; 

    double *mexinput1208_temp = NULL; 
    if( !mxIsDouble(prhs[1208]) || mxIsComplex(prhs[1208]) || !(mxGetM(prhs[1208])==1 && mxGetN(prhs[1208])==1) ) { 
      mexErrMsgTxt("Input 1208 must be a noncomplex scalar double.");
    } 
    mexinput1208_temp = mxGetPr(prhs[1208]); 
    double mexinput1208 = *mexinput1208_temp; 

    double *mexinput1209_temp = NULL; 
    if( !mxIsDouble(prhs[1209]) || mxIsComplex(prhs[1209]) || !(mxGetM(prhs[1209])==1 && mxGetN(prhs[1209])==1) ) { 
      mexErrMsgTxt("Input 1209 must be a noncomplex scalar double.");
    } 
    mexinput1209_temp = mxGetPr(prhs[1209]); 
    double mexinput1209 = *mexinput1209_temp; 

    double *mexinput1210_temp = NULL; 
    if( !mxIsDouble(prhs[1210]) || mxIsComplex(prhs[1210]) || !(mxGetM(prhs[1210])==1 && mxGetN(prhs[1210])==1) ) { 
      mexErrMsgTxt("Input 1210 must be a noncomplex scalar double.");
    } 
    mexinput1210_temp = mxGetPr(prhs[1210]); 
    double mexinput1210 = *mexinput1210_temp; 

    double *mexinput1211_temp = NULL; 
    if( !mxIsDouble(prhs[1211]) || mxIsComplex(prhs[1211]) || !(mxGetM(prhs[1211])==1 && mxGetN(prhs[1211])==1) ) { 
      mexErrMsgTxt("Input 1211 must be a noncomplex scalar double.");
    } 
    mexinput1211_temp = mxGetPr(prhs[1211]); 
    double mexinput1211 = *mexinput1211_temp; 

    double *mexinput1212_temp = NULL; 
    if( !mxIsDouble(prhs[1212]) || mxIsComplex(prhs[1212]) || !(mxGetM(prhs[1212])==1 && mxGetN(prhs[1212])==1) ) { 
      mexErrMsgTxt("Input 1212 must be a noncomplex scalar double.");
    } 
    mexinput1212_temp = mxGetPr(prhs[1212]); 
    double mexinput1212 = *mexinput1212_temp; 

    double *mexinput1213_temp = NULL; 
    if( !mxIsDouble(prhs[1213]) || mxIsComplex(prhs[1213]) || !(mxGetM(prhs[1213])==1 && mxGetN(prhs[1213])==1) ) { 
      mexErrMsgTxt("Input 1213 must be a noncomplex scalar double.");
    } 
    mexinput1213_temp = mxGetPr(prhs[1213]); 
    double mexinput1213 = *mexinput1213_temp; 

    double *mexinput1214_temp = NULL; 
    if( !mxIsDouble(prhs[1214]) || mxIsComplex(prhs[1214]) || !(mxGetM(prhs[1214])==1 && mxGetN(prhs[1214])==1) ) { 
      mexErrMsgTxt("Input 1214 must be a noncomplex scalar double.");
    } 
    mexinput1214_temp = mxGetPr(prhs[1214]); 
    double mexinput1214 = *mexinput1214_temp; 

    double *mexinput1215_temp = NULL; 
    if( !mxIsDouble(prhs[1215]) || mxIsComplex(prhs[1215]) || !(mxGetM(prhs[1215])==1 && mxGetN(prhs[1215])==1) ) { 
      mexErrMsgTxt("Input 1215 must be a noncomplex scalar double.");
    } 
    mexinput1215_temp = mxGetPr(prhs[1215]); 
    double mexinput1215 = *mexinput1215_temp; 

    double *mexinput1216_temp = NULL; 
    if( !mxIsDouble(prhs[1216]) || mxIsComplex(prhs[1216]) || !(mxGetM(prhs[1216])==1 && mxGetN(prhs[1216])==1) ) { 
      mexErrMsgTxt("Input 1216 must be a noncomplex scalar double.");
    } 
    mexinput1216_temp = mxGetPr(prhs[1216]); 
    double mexinput1216 = *mexinput1216_temp; 

    double *mexinput1217_temp = NULL; 
    if( !mxIsDouble(prhs[1217]) || mxIsComplex(prhs[1217]) || !(mxGetM(prhs[1217])==1 && mxGetN(prhs[1217])==1) ) { 
      mexErrMsgTxt("Input 1217 must be a noncomplex scalar double.");
    } 
    mexinput1217_temp = mxGetPr(prhs[1217]); 
    double mexinput1217 = *mexinput1217_temp; 

    double *mexinput1218_temp = NULL; 
    if( !mxIsDouble(prhs[1218]) || mxIsComplex(prhs[1218]) || !(mxGetM(prhs[1218])==1 && mxGetN(prhs[1218])==1) ) { 
      mexErrMsgTxt("Input 1218 must be a noncomplex scalar double.");
    } 
    mexinput1218_temp = mxGetPr(prhs[1218]); 
    double mexinput1218 = *mexinput1218_temp; 

    double *mexinput1219_temp = NULL; 
    if( !mxIsDouble(prhs[1219]) || mxIsComplex(prhs[1219]) || !(mxGetM(prhs[1219])==1 && mxGetN(prhs[1219])==1) ) { 
      mexErrMsgTxt("Input 1219 must be a noncomplex scalar double.");
    } 
    mexinput1219_temp = mxGetPr(prhs[1219]); 
    double mexinput1219 = *mexinput1219_temp; 

    double *mexinput1220_temp = NULL; 
    if( !mxIsDouble(prhs[1220]) || mxIsComplex(prhs[1220]) || !(mxGetM(prhs[1220])==1 && mxGetN(prhs[1220])==1) ) { 
      mexErrMsgTxt("Input 1220 must be a noncomplex scalar double.");
    } 
    mexinput1220_temp = mxGetPr(prhs[1220]); 
    double mexinput1220 = *mexinput1220_temp; 

    double *mexinput1221_temp = NULL; 
    if( !mxIsDouble(prhs[1221]) || mxIsComplex(prhs[1221]) || !(mxGetM(prhs[1221])==1 && mxGetN(prhs[1221])==1) ) { 
      mexErrMsgTxt("Input 1221 must be a noncomplex scalar double.");
    } 
    mexinput1221_temp = mxGetPr(prhs[1221]); 
    double mexinput1221 = *mexinput1221_temp; 

    double *mexinput1222_temp = NULL; 
    if( !mxIsDouble(prhs[1222]) || mxIsComplex(prhs[1222]) || !(mxGetM(prhs[1222])==1 && mxGetN(prhs[1222])==1) ) { 
      mexErrMsgTxt("Input 1222 must be a noncomplex scalar double.");
    } 
    mexinput1222_temp = mxGetPr(prhs[1222]); 
    double mexinput1222 = *mexinput1222_temp; 

    double *mexinput1223_temp = NULL; 
    if( !mxIsDouble(prhs[1223]) || mxIsComplex(prhs[1223]) || !(mxGetM(prhs[1223])==1 && mxGetN(prhs[1223])==1) ) { 
      mexErrMsgTxt("Input 1223 must be a noncomplex scalar double.");
    } 
    mexinput1223_temp = mxGetPr(prhs[1223]); 
    double mexinput1223 = *mexinput1223_temp; 

    double *mexinput1224_temp = NULL; 
    if( !mxIsDouble(prhs[1224]) || mxIsComplex(prhs[1224]) || !(mxGetM(prhs[1224])==1 && mxGetN(prhs[1224])==1) ) { 
      mexErrMsgTxt("Input 1224 must be a noncomplex scalar double.");
    } 
    mexinput1224_temp = mxGetPr(prhs[1224]); 
    double mexinput1224 = *mexinput1224_temp; 

    double *mexinput1225_temp = NULL; 
    if( !mxIsDouble(prhs[1225]) || mxIsComplex(prhs[1225]) || !(mxGetM(prhs[1225])==1 && mxGetN(prhs[1225])==1) ) { 
      mexErrMsgTxt("Input 1225 must be a noncomplex scalar double.");
    } 
    mexinput1225_temp = mxGetPr(prhs[1225]); 
    double mexinput1225 = *mexinput1225_temp; 

    double *mexinput1226_temp = NULL; 
    if( !mxIsDouble(prhs[1226]) || mxIsComplex(prhs[1226]) || !(mxGetM(prhs[1226])==1 && mxGetN(prhs[1226])==1) ) { 
      mexErrMsgTxt("Input 1226 must be a noncomplex scalar double.");
    } 
    mexinput1226_temp = mxGetPr(prhs[1226]); 
    double mexinput1226 = *mexinput1226_temp; 

    double *mexinput1227_temp = NULL; 
    if( !mxIsDouble(prhs[1227]) || mxIsComplex(prhs[1227]) || !(mxGetM(prhs[1227])==1 && mxGetN(prhs[1227])==1) ) { 
      mexErrMsgTxt("Input 1227 must be a noncomplex scalar double.");
    } 
    mexinput1227_temp = mxGetPr(prhs[1227]); 
    double mexinput1227 = *mexinput1227_temp; 

    double *mexinput1228_temp = NULL; 
    if( !mxIsDouble(prhs[1228]) || mxIsComplex(prhs[1228]) || !(mxGetM(prhs[1228])==1 && mxGetN(prhs[1228])==1) ) { 
      mexErrMsgTxt("Input 1228 must be a noncomplex scalar double.");
    } 
    mexinput1228_temp = mxGetPr(prhs[1228]); 
    double mexinput1228 = *mexinput1228_temp; 

    double *mexinput1229_temp = NULL; 
    if( !mxIsDouble(prhs[1229]) || mxIsComplex(prhs[1229]) || !(mxGetM(prhs[1229])==1 && mxGetN(prhs[1229])==1) ) { 
      mexErrMsgTxt("Input 1229 must be a noncomplex scalar double.");
    } 
    mexinput1229_temp = mxGetPr(prhs[1229]); 
    double mexinput1229 = *mexinput1229_temp; 

    double *mexinput1230_temp = NULL; 
    if( !mxIsDouble(prhs[1230]) || mxIsComplex(prhs[1230]) || !(mxGetM(prhs[1230])==1 && mxGetN(prhs[1230])==1) ) { 
      mexErrMsgTxt("Input 1230 must be a noncomplex scalar double.");
    } 
    mexinput1230_temp = mxGetPr(prhs[1230]); 
    double mexinput1230 = *mexinput1230_temp; 

    double *mexinput1231_temp = NULL; 
    if( !mxIsDouble(prhs[1231]) || mxIsComplex(prhs[1231]) || !(mxGetM(prhs[1231])==1 && mxGetN(prhs[1231])==1) ) { 
      mexErrMsgTxt("Input 1231 must be a noncomplex scalar double.");
    } 
    mexinput1231_temp = mxGetPr(prhs[1231]); 
    double mexinput1231 = *mexinput1231_temp; 

    double *mexinput1232_temp = NULL; 
    if( !mxIsDouble(prhs[1232]) || mxIsComplex(prhs[1232]) || !(mxGetM(prhs[1232])==1 && mxGetN(prhs[1232])==1) ) { 
      mexErrMsgTxt("Input 1232 must be a noncomplex scalar double.");
    } 
    mexinput1232_temp = mxGetPr(prhs[1232]); 
    double mexinput1232 = *mexinput1232_temp; 

    double *mexinput1233_temp = NULL; 
    if( !mxIsDouble(prhs[1233]) || mxIsComplex(prhs[1233]) || !(mxGetM(prhs[1233])==1 && mxGetN(prhs[1233])==1) ) { 
      mexErrMsgTxt("Input 1233 must be a noncomplex scalar double.");
    } 
    mexinput1233_temp = mxGetPr(prhs[1233]); 
    double mexinput1233 = *mexinput1233_temp; 

    double *mexinput1234_temp = NULL; 
    if( !mxIsDouble(prhs[1234]) || mxIsComplex(prhs[1234]) || !(mxGetM(prhs[1234])==1 && mxGetN(prhs[1234])==1) ) { 
      mexErrMsgTxt("Input 1234 must be a noncomplex scalar double.");
    } 
    mexinput1234_temp = mxGetPr(prhs[1234]); 
    double mexinput1234 = *mexinput1234_temp; 

    double *mexinput1235_temp = NULL; 
    if( !mxIsDouble(prhs[1235]) || mxIsComplex(prhs[1235]) || !(mxGetM(prhs[1235])==1 && mxGetN(prhs[1235])==1) ) { 
      mexErrMsgTxt("Input 1235 must be a noncomplex scalar double.");
    } 
    mexinput1235_temp = mxGetPr(prhs[1235]); 
    double mexinput1235 = *mexinput1235_temp; 

    double *mexinput1236_temp = NULL; 
    if( !mxIsDouble(prhs[1236]) || mxIsComplex(prhs[1236]) || !(mxGetM(prhs[1236])==1 && mxGetN(prhs[1236])==1) ) { 
      mexErrMsgTxt("Input 1236 must be a noncomplex scalar double.");
    } 
    mexinput1236_temp = mxGetPr(prhs[1236]); 
    double mexinput1236 = *mexinput1236_temp; 

    double *mexinput1237_temp = NULL; 
    if( !mxIsDouble(prhs[1237]) || mxIsComplex(prhs[1237]) || !(mxGetM(prhs[1237])==1 && mxGetN(prhs[1237])==1) ) { 
      mexErrMsgTxt("Input 1237 must be a noncomplex scalar double.");
    } 
    mexinput1237_temp = mxGetPr(prhs[1237]); 
    double mexinput1237 = *mexinput1237_temp; 

    double *mexinput1238_temp = NULL; 
    if( !mxIsDouble(prhs[1238]) || mxIsComplex(prhs[1238]) || !(mxGetM(prhs[1238])==1 && mxGetN(prhs[1238])==1) ) { 
      mexErrMsgTxt("Input 1238 must be a noncomplex scalar double.");
    } 
    mexinput1238_temp = mxGetPr(prhs[1238]); 
    double mexinput1238 = *mexinput1238_temp; 

    double *mexinput1239_temp = NULL; 
    if( !mxIsDouble(prhs[1239]) || mxIsComplex(prhs[1239]) || !(mxGetM(prhs[1239])==1 && mxGetN(prhs[1239])==1) ) { 
      mexErrMsgTxt("Input 1239 must be a noncomplex scalar double.");
    } 
    mexinput1239_temp = mxGetPr(prhs[1239]); 
    double mexinput1239 = *mexinput1239_temp; 

    double *mexinput1240_temp = NULL; 
    if( !mxIsDouble(prhs[1240]) || mxIsComplex(prhs[1240]) || !(mxGetM(prhs[1240])==1 && mxGetN(prhs[1240])==1) ) { 
      mexErrMsgTxt("Input 1240 must be a noncomplex scalar double.");
    } 
    mexinput1240_temp = mxGetPr(prhs[1240]); 
    double mexinput1240 = *mexinput1240_temp; 

    double *mexinput1241_temp = NULL; 
    if( !mxIsDouble(prhs[1241]) || mxIsComplex(prhs[1241]) || !(mxGetM(prhs[1241])==1 && mxGetN(prhs[1241])==1) ) { 
      mexErrMsgTxt("Input 1241 must be a noncomplex scalar double.");
    } 
    mexinput1241_temp = mxGetPr(prhs[1241]); 
    double mexinput1241 = *mexinput1241_temp; 

    double *mexinput1242_temp = NULL; 
    if( !mxIsDouble(prhs[1242]) || mxIsComplex(prhs[1242]) || !(mxGetM(prhs[1242])==1 && mxGetN(prhs[1242])==1) ) { 
      mexErrMsgTxt("Input 1242 must be a noncomplex scalar double.");
    } 
    mexinput1242_temp = mxGetPr(prhs[1242]); 
    double mexinput1242 = *mexinput1242_temp; 

    double *mexinput1243_temp = NULL; 
    if( !mxIsDouble(prhs[1243]) || mxIsComplex(prhs[1243]) || !(mxGetM(prhs[1243])==1 && mxGetN(prhs[1243])==1) ) { 
      mexErrMsgTxt("Input 1243 must be a noncomplex scalar double.");
    } 
    mexinput1243_temp = mxGetPr(prhs[1243]); 
    double mexinput1243 = *mexinput1243_temp; 

    double *mexinput1244_temp = NULL; 
    if( !mxIsDouble(prhs[1244]) || mxIsComplex(prhs[1244]) || !(mxGetM(prhs[1244])==1 && mxGetN(prhs[1244])==1) ) { 
      mexErrMsgTxt("Input 1244 must be a noncomplex scalar double.");
    } 
    mexinput1244_temp = mxGetPr(prhs[1244]); 
    double mexinput1244 = *mexinput1244_temp; 

    double *mexinput1245_temp = NULL; 
    if( !mxIsDouble(prhs[1245]) || mxIsComplex(prhs[1245]) || !(mxGetM(prhs[1245])==1 && mxGetN(prhs[1245])==1) ) { 
      mexErrMsgTxt("Input 1245 must be a noncomplex scalar double.");
    } 
    mexinput1245_temp = mxGetPr(prhs[1245]); 
    double mexinput1245 = *mexinput1245_temp; 

    double *mexinput1246_temp = NULL; 
    if( !mxIsDouble(prhs[1246]) || mxIsComplex(prhs[1246]) || !(mxGetM(prhs[1246])==1 && mxGetN(prhs[1246])==1) ) { 
      mexErrMsgTxt("Input 1246 must be a noncomplex scalar double.");
    } 
    mexinput1246_temp = mxGetPr(prhs[1246]); 
    double mexinput1246 = *mexinput1246_temp; 

    double *mexinput1247_temp = NULL; 
    if( !mxIsDouble(prhs[1247]) || mxIsComplex(prhs[1247]) || !(mxGetM(prhs[1247])==1 && mxGetN(prhs[1247])==1) ) { 
      mexErrMsgTxt("Input 1247 must be a noncomplex scalar double.");
    } 
    mexinput1247_temp = mxGetPr(prhs[1247]); 
    double mexinput1247 = *mexinput1247_temp; 

    double *mexinput1248_temp = NULL; 
    if( !mxIsDouble(prhs[1248]) || mxIsComplex(prhs[1248]) || !(mxGetM(prhs[1248])==1 && mxGetN(prhs[1248])==1) ) { 
      mexErrMsgTxt("Input 1248 must be a noncomplex scalar double.");
    } 
    mexinput1248_temp = mxGetPr(prhs[1248]); 
    double mexinput1248 = *mexinput1248_temp; 

    double *mexinput1249_temp = NULL; 
    if( !mxIsDouble(prhs[1249]) || mxIsComplex(prhs[1249]) || !(mxGetM(prhs[1249])==1 && mxGetN(prhs[1249])==1) ) { 
      mexErrMsgTxt("Input 1249 must be a noncomplex scalar double.");
    } 
    mexinput1249_temp = mxGetPr(prhs[1249]); 
    double mexinput1249 = *mexinput1249_temp; 

    double *mexinput1250_temp = NULL; 
    if( !mxIsDouble(prhs[1250]) || mxIsComplex(prhs[1250]) || !(mxGetM(prhs[1250])==1 && mxGetN(prhs[1250])==1) ) { 
      mexErrMsgTxt("Input 1250 must be a noncomplex scalar double.");
    } 
    mexinput1250_temp = mxGetPr(prhs[1250]); 
    double mexinput1250 = *mexinput1250_temp; 

    double *mexinput1251_temp = NULL; 
    if( !mxIsDouble(prhs[1251]) || mxIsComplex(prhs[1251]) || !(mxGetM(prhs[1251])==1 && mxGetN(prhs[1251])==1) ) { 
      mexErrMsgTxt("Input 1251 must be a noncomplex scalar double.");
    } 
    mexinput1251_temp = mxGetPr(prhs[1251]); 
    double mexinput1251 = *mexinput1251_temp; 

    double *mexinput1252_temp = NULL; 
    if( !mxIsDouble(prhs[1252]) || mxIsComplex(prhs[1252]) || !(mxGetM(prhs[1252])==1 && mxGetN(prhs[1252])==1) ) { 
      mexErrMsgTxt("Input 1252 must be a noncomplex scalar double.");
    } 
    mexinput1252_temp = mxGetPr(prhs[1252]); 
    double mexinput1252 = *mexinput1252_temp; 

    double *mexinput1253_temp = NULL; 
    if( !mxIsDouble(prhs[1253]) || mxIsComplex(prhs[1253]) || !(mxGetM(prhs[1253])==1 && mxGetN(prhs[1253])==1) ) { 
      mexErrMsgTxt("Input 1253 must be a noncomplex scalar double.");
    } 
    mexinput1253_temp = mxGetPr(prhs[1253]); 
    double mexinput1253 = *mexinput1253_temp; 

    double *mexinput1254_temp = NULL; 
    if( !mxIsDouble(prhs[1254]) || mxIsComplex(prhs[1254]) || !(mxGetM(prhs[1254])==1 && mxGetN(prhs[1254])==1) ) { 
      mexErrMsgTxt("Input 1254 must be a noncomplex scalar double.");
    } 
    mexinput1254_temp = mxGetPr(prhs[1254]); 
    double mexinput1254 = *mexinput1254_temp; 

    double *mexinput1255_temp = NULL; 
    if( !mxIsDouble(prhs[1255]) || mxIsComplex(prhs[1255]) || !(mxGetM(prhs[1255])==1 && mxGetN(prhs[1255])==1) ) { 
      mexErrMsgTxt("Input 1255 must be a noncomplex scalar double.");
    } 
    mexinput1255_temp = mxGetPr(prhs[1255]); 
    double mexinput1255 = *mexinput1255_temp; 

    double *mexinput1256_temp = NULL; 
    if( !mxIsDouble(prhs[1256]) || mxIsComplex(prhs[1256]) || !(mxGetM(prhs[1256])==1 && mxGetN(prhs[1256])==1) ) { 
      mexErrMsgTxt("Input 1256 must be a noncomplex scalar double.");
    } 
    mexinput1256_temp = mxGetPr(prhs[1256]); 
    double mexinput1256 = *mexinput1256_temp; 

    double *mexinput1257_temp = NULL; 
    if( !mxIsDouble(prhs[1257]) || mxIsComplex(prhs[1257]) || !(mxGetM(prhs[1257])==1 && mxGetN(prhs[1257])==1) ) { 
      mexErrMsgTxt("Input 1257 must be a noncomplex scalar double.");
    } 
    mexinput1257_temp = mxGetPr(prhs[1257]); 
    double mexinput1257 = *mexinput1257_temp; 

    double *mexinput1258_temp = NULL; 
    if( !mxIsDouble(prhs[1258]) || mxIsComplex(prhs[1258]) || !(mxGetM(prhs[1258])==1 && mxGetN(prhs[1258])==1) ) { 
      mexErrMsgTxt("Input 1258 must be a noncomplex scalar double.");
    } 
    mexinput1258_temp = mxGetPr(prhs[1258]); 
    double mexinput1258 = *mexinput1258_temp; 

    double *mexinput1259_temp = NULL; 
    if( !mxIsDouble(prhs[1259]) || mxIsComplex(prhs[1259]) || !(mxGetM(prhs[1259])==1 && mxGetN(prhs[1259])==1) ) { 
      mexErrMsgTxt("Input 1259 must be a noncomplex scalar double.");
    } 
    mexinput1259_temp = mxGetPr(prhs[1259]); 
    double mexinput1259 = *mexinput1259_temp; 

    double *mexinput1260_temp = NULL; 
    if( !mxIsDouble(prhs[1260]) || mxIsComplex(prhs[1260]) || !(mxGetM(prhs[1260])==1 && mxGetN(prhs[1260])==1) ) { 
      mexErrMsgTxt("Input 1260 must be a noncomplex scalar double.");
    } 
    mexinput1260_temp = mxGetPr(prhs[1260]); 
    double mexinput1260 = *mexinput1260_temp; 

    double *mexinput1261_temp = NULL; 
    if( !mxIsDouble(prhs[1261]) || mxIsComplex(prhs[1261]) || !(mxGetM(prhs[1261])==1 && mxGetN(prhs[1261])==1) ) { 
      mexErrMsgTxt("Input 1261 must be a noncomplex scalar double.");
    } 
    mexinput1261_temp = mxGetPr(prhs[1261]); 
    double mexinput1261 = *mexinput1261_temp; 

    double *mexinput1262_temp = NULL; 
    if( !mxIsDouble(prhs[1262]) || mxIsComplex(prhs[1262]) || !(mxGetM(prhs[1262])==1 && mxGetN(prhs[1262])==1) ) { 
      mexErrMsgTxt("Input 1262 must be a noncomplex scalar double.");
    } 
    mexinput1262_temp = mxGetPr(prhs[1262]); 
    double mexinput1262 = *mexinput1262_temp; 

    double *mexinput1263_temp = NULL; 
    if( !mxIsDouble(prhs[1263]) || mxIsComplex(prhs[1263]) || !(mxGetM(prhs[1263])==1 && mxGetN(prhs[1263])==1) ) { 
      mexErrMsgTxt("Input 1263 must be a noncomplex scalar double.");
    } 
    mexinput1263_temp = mxGetPr(prhs[1263]); 
    double mexinput1263 = *mexinput1263_temp; 

    double *mexinput1264_temp = NULL; 
    if( !mxIsDouble(prhs[1264]) || mxIsComplex(prhs[1264]) || !(mxGetM(prhs[1264])==1 && mxGetN(prhs[1264])==1) ) { 
      mexErrMsgTxt("Input 1264 must be a noncomplex scalar double.");
    } 
    mexinput1264_temp = mxGetPr(prhs[1264]); 
    double mexinput1264 = *mexinput1264_temp; 

    double *mexinput1265_temp = NULL; 
    if( !mxIsDouble(prhs[1265]) || mxIsComplex(prhs[1265]) || !(mxGetM(prhs[1265])==1 && mxGetN(prhs[1265])==1) ) { 
      mexErrMsgTxt("Input 1265 must be a noncomplex scalar double.");
    } 
    mexinput1265_temp = mxGetPr(prhs[1265]); 
    double mexinput1265 = *mexinput1265_temp; 

    double *mexinput1266_temp = NULL; 
    if( !mxIsDouble(prhs[1266]) || mxIsComplex(prhs[1266]) || !(mxGetM(prhs[1266])==1 && mxGetN(prhs[1266])==1) ) { 
      mexErrMsgTxt("Input 1266 must be a noncomplex scalar double.");
    } 
    mexinput1266_temp = mxGetPr(prhs[1266]); 
    double mexinput1266 = *mexinput1266_temp; 

    double *mexinput1267_temp = NULL; 
    if( !mxIsDouble(prhs[1267]) || mxIsComplex(prhs[1267]) || !(mxGetM(prhs[1267])==1 && mxGetN(prhs[1267])==1) ) { 
      mexErrMsgTxt("Input 1267 must be a noncomplex scalar double.");
    } 
    mexinput1267_temp = mxGetPr(prhs[1267]); 
    double mexinput1267 = *mexinput1267_temp; 

    double *mexinput1268_temp = NULL; 
    if( !mxIsDouble(prhs[1268]) || mxIsComplex(prhs[1268]) || !(mxGetM(prhs[1268])==1 && mxGetN(prhs[1268])==1) ) { 
      mexErrMsgTxt("Input 1268 must be a noncomplex scalar double.");
    } 
    mexinput1268_temp = mxGetPr(prhs[1268]); 
    double mexinput1268 = *mexinput1268_temp; 

    double *mexinput1269_temp = NULL; 
    if( !mxIsDouble(prhs[1269]) || mxIsComplex(prhs[1269]) || !(mxGetM(prhs[1269])==1 && mxGetN(prhs[1269])==1) ) { 
      mexErrMsgTxt("Input 1269 must be a noncomplex scalar double.");
    } 
    mexinput1269_temp = mxGetPr(prhs[1269]); 
    double mexinput1269 = *mexinput1269_temp; 

    double *mexinput1270_temp = NULL; 
    if( !mxIsDouble(prhs[1270]) || mxIsComplex(prhs[1270]) || !(mxGetM(prhs[1270])==1 && mxGetN(prhs[1270])==1) ) { 
      mexErrMsgTxt("Input 1270 must be a noncomplex scalar double.");
    } 
    mexinput1270_temp = mxGetPr(prhs[1270]); 
    double mexinput1270 = *mexinput1270_temp; 

    double *mexinput1271_temp = NULL; 
    if( !mxIsDouble(prhs[1271]) || mxIsComplex(prhs[1271]) || !(mxGetM(prhs[1271])==1 && mxGetN(prhs[1271])==1) ) { 
      mexErrMsgTxt("Input 1271 must be a noncomplex scalar double.");
    } 
    mexinput1271_temp = mxGetPr(prhs[1271]); 
    double mexinput1271 = *mexinput1271_temp; 

    double *mexinput1272_temp = NULL; 
    if( !mxIsDouble(prhs[1272]) || mxIsComplex(prhs[1272]) || !(mxGetM(prhs[1272])==1 && mxGetN(prhs[1272])==1) ) { 
      mexErrMsgTxt("Input 1272 must be a noncomplex scalar double.");
    } 
    mexinput1272_temp = mxGetPr(prhs[1272]); 
    double mexinput1272 = *mexinput1272_temp; 

    double *mexinput1273_temp = NULL; 
    if( !mxIsDouble(prhs[1273]) || mxIsComplex(prhs[1273]) || !(mxGetM(prhs[1273])==1 && mxGetN(prhs[1273])==1) ) { 
      mexErrMsgTxt("Input 1273 must be a noncomplex scalar double.");
    } 
    mexinput1273_temp = mxGetPr(prhs[1273]); 
    double mexinput1273 = *mexinput1273_temp; 

    double *mexinput1274_temp = NULL; 
    if( !mxIsDouble(prhs[1274]) || mxIsComplex(prhs[1274]) || !(mxGetM(prhs[1274])==1 && mxGetN(prhs[1274])==1) ) { 
      mexErrMsgTxt("Input 1274 must be a noncomplex scalar double.");
    } 
    mexinput1274_temp = mxGetPr(prhs[1274]); 
    double mexinput1274 = *mexinput1274_temp; 

    double *mexinput1275_temp = NULL; 
    if( !mxIsDouble(prhs[1275]) || mxIsComplex(prhs[1275]) || !(mxGetM(prhs[1275])==1 && mxGetN(prhs[1275])==1) ) { 
      mexErrMsgTxt("Input 1275 must be a noncomplex scalar double.");
    } 
    mexinput1275_temp = mxGetPr(prhs[1275]); 
    double mexinput1275 = *mexinput1275_temp; 

    double *mexinput1276_temp = NULL; 
    if( !mxIsDouble(prhs[1276]) || mxIsComplex(prhs[1276]) || !(mxGetM(prhs[1276])==1 && mxGetN(prhs[1276])==1) ) { 
      mexErrMsgTxt("Input 1276 must be a noncomplex scalar double.");
    } 
    mexinput1276_temp = mxGetPr(prhs[1276]); 
    double mexinput1276 = *mexinput1276_temp; 

    double *mexinput1277_temp = NULL; 
    if( !mxIsDouble(prhs[1277]) || mxIsComplex(prhs[1277]) || !(mxGetM(prhs[1277])==1 && mxGetN(prhs[1277])==1) ) { 
      mexErrMsgTxt("Input 1277 must be a noncomplex scalar double.");
    } 
    mexinput1277_temp = mxGetPr(prhs[1277]); 
    double mexinput1277 = *mexinput1277_temp; 

    double *mexinput1278_temp = NULL; 
    if( !mxIsDouble(prhs[1278]) || mxIsComplex(prhs[1278]) || !(mxGetM(prhs[1278])==1 && mxGetN(prhs[1278])==1) ) { 
      mexErrMsgTxt("Input 1278 must be a noncomplex scalar double.");
    } 
    mexinput1278_temp = mxGetPr(prhs[1278]); 
    double mexinput1278 = *mexinput1278_temp; 

    double *mexinput1279_temp = NULL; 
    if( !mxIsDouble(prhs[1279]) || mxIsComplex(prhs[1279]) || !(mxGetM(prhs[1279])==1 && mxGetN(prhs[1279])==1) ) { 
      mexErrMsgTxt("Input 1279 must be a noncomplex scalar double.");
    } 
    mexinput1279_temp = mxGetPr(prhs[1279]); 
    double mexinput1279 = *mexinput1279_temp; 

    double *mexinput1280_temp = NULL; 
    if( !mxIsDouble(prhs[1280]) || mxIsComplex(prhs[1280]) || !(mxGetM(prhs[1280])==1 && mxGetN(prhs[1280])==1) ) { 
      mexErrMsgTxt("Input 1280 must be a noncomplex scalar double.");
    } 
    mexinput1280_temp = mxGetPr(prhs[1280]); 
    double mexinput1280 = *mexinput1280_temp; 

    double *mexinput1281_temp = NULL; 
    if( !mxIsDouble(prhs[1281]) || mxIsComplex(prhs[1281]) || !(mxGetM(prhs[1281])==1 && mxGetN(prhs[1281])==1) ) { 
      mexErrMsgTxt("Input 1281 must be a noncomplex scalar double.");
    } 
    mexinput1281_temp = mxGetPr(prhs[1281]); 
    double mexinput1281 = *mexinput1281_temp; 

    double *mexinput1282_temp = NULL; 
    if( !mxIsDouble(prhs[1282]) || mxIsComplex(prhs[1282]) || !(mxGetM(prhs[1282])==1 && mxGetN(prhs[1282])==1) ) { 
      mexErrMsgTxt("Input 1282 must be a noncomplex scalar double.");
    } 
    mexinput1282_temp = mxGetPr(prhs[1282]); 
    double mexinput1282 = *mexinput1282_temp; 

    double *mexinput1283_temp = NULL; 
    if( !mxIsDouble(prhs[1283]) || mxIsComplex(prhs[1283]) || !(mxGetM(prhs[1283])==1 && mxGetN(prhs[1283])==1) ) { 
      mexErrMsgTxt("Input 1283 must be a noncomplex scalar double.");
    } 
    mexinput1283_temp = mxGetPr(prhs[1283]); 
    double mexinput1283 = *mexinput1283_temp; 

    double *mexinput1284_temp = NULL; 
    if( !mxIsDouble(prhs[1284]) || mxIsComplex(prhs[1284]) || !(mxGetM(prhs[1284])==1 && mxGetN(prhs[1284])==1) ) { 
      mexErrMsgTxt("Input 1284 must be a noncomplex scalar double.");
    } 
    mexinput1284_temp = mxGetPr(prhs[1284]); 
    double mexinput1284 = *mexinput1284_temp; 

    double *mexinput1285_temp = NULL; 
    if( !mxIsDouble(prhs[1285]) || mxIsComplex(prhs[1285]) || !(mxGetM(prhs[1285])==1 && mxGetN(prhs[1285])==1) ) { 
      mexErrMsgTxt("Input 1285 must be a noncomplex scalar double.");
    } 
    mexinput1285_temp = mxGetPr(prhs[1285]); 
    double mexinput1285 = *mexinput1285_temp; 

    double *mexinput1286_temp = NULL; 
    if( !mxIsDouble(prhs[1286]) || mxIsComplex(prhs[1286]) || !(mxGetM(prhs[1286])==1 && mxGetN(prhs[1286])==1) ) { 
      mexErrMsgTxt("Input 1286 must be a noncomplex scalar double.");
    } 
    mexinput1286_temp = mxGetPr(prhs[1286]); 
    double mexinput1286 = *mexinput1286_temp; 

    double *mexinput1287_temp = NULL; 
    if( !mxIsDouble(prhs[1287]) || mxIsComplex(prhs[1287]) || !(mxGetM(prhs[1287])==1 && mxGetN(prhs[1287])==1) ) { 
      mexErrMsgTxt("Input 1287 must be a noncomplex scalar double.");
    } 
    mexinput1287_temp = mxGetPr(prhs[1287]); 
    double mexinput1287 = *mexinput1287_temp; 

    double *mexinput1288_temp = NULL; 
    if( !mxIsDouble(prhs[1288]) || mxIsComplex(prhs[1288]) || !(mxGetM(prhs[1288])==1 && mxGetN(prhs[1288])==1) ) { 
      mexErrMsgTxt("Input 1288 must be a noncomplex scalar double.");
    } 
    mexinput1288_temp = mxGetPr(prhs[1288]); 
    double mexinput1288 = *mexinput1288_temp; 

    double *mexinput1289_temp = NULL; 
    if( !mxIsDouble(prhs[1289]) || mxIsComplex(prhs[1289]) || !(mxGetM(prhs[1289])==1 && mxGetN(prhs[1289])==1) ) { 
      mexErrMsgTxt("Input 1289 must be a noncomplex scalar double.");
    } 
    mexinput1289_temp = mxGetPr(prhs[1289]); 
    double mexinput1289 = *mexinput1289_temp; 

    double *mexinput1290_temp = NULL; 
    if( !mxIsDouble(prhs[1290]) || mxIsComplex(prhs[1290]) || !(mxGetM(prhs[1290])==1 && mxGetN(prhs[1290])==1) ) { 
      mexErrMsgTxt("Input 1290 must be a noncomplex scalar double.");
    } 
    mexinput1290_temp = mxGetPr(prhs[1290]); 
    double mexinput1290 = *mexinput1290_temp; 

    double *mexinput1291_temp = NULL; 
    if( !mxIsDouble(prhs[1291]) || mxIsComplex(prhs[1291]) || !(mxGetM(prhs[1291])==1 && mxGetN(prhs[1291])==1) ) { 
      mexErrMsgTxt("Input 1291 must be a noncomplex scalar double.");
    } 
    mexinput1291_temp = mxGetPr(prhs[1291]); 
    double mexinput1291 = *mexinput1291_temp; 

    double *mexinput1292_temp = NULL; 
    if( !mxIsDouble(prhs[1292]) || mxIsComplex(prhs[1292]) || !(mxGetM(prhs[1292])==1 && mxGetN(prhs[1292])==1) ) { 
      mexErrMsgTxt("Input 1292 must be a noncomplex scalar double.");
    } 
    mexinput1292_temp = mxGetPr(prhs[1292]); 
    double mexinput1292 = *mexinput1292_temp; 

    double *mexinput1293_temp = NULL; 
    if( !mxIsDouble(prhs[1293]) || mxIsComplex(prhs[1293]) || !(mxGetM(prhs[1293])==1 && mxGetN(prhs[1293])==1) ) { 
      mexErrMsgTxt("Input 1293 must be a noncomplex scalar double.");
    } 
    mexinput1293_temp = mxGetPr(prhs[1293]); 
    double mexinput1293 = *mexinput1293_temp; 

    double *mexinput1294_temp = NULL; 
    if( !mxIsDouble(prhs[1294]) || mxIsComplex(prhs[1294]) || !(mxGetM(prhs[1294])==1 && mxGetN(prhs[1294])==1) ) { 
      mexErrMsgTxt("Input 1294 must be a noncomplex scalar double.");
    } 
    mexinput1294_temp = mxGetPr(prhs[1294]); 
    double mexinput1294 = *mexinput1294_temp; 

    double *mexinput1295_temp = NULL; 
    if( !mxIsDouble(prhs[1295]) || mxIsComplex(prhs[1295]) || !(mxGetM(prhs[1295])==1 && mxGetN(prhs[1295])==1) ) { 
      mexErrMsgTxt("Input 1295 must be a noncomplex scalar double.");
    } 
    mexinput1295_temp = mxGetPr(prhs[1295]); 
    double mexinput1295 = *mexinput1295_temp; 

    double *mexinput1296_temp = NULL; 
    if( !mxIsDouble(prhs[1296]) || mxIsComplex(prhs[1296]) || !(mxGetM(prhs[1296])==1 && mxGetN(prhs[1296])==1) ) { 
      mexErrMsgTxt("Input 1296 must be a noncomplex scalar double.");
    } 
    mexinput1296_temp = mxGetPr(prhs[1296]); 
    double mexinput1296 = *mexinput1296_temp; 

    double *mexinput1297_temp = NULL; 
    if( !mxIsDouble(prhs[1297]) || mxIsComplex(prhs[1297]) || !(mxGetM(prhs[1297])==1 && mxGetN(prhs[1297])==1) ) { 
      mexErrMsgTxt("Input 1297 must be a noncomplex scalar double.");
    } 
    mexinput1297_temp = mxGetPr(prhs[1297]); 
    double mexinput1297 = *mexinput1297_temp; 

    double *mexinput1298_temp = NULL; 
    if( !mxIsDouble(prhs[1298]) || mxIsComplex(prhs[1298]) || !(mxGetM(prhs[1298])==1 && mxGetN(prhs[1298])==1) ) { 
      mexErrMsgTxt("Input 1298 must be a noncomplex scalar double.");
    } 
    mexinput1298_temp = mxGetPr(prhs[1298]); 
    double mexinput1298 = *mexinput1298_temp; 

    double *mexinput1299_temp = NULL; 
    if( !mxIsDouble(prhs[1299]) || mxIsComplex(prhs[1299]) || !(mxGetM(prhs[1299])==1 && mxGetN(prhs[1299])==1) ) { 
      mexErrMsgTxt("Input 1299 must be a noncomplex scalar double.");
    } 
    mexinput1299_temp = mxGetPr(prhs[1299]); 
    double mexinput1299 = *mexinput1299_temp; 

    double *mexinput1300_temp = NULL; 
    if( !mxIsDouble(prhs[1300]) || mxIsComplex(prhs[1300]) || !(mxGetM(prhs[1300])==1 && mxGetN(prhs[1300])==1) ) { 
      mexErrMsgTxt("Input 1300 must be a noncomplex scalar double.");
    } 
    mexinput1300_temp = mxGetPr(prhs[1300]); 
    double mexinput1300 = *mexinput1300_temp; 

    double *mexinput1301_temp = NULL; 
    if( !mxIsDouble(prhs[1301]) || mxIsComplex(prhs[1301]) || !(mxGetM(prhs[1301])==1 && mxGetN(prhs[1301])==1) ) { 
      mexErrMsgTxt("Input 1301 must be a noncomplex scalar double.");
    } 
    mexinput1301_temp = mxGetPr(prhs[1301]); 
    double mexinput1301 = *mexinput1301_temp; 

    double *mexinput1302_temp = NULL; 
    if( !mxIsDouble(prhs[1302]) || mxIsComplex(prhs[1302]) || !(mxGetM(prhs[1302])==1 && mxGetN(prhs[1302])==1) ) { 
      mexErrMsgTxt("Input 1302 must be a noncomplex scalar double.");
    } 
    mexinput1302_temp = mxGetPr(prhs[1302]); 
    double mexinput1302 = *mexinput1302_temp; 

    double *mexinput1303_temp = NULL; 
    if( !mxIsDouble(prhs[1303]) || mxIsComplex(prhs[1303]) || !(mxGetM(prhs[1303])==1 && mxGetN(prhs[1303])==1) ) { 
      mexErrMsgTxt("Input 1303 must be a noncomplex scalar double.");
    } 
    mexinput1303_temp = mxGetPr(prhs[1303]); 
    double mexinput1303 = *mexinput1303_temp; 

    double *mexinput1304_temp = NULL; 
    if( !mxIsDouble(prhs[1304]) || mxIsComplex(prhs[1304]) || !(mxGetM(prhs[1304])==1 && mxGetN(prhs[1304])==1) ) { 
      mexErrMsgTxt("Input 1304 must be a noncomplex scalar double.");
    } 
    mexinput1304_temp = mxGetPr(prhs[1304]); 
    double mexinput1304 = *mexinput1304_temp; 

    double *mexinput1305_temp = NULL; 
    if( !mxIsDouble(prhs[1305]) || mxIsComplex(prhs[1305]) || !(mxGetM(prhs[1305])==1 && mxGetN(prhs[1305])==1) ) { 
      mexErrMsgTxt("Input 1305 must be a noncomplex scalar double.");
    } 
    mexinput1305_temp = mxGetPr(prhs[1305]); 
    double mexinput1305 = *mexinput1305_temp; 

    double *mexinput1306_temp = NULL; 
    if( !mxIsDouble(prhs[1306]) || mxIsComplex(prhs[1306]) || !(mxGetM(prhs[1306])==1 && mxGetN(prhs[1306])==1) ) { 
      mexErrMsgTxt("Input 1306 must be a noncomplex scalar double.");
    } 
    mexinput1306_temp = mxGetPr(prhs[1306]); 
    double mexinput1306 = *mexinput1306_temp; 

    double *mexinput1307_temp = NULL; 
    if( !mxIsDouble(prhs[1307]) || mxIsComplex(prhs[1307]) || !(mxGetM(prhs[1307])==1 && mxGetN(prhs[1307])==1) ) { 
      mexErrMsgTxt("Input 1307 must be a noncomplex scalar double.");
    } 
    mexinput1307_temp = mxGetPr(prhs[1307]); 
    double mexinput1307 = *mexinput1307_temp; 

    double *mexinput1308_temp = NULL; 
    if( !mxIsDouble(prhs[1308]) || mxIsComplex(prhs[1308]) || !(mxGetM(prhs[1308])==1 && mxGetN(prhs[1308])==1) ) { 
      mexErrMsgTxt("Input 1308 must be a noncomplex scalar double.");
    } 
    mexinput1308_temp = mxGetPr(prhs[1308]); 
    double mexinput1308 = *mexinput1308_temp; 

    double *mexinput1309_temp = NULL; 
    if( !mxIsDouble(prhs[1309]) || mxIsComplex(prhs[1309]) || !(mxGetM(prhs[1309])==1 && mxGetN(prhs[1309])==1) ) { 
      mexErrMsgTxt("Input 1309 must be a noncomplex scalar double.");
    } 
    mexinput1309_temp = mxGetPr(prhs[1309]); 
    double mexinput1309 = *mexinput1309_temp; 

    double *mexinput1310_temp = NULL; 
    if( !mxIsDouble(prhs[1310]) || mxIsComplex(prhs[1310]) || !(mxGetM(prhs[1310])==1 && mxGetN(prhs[1310])==1) ) { 
      mexErrMsgTxt("Input 1310 must be a noncomplex scalar double.");
    } 
    mexinput1310_temp = mxGetPr(prhs[1310]); 
    double mexinput1310 = *mexinput1310_temp; 

    double *mexinput1311_temp = NULL; 
    if( !mxIsDouble(prhs[1311]) || mxIsComplex(prhs[1311]) || !(mxGetM(prhs[1311])==1 && mxGetN(prhs[1311])==1) ) { 
      mexErrMsgTxt("Input 1311 must be a noncomplex scalar double.");
    } 
    mexinput1311_temp = mxGetPr(prhs[1311]); 
    double mexinput1311 = *mexinput1311_temp; 

    double *mexinput1312_temp = NULL; 
    if( !mxIsDouble(prhs[1312]) || mxIsComplex(prhs[1312]) || !(mxGetM(prhs[1312])==1 && mxGetN(prhs[1312])==1) ) { 
      mexErrMsgTxt("Input 1312 must be a noncomplex scalar double.");
    } 
    mexinput1312_temp = mxGetPr(prhs[1312]); 
    double mexinput1312 = *mexinput1312_temp; 

    double *mexinput1313_temp = NULL; 
    if( !mxIsDouble(prhs[1313]) || mxIsComplex(prhs[1313]) || !(mxGetM(prhs[1313])==1 && mxGetN(prhs[1313])==1) ) { 
      mexErrMsgTxt("Input 1313 must be a noncomplex scalar double.");
    } 
    mexinput1313_temp = mxGetPr(prhs[1313]); 
    double mexinput1313 = *mexinput1313_temp; 

    double *mexinput1314_temp = NULL; 
    if( !mxIsDouble(prhs[1314]) || mxIsComplex(prhs[1314]) || !(mxGetM(prhs[1314])==1 && mxGetN(prhs[1314])==1) ) { 
      mexErrMsgTxt("Input 1314 must be a noncomplex scalar double.");
    } 
    mexinput1314_temp = mxGetPr(prhs[1314]); 
    double mexinput1314 = *mexinput1314_temp; 

    double *mexinput1315_temp = NULL; 
    if( !mxIsDouble(prhs[1315]) || mxIsComplex(prhs[1315]) || !(mxGetM(prhs[1315])==1 && mxGetN(prhs[1315])==1) ) { 
      mexErrMsgTxt("Input 1315 must be a noncomplex scalar double.");
    } 
    mexinput1315_temp = mxGetPr(prhs[1315]); 
    double mexinput1315 = *mexinput1315_temp; 

    double *mexinput1316_temp = NULL; 
    if( !mxIsDouble(prhs[1316]) || mxIsComplex(prhs[1316]) || !(mxGetM(prhs[1316])==1 && mxGetN(prhs[1316])==1) ) { 
      mexErrMsgTxt("Input 1316 must be a noncomplex scalar double.");
    } 
    mexinput1316_temp = mxGetPr(prhs[1316]); 
    double mexinput1316 = *mexinput1316_temp; 

    double *mexinput1317_temp = NULL; 
    if( !mxIsDouble(prhs[1317]) || mxIsComplex(prhs[1317]) || !(mxGetM(prhs[1317])==1 && mxGetN(prhs[1317])==1) ) { 
      mexErrMsgTxt("Input 1317 must be a noncomplex scalar double.");
    } 
    mexinput1317_temp = mxGetPr(prhs[1317]); 
    double mexinput1317 = *mexinput1317_temp; 

    double *mexinput1318_temp = NULL; 
    if( !mxIsDouble(prhs[1318]) || mxIsComplex(prhs[1318]) || !(mxGetM(prhs[1318])==1 && mxGetN(prhs[1318])==1) ) { 
      mexErrMsgTxt("Input 1318 must be a noncomplex scalar double.");
    } 
    mexinput1318_temp = mxGetPr(prhs[1318]); 
    double mexinput1318 = *mexinput1318_temp; 

    double *mexinput1319_temp = NULL; 
    if( !mxIsDouble(prhs[1319]) || mxIsComplex(prhs[1319]) || !(mxGetM(prhs[1319])==1 && mxGetN(prhs[1319])==1) ) { 
      mexErrMsgTxt("Input 1319 must be a noncomplex scalar double.");
    } 
    mexinput1319_temp = mxGetPr(prhs[1319]); 
    double mexinput1319 = *mexinput1319_temp; 

    double *mexinput1320_temp = NULL; 
    if( !mxIsDouble(prhs[1320]) || mxIsComplex(prhs[1320]) || !(mxGetM(prhs[1320])==1 && mxGetN(prhs[1320])==1) ) { 
      mexErrMsgTxt("Input 1320 must be a noncomplex scalar double.");
    } 
    mexinput1320_temp = mxGetPr(prhs[1320]); 
    double mexinput1320 = *mexinput1320_temp; 

    double *mexinput1321_temp = NULL; 
    if( !mxIsDouble(prhs[1321]) || mxIsComplex(prhs[1321]) || !(mxGetM(prhs[1321])==1 && mxGetN(prhs[1321])==1) ) { 
      mexErrMsgTxt("Input 1321 must be a noncomplex scalar double.");
    } 
    mexinput1321_temp = mxGetPr(prhs[1321]); 
    double mexinput1321 = *mexinput1321_temp; 

    double *mexinput1322_temp = NULL; 
    if( !mxIsDouble(prhs[1322]) || mxIsComplex(prhs[1322]) || !(mxGetM(prhs[1322])==1 && mxGetN(prhs[1322])==1) ) { 
      mexErrMsgTxt("Input 1322 must be a noncomplex scalar double.");
    } 
    mexinput1322_temp = mxGetPr(prhs[1322]); 
    double mexinput1322 = *mexinput1322_temp; 

    double *mexinput1323_temp = NULL; 
    if( !mxIsDouble(prhs[1323]) || mxIsComplex(prhs[1323]) || !(mxGetM(prhs[1323])==1 && mxGetN(prhs[1323])==1) ) { 
      mexErrMsgTxt("Input 1323 must be a noncomplex scalar double.");
    } 
    mexinput1323_temp = mxGetPr(prhs[1323]); 
    double mexinput1323 = *mexinput1323_temp; 

    double *mexinput1324_temp = NULL; 
    if( !mxIsDouble(prhs[1324]) || mxIsComplex(prhs[1324]) || !(mxGetM(prhs[1324])==1 && mxGetN(prhs[1324])==1) ) { 
      mexErrMsgTxt("Input 1324 must be a noncomplex scalar double.");
    } 
    mexinput1324_temp = mxGetPr(prhs[1324]); 
    double mexinput1324 = *mexinput1324_temp; 

    double *mexinput1325_temp = NULL; 
    if( !mxIsDouble(prhs[1325]) || mxIsComplex(prhs[1325]) || !(mxGetM(prhs[1325])==1 && mxGetN(prhs[1325])==1) ) { 
      mexErrMsgTxt("Input 1325 must be a noncomplex scalar double.");
    } 
    mexinput1325_temp = mxGetPr(prhs[1325]); 
    double mexinput1325 = *mexinput1325_temp; 

    double *mexinput1326_temp = NULL; 
    if( !mxIsDouble(prhs[1326]) || mxIsComplex(prhs[1326]) || !(mxGetM(prhs[1326])==1 && mxGetN(prhs[1326])==1) ) { 
      mexErrMsgTxt("Input 1326 must be a noncomplex scalar double.");
    } 
    mexinput1326_temp = mxGetPr(prhs[1326]); 
    double mexinput1326 = *mexinput1326_temp; 

    double *mexinput1327_temp = NULL; 
    if( !mxIsDouble(prhs[1327]) || mxIsComplex(prhs[1327]) || !(mxGetM(prhs[1327])==1 && mxGetN(prhs[1327])==1) ) { 
      mexErrMsgTxt("Input 1327 must be a noncomplex scalar double.");
    } 
    mexinput1327_temp = mxGetPr(prhs[1327]); 
    double mexinput1327 = *mexinput1327_temp; 

    double *mexinput1328_temp = NULL; 
    if( !mxIsDouble(prhs[1328]) || mxIsComplex(prhs[1328]) || !(mxGetM(prhs[1328])==1 && mxGetN(prhs[1328])==1) ) { 
      mexErrMsgTxt("Input 1328 must be a noncomplex scalar double.");
    } 
    mexinput1328_temp = mxGetPr(prhs[1328]); 
    double mexinput1328 = *mexinput1328_temp; 

    double *mexinput1329_temp = NULL; 
    if( !mxIsDouble(prhs[1329]) || mxIsComplex(prhs[1329]) || !(mxGetM(prhs[1329])==1 && mxGetN(prhs[1329])==1) ) { 
      mexErrMsgTxt("Input 1329 must be a noncomplex scalar double.");
    } 
    mexinput1329_temp = mxGetPr(prhs[1329]); 
    double mexinput1329 = *mexinput1329_temp; 

    double *mexinput1330_temp = NULL; 
    if( !mxIsDouble(prhs[1330]) || mxIsComplex(prhs[1330]) || !(mxGetM(prhs[1330])==1 && mxGetN(prhs[1330])==1) ) { 
      mexErrMsgTxt("Input 1330 must be a noncomplex scalar double.");
    } 
    mexinput1330_temp = mxGetPr(prhs[1330]); 
    double mexinput1330 = *mexinput1330_temp; 

    double *mexinput1331_temp = NULL; 
    if( !mxIsDouble(prhs[1331]) || mxIsComplex(prhs[1331]) || !(mxGetM(prhs[1331])==1 && mxGetN(prhs[1331])==1) ) { 
      mexErrMsgTxt("Input 1331 must be a noncomplex scalar double.");
    } 
    mexinput1331_temp = mxGetPr(prhs[1331]); 
    double mexinput1331 = *mexinput1331_temp; 

    double *mexinput1332_temp = NULL; 
    if( !mxIsDouble(prhs[1332]) || mxIsComplex(prhs[1332]) || !(mxGetM(prhs[1332])==1 && mxGetN(prhs[1332])==1) ) { 
      mexErrMsgTxt("Input 1332 must be a noncomplex scalar double.");
    } 
    mexinput1332_temp = mxGetPr(prhs[1332]); 
    double mexinput1332 = *mexinput1332_temp; 

    double *mexinput1333_temp = NULL; 
    if( !mxIsDouble(prhs[1333]) || mxIsComplex(prhs[1333]) || !(mxGetM(prhs[1333])==1 && mxGetN(prhs[1333])==1) ) { 
      mexErrMsgTxt("Input 1333 must be a noncomplex scalar double.");
    } 
    mexinput1333_temp = mxGetPr(prhs[1333]); 
    double mexinput1333 = *mexinput1333_temp; 

    double *mexinput1334_temp = NULL; 
    if( !mxIsDouble(prhs[1334]) || mxIsComplex(prhs[1334]) || !(mxGetM(prhs[1334])==1 && mxGetN(prhs[1334])==1) ) { 
      mexErrMsgTxt("Input 1334 must be a noncomplex scalar double.");
    } 
    mexinput1334_temp = mxGetPr(prhs[1334]); 
    double mexinput1334 = *mexinput1334_temp; 

    double *mexinput1335_temp = NULL; 
    if( !mxIsDouble(prhs[1335]) || mxIsComplex(prhs[1335]) || !(mxGetM(prhs[1335])==1 && mxGetN(prhs[1335])==1) ) { 
      mexErrMsgTxt("Input 1335 must be a noncomplex scalar double.");
    } 
    mexinput1335_temp = mxGetPr(prhs[1335]); 
    double mexinput1335 = *mexinput1335_temp; 

    double *mexinput1336_temp = NULL; 
    if( !mxIsDouble(prhs[1336]) || mxIsComplex(prhs[1336]) || !(mxGetM(prhs[1336])==1 && mxGetN(prhs[1336])==1) ) { 
      mexErrMsgTxt("Input 1336 must be a noncomplex scalar double.");
    } 
    mexinput1336_temp = mxGetPr(prhs[1336]); 
    double mexinput1336 = *mexinput1336_temp; 

    double *mexinput1337_temp = NULL; 
    if( !mxIsDouble(prhs[1337]) || mxIsComplex(prhs[1337]) || !(mxGetM(prhs[1337])==1 && mxGetN(prhs[1337])==1) ) { 
      mexErrMsgTxt("Input 1337 must be a noncomplex scalar double.");
    } 
    mexinput1337_temp = mxGetPr(prhs[1337]); 
    double mexinput1337 = *mexinput1337_temp; 

    double *mexinput1338_temp = NULL; 
    if( !mxIsDouble(prhs[1338]) || mxIsComplex(prhs[1338]) || !(mxGetM(prhs[1338])==1 && mxGetN(prhs[1338])==1) ) { 
      mexErrMsgTxt("Input 1338 must be a noncomplex scalar double.");
    } 
    mexinput1338_temp = mxGetPr(prhs[1338]); 
    double mexinput1338 = *mexinput1338_temp; 

    double *mexinput1339_temp = NULL; 
    if( !mxIsDouble(prhs[1339]) || mxIsComplex(prhs[1339]) || !(mxGetM(prhs[1339])==1 && mxGetN(prhs[1339])==1) ) { 
      mexErrMsgTxt("Input 1339 must be a noncomplex scalar double.");
    } 
    mexinput1339_temp = mxGetPr(prhs[1339]); 
    double mexinput1339 = *mexinput1339_temp; 

    double *mexinput1340_temp = NULL; 
    if( !mxIsDouble(prhs[1340]) || mxIsComplex(prhs[1340]) || !(mxGetM(prhs[1340])==1 && mxGetN(prhs[1340])==1) ) { 
      mexErrMsgTxt("Input 1340 must be a noncomplex scalar double.");
    } 
    mexinput1340_temp = mxGetPr(prhs[1340]); 
    double mexinput1340 = *mexinput1340_temp; 

    double *mexinput1341_temp = NULL; 
    if( !mxIsDouble(prhs[1341]) || mxIsComplex(prhs[1341]) || !(mxGetM(prhs[1341])==1 && mxGetN(prhs[1341])==1) ) { 
      mexErrMsgTxt("Input 1341 must be a noncomplex scalar double.");
    } 
    mexinput1341_temp = mxGetPr(prhs[1341]); 
    double mexinput1341 = *mexinput1341_temp; 

    double *mexinput1342_temp = NULL; 
    if( !mxIsDouble(prhs[1342]) || mxIsComplex(prhs[1342]) || !(mxGetM(prhs[1342])==1 && mxGetN(prhs[1342])==1) ) { 
      mexErrMsgTxt("Input 1342 must be a noncomplex scalar double.");
    } 
    mexinput1342_temp = mxGetPr(prhs[1342]); 
    double mexinput1342 = *mexinput1342_temp; 

    double *mexinput1343_temp = NULL; 
    if( !mxIsDouble(prhs[1343]) || mxIsComplex(prhs[1343]) || !(mxGetM(prhs[1343])==1 && mxGetN(prhs[1343])==1) ) { 
      mexErrMsgTxt("Input 1343 must be a noncomplex scalar double.");
    } 
    mexinput1343_temp = mxGetPr(prhs[1343]); 
    double mexinput1343 = *mexinput1343_temp; 

    double *mexinput1344_temp = NULL; 
    if( !mxIsDouble(prhs[1344]) || mxIsComplex(prhs[1344]) || !(mxGetM(prhs[1344])==1 && mxGetN(prhs[1344])==1) ) { 
      mexErrMsgTxt("Input 1344 must be a noncomplex scalar double.");
    } 
    mexinput1344_temp = mxGetPr(prhs[1344]); 
    double mexinput1344 = *mexinput1344_temp; 

    double *mexinput1345_temp = NULL; 
    if( !mxIsDouble(prhs[1345]) || mxIsComplex(prhs[1345]) || !(mxGetM(prhs[1345])==1 && mxGetN(prhs[1345])==1) ) { 
      mexErrMsgTxt("Input 1345 must be a noncomplex scalar double.");
    } 
    mexinput1345_temp = mxGetPr(prhs[1345]); 
    double mexinput1345 = *mexinput1345_temp; 

    double *mexinput1346_temp = NULL; 
    if( !mxIsDouble(prhs[1346]) || mxIsComplex(prhs[1346]) || !(mxGetM(prhs[1346])==1 && mxGetN(prhs[1346])==1) ) { 
      mexErrMsgTxt("Input 1346 must be a noncomplex scalar double.");
    } 
    mexinput1346_temp = mxGetPr(prhs[1346]); 
    double mexinput1346 = *mexinput1346_temp; 

    double *mexinput1347_temp = NULL; 
    if( !mxIsDouble(prhs[1347]) || mxIsComplex(prhs[1347]) || !(mxGetM(prhs[1347])==1 && mxGetN(prhs[1347])==1) ) { 
      mexErrMsgTxt("Input 1347 must be a noncomplex scalar double.");
    } 
    mexinput1347_temp = mxGetPr(prhs[1347]); 
    double mexinput1347 = *mexinput1347_temp; 

    double *mexinput1348_temp = NULL; 
    if( !mxIsDouble(prhs[1348]) || mxIsComplex(prhs[1348]) || !(mxGetM(prhs[1348])==1 && mxGetN(prhs[1348])==1) ) { 
      mexErrMsgTxt("Input 1348 must be a noncomplex scalar double.");
    } 
    mexinput1348_temp = mxGetPr(prhs[1348]); 
    double mexinput1348 = *mexinput1348_temp; 

    double *mexinput1349_temp = NULL; 
    if( !mxIsDouble(prhs[1349]) || mxIsComplex(prhs[1349]) || !(mxGetM(prhs[1349])==1 && mxGetN(prhs[1349])==1) ) { 
      mexErrMsgTxt("Input 1349 must be a noncomplex scalar double.");
    } 
    mexinput1349_temp = mxGetPr(prhs[1349]); 
    double mexinput1349 = *mexinput1349_temp; 

    double *mexinput1350_temp = NULL; 
    if( !mxIsDouble(prhs[1350]) || mxIsComplex(prhs[1350]) || !(mxGetM(prhs[1350])==1 && mxGetN(prhs[1350])==1) ) { 
      mexErrMsgTxt("Input 1350 must be a noncomplex scalar double.");
    } 
    mexinput1350_temp = mxGetPr(prhs[1350]); 
    double mexinput1350 = *mexinput1350_temp; 

    double *mexinput1351_temp = NULL; 
    if( !mxIsDouble(prhs[1351]) || mxIsComplex(prhs[1351]) || !(mxGetM(prhs[1351])==1 && mxGetN(prhs[1351])==1) ) { 
      mexErrMsgTxt("Input 1351 must be a noncomplex scalar double.");
    } 
    mexinput1351_temp = mxGetPr(prhs[1351]); 
    double mexinput1351 = *mexinput1351_temp; 

    double *mexinput1352_temp = NULL; 
    if( !mxIsDouble(prhs[1352]) || mxIsComplex(prhs[1352]) || !(mxGetM(prhs[1352])==1 && mxGetN(prhs[1352])==1) ) { 
      mexErrMsgTxt("Input 1352 must be a noncomplex scalar double.");
    } 
    mexinput1352_temp = mxGetPr(prhs[1352]); 
    double mexinput1352 = *mexinput1352_temp; 

    double *mexinput1353_temp = NULL; 
    if( !mxIsDouble(prhs[1353]) || mxIsComplex(prhs[1353]) || !(mxGetM(prhs[1353])==1 && mxGetN(prhs[1353])==1) ) { 
      mexErrMsgTxt("Input 1353 must be a noncomplex scalar double.");
    } 
    mexinput1353_temp = mxGetPr(prhs[1353]); 
    double mexinput1353 = *mexinput1353_temp; 

    double *mexinput1354_temp = NULL; 
    if( !mxIsDouble(prhs[1354]) || mxIsComplex(prhs[1354]) || !(mxGetM(prhs[1354])==1 && mxGetN(prhs[1354])==1) ) { 
      mexErrMsgTxt("Input 1354 must be a noncomplex scalar double.");
    } 
    mexinput1354_temp = mxGetPr(prhs[1354]); 
    double mexinput1354 = *mexinput1354_temp; 

    double *mexinput1355_temp = NULL; 
    if( !mxIsDouble(prhs[1355]) || mxIsComplex(prhs[1355]) || !(mxGetM(prhs[1355])==1 && mxGetN(prhs[1355])==1) ) { 
      mexErrMsgTxt("Input 1355 must be a noncomplex scalar double.");
    } 
    mexinput1355_temp = mxGetPr(prhs[1355]); 
    double mexinput1355 = *mexinput1355_temp; 

    double *mexinput1356_temp = NULL; 
    if( !mxIsDouble(prhs[1356]) || mxIsComplex(prhs[1356]) || !(mxGetM(prhs[1356])==1 && mxGetN(prhs[1356])==1) ) { 
      mexErrMsgTxt("Input 1356 must be a noncomplex scalar double.");
    } 
    mexinput1356_temp = mxGetPr(prhs[1356]); 
    double mexinput1356 = *mexinput1356_temp; 

    double *mexinput1357_temp = NULL; 
    if( !mxIsDouble(prhs[1357]) || mxIsComplex(prhs[1357]) || !(mxGetM(prhs[1357])==1 && mxGetN(prhs[1357])==1) ) { 
      mexErrMsgTxt("Input 1357 must be a noncomplex scalar double.");
    } 
    mexinput1357_temp = mxGetPr(prhs[1357]); 
    double mexinput1357 = *mexinput1357_temp; 

    double *mexinput1358_temp = NULL; 
    if( !mxIsDouble(prhs[1358]) || mxIsComplex(prhs[1358]) || !(mxGetM(prhs[1358])==1 && mxGetN(prhs[1358])==1) ) { 
      mexErrMsgTxt("Input 1358 must be a noncomplex scalar double.");
    } 
    mexinput1358_temp = mxGetPr(prhs[1358]); 
    double mexinput1358 = *mexinput1358_temp; 

    double *mexinput1359_temp = NULL; 
    if( !mxIsDouble(prhs[1359]) || mxIsComplex(prhs[1359]) || !(mxGetM(prhs[1359])==1 && mxGetN(prhs[1359])==1) ) { 
      mexErrMsgTxt("Input 1359 must be a noncomplex scalar double.");
    } 
    mexinput1359_temp = mxGetPr(prhs[1359]); 
    double mexinput1359 = *mexinput1359_temp; 

    double *mexinput1360_temp = NULL; 
    if( !mxIsDouble(prhs[1360]) || mxIsComplex(prhs[1360]) || !(mxGetM(prhs[1360])==1 && mxGetN(prhs[1360])==1) ) { 
      mexErrMsgTxt("Input 1360 must be a noncomplex scalar double.");
    } 
    mexinput1360_temp = mxGetPr(prhs[1360]); 
    double mexinput1360 = *mexinput1360_temp; 

    double *mexinput1361_temp = NULL; 
    if( !mxIsDouble(prhs[1361]) || mxIsComplex(prhs[1361]) || !(mxGetM(prhs[1361])==1 && mxGetN(prhs[1361])==1) ) { 
      mexErrMsgTxt("Input 1361 must be a noncomplex scalar double.");
    } 
    mexinput1361_temp = mxGetPr(prhs[1361]); 
    double mexinput1361 = *mexinput1361_temp; 

    double *mexinput1362_temp = NULL; 
    if( !mxIsDouble(prhs[1362]) || mxIsComplex(prhs[1362]) || !(mxGetM(prhs[1362])==1 && mxGetN(prhs[1362])==1) ) { 
      mexErrMsgTxt("Input 1362 must be a noncomplex scalar double.");
    } 
    mexinput1362_temp = mxGetPr(prhs[1362]); 
    double mexinput1362 = *mexinput1362_temp; 

    double *mexinput1363_temp = NULL; 
    if( !mxIsDouble(prhs[1363]) || mxIsComplex(prhs[1363]) || !(mxGetM(prhs[1363])==1 && mxGetN(prhs[1363])==1) ) { 
      mexErrMsgTxt("Input 1363 must be a noncomplex scalar double.");
    } 
    mexinput1363_temp = mxGetPr(prhs[1363]); 
    double mexinput1363 = *mexinput1363_temp; 

    double *mexinput1364_temp = NULL; 
    if( !mxIsDouble(prhs[1364]) || mxIsComplex(prhs[1364]) || !(mxGetM(prhs[1364])==1 && mxGetN(prhs[1364])==1) ) { 
      mexErrMsgTxt("Input 1364 must be a noncomplex scalar double.");
    } 
    mexinput1364_temp = mxGetPr(prhs[1364]); 
    double mexinput1364 = *mexinput1364_temp; 

    double *mexinput1365_temp = NULL; 
    if( !mxIsDouble(prhs[1365]) || mxIsComplex(prhs[1365]) || !(mxGetM(prhs[1365])==1 && mxGetN(prhs[1365])==1) ) { 
      mexErrMsgTxt("Input 1365 must be a noncomplex scalar double.");
    } 
    mexinput1365_temp = mxGetPr(prhs[1365]); 
    double mexinput1365 = *mexinput1365_temp; 

    double *mexinput1366_temp = NULL; 
    if( !mxIsDouble(prhs[1366]) || mxIsComplex(prhs[1366]) || !(mxGetM(prhs[1366])==1 && mxGetN(prhs[1366])==1) ) { 
      mexErrMsgTxt("Input 1366 must be a noncomplex scalar double.");
    } 
    mexinput1366_temp = mxGetPr(prhs[1366]); 
    double mexinput1366 = *mexinput1366_temp; 

    double *mexinput1367_temp = NULL; 
    if( !mxIsDouble(prhs[1367]) || mxIsComplex(prhs[1367]) || !(mxGetM(prhs[1367])==1 && mxGetN(prhs[1367])==1) ) { 
      mexErrMsgTxt("Input 1367 must be a noncomplex scalar double.");
    } 
    mexinput1367_temp = mxGetPr(prhs[1367]); 
    double mexinput1367 = *mexinput1367_temp; 

    double *mexinput1368_temp = NULL; 
    if( !mxIsDouble(prhs[1368]) || mxIsComplex(prhs[1368]) || !(mxGetM(prhs[1368])==1 && mxGetN(prhs[1368])==1) ) { 
      mexErrMsgTxt("Input 1368 must be a noncomplex scalar double.");
    } 
    mexinput1368_temp = mxGetPr(prhs[1368]); 
    double mexinput1368 = *mexinput1368_temp; 

    double *mexinput1369_temp = NULL; 
    if( !mxIsDouble(prhs[1369]) || mxIsComplex(prhs[1369]) || !(mxGetM(prhs[1369])==1 && mxGetN(prhs[1369])==1) ) { 
      mexErrMsgTxt("Input 1369 must be a noncomplex scalar double.");
    } 
    mexinput1369_temp = mxGetPr(prhs[1369]); 
    double mexinput1369 = *mexinput1369_temp; 

    double *mexinput1370_temp = NULL; 
    if( !mxIsDouble(prhs[1370]) || mxIsComplex(prhs[1370]) || !(mxGetM(prhs[1370])==1 && mxGetN(prhs[1370])==1) ) { 
      mexErrMsgTxt("Input 1370 must be a noncomplex scalar double.");
    } 
    mexinput1370_temp = mxGetPr(prhs[1370]); 
    double mexinput1370 = *mexinput1370_temp; 

    double *mexinput1371_temp = NULL; 
    if( !mxIsDouble(prhs[1371]) || mxIsComplex(prhs[1371]) || !(mxGetM(prhs[1371])==1 && mxGetN(prhs[1371])==1) ) { 
      mexErrMsgTxt("Input 1371 must be a noncomplex scalar double.");
    } 
    mexinput1371_temp = mxGetPr(prhs[1371]); 
    double mexinput1371 = *mexinput1371_temp; 

    double *mexinput1372_temp = NULL; 
    if( !mxIsDouble(prhs[1372]) || mxIsComplex(prhs[1372]) || !(mxGetM(prhs[1372])==1 && mxGetN(prhs[1372])==1) ) { 
      mexErrMsgTxt("Input 1372 must be a noncomplex scalar double.");
    } 
    mexinput1372_temp = mxGetPr(prhs[1372]); 
    double mexinput1372 = *mexinput1372_temp; 

    double *mexinput1373_temp = NULL; 
    if( !mxIsDouble(prhs[1373]) || mxIsComplex(prhs[1373]) || !(mxGetM(prhs[1373])==1 && mxGetN(prhs[1373])==1) ) { 
      mexErrMsgTxt("Input 1373 must be a noncomplex scalar double.");
    } 
    mexinput1373_temp = mxGetPr(prhs[1373]); 
    double mexinput1373 = *mexinput1373_temp; 

    double *mexinput1374_temp = NULL; 
    if( !mxIsDouble(prhs[1374]) || mxIsComplex(prhs[1374]) || !(mxGetM(prhs[1374])==1 && mxGetN(prhs[1374])==1) ) { 
      mexErrMsgTxt("Input 1374 must be a noncomplex scalar double.");
    } 
    mexinput1374_temp = mxGetPr(prhs[1374]); 
    double mexinput1374 = *mexinput1374_temp; 

    double *mexinput1375_temp = NULL; 
    if( !mxIsDouble(prhs[1375]) || mxIsComplex(prhs[1375]) || !(mxGetM(prhs[1375])==1 && mxGetN(prhs[1375])==1) ) { 
      mexErrMsgTxt("Input 1375 must be a noncomplex scalar double.");
    } 
    mexinput1375_temp = mxGetPr(prhs[1375]); 
    double mexinput1375 = *mexinput1375_temp; 

    double *mexinput1376_temp = NULL; 
    if( !mxIsDouble(prhs[1376]) || mxIsComplex(prhs[1376]) || !(mxGetM(prhs[1376])==1 && mxGetN(prhs[1376])==1) ) { 
      mexErrMsgTxt("Input 1376 must be a noncomplex scalar double.");
    } 
    mexinput1376_temp = mxGetPr(prhs[1376]); 
    double mexinput1376 = *mexinput1376_temp; 

    double *mexinput1377_temp = NULL; 
    if( !mxIsDouble(prhs[1377]) || mxIsComplex(prhs[1377]) || !(mxGetM(prhs[1377])==1 && mxGetN(prhs[1377])==1) ) { 
      mexErrMsgTxt("Input 1377 must be a noncomplex scalar double.");
    } 
    mexinput1377_temp = mxGetPr(prhs[1377]); 
    double mexinput1377 = *mexinput1377_temp; 

    double *mexinput1378_temp = NULL; 
    if( !mxIsDouble(prhs[1378]) || mxIsComplex(prhs[1378]) || !(mxGetM(prhs[1378])==1 && mxGetN(prhs[1378])==1) ) { 
      mexErrMsgTxt("Input 1378 must be a noncomplex scalar double.");
    } 
    mexinput1378_temp = mxGetPr(prhs[1378]); 
    double mexinput1378 = *mexinput1378_temp; 

    double *mexinput1379_temp = NULL; 
    if( !mxIsDouble(prhs[1379]) || mxIsComplex(prhs[1379]) || !(mxGetM(prhs[1379])==1 && mxGetN(prhs[1379])==1) ) { 
      mexErrMsgTxt("Input 1379 must be a noncomplex scalar double.");
    } 
    mexinput1379_temp = mxGetPr(prhs[1379]); 
    double mexinput1379 = *mexinput1379_temp; 

    double *mexinput1380_temp = NULL; 
    if( !mxIsDouble(prhs[1380]) || mxIsComplex(prhs[1380]) || !(mxGetM(prhs[1380])==1 && mxGetN(prhs[1380])==1) ) { 
      mexErrMsgTxt("Input 1380 must be a noncomplex scalar double.");
    } 
    mexinput1380_temp = mxGetPr(prhs[1380]); 
    double mexinput1380 = *mexinput1380_temp; 

    double *mexinput1381_temp = NULL; 
    if( !mxIsDouble(prhs[1381]) || mxIsComplex(prhs[1381]) || !(mxGetM(prhs[1381])==1 && mxGetN(prhs[1381])==1) ) { 
      mexErrMsgTxt("Input 1381 must be a noncomplex scalar double.");
    } 
    mexinput1381_temp = mxGetPr(prhs[1381]); 
    double mexinput1381 = *mexinput1381_temp; 

    double *mexinput1382_temp = NULL; 
    if( !mxIsDouble(prhs[1382]) || mxIsComplex(prhs[1382]) || !(mxGetM(prhs[1382])==1 && mxGetN(prhs[1382])==1) ) { 
      mexErrMsgTxt("Input 1382 must be a noncomplex scalar double.");
    } 
    mexinput1382_temp = mxGetPr(prhs[1382]); 
    double mexinput1382 = *mexinput1382_temp; 

    double *mexinput1383_temp = NULL; 
    if( !mxIsDouble(prhs[1383]) || mxIsComplex(prhs[1383]) || !(mxGetM(prhs[1383])==1 && mxGetN(prhs[1383])==1) ) { 
      mexErrMsgTxt("Input 1383 must be a noncomplex scalar double.");
    } 
    mexinput1383_temp = mxGetPr(prhs[1383]); 
    double mexinput1383 = *mexinput1383_temp; 

    double *mexinput1384_temp = NULL; 
    if( !mxIsDouble(prhs[1384]) || mxIsComplex(prhs[1384]) || !(mxGetM(prhs[1384])==1 && mxGetN(prhs[1384])==1) ) { 
      mexErrMsgTxt("Input 1384 must be a noncomplex scalar double.");
    } 
    mexinput1384_temp = mxGetPr(prhs[1384]); 
    double mexinput1384 = *mexinput1384_temp; 

    double *mexinput1385_temp = NULL; 
    if( !mxIsDouble(prhs[1385]) || mxIsComplex(prhs[1385]) || !(mxGetM(prhs[1385])==1 && mxGetN(prhs[1385])==1) ) { 
      mexErrMsgTxt("Input 1385 must be a noncomplex scalar double.");
    } 
    mexinput1385_temp = mxGetPr(prhs[1385]); 
    double mexinput1385 = *mexinput1385_temp; 

    double *mexinput1386_temp = NULL; 
    if( !mxIsDouble(prhs[1386]) || mxIsComplex(prhs[1386]) || !(mxGetM(prhs[1386])==1 && mxGetN(prhs[1386])==1) ) { 
      mexErrMsgTxt("Input 1386 must be a noncomplex scalar double.");
    } 
    mexinput1386_temp = mxGetPr(prhs[1386]); 
    double mexinput1386 = *mexinput1386_temp; 

    double *mexinput1387_temp = NULL; 
    if( !mxIsDouble(prhs[1387]) || mxIsComplex(prhs[1387]) || !(mxGetM(prhs[1387])==1 && mxGetN(prhs[1387])==1) ) { 
      mexErrMsgTxt("Input 1387 must be a noncomplex scalar double.");
    } 
    mexinput1387_temp = mxGetPr(prhs[1387]); 
    double mexinput1387 = *mexinput1387_temp; 

    double *mexinput1388_temp = NULL; 
    if( !mxIsDouble(prhs[1388]) || mxIsComplex(prhs[1388]) || !(mxGetM(prhs[1388])==1 && mxGetN(prhs[1388])==1) ) { 
      mexErrMsgTxt("Input 1388 must be a noncomplex scalar double.");
    } 
    mexinput1388_temp = mxGetPr(prhs[1388]); 
    double mexinput1388 = *mexinput1388_temp; 

    double *mexinput1389_temp = NULL; 
    if( !mxIsDouble(prhs[1389]) || mxIsComplex(prhs[1389]) || !(mxGetM(prhs[1389])==1 && mxGetN(prhs[1389])==1) ) { 
      mexErrMsgTxt("Input 1389 must be a noncomplex scalar double.");
    } 
    mexinput1389_temp = mxGetPr(prhs[1389]); 
    double mexinput1389 = *mexinput1389_temp; 

    double *mexinput1390_temp = NULL; 
    if( !mxIsDouble(prhs[1390]) || mxIsComplex(prhs[1390]) || !(mxGetM(prhs[1390])==1 && mxGetN(prhs[1390])==1) ) { 
      mexErrMsgTxt("Input 1390 must be a noncomplex scalar double.");
    } 
    mexinput1390_temp = mxGetPr(prhs[1390]); 
    double mexinput1390 = *mexinput1390_temp; 

    double *mexinput1391_temp = NULL; 
    if( !mxIsDouble(prhs[1391]) || mxIsComplex(prhs[1391]) || !(mxGetM(prhs[1391])==1 && mxGetN(prhs[1391])==1) ) { 
      mexErrMsgTxt("Input 1391 must be a noncomplex scalar double.");
    } 
    mexinput1391_temp = mxGetPr(prhs[1391]); 
    double mexinput1391 = *mexinput1391_temp; 

    double *mexinput1392_temp = NULL; 
    if( !mxIsDouble(prhs[1392]) || mxIsComplex(prhs[1392]) || !(mxGetM(prhs[1392])==1 && mxGetN(prhs[1392])==1) ) { 
      mexErrMsgTxt("Input 1392 must be a noncomplex scalar double.");
    } 
    mexinput1392_temp = mxGetPr(prhs[1392]); 
    double mexinput1392 = *mexinput1392_temp; 

    double *mexinput1393_temp = NULL; 
    if( !mxIsDouble(prhs[1393]) || mxIsComplex(prhs[1393]) || !(mxGetM(prhs[1393])==1 && mxGetN(prhs[1393])==1) ) { 
      mexErrMsgTxt("Input 1393 must be a noncomplex scalar double.");
    } 
    mexinput1393_temp = mxGetPr(prhs[1393]); 
    double mexinput1393 = *mexinput1393_temp; 

    double *mexinput1394_temp = NULL; 
    if( !mxIsDouble(prhs[1394]) || mxIsComplex(prhs[1394]) || !(mxGetM(prhs[1394])==1 && mxGetN(prhs[1394])==1) ) { 
      mexErrMsgTxt("Input 1394 must be a noncomplex scalar double.");
    } 
    mexinput1394_temp = mxGetPr(prhs[1394]); 
    double mexinput1394 = *mexinput1394_temp; 

    double *mexinput1395_temp = NULL; 
    if( !mxIsDouble(prhs[1395]) || mxIsComplex(prhs[1395]) || !(mxGetM(prhs[1395])==1 && mxGetN(prhs[1395])==1) ) { 
      mexErrMsgTxt("Input 1395 must be a noncomplex scalar double.");
    } 
    mexinput1395_temp = mxGetPr(prhs[1395]); 
    double mexinput1395 = *mexinput1395_temp; 

    double *mexinput1396_temp = NULL; 
    if( !mxIsDouble(prhs[1396]) || mxIsComplex(prhs[1396]) || !(mxGetM(prhs[1396])==1 && mxGetN(prhs[1396])==1) ) { 
      mexErrMsgTxt("Input 1396 must be a noncomplex scalar double.");
    } 
    mexinput1396_temp = mxGetPr(prhs[1396]); 
    double mexinput1396 = *mexinput1396_temp; 

    double *mexinput1397_temp = NULL; 
    if( !mxIsDouble(prhs[1397]) || mxIsComplex(prhs[1397]) || !(mxGetM(prhs[1397])==1 && mxGetN(prhs[1397])==1) ) { 
      mexErrMsgTxt("Input 1397 must be a noncomplex scalar double.");
    } 
    mexinput1397_temp = mxGetPr(prhs[1397]); 
    double mexinput1397 = *mexinput1397_temp; 

    double *mexinput1398_temp = NULL; 
    if( !mxIsDouble(prhs[1398]) || mxIsComplex(prhs[1398]) || !(mxGetM(prhs[1398])==1 && mxGetN(prhs[1398])==1) ) { 
      mexErrMsgTxt("Input 1398 must be a noncomplex scalar double.");
    } 
    mexinput1398_temp = mxGetPr(prhs[1398]); 
    double mexinput1398 = *mexinput1398_temp; 

    double *mexinput1399_temp = NULL; 
    if( !mxIsDouble(prhs[1399]) || mxIsComplex(prhs[1399]) || !(mxGetM(prhs[1399])==1 && mxGetN(prhs[1399])==1) ) { 
      mexErrMsgTxt("Input 1399 must be a noncomplex scalar double.");
    } 
    mexinput1399_temp = mxGetPr(prhs[1399]); 
    double mexinput1399 = *mexinput1399_temp; 

    double *mexinput1400_temp = NULL; 
    if( !mxIsDouble(prhs[1400]) || mxIsComplex(prhs[1400]) || !(mxGetM(prhs[1400])==1 && mxGetN(prhs[1400])==1) ) { 
      mexErrMsgTxt("Input 1400 must be a noncomplex scalar double.");
    } 
    mexinput1400_temp = mxGetPr(prhs[1400]); 
    double mexinput1400 = *mexinput1400_temp; 

    double *mexinput1401_temp = NULL; 
    if( !mxIsDouble(prhs[1401]) || mxIsComplex(prhs[1401]) || !(mxGetM(prhs[1401])==1 && mxGetN(prhs[1401])==1) ) { 
      mexErrMsgTxt("Input 1401 must be a noncomplex scalar double.");
    } 
    mexinput1401_temp = mxGetPr(prhs[1401]); 
    double mexinput1401 = *mexinput1401_temp; 

    double *mexinput1402_temp = NULL; 
    if( !mxIsDouble(prhs[1402]) || mxIsComplex(prhs[1402]) || !(mxGetM(prhs[1402])==1 && mxGetN(prhs[1402])==1) ) { 
      mexErrMsgTxt("Input 1402 must be a noncomplex scalar double.");
    } 
    mexinput1402_temp = mxGetPr(prhs[1402]); 
    double mexinput1402 = *mexinput1402_temp; 

    double *mexinput1403_temp = NULL; 
    if( !mxIsDouble(prhs[1403]) || mxIsComplex(prhs[1403]) || !(mxGetM(prhs[1403])==1 && mxGetN(prhs[1403])==1) ) { 
      mexErrMsgTxt("Input 1403 must be a noncomplex scalar double.");
    } 
    mexinput1403_temp = mxGetPr(prhs[1403]); 
    double mexinput1403 = *mexinput1403_temp; 

    double *mexinput1404_temp = NULL; 
    if( !mxIsDouble(prhs[1404]) || mxIsComplex(prhs[1404]) || !(mxGetM(prhs[1404])==1 && mxGetN(prhs[1404])==1) ) { 
      mexErrMsgTxt("Input 1404 must be a noncomplex scalar double.");
    } 
    mexinput1404_temp = mxGetPr(prhs[1404]); 
    double mexinput1404 = *mexinput1404_temp; 

    double *mexinput1405_temp = NULL; 
    if( !mxIsDouble(prhs[1405]) || mxIsComplex(prhs[1405]) || !(mxGetM(prhs[1405])==1 && mxGetN(prhs[1405])==1) ) { 
      mexErrMsgTxt("Input 1405 must be a noncomplex scalar double.");
    } 
    mexinput1405_temp = mxGetPr(prhs[1405]); 
    double mexinput1405 = *mexinput1405_temp; 

    double *mexinput1406_temp = NULL; 
    if( !mxIsDouble(prhs[1406]) || mxIsComplex(prhs[1406]) || !(mxGetM(prhs[1406])==1 && mxGetN(prhs[1406])==1) ) { 
      mexErrMsgTxt("Input 1406 must be a noncomplex scalar double.");
    } 
    mexinput1406_temp = mxGetPr(prhs[1406]); 
    double mexinput1406 = *mexinput1406_temp; 

    double *mexinput1407_temp = NULL; 
    if( !mxIsDouble(prhs[1407]) || mxIsComplex(prhs[1407]) || !(mxGetM(prhs[1407])==1 && mxGetN(prhs[1407])==1) ) { 
      mexErrMsgTxt("Input 1407 must be a noncomplex scalar double.");
    } 
    mexinput1407_temp = mxGetPr(prhs[1407]); 
    double mexinput1407 = *mexinput1407_temp; 

    double *mexinput1408_temp = NULL; 
    if( !mxIsDouble(prhs[1408]) || mxIsComplex(prhs[1408]) || !(mxGetM(prhs[1408])==1 && mxGetN(prhs[1408])==1) ) { 
      mexErrMsgTxt("Input 1408 must be a noncomplex scalar double.");
    } 
    mexinput1408_temp = mxGetPr(prhs[1408]); 
    double mexinput1408 = *mexinput1408_temp; 

    double *mexinput1409_temp = NULL; 
    if( !mxIsDouble(prhs[1409]) || mxIsComplex(prhs[1409]) || !(mxGetM(prhs[1409])==1 && mxGetN(prhs[1409])==1) ) { 
      mexErrMsgTxt("Input 1409 must be a noncomplex scalar double.");
    } 
    mexinput1409_temp = mxGetPr(prhs[1409]); 
    double mexinput1409 = *mexinput1409_temp; 

    double *mexinput1410_temp = NULL; 
    if( !mxIsDouble(prhs[1410]) || mxIsComplex(prhs[1410]) || !(mxGetM(prhs[1410])==1 && mxGetN(prhs[1410])==1) ) { 
      mexErrMsgTxt("Input 1410 must be a noncomplex scalar double.");
    } 
    mexinput1410_temp = mxGetPr(prhs[1410]); 
    double mexinput1410 = *mexinput1410_temp; 

    double *mexinput1411_temp = NULL; 
    if( !mxIsDouble(prhs[1411]) || mxIsComplex(prhs[1411]) || !(mxGetM(prhs[1411])==1 && mxGetN(prhs[1411])==1) ) { 
      mexErrMsgTxt("Input 1411 must be a noncomplex scalar double.");
    } 
    mexinput1411_temp = mxGetPr(prhs[1411]); 
    double mexinput1411 = *mexinput1411_temp; 

    double *mexinput1412_temp = NULL; 
    if( !mxIsDouble(prhs[1412]) || mxIsComplex(prhs[1412]) || !(mxGetM(prhs[1412])==1 && mxGetN(prhs[1412])==1) ) { 
      mexErrMsgTxt("Input 1412 must be a noncomplex scalar double.");
    } 
    mexinput1412_temp = mxGetPr(prhs[1412]); 
    double mexinput1412 = *mexinput1412_temp; 

    double *mexinput1413_temp = NULL; 
    if( !mxIsDouble(prhs[1413]) || mxIsComplex(prhs[1413]) || !(mxGetM(prhs[1413])==1 && mxGetN(prhs[1413])==1) ) { 
      mexErrMsgTxt("Input 1413 must be a noncomplex scalar double.");
    } 
    mexinput1413_temp = mxGetPr(prhs[1413]); 
    double mexinput1413 = *mexinput1413_temp; 

    double *mexinput1414_temp = NULL; 
    if( !mxIsDouble(prhs[1414]) || mxIsComplex(prhs[1414]) || !(mxGetM(prhs[1414])==1 && mxGetN(prhs[1414])==1) ) { 
      mexErrMsgTxt("Input 1414 must be a noncomplex scalar double.");
    } 
    mexinput1414_temp = mxGetPr(prhs[1414]); 
    double mexinput1414 = *mexinput1414_temp; 

    double *mexinput1415_temp = NULL; 
    if( !mxIsDouble(prhs[1415]) || mxIsComplex(prhs[1415]) || !(mxGetM(prhs[1415])==1 && mxGetN(prhs[1415])==1) ) { 
      mexErrMsgTxt("Input 1415 must be a noncomplex scalar double.");
    } 
    mexinput1415_temp = mxGetPr(prhs[1415]); 
    double mexinput1415 = *mexinput1415_temp; 

    double *mexinput1416_temp = NULL; 
    if( !mxIsDouble(prhs[1416]) || mxIsComplex(prhs[1416]) || !(mxGetM(prhs[1416])==1 && mxGetN(prhs[1416])==1) ) { 
      mexErrMsgTxt("Input 1416 must be a noncomplex scalar double.");
    } 
    mexinput1416_temp = mxGetPr(prhs[1416]); 
    double mexinput1416 = *mexinput1416_temp; 

    double *mexinput1417_temp = NULL; 
    if( !mxIsDouble(prhs[1417]) || mxIsComplex(prhs[1417]) || !(mxGetM(prhs[1417])==1 && mxGetN(prhs[1417])==1) ) { 
      mexErrMsgTxt("Input 1417 must be a noncomplex scalar double.");
    } 
    mexinput1417_temp = mxGetPr(prhs[1417]); 
    double mexinput1417 = *mexinput1417_temp; 

    double *mexinput1418_temp = NULL; 
    if( !mxIsDouble(prhs[1418]) || mxIsComplex(prhs[1418]) || !(mxGetM(prhs[1418])==1 && mxGetN(prhs[1418])==1) ) { 
      mexErrMsgTxt("Input 1418 must be a noncomplex scalar double.");
    } 
    mexinput1418_temp = mxGetPr(prhs[1418]); 
    double mexinput1418 = *mexinput1418_temp; 

    double *mexinput1419_temp = NULL; 
    if( !mxIsDouble(prhs[1419]) || mxIsComplex(prhs[1419]) || !(mxGetM(prhs[1419])==1 && mxGetN(prhs[1419])==1) ) { 
      mexErrMsgTxt("Input 1419 must be a noncomplex scalar double.");
    } 
    mexinput1419_temp = mxGetPr(prhs[1419]); 
    double mexinput1419 = *mexinput1419_temp; 

    double *mexinput1420_temp = NULL; 
    if( !mxIsDouble(prhs[1420]) || mxIsComplex(prhs[1420]) || !(mxGetM(prhs[1420])==1 && mxGetN(prhs[1420])==1) ) { 
      mexErrMsgTxt("Input 1420 must be a noncomplex scalar double.");
    } 
    mexinput1420_temp = mxGetPr(prhs[1420]); 
    double mexinput1420 = *mexinput1420_temp; 

    double *mexinput1421_temp = NULL; 
    if( !mxIsDouble(prhs[1421]) || mxIsComplex(prhs[1421]) || !(mxGetM(prhs[1421])==1 && mxGetN(prhs[1421])==1) ) { 
      mexErrMsgTxt("Input 1421 must be a noncomplex scalar double.");
    } 
    mexinput1421_temp = mxGetPr(prhs[1421]); 
    double mexinput1421 = *mexinput1421_temp; 

    double *mexinput1422_temp = NULL; 
    if( !mxIsDouble(prhs[1422]) || mxIsComplex(prhs[1422]) || !(mxGetM(prhs[1422])==1 && mxGetN(prhs[1422])==1) ) { 
      mexErrMsgTxt("Input 1422 must be a noncomplex scalar double.");
    } 
    mexinput1422_temp = mxGetPr(prhs[1422]); 
    double mexinput1422 = *mexinput1422_temp; 

    double *mexinput1423_temp = NULL; 
    if( !mxIsDouble(prhs[1423]) || mxIsComplex(prhs[1423]) || !(mxGetM(prhs[1423])==1 && mxGetN(prhs[1423])==1) ) { 
      mexErrMsgTxt("Input 1423 must be a noncomplex scalar double.");
    } 
    mexinput1423_temp = mxGetPr(prhs[1423]); 
    double mexinput1423 = *mexinput1423_temp; 

    double *mexinput1424_temp = NULL; 
    if( !mxIsDouble(prhs[1424]) || mxIsComplex(prhs[1424]) || !(mxGetM(prhs[1424])==1 && mxGetN(prhs[1424])==1) ) { 
      mexErrMsgTxt("Input 1424 must be a noncomplex scalar double.");
    } 
    mexinput1424_temp = mxGetPr(prhs[1424]); 
    double mexinput1424 = *mexinput1424_temp; 

    double *mexinput1425_temp = NULL; 
    if( !mxIsDouble(prhs[1425]) || mxIsComplex(prhs[1425]) || !(mxGetM(prhs[1425])==1 && mxGetN(prhs[1425])==1) ) { 
      mexErrMsgTxt("Input 1425 must be a noncomplex scalar double.");
    } 
    mexinput1425_temp = mxGetPr(prhs[1425]); 
    double mexinput1425 = *mexinput1425_temp; 

    double *mexinput1426_temp = NULL; 
    if( !mxIsDouble(prhs[1426]) || mxIsComplex(prhs[1426]) || !(mxGetM(prhs[1426])==1 && mxGetN(prhs[1426])==1) ) { 
      mexErrMsgTxt("Input 1426 must be a noncomplex scalar double.");
    } 
    mexinput1426_temp = mxGetPr(prhs[1426]); 
    double mexinput1426 = *mexinput1426_temp; 

    double *mexinput1427_temp = NULL; 
    if( !mxIsDouble(prhs[1427]) || mxIsComplex(prhs[1427]) || !(mxGetM(prhs[1427])==1 && mxGetN(prhs[1427])==1) ) { 
      mexErrMsgTxt("Input 1427 must be a noncomplex scalar double.");
    } 
    mexinput1427_temp = mxGetPr(prhs[1427]); 
    double mexinput1427 = *mexinput1427_temp; 

    double *mexinput1428_temp = NULL; 
    if( !mxIsDouble(prhs[1428]) || mxIsComplex(prhs[1428]) || !(mxGetM(prhs[1428])==1 && mxGetN(prhs[1428])==1) ) { 
      mexErrMsgTxt("Input 1428 must be a noncomplex scalar double.");
    } 
    mexinput1428_temp = mxGetPr(prhs[1428]); 
    double mexinput1428 = *mexinput1428_temp; 

    double *mexinput1429_temp = NULL; 
    if( !mxIsDouble(prhs[1429]) || mxIsComplex(prhs[1429]) || !(mxGetM(prhs[1429])==1 && mxGetN(prhs[1429])==1) ) { 
      mexErrMsgTxt("Input 1429 must be a noncomplex scalar double.");
    } 
    mexinput1429_temp = mxGetPr(prhs[1429]); 
    double mexinput1429 = *mexinput1429_temp; 

    double *mexinput1430_temp = NULL; 
    if( !mxIsDouble(prhs[1430]) || mxIsComplex(prhs[1430]) || !(mxGetM(prhs[1430])==1 && mxGetN(prhs[1430])==1) ) { 
      mexErrMsgTxt("Input 1430 must be a noncomplex scalar double.");
    } 
    mexinput1430_temp = mxGetPr(prhs[1430]); 
    double mexinput1430 = *mexinput1430_temp; 

    double *mexinput1431_temp = NULL; 
    if( !mxIsDouble(prhs[1431]) || mxIsComplex(prhs[1431]) || !(mxGetM(prhs[1431])==1 && mxGetN(prhs[1431])==1) ) { 
      mexErrMsgTxt("Input 1431 must be a noncomplex scalar double.");
    } 
    mexinput1431_temp = mxGetPr(prhs[1431]); 
    double mexinput1431 = *mexinput1431_temp; 

    double *mexinput1432_temp = NULL; 
    if( !mxIsDouble(prhs[1432]) || mxIsComplex(prhs[1432]) || !(mxGetM(prhs[1432])==1 && mxGetN(prhs[1432])==1) ) { 
      mexErrMsgTxt("Input 1432 must be a noncomplex scalar double.");
    } 
    mexinput1432_temp = mxGetPr(prhs[1432]); 
    double mexinput1432 = *mexinput1432_temp; 

    double *mexinput1433_temp = NULL; 
    if( !mxIsDouble(prhs[1433]) || mxIsComplex(prhs[1433]) || !(mxGetM(prhs[1433])==1 && mxGetN(prhs[1433])==1) ) { 
      mexErrMsgTxt("Input 1433 must be a noncomplex scalar double.");
    } 
    mexinput1433_temp = mxGetPr(prhs[1433]); 
    double mexinput1433 = *mexinput1433_temp; 

    double *mexinput1434_temp = NULL; 
    if( !mxIsDouble(prhs[1434]) || mxIsComplex(prhs[1434]) || !(mxGetM(prhs[1434])==1 && mxGetN(prhs[1434])==1) ) { 
      mexErrMsgTxt("Input 1434 must be a noncomplex scalar double.");
    } 
    mexinput1434_temp = mxGetPr(prhs[1434]); 
    double mexinput1434 = *mexinput1434_temp; 

    double *mexinput1435_temp = NULL; 
    if( !mxIsDouble(prhs[1435]) || mxIsComplex(prhs[1435]) || !(mxGetM(prhs[1435])==1 && mxGetN(prhs[1435])==1) ) { 
      mexErrMsgTxt("Input 1435 must be a noncomplex scalar double.");
    } 
    mexinput1435_temp = mxGetPr(prhs[1435]); 
    double mexinput1435 = *mexinput1435_temp; 

    double *mexinput1436_temp = NULL; 
    if( !mxIsDouble(prhs[1436]) || mxIsComplex(prhs[1436]) || !(mxGetM(prhs[1436])==1 && mxGetN(prhs[1436])==1) ) { 
      mexErrMsgTxt("Input 1436 must be a noncomplex scalar double.");
    } 
    mexinput1436_temp = mxGetPr(prhs[1436]); 
    double mexinput1436 = *mexinput1436_temp; 

    double *mexinput1437_temp = NULL; 
    if( !mxIsDouble(prhs[1437]) || mxIsComplex(prhs[1437]) || !(mxGetM(prhs[1437])==1 && mxGetN(prhs[1437])==1) ) { 
      mexErrMsgTxt("Input 1437 must be a noncomplex scalar double.");
    } 
    mexinput1437_temp = mxGetPr(prhs[1437]); 
    double mexinput1437 = *mexinput1437_temp; 

    double *mexinput1438_temp = NULL; 
    if( !mxIsDouble(prhs[1438]) || mxIsComplex(prhs[1438]) || !(mxGetM(prhs[1438])==1 && mxGetN(prhs[1438])==1) ) { 
      mexErrMsgTxt("Input 1438 must be a noncomplex scalar double.");
    } 
    mexinput1438_temp = mxGetPr(prhs[1438]); 
    double mexinput1438 = *mexinput1438_temp; 

    double *mexinput1439_temp = NULL; 
    if( !mxIsDouble(prhs[1439]) || mxIsComplex(prhs[1439]) || !(mxGetM(prhs[1439])==1 && mxGetN(prhs[1439])==1) ) { 
      mexErrMsgTxt("Input 1439 must be a noncomplex scalar double.");
    } 
    mexinput1439_temp = mxGetPr(prhs[1439]); 
    double mexinput1439 = *mexinput1439_temp; 

    double *mexinput1440_temp = NULL; 
    if( !mxIsDouble(prhs[1440]) || mxIsComplex(prhs[1440]) || !(mxGetM(prhs[1440])==1 && mxGetN(prhs[1440])==1) ) { 
      mexErrMsgTxt("Input 1440 must be a noncomplex scalar double.");
    } 
    mexinput1440_temp = mxGetPr(prhs[1440]); 
    double mexinput1440 = *mexinput1440_temp; 

    double *mexinput1441_temp = NULL; 
    if( !mxIsDouble(prhs[1441]) || mxIsComplex(prhs[1441]) || !(mxGetM(prhs[1441])==1 && mxGetN(prhs[1441])==1) ) { 
      mexErrMsgTxt("Input 1441 must be a noncomplex scalar double.");
    } 
    mexinput1441_temp = mxGetPr(prhs[1441]); 
    double mexinput1441 = *mexinput1441_temp; 

    double *mexinput1442_temp = NULL; 
    if( !mxIsDouble(prhs[1442]) || mxIsComplex(prhs[1442]) || !(mxGetM(prhs[1442])==1 && mxGetN(prhs[1442])==1) ) { 
      mexErrMsgTxt("Input 1442 must be a noncomplex scalar double.");
    } 
    mexinput1442_temp = mxGetPr(prhs[1442]); 
    double mexinput1442 = *mexinput1442_temp; 

    double *mexinput1443_temp = NULL; 
    if( !mxIsDouble(prhs[1443]) || mxIsComplex(prhs[1443]) || !(mxGetM(prhs[1443])==1 && mxGetN(prhs[1443])==1) ) { 
      mexErrMsgTxt("Input 1443 must be a noncomplex scalar double.");
    } 
    mexinput1443_temp = mxGetPr(prhs[1443]); 
    double mexinput1443 = *mexinput1443_temp; 

    double *mexinput1444_temp = NULL; 
    if( !mxIsDouble(prhs[1444]) || mxIsComplex(prhs[1444]) || !(mxGetM(prhs[1444])==1 && mxGetN(prhs[1444])==1) ) { 
      mexErrMsgTxt("Input 1444 must be a noncomplex scalar double.");
    } 
    mexinput1444_temp = mxGetPr(prhs[1444]); 
    double mexinput1444 = *mexinput1444_temp; 

    double *mexinput1445_temp = NULL; 
    if( !mxIsDouble(prhs[1445]) || mxIsComplex(prhs[1445]) || !(mxGetM(prhs[1445])==1 && mxGetN(prhs[1445])==1) ) { 
      mexErrMsgTxt("Input 1445 must be a noncomplex scalar double.");
    } 
    mexinput1445_temp = mxGetPr(prhs[1445]); 
    double mexinput1445 = *mexinput1445_temp; 

    double *mexinput1446_temp = NULL; 
    if( !mxIsDouble(prhs[1446]) || mxIsComplex(prhs[1446]) || !(mxGetM(prhs[1446])==1 && mxGetN(prhs[1446])==1) ) { 
      mexErrMsgTxt("Input 1446 must be a noncomplex scalar double.");
    } 
    mexinput1446_temp = mxGetPr(prhs[1446]); 
    double mexinput1446 = *mexinput1446_temp; 

    double *mexinput1447_temp = NULL; 
    if( !mxIsDouble(prhs[1447]) || mxIsComplex(prhs[1447]) || !(mxGetM(prhs[1447])==1 && mxGetN(prhs[1447])==1) ) { 
      mexErrMsgTxt("Input 1447 must be a noncomplex scalar double.");
    } 
    mexinput1447_temp = mxGetPr(prhs[1447]); 
    double mexinput1447 = *mexinput1447_temp; 

    double *mexinput1448_temp = NULL; 
    if( !mxIsDouble(prhs[1448]) || mxIsComplex(prhs[1448]) || !(mxGetM(prhs[1448])==1 && mxGetN(prhs[1448])==1) ) { 
      mexErrMsgTxt("Input 1448 must be a noncomplex scalar double.");
    } 
    mexinput1448_temp = mxGetPr(prhs[1448]); 
    double mexinput1448 = *mexinput1448_temp; 

    double *mexinput1449_temp = NULL; 
    if( !mxIsDouble(prhs[1449]) || mxIsComplex(prhs[1449]) || !(mxGetM(prhs[1449])==1 && mxGetN(prhs[1449])==1) ) { 
      mexErrMsgTxt("Input 1449 must be a noncomplex scalar double.");
    } 
    mexinput1449_temp = mxGetPr(prhs[1449]); 
    double mexinput1449 = *mexinput1449_temp; 

    double *mexinput1450_temp = NULL; 
    if( !mxIsDouble(prhs[1450]) || mxIsComplex(prhs[1450]) || !(mxGetM(prhs[1450])==1 && mxGetN(prhs[1450])==1) ) { 
      mexErrMsgTxt("Input 1450 must be a noncomplex scalar double.");
    } 
    mexinput1450_temp = mxGetPr(prhs[1450]); 
    double mexinput1450 = *mexinput1450_temp; 

    double *mexinput1451_temp = NULL; 
    if( !mxIsDouble(prhs[1451]) || mxIsComplex(prhs[1451]) || !(mxGetM(prhs[1451])==1 && mxGetN(prhs[1451])==1) ) { 
      mexErrMsgTxt("Input 1451 must be a noncomplex scalar double.");
    } 
    mexinput1451_temp = mxGetPr(prhs[1451]); 
    double mexinput1451 = *mexinput1451_temp; 

    double *mexinput1452_temp = NULL; 
    if( !mxIsDouble(prhs[1452]) || mxIsComplex(prhs[1452]) || !(mxGetM(prhs[1452])==1 && mxGetN(prhs[1452])==1) ) { 
      mexErrMsgTxt("Input 1452 must be a noncomplex scalar double.");
    } 
    mexinput1452_temp = mxGetPr(prhs[1452]); 
    double mexinput1452 = *mexinput1452_temp; 

    double *mexinput1453_temp = NULL; 
    if( !mxIsDouble(prhs[1453]) || mxIsComplex(prhs[1453]) || !(mxGetM(prhs[1453])==1 && mxGetN(prhs[1453])==1) ) { 
      mexErrMsgTxt("Input 1453 must be a noncomplex scalar double.");
    } 
    mexinput1453_temp = mxGetPr(prhs[1453]); 
    double mexinput1453 = *mexinput1453_temp; 

    double *mexinput1454_temp = NULL; 
    if( !mxIsDouble(prhs[1454]) || mxIsComplex(prhs[1454]) || !(mxGetM(prhs[1454])==1 && mxGetN(prhs[1454])==1) ) { 
      mexErrMsgTxt("Input 1454 must be a noncomplex scalar double.");
    } 
    mexinput1454_temp = mxGetPr(prhs[1454]); 
    double mexinput1454 = *mexinput1454_temp; 

    double *mexinput1455_temp = NULL; 
    if( !mxIsDouble(prhs[1455]) || mxIsComplex(prhs[1455]) || !(mxGetM(prhs[1455])==1 && mxGetN(prhs[1455])==1) ) { 
      mexErrMsgTxt("Input 1455 must be a noncomplex scalar double.");
    } 
    mexinput1455_temp = mxGetPr(prhs[1455]); 
    double mexinput1455 = *mexinput1455_temp; 

    double *mexinput1456_temp = NULL; 
    if( !mxIsDouble(prhs[1456]) || mxIsComplex(prhs[1456]) || !(mxGetM(prhs[1456])==1 && mxGetN(prhs[1456])==1) ) { 
      mexErrMsgTxt("Input 1456 must be a noncomplex scalar double.");
    } 
    mexinput1456_temp = mxGetPr(prhs[1456]); 
    double mexinput1456 = *mexinput1456_temp; 

    double *mexinput1457_temp = NULL; 
    if( !mxIsDouble(prhs[1457]) || mxIsComplex(prhs[1457]) || !(mxGetM(prhs[1457])==1 && mxGetN(prhs[1457])==1) ) { 
      mexErrMsgTxt("Input 1457 must be a noncomplex scalar double.");
    } 
    mexinput1457_temp = mxGetPr(prhs[1457]); 
    double mexinput1457 = *mexinput1457_temp; 

    double *mexinput1458_temp = NULL; 
    if( !mxIsDouble(prhs[1458]) || mxIsComplex(prhs[1458]) || !(mxGetM(prhs[1458])==1 && mxGetN(prhs[1458])==1) ) { 
      mexErrMsgTxt("Input 1458 must be a noncomplex scalar double.");
    } 
    mexinput1458_temp = mxGetPr(prhs[1458]); 
    double mexinput1458 = *mexinput1458_temp; 

    double *mexinput1459_temp = NULL; 
    if( !mxIsDouble(prhs[1459]) || mxIsComplex(prhs[1459]) || !(mxGetM(prhs[1459])==1 && mxGetN(prhs[1459])==1) ) { 
      mexErrMsgTxt("Input 1459 must be a noncomplex scalar double.");
    } 
    mexinput1459_temp = mxGetPr(prhs[1459]); 
    double mexinput1459 = *mexinput1459_temp; 

    double *mexinput1460_temp = NULL; 
    if( !mxIsDouble(prhs[1460]) || mxIsComplex(prhs[1460]) || !(mxGetM(prhs[1460])==1 && mxGetN(prhs[1460])==1) ) { 
      mexErrMsgTxt("Input 1460 must be a noncomplex scalar double.");
    } 
    mexinput1460_temp = mxGetPr(prhs[1460]); 
    double mexinput1460 = *mexinput1460_temp; 

    double *mexinput1461_temp = NULL; 
    if( !mxIsDouble(prhs[1461]) || mxIsComplex(prhs[1461]) || !(mxGetM(prhs[1461])==1 && mxGetN(prhs[1461])==1) ) { 
      mexErrMsgTxt("Input 1461 must be a noncomplex scalar double.");
    } 
    mexinput1461_temp = mxGetPr(prhs[1461]); 
    double mexinput1461 = *mexinput1461_temp; 

    double *mexinput1462_temp = NULL; 
    if( !mxIsDouble(prhs[1462]) || mxIsComplex(prhs[1462]) || !(mxGetM(prhs[1462])==1 && mxGetN(prhs[1462])==1) ) { 
      mexErrMsgTxt("Input 1462 must be a noncomplex scalar double.");
    } 
    mexinput1462_temp = mxGetPr(prhs[1462]); 
    double mexinput1462 = *mexinput1462_temp; 

    double *mexinput1463_temp = NULL; 
    if( !mxIsDouble(prhs[1463]) || mxIsComplex(prhs[1463]) || !(mxGetM(prhs[1463])==1 && mxGetN(prhs[1463])==1) ) { 
      mexErrMsgTxt("Input 1463 must be a noncomplex scalar double.");
    } 
    mexinput1463_temp = mxGetPr(prhs[1463]); 
    double mexinput1463 = *mexinput1463_temp; 

    double *mexinput1464_temp = NULL; 
    if( !mxIsDouble(prhs[1464]) || mxIsComplex(prhs[1464]) || !(mxGetM(prhs[1464])==1 && mxGetN(prhs[1464])==1) ) { 
      mexErrMsgTxt("Input 1464 must be a noncomplex scalar double.");
    } 
    mexinput1464_temp = mxGetPr(prhs[1464]); 
    double mexinput1464 = *mexinput1464_temp; 

    double *mexinput1465_temp = NULL; 
    if( !mxIsDouble(prhs[1465]) || mxIsComplex(prhs[1465]) || !(mxGetM(prhs[1465])==1 && mxGetN(prhs[1465])==1) ) { 
      mexErrMsgTxt("Input 1465 must be a noncomplex scalar double.");
    } 
    mexinput1465_temp = mxGetPr(prhs[1465]); 
    double mexinput1465 = *mexinput1465_temp; 

    double *mexinput1466_temp = NULL; 
    if( !mxIsDouble(prhs[1466]) || mxIsComplex(prhs[1466]) || !(mxGetM(prhs[1466])==1 && mxGetN(prhs[1466])==1) ) { 
      mexErrMsgTxt("Input 1466 must be a noncomplex scalar double.");
    } 
    mexinput1466_temp = mxGetPr(prhs[1466]); 
    double mexinput1466 = *mexinput1466_temp; 

    double *mexinput1467_temp = NULL; 
    if( !mxIsDouble(prhs[1467]) || mxIsComplex(prhs[1467]) || !(mxGetM(prhs[1467])==1 && mxGetN(prhs[1467])==1) ) { 
      mexErrMsgTxt("Input 1467 must be a noncomplex scalar double.");
    } 
    mexinput1467_temp = mxGetPr(prhs[1467]); 
    double mexinput1467 = *mexinput1467_temp; 

    double *mexinput1468_temp = NULL; 
    if( !mxIsDouble(prhs[1468]) || mxIsComplex(prhs[1468]) || !(mxGetM(prhs[1468])==1 && mxGetN(prhs[1468])==1) ) { 
      mexErrMsgTxt("Input 1468 must be a noncomplex scalar double.");
    } 
    mexinput1468_temp = mxGetPr(prhs[1468]); 
    double mexinput1468 = *mexinput1468_temp; 

    double *mexinput1469_temp = NULL; 
    if( !mxIsDouble(prhs[1469]) || mxIsComplex(prhs[1469]) || !(mxGetM(prhs[1469])==1 && mxGetN(prhs[1469])==1) ) { 
      mexErrMsgTxt("Input 1469 must be a noncomplex scalar double.");
    } 
    mexinput1469_temp = mxGetPr(prhs[1469]); 
    double mexinput1469 = *mexinput1469_temp; 

    double *mexinput1470_temp = NULL; 
    if( !mxIsDouble(prhs[1470]) || mxIsComplex(prhs[1470]) || !(mxGetM(prhs[1470])==1 && mxGetN(prhs[1470])==1) ) { 
      mexErrMsgTxt("Input 1470 must be a noncomplex scalar double.");
    } 
    mexinput1470_temp = mxGetPr(prhs[1470]); 
    double mexinput1470 = *mexinput1470_temp; 

    double *mexinput1471_temp = NULL; 
    if( !mxIsDouble(prhs[1471]) || mxIsComplex(prhs[1471]) || !(mxGetM(prhs[1471])==1 && mxGetN(prhs[1471])==1) ) { 
      mexErrMsgTxt("Input 1471 must be a noncomplex scalar double.");
    } 
    mexinput1471_temp = mxGetPr(prhs[1471]); 
    double mexinput1471 = *mexinput1471_temp; 

    double *mexinput1472_temp = NULL; 
    if( !mxIsDouble(prhs[1472]) || mxIsComplex(prhs[1472]) || !(mxGetM(prhs[1472])==1 && mxGetN(prhs[1472])==1) ) { 
      mexErrMsgTxt("Input 1472 must be a noncomplex scalar double.");
    } 
    mexinput1472_temp = mxGetPr(prhs[1472]); 
    double mexinput1472 = *mexinput1472_temp; 

    double *mexinput1473_temp = NULL; 
    if( !mxIsDouble(prhs[1473]) || mxIsComplex(prhs[1473]) || !(mxGetM(prhs[1473])==1 && mxGetN(prhs[1473])==1) ) { 
      mexErrMsgTxt("Input 1473 must be a noncomplex scalar double.");
    } 
    mexinput1473_temp = mxGetPr(prhs[1473]); 
    double mexinput1473 = *mexinput1473_temp; 

    double *mexinput1474_temp = NULL; 
    if( !mxIsDouble(prhs[1474]) || mxIsComplex(prhs[1474]) || !(mxGetM(prhs[1474])==1 && mxGetN(prhs[1474])==1) ) { 
      mexErrMsgTxt("Input 1474 must be a noncomplex scalar double.");
    } 
    mexinput1474_temp = mxGetPr(prhs[1474]); 
    double mexinput1474 = *mexinput1474_temp; 

    double *mexinput1475_temp = NULL; 
    if( !mxIsDouble(prhs[1475]) || mxIsComplex(prhs[1475]) || !(mxGetM(prhs[1475])==1 && mxGetN(prhs[1475])==1) ) { 
      mexErrMsgTxt("Input 1475 must be a noncomplex scalar double.");
    } 
    mexinput1475_temp = mxGetPr(prhs[1475]); 
    double mexinput1475 = *mexinput1475_temp; 

    double *mexinput1476_temp = NULL; 
    if( !mxIsDouble(prhs[1476]) || mxIsComplex(prhs[1476]) || !(mxGetM(prhs[1476])==1 && mxGetN(prhs[1476])==1) ) { 
      mexErrMsgTxt("Input 1476 must be a noncomplex scalar double.");
    } 
    mexinput1476_temp = mxGetPr(prhs[1476]); 
    double mexinput1476 = *mexinput1476_temp; 

    double *mexinput1477_temp = NULL; 
    if( !mxIsDouble(prhs[1477]) || mxIsComplex(prhs[1477]) || !(mxGetM(prhs[1477])==1 && mxGetN(prhs[1477])==1) ) { 
      mexErrMsgTxt("Input 1477 must be a noncomplex scalar double.");
    } 
    mexinput1477_temp = mxGetPr(prhs[1477]); 
    double mexinput1477 = *mexinput1477_temp; 

    double *mexinput1478_temp = NULL; 
    if( !mxIsDouble(prhs[1478]) || mxIsComplex(prhs[1478]) || !(mxGetM(prhs[1478])==1 && mxGetN(prhs[1478])==1) ) { 
      mexErrMsgTxt("Input 1478 must be a noncomplex scalar double.");
    } 
    mexinput1478_temp = mxGetPr(prhs[1478]); 
    double mexinput1478 = *mexinput1478_temp; 

    double *mexinput1479_temp = NULL; 
    if( !mxIsDouble(prhs[1479]) || mxIsComplex(prhs[1479]) || !(mxGetM(prhs[1479])==1 && mxGetN(prhs[1479])==1) ) { 
      mexErrMsgTxt("Input 1479 must be a noncomplex scalar double.");
    } 
    mexinput1479_temp = mxGetPr(prhs[1479]); 
    double mexinput1479 = *mexinput1479_temp; 

    double *mexinput1480_temp = NULL; 
    if( !mxIsDouble(prhs[1480]) || mxIsComplex(prhs[1480]) || !(mxGetM(prhs[1480])==1 && mxGetN(prhs[1480])==1) ) { 
      mexErrMsgTxt("Input 1480 must be a noncomplex scalar double.");
    } 
    mexinput1480_temp = mxGetPr(prhs[1480]); 
    double mexinput1480 = *mexinput1480_temp; 

    double *mexinput1481_temp = NULL; 
    if( !mxIsDouble(prhs[1481]) || mxIsComplex(prhs[1481]) || !(mxGetM(prhs[1481])==1 && mxGetN(prhs[1481])==1) ) { 
      mexErrMsgTxt("Input 1481 must be a noncomplex scalar double.");
    } 
    mexinput1481_temp = mxGetPr(prhs[1481]); 
    double mexinput1481 = *mexinput1481_temp; 

    double *mexinput1482_temp = NULL; 
    if( !mxIsDouble(prhs[1482]) || mxIsComplex(prhs[1482]) || !(mxGetM(prhs[1482])==1 && mxGetN(prhs[1482])==1) ) { 
      mexErrMsgTxt("Input 1482 must be a noncomplex scalar double.");
    } 
    mexinput1482_temp = mxGetPr(prhs[1482]); 
    double mexinput1482 = *mexinput1482_temp; 

    double *mexinput1483_temp = NULL; 
    if( !mxIsDouble(prhs[1483]) || mxIsComplex(prhs[1483]) || !(mxGetM(prhs[1483])==1 && mxGetN(prhs[1483])==1) ) { 
      mexErrMsgTxt("Input 1483 must be a noncomplex scalar double.");
    } 
    mexinput1483_temp = mxGetPr(prhs[1483]); 
    double mexinput1483 = *mexinput1483_temp; 

    double *mexinput1484_temp = NULL; 
    if( !mxIsDouble(prhs[1484]) || mxIsComplex(prhs[1484]) || !(mxGetM(prhs[1484])==1 && mxGetN(prhs[1484])==1) ) { 
      mexErrMsgTxt("Input 1484 must be a noncomplex scalar double.");
    } 
    mexinput1484_temp = mxGetPr(prhs[1484]); 
    double mexinput1484 = *mexinput1484_temp; 

    double *mexinput1485_temp = NULL; 
    if( !mxIsDouble(prhs[1485]) || mxIsComplex(prhs[1485]) || !(mxGetM(prhs[1485])==1 && mxGetN(prhs[1485])==1) ) { 
      mexErrMsgTxt("Input 1485 must be a noncomplex scalar double.");
    } 
    mexinput1485_temp = mxGetPr(prhs[1485]); 
    double mexinput1485 = *mexinput1485_temp; 

    double *mexinput1486_temp = NULL; 
    if( !mxIsDouble(prhs[1486]) || mxIsComplex(prhs[1486]) || !(mxGetM(prhs[1486])==1 && mxGetN(prhs[1486])==1) ) { 
      mexErrMsgTxt("Input 1486 must be a noncomplex scalar double.");
    } 
    mexinput1486_temp = mxGetPr(prhs[1486]); 
    double mexinput1486 = *mexinput1486_temp; 

    double *mexinput1487_temp = NULL; 
    if( !mxIsDouble(prhs[1487]) || mxIsComplex(prhs[1487]) || !(mxGetM(prhs[1487])==1 && mxGetN(prhs[1487])==1) ) { 
      mexErrMsgTxt("Input 1487 must be a noncomplex scalar double.");
    } 
    mexinput1487_temp = mxGetPr(prhs[1487]); 
    double mexinput1487 = *mexinput1487_temp; 

    double *mexinput1488_temp = NULL; 
    if( !mxIsDouble(prhs[1488]) || mxIsComplex(prhs[1488]) || !(mxGetM(prhs[1488])==1 && mxGetN(prhs[1488])==1) ) { 
      mexErrMsgTxt("Input 1488 must be a noncomplex scalar double.");
    } 
    mexinput1488_temp = mxGetPr(prhs[1488]); 
    double mexinput1488 = *mexinput1488_temp; 

    double *mexinput1489_temp = NULL; 
    if( !mxIsDouble(prhs[1489]) || mxIsComplex(prhs[1489]) || !(mxGetM(prhs[1489])==1 && mxGetN(prhs[1489])==1) ) { 
      mexErrMsgTxt("Input 1489 must be a noncomplex scalar double.");
    } 
    mexinput1489_temp = mxGetPr(prhs[1489]); 
    double mexinput1489 = *mexinput1489_temp; 

    double *mexinput1490_temp = NULL; 
    if( !mxIsDouble(prhs[1490]) || mxIsComplex(prhs[1490]) || !(mxGetM(prhs[1490])==1 && mxGetN(prhs[1490])==1) ) { 
      mexErrMsgTxt("Input 1490 must be a noncomplex scalar double.");
    } 
    mexinput1490_temp = mxGetPr(prhs[1490]); 
    double mexinput1490 = *mexinput1490_temp; 

    double *mexinput1491_temp = NULL; 
    if( !mxIsDouble(prhs[1491]) || mxIsComplex(prhs[1491]) || !(mxGetM(prhs[1491])==1 && mxGetN(prhs[1491])==1) ) { 
      mexErrMsgTxt("Input 1491 must be a noncomplex scalar double.");
    } 
    mexinput1491_temp = mxGetPr(prhs[1491]); 
    double mexinput1491 = *mexinput1491_temp; 

    double *mexinput1492_temp = NULL; 
    if( !mxIsDouble(prhs[1492]) || mxIsComplex(prhs[1492]) || !(mxGetM(prhs[1492])==1 && mxGetN(prhs[1492])==1) ) { 
      mexErrMsgTxt("Input 1492 must be a noncomplex scalar double.");
    } 
    mexinput1492_temp = mxGetPr(prhs[1492]); 
    double mexinput1492 = *mexinput1492_temp; 

    double *mexinput1493_temp = NULL; 
    if( !mxIsDouble(prhs[1493]) || mxIsComplex(prhs[1493]) || !(mxGetM(prhs[1493])==1 && mxGetN(prhs[1493])==1) ) { 
      mexErrMsgTxt("Input 1493 must be a noncomplex scalar double.");
    } 
    mexinput1493_temp = mxGetPr(prhs[1493]); 
    double mexinput1493 = *mexinput1493_temp; 

    double *mexinput1494_temp = NULL; 
    if( !mxIsDouble(prhs[1494]) || mxIsComplex(prhs[1494]) || !(mxGetM(prhs[1494])==1 && mxGetN(prhs[1494])==1) ) { 
      mexErrMsgTxt("Input 1494 must be a noncomplex scalar double.");
    } 
    mexinput1494_temp = mxGetPr(prhs[1494]); 
    double mexinput1494 = *mexinput1494_temp; 

    double *mexinput1495_temp = NULL; 
    if( !mxIsDouble(prhs[1495]) || mxIsComplex(prhs[1495]) || !(mxGetM(prhs[1495])==1 && mxGetN(prhs[1495])==1) ) { 
      mexErrMsgTxt("Input 1495 must be a noncomplex scalar double.");
    } 
    mexinput1495_temp = mxGetPr(prhs[1495]); 
    double mexinput1495 = *mexinput1495_temp; 

    double *mexinput1496_temp = NULL; 
    if( !mxIsDouble(prhs[1496]) || mxIsComplex(prhs[1496]) || !(mxGetM(prhs[1496])==1 && mxGetN(prhs[1496])==1) ) { 
      mexErrMsgTxt("Input 1496 must be a noncomplex scalar double.");
    } 
    mexinput1496_temp = mxGetPr(prhs[1496]); 
    double mexinput1496 = *mexinput1496_temp; 

    double *mexinput1497_temp = NULL; 
    if( !mxIsDouble(prhs[1497]) || mxIsComplex(prhs[1497]) || !(mxGetM(prhs[1497])==1 && mxGetN(prhs[1497])==1) ) { 
      mexErrMsgTxt("Input 1497 must be a noncomplex scalar double.");
    } 
    mexinput1497_temp = mxGetPr(prhs[1497]); 
    double mexinput1497 = *mexinput1497_temp; 

    double *mexinput1498_temp = NULL; 
    if( !mxIsDouble(prhs[1498]) || mxIsComplex(prhs[1498]) || !(mxGetM(prhs[1498])==1 && mxGetN(prhs[1498])==1) ) { 
      mexErrMsgTxt("Input 1498 must be a noncomplex scalar double.");
    } 
    mexinput1498_temp = mxGetPr(prhs[1498]); 
    double mexinput1498 = *mexinput1498_temp; 

    double *mexinput1499_temp = NULL; 
    if( !mxIsDouble(prhs[1499]) || mxIsComplex(prhs[1499]) || !(mxGetM(prhs[1499])==1 && mxGetN(prhs[1499])==1) ) { 
      mexErrMsgTxt("Input 1499 must be a noncomplex scalar double.");
    } 
    mexinput1499_temp = mxGetPr(prhs[1499]); 
    double mexinput1499 = *mexinput1499_temp; 

    double *mexinput1500_temp = NULL; 
    if( !mxIsDouble(prhs[1500]) || mxIsComplex(prhs[1500]) || !(mxGetM(prhs[1500])==1 && mxGetN(prhs[1500])==1) ) { 
      mexErrMsgTxt("Input 1500 must be a noncomplex scalar double.");
    } 
    mexinput1500_temp = mxGetPr(prhs[1500]); 
    double mexinput1500 = *mexinput1500_temp; 

    double *mexinput1501_temp = NULL; 
    if( !mxIsDouble(prhs[1501]) || mxIsComplex(prhs[1501]) || !(mxGetM(prhs[1501])==1 && mxGetN(prhs[1501])==1) ) { 
      mexErrMsgTxt("Input 1501 must be a noncomplex scalar double.");
    } 
    mexinput1501_temp = mxGetPr(prhs[1501]); 
    double mexinput1501 = *mexinput1501_temp; 

    double *mexinput1502_temp = NULL; 
    if( !mxIsDouble(prhs[1502]) || mxIsComplex(prhs[1502]) || !(mxGetM(prhs[1502])==1 && mxGetN(prhs[1502])==1) ) { 
      mexErrMsgTxt("Input 1502 must be a noncomplex scalar double.");
    } 
    mexinput1502_temp = mxGetPr(prhs[1502]); 
    double mexinput1502 = *mexinput1502_temp; 

    double *mexinput1503_temp = NULL; 
    if( !mxIsDouble(prhs[1503]) || mxIsComplex(prhs[1503]) || !(mxGetM(prhs[1503])==1 && mxGetN(prhs[1503])==1) ) { 
      mexErrMsgTxt("Input 1503 must be a noncomplex scalar double.");
    } 
    mexinput1503_temp = mxGetPr(prhs[1503]); 
    double mexinput1503 = *mexinput1503_temp; 

    double *mexinput1504_temp = NULL; 
    if( !mxIsDouble(prhs[1504]) || mxIsComplex(prhs[1504]) || !(mxGetM(prhs[1504])==1 && mxGetN(prhs[1504])==1) ) { 
      mexErrMsgTxt("Input 1504 must be a noncomplex scalar double.");
    } 
    mexinput1504_temp = mxGetPr(prhs[1504]); 
    double mexinput1504 = *mexinput1504_temp; 

    double *mexinput1505_temp = NULL; 
    if( !mxIsDouble(prhs[1505]) || mxIsComplex(prhs[1505]) || !(mxGetM(prhs[1505])==1 && mxGetN(prhs[1505])==1) ) { 
      mexErrMsgTxt("Input 1505 must be a noncomplex scalar double.");
    } 
    mexinput1505_temp = mxGetPr(prhs[1505]); 
    double mexinput1505 = *mexinput1505_temp; 

    double *mexinput1506_temp = NULL; 
    if( !mxIsDouble(prhs[1506]) || mxIsComplex(prhs[1506]) || !(mxGetM(prhs[1506])==1 && mxGetN(prhs[1506])==1) ) { 
      mexErrMsgTxt("Input 1506 must be a noncomplex scalar double.");
    } 
    mexinput1506_temp = mxGetPr(prhs[1506]); 
    double mexinput1506 = *mexinput1506_temp; 

    double *mexinput1507_temp = NULL; 
    if( !mxIsDouble(prhs[1507]) || mxIsComplex(prhs[1507]) || !(mxGetM(prhs[1507])==1 && mxGetN(prhs[1507])==1) ) { 
      mexErrMsgTxt("Input 1507 must be a noncomplex scalar double.");
    } 
    mexinput1507_temp = mxGetPr(prhs[1507]); 
    double mexinput1507 = *mexinput1507_temp; 

    double *mexinput1508_temp = NULL; 
    if( !mxIsDouble(prhs[1508]) || mxIsComplex(prhs[1508]) || !(mxGetM(prhs[1508])==1 && mxGetN(prhs[1508])==1) ) { 
      mexErrMsgTxt("Input 1508 must be a noncomplex scalar double.");
    } 
    mexinput1508_temp = mxGetPr(prhs[1508]); 
    double mexinput1508 = *mexinput1508_temp; 

    double *mexinput1509_temp = NULL; 
    if( !mxIsDouble(prhs[1509]) || mxIsComplex(prhs[1509]) || !(mxGetM(prhs[1509])==1 && mxGetN(prhs[1509])==1) ) { 
      mexErrMsgTxt("Input 1509 must be a noncomplex scalar double.");
    } 
    mexinput1509_temp = mxGetPr(prhs[1509]); 
    double mexinput1509 = *mexinput1509_temp; 

    double *mexinput1510_temp = NULL; 
    if( !mxIsDouble(prhs[1510]) || mxIsComplex(prhs[1510]) || !(mxGetM(prhs[1510])==1 && mxGetN(prhs[1510])==1) ) { 
      mexErrMsgTxt("Input 1510 must be a noncomplex scalar double.");
    } 
    mexinput1510_temp = mxGetPr(prhs[1510]); 
    double mexinput1510 = *mexinput1510_temp; 

    double *mexinput1511_temp = NULL; 
    if( !mxIsDouble(prhs[1511]) || mxIsComplex(prhs[1511]) || !(mxGetM(prhs[1511])==1 && mxGetN(prhs[1511])==1) ) { 
      mexErrMsgTxt("Input 1511 must be a noncomplex scalar double.");
    } 
    mexinput1511_temp = mxGetPr(prhs[1511]); 
    double mexinput1511 = *mexinput1511_temp; 

    double *mexinput1512_temp = NULL; 
    if( !mxIsDouble(prhs[1512]) || mxIsComplex(prhs[1512]) || !(mxGetM(prhs[1512])==1 && mxGetN(prhs[1512])==1) ) { 
      mexErrMsgTxt("Input 1512 must be a noncomplex scalar double.");
    } 
    mexinput1512_temp = mxGetPr(prhs[1512]); 
    double mexinput1512 = *mexinput1512_temp; 

    double *mexinput1513_temp = NULL; 
    if( !mxIsDouble(prhs[1513]) || mxIsComplex(prhs[1513]) || !(mxGetM(prhs[1513])==1 && mxGetN(prhs[1513])==1) ) { 
      mexErrMsgTxt("Input 1513 must be a noncomplex scalar double.");
    } 
    mexinput1513_temp = mxGetPr(prhs[1513]); 
    double mexinput1513 = *mexinput1513_temp; 

    double *mexinput1514_temp = NULL; 
    if( !mxIsDouble(prhs[1514]) || mxIsComplex(prhs[1514]) || !(mxGetM(prhs[1514])==1 && mxGetN(prhs[1514])==1) ) { 
      mexErrMsgTxt("Input 1514 must be a noncomplex scalar double.");
    } 
    mexinput1514_temp = mxGetPr(prhs[1514]); 
    double mexinput1514 = *mexinput1514_temp; 

    double *mexinput1515_temp = NULL; 
    if( !mxIsDouble(prhs[1515]) || mxIsComplex(prhs[1515]) || !(mxGetM(prhs[1515])==1 && mxGetN(prhs[1515])==1) ) { 
      mexErrMsgTxt("Input 1515 must be a noncomplex scalar double.");
    } 
    mexinput1515_temp = mxGetPr(prhs[1515]); 
    double mexinput1515 = *mexinput1515_temp; 

    double *mexinput1516_temp = NULL; 
    if( !mxIsDouble(prhs[1516]) || mxIsComplex(prhs[1516]) || !(mxGetM(prhs[1516])==1 && mxGetN(prhs[1516])==1) ) { 
      mexErrMsgTxt("Input 1516 must be a noncomplex scalar double.");
    } 
    mexinput1516_temp = mxGetPr(prhs[1516]); 
    double mexinput1516 = *mexinput1516_temp; 

    double *mexinput1517_temp = NULL; 
    if( !mxIsDouble(prhs[1517]) || mxIsComplex(prhs[1517]) || !(mxGetM(prhs[1517])==1 && mxGetN(prhs[1517])==1) ) { 
      mexErrMsgTxt("Input 1517 must be a noncomplex scalar double.");
    } 
    mexinput1517_temp = mxGetPr(prhs[1517]); 
    double mexinput1517 = *mexinput1517_temp; 

    double *mexinput1518_temp = NULL; 
    if( !mxIsDouble(prhs[1518]) || mxIsComplex(prhs[1518]) || !(mxGetM(prhs[1518])==1 && mxGetN(prhs[1518])==1) ) { 
      mexErrMsgTxt("Input 1518 must be a noncomplex scalar double.");
    } 
    mexinput1518_temp = mxGetPr(prhs[1518]); 
    double mexinput1518 = *mexinput1518_temp; 

    double *mexinput1519_temp = NULL; 
    if( !mxIsDouble(prhs[1519]) || mxIsComplex(prhs[1519]) || !(mxGetM(prhs[1519])==1 && mxGetN(prhs[1519])==1) ) { 
      mexErrMsgTxt("Input 1519 must be a noncomplex scalar double.");
    } 
    mexinput1519_temp = mxGetPr(prhs[1519]); 
    double mexinput1519 = *mexinput1519_temp; 

    double *mexinput1520_temp = NULL; 
    if( !mxIsDouble(prhs[1520]) || mxIsComplex(prhs[1520]) || !(mxGetM(prhs[1520])==1 && mxGetN(prhs[1520])==1) ) { 
      mexErrMsgTxt("Input 1520 must be a noncomplex scalar double.");
    } 
    mexinput1520_temp = mxGetPr(prhs[1520]); 
    double mexinput1520 = *mexinput1520_temp; 

    double *mexinput1521_temp = NULL; 
    if( !mxIsDouble(prhs[1521]) || mxIsComplex(prhs[1521]) || !(mxGetM(prhs[1521])==1 && mxGetN(prhs[1521])==1) ) { 
      mexErrMsgTxt("Input 1521 must be a noncomplex scalar double.");
    } 
    mexinput1521_temp = mxGetPr(prhs[1521]); 
    double mexinput1521 = *mexinput1521_temp; 

    double *mexinput1522_temp = NULL; 
    if( !mxIsDouble(prhs[1522]) || mxIsComplex(prhs[1522]) || !(mxGetM(prhs[1522])==1 && mxGetN(prhs[1522])==1) ) { 
      mexErrMsgTxt("Input 1522 must be a noncomplex scalar double.");
    } 
    mexinput1522_temp = mxGetPr(prhs[1522]); 
    double mexinput1522 = *mexinput1522_temp; 

    double *mexinput1523_temp = NULL; 
    if( !mxIsDouble(prhs[1523]) || mxIsComplex(prhs[1523]) || !(mxGetM(prhs[1523])==1 && mxGetN(prhs[1523])==1) ) { 
      mexErrMsgTxt("Input 1523 must be a noncomplex scalar double.");
    } 
    mexinput1523_temp = mxGetPr(prhs[1523]); 
    double mexinput1523 = *mexinput1523_temp; 

    double *mexinput1524_temp = NULL; 
    if( !mxIsDouble(prhs[1524]) || mxIsComplex(prhs[1524]) || !(mxGetM(prhs[1524])==1 && mxGetN(prhs[1524])==1) ) { 
      mexErrMsgTxt("Input 1524 must be a noncomplex scalar double.");
    } 
    mexinput1524_temp = mxGetPr(prhs[1524]); 
    double mexinput1524 = *mexinput1524_temp; 

    double *mexinput1525_temp = NULL; 
    if( !mxIsDouble(prhs[1525]) || mxIsComplex(prhs[1525]) || !(mxGetM(prhs[1525])==1 && mxGetN(prhs[1525])==1) ) { 
      mexErrMsgTxt("Input 1525 must be a noncomplex scalar double.");
    } 
    mexinput1525_temp = mxGetPr(prhs[1525]); 
    double mexinput1525 = *mexinput1525_temp; 

    double *mexinput1526_temp = NULL; 
    if( !mxIsDouble(prhs[1526]) || mxIsComplex(prhs[1526]) || !(mxGetM(prhs[1526])==1 && mxGetN(prhs[1526])==1) ) { 
      mexErrMsgTxt("Input 1526 must be a noncomplex scalar double.");
    } 
    mexinput1526_temp = mxGetPr(prhs[1526]); 
    double mexinput1526 = *mexinput1526_temp; 

    double *mexinput1527_temp = NULL; 
    if( !mxIsDouble(prhs[1527]) || mxIsComplex(prhs[1527]) || !(mxGetM(prhs[1527])==1 && mxGetN(prhs[1527])==1) ) { 
      mexErrMsgTxt("Input 1527 must be a noncomplex scalar double.");
    } 
    mexinput1527_temp = mxGetPr(prhs[1527]); 
    double mexinput1527 = *mexinput1527_temp; 

    double *mexinput1528_temp = NULL; 
    if( !mxIsDouble(prhs[1528]) || mxIsComplex(prhs[1528]) || !(mxGetM(prhs[1528])==1 && mxGetN(prhs[1528])==1) ) { 
      mexErrMsgTxt("Input 1528 must be a noncomplex scalar double.");
    } 
    mexinput1528_temp = mxGetPr(prhs[1528]); 
    double mexinput1528 = *mexinput1528_temp; 

    double *mexinput1529_temp = NULL; 
    if( !mxIsDouble(prhs[1529]) || mxIsComplex(prhs[1529]) || !(mxGetM(prhs[1529])==1 && mxGetN(prhs[1529])==1) ) { 
      mexErrMsgTxt("Input 1529 must be a noncomplex scalar double.");
    } 
    mexinput1529_temp = mxGetPr(prhs[1529]); 
    double mexinput1529 = *mexinput1529_temp; 

    double *mexinput1530_temp = NULL; 
    if( !mxIsDouble(prhs[1530]) || mxIsComplex(prhs[1530]) || !(mxGetM(prhs[1530])==1 && mxGetN(prhs[1530])==1) ) { 
      mexErrMsgTxt("Input 1530 must be a noncomplex scalar double.");
    } 
    mexinput1530_temp = mxGetPr(prhs[1530]); 
    double mexinput1530 = *mexinput1530_temp; 

    double *mexinput1531_temp = NULL; 
    if( !mxIsDouble(prhs[1531]) || mxIsComplex(prhs[1531]) || !(mxGetM(prhs[1531])==1 && mxGetN(prhs[1531])==1) ) { 
      mexErrMsgTxt("Input 1531 must be a noncomplex scalar double.");
    } 
    mexinput1531_temp = mxGetPr(prhs[1531]); 
    double mexinput1531 = *mexinput1531_temp; 

    double *mexinput1532_temp = NULL; 
    if( !mxIsDouble(prhs[1532]) || mxIsComplex(prhs[1532]) || !(mxGetM(prhs[1532])==1 && mxGetN(prhs[1532])==1) ) { 
      mexErrMsgTxt("Input 1532 must be a noncomplex scalar double.");
    } 
    mexinput1532_temp = mxGetPr(prhs[1532]); 
    double mexinput1532 = *mexinput1532_temp; 

    double *mexinput1533_temp = NULL; 
    if( !mxIsDouble(prhs[1533]) || mxIsComplex(prhs[1533]) || !(mxGetM(prhs[1533])==1 && mxGetN(prhs[1533])==1) ) { 
      mexErrMsgTxt("Input 1533 must be a noncomplex scalar double.");
    } 
    mexinput1533_temp = mxGetPr(prhs[1533]); 
    double mexinput1533 = *mexinput1533_temp; 

    double *mexinput1534_temp = NULL; 
    if( !mxIsDouble(prhs[1534]) || mxIsComplex(prhs[1534]) || !(mxGetM(prhs[1534])==1 && mxGetN(prhs[1534])==1) ) { 
      mexErrMsgTxt("Input 1534 must be a noncomplex scalar double.");
    } 
    mexinput1534_temp = mxGetPr(prhs[1534]); 
    double mexinput1534 = *mexinput1534_temp; 

    double *mexinput1535_temp = NULL; 
    if( !mxIsDouble(prhs[1535]) || mxIsComplex(prhs[1535]) || !(mxGetM(prhs[1535])==1 && mxGetN(prhs[1535])==1) ) { 
      mexErrMsgTxt("Input 1535 must be a noncomplex scalar double.");
    } 
    mexinput1535_temp = mxGetPr(prhs[1535]); 
    double mexinput1535 = *mexinput1535_temp; 

    double *mexinput1536_temp = NULL; 
    if( !mxIsDouble(prhs[1536]) || mxIsComplex(prhs[1536]) || !(mxGetM(prhs[1536])==1 && mxGetN(prhs[1536])==1) ) { 
      mexErrMsgTxt("Input 1536 must be a noncomplex scalar double.");
    } 
    mexinput1536_temp = mxGetPr(prhs[1536]); 
    double mexinput1536 = *mexinput1536_temp; 

    double *mexinput1537_temp = NULL; 
    if( !mxIsDouble(prhs[1537]) || mxIsComplex(prhs[1537]) || !(mxGetM(prhs[1537])==1 && mxGetN(prhs[1537])==1) ) { 
      mexErrMsgTxt("Input 1537 must be a noncomplex scalar double.");
    } 
    mexinput1537_temp = mxGetPr(prhs[1537]); 
    double mexinput1537 = *mexinput1537_temp; 

    double *mexinput1538_temp = NULL; 
    if( !mxIsDouble(prhs[1538]) || mxIsComplex(prhs[1538]) || !(mxGetM(prhs[1538])==1 && mxGetN(prhs[1538])==1) ) { 
      mexErrMsgTxt("Input 1538 must be a noncomplex scalar double.");
    } 
    mexinput1538_temp = mxGetPr(prhs[1538]); 
    double mexinput1538 = *mexinput1538_temp; 

    double *mexinput1539_temp = NULL; 
    if( !mxIsDouble(prhs[1539]) || mxIsComplex(prhs[1539]) || !(mxGetM(prhs[1539])==1 && mxGetN(prhs[1539])==1) ) { 
      mexErrMsgTxt("Input 1539 must be a noncomplex scalar double.");
    } 
    mexinput1539_temp = mxGetPr(prhs[1539]); 
    double mexinput1539 = *mexinput1539_temp; 

    double *mexinput1540_temp = NULL; 
    if( !mxIsDouble(prhs[1540]) || mxIsComplex(prhs[1540]) || !(mxGetM(prhs[1540])==1 && mxGetN(prhs[1540])==1) ) { 
      mexErrMsgTxt("Input 1540 must be a noncomplex scalar double.");
    } 
    mexinput1540_temp = mxGetPr(prhs[1540]); 
    double mexinput1540 = *mexinput1540_temp; 

    double *mexinput1541_temp = NULL; 
    if( !mxIsDouble(prhs[1541]) || mxIsComplex(prhs[1541]) || !(mxGetM(prhs[1541])==1 && mxGetN(prhs[1541])==1) ) { 
      mexErrMsgTxt("Input 1541 must be a noncomplex scalar double.");
    } 
    mexinput1541_temp = mxGetPr(prhs[1541]); 
    double mexinput1541 = *mexinput1541_temp; 

    double *mexinput1542_temp = NULL; 
    if( !mxIsDouble(prhs[1542]) || mxIsComplex(prhs[1542]) || !(mxGetM(prhs[1542])==1 && mxGetN(prhs[1542])==1) ) { 
      mexErrMsgTxt("Input 1542 must be a noncomplex scalar double.");
    } 
    mexinput1542_temp = mxGetPr(prhs[1542]); 
    double mexinput1542 = *mexinput1542_temp; 

    double *mexinput1543_temp = NULL; 
    if( !mxIsDouble(prhs[1543]) || mxIsComplex(prhs[1543]) || !(mxGetM(prhs[1543])==1 && mxGetN(prhs[1543])==1) ) { 
      mexErrMsgTxt("Input 1543 must be a noncomplex scalar double.");
    } 
    mexinput1543_temp = mxGetPr(prhs[1543]); 
    double mexinput1543 = *mexinput1543_temp; 

    double *mexinput1544_temp = NULL; 
    if( !mxIsDouble(prhs[1544]) || mxIsComplex(prhs[1544]) || !(mxGetM(prhs[1544])==1 && mxGetN(prhs[1544])==1) ) { 
      mexErrMsgTxt("Input 1544 must be a noncomplex scalar double.");
    } 
    mexinput1544_temp = mxGetPr(prhs[1544]); 
    double mexinput1544 = *mexinput1544_temp; 

    double *mexinput1545_temp = NULL; 
    if( !mxIsDouble(prhs[1545]) || mxIsComplex(prhs[1545]) || !(mxGetM(prhs[1545])==1 && mxGetN(prhs[1545])==1) ) { 
      mexErrMsgTxt("Input 1545 must be a noncomplex scalar double.");
    } 
    mexinput1545_temp = mxGetPr(prhs[1545]); 
    double mexinput1545 = *mexinput1545_temp; 

    double *mexinput1546_temp = NULL; 
    if( !mxIsDouble(prhs[1546]) || mxIsComplex(prhs[1546]) || !(mxGetM(prhs[1546])==1 && mxGetN(prhs[1546])==1) ) { 
      mexErrMsgTxt("Input 1546 must be a noncomplex scalar double.");
    } 
    mexinput1546_temp = mxGetPr(prhs[1546]); 
    double mexinput1546 = *mexinput1546_temp; 

    double *mexinput1547_temp = NULL; 
    if( !mxIsDouble(prhs[1547]) || mxIsComplex(prhs[1547]) || !(mxGetM(prhs[1547])==1 && mxGetN(prhs[1547])==1) ) { 
      mexErrMsgTxt("Input 1547 must be a noncomplex scalar double.");
    } 
    mexinput1547_temp = mxGetPr(prhs[1547]); 
    double mexinput1547 = *mexinput1547_temp; 

    double *mexinput1548_temp = NULL; 
    if( !mxIsDouble(prhs[1548]) || mxIsComplex(prhs[1548]) || !(mxGetM(prhs[1548])==1 && mxGetN(prhs[1548])==1) ) { 
      mexErrMsgTxt("Input 1548 must be a noncomplex scalar double.");
    } 
    mexinput1548_temp = mxGetPr(prhs[1548]); 
    double mexinput1548 = *mexinput1548_temp; 

    double *mexinput1549_temp = NULL; 
    if( !mxIsDouble(prhs[1549]) || mxIsComplex(prhs[1549]) || !(mxGetM(prhs[1549])==1 && mxGetN(prhs[1549])==1) ) { 
      mexErrMsgTxt("Input 1549 must be a noncomplex scalar double.");
    } 
    mexinput1549_temp = mxGetPr(prhs[1549]); 
    double mexinput1549 = *mexinput1549_temp; 

    double *mexinput1550_temp = NULL; 
    if( !mxIsDouble(prhs[1550]) || mxIsComplex(prhs[1550]) || !(mxGetM(prhs[1550])==1 && mxGetN(prhs[1550])==1) ) { 
      mexErrMsgTxt("Input 1550 must be a noncomplex scalar double.");
    } 
    mexinput1550_temp = mxGetPr(prhs[1550]); 
    double mexinput1550 = *mexinput1550_temp; 

    double *mexinput1551_temp = NULL; 
    if( !mxIsDouble(prhs[1551]) || mxIsComplex(prhs[1551]) || !(mxGetM(prhs[1551])==1 && mxGetN(prhs[1551])==1) ) { 
      mexErrMsgTxt("Input 1551 must be a noncomplex scalar double.");
    } 
    mexinput1551_temp = mxGetPr(prhs[1551]); 
    double mexinput1551 = *mexinput1551_temp; 

    double *mexinput1552_temp = NULL; 
    if( !mxIsDouble(prhs[1552]) || mxIsComplex(prhs[1552]) || !(mxGetM(prhs[1552])==1 && mxGetN(prhs[1552])==1) ) { 
      mexErrMsgTxt("Input 1552 must be a noncomplex scalar double.");
    } 
    mexinput1552_temp = mxGetPr(prhs[1552]); 
    double mexinput1552 = *mexinput1552_temp; 

    double *mexinput1553_temp = NULL; 
    if( !mxIsDouble(prhs[1553]) || mxIsComplex(prhs[1553]) || !(mxGetM(prhs[1553])==1 && mxGetN(prhs[1553])==1) ) { 
      mexErrMsgTxt("Input 1553 must be a noncomplex scalar double.");
    } 
    mexinput1553_temp = mxGetPr(prhs[1553]); 
    double mexinput1553 = *mexinput1553_temp; 

    double *mexinput1554_temp = NULL; 
    if( !mxIsDouble(prhs[1554]) || mxIsComplex(prhs[1554]) || !(mxGetM(prhs[1554])==1 && mxGetN(prhs[1554])==1) ) { 
      mexErrMsgTxt("Input 1554 must be a noncomplex scalar double.");
    } 
    mexinput1554_temp = mxGetPr(prhs[1554]); 
    double mexinput1554 = *mexinput1554_temp; 

    double *mexinput1555_temp = NULL; 
    if( !mxIsDouble(prhs[1555]) || mxIsComplex(prhs[1555]) || !(mxGetM(prhs[1555])==1 && mxGetN(prhs[1555])==1) ) { 
      mexErrMsgTxt("Input 1555 must be a noncomplex scalar double.");
    } 
    mexinput1555_temp = mxGetPr(prhs[1555]); 
    double mexinput1555 = *mexinput1555_temp; 

    double *mexinput1556_temp = NULL; 
    if( !mxIsDouble(prhs[1556]) || mxIsComplex(prhs[1556]) || !(mxGetM(prhs[1556])==1 && mxGetN(prhs[1556])==1) ) { 
      mexErrMsgTxt("Input 1556 must be a noncomplex scalar double.");
    } 
    mexinput1556_temp = mxGetPr(prhs[1556]); 
    double mexinput1556 = *mexinput1556_temp; 

    double *mexinput1557_temp = NULL; 
    if( !mxIsDouble(prhs[1557]) || mxIsComplex(prhs[1557]) || !(mxGetM(prhs[1557])==1 && mxGetN(prhs[1557])==1) ) { 
      mexErrMsgTxt("Input 1557 must be a noncomplex scalar double.");
    } 
    mexinput1557_temp = mxGetPr(prhs[1557]); 
    double mexinput1557 = *mexinput1557_temp; 

    double *mexinput1558_temp = NULL; 
    if( !mxIsDouble(prhs[1558]) || mxIsComplex(prhs[1558]) || !(mxGetM(prhs[1558])==1 && mxGetN(prhs[1558])==1) ) { 
      mexErrMsgTxt("Input 1558 must be a noncomplex scalar double.");
    } 
    mexinput1558_temp = mxGetPr(prhs[1558]); 
    double mexinput1558 = *mexinput1558_temp; 

    double *mexinput1559_temp = NULL; 
    if( !mxIsDouble(prhs[1559]) || mxIsComplex(prhs[1559]) || !(mxGetM(prhs[1559])==1 && mxGetN(prhs[1559])==1) ) { 
      mexErrMsgTxt("Input 1559 must be a noncomplex scalar double.");
    } 
    mexinput1559_temp = mxGetPr(prhs[1559]); 
    double mexinput1559 = *mexinput1559_temp; 

    double *mexinput1560_temp = NULL; 
    if( !mxIsDouble(prhs[1560]) || mxIsComplex(prhs[1560]) || !(mxGetM(prhs[1560])==1 && mxGetN(prhs[1560])==1) ) { 
      mexErrMsgTxt("Input 1560 must be a noncomplex scalar double.");
    } 
    mexinput1560_temp = mxGetPr(prhs[1560]); 
    double mexinput1560 = *mexinput1560_temp; 

    double *mexinput1561_temp = NULL; 
    if( !mxIsDouble(prhs[1561]) || mxIsComplex(prhs[1561]) || !(mxGetM(prhs[1561])==1 && mxGetN(prhs[1561])==1) ) { 
      mexErrMsgTxt("Input 1561 must be a noncomplex scalar double.");
    } 
    mexinput1561_temp = mxGetPr(prhs[1561]); 
    double mexinput1561 = *mexinput1561_temp; 

    double *mexinput1562_temp = NULL; 
    if( !mxIsDouble(prhs[1562]) || mxIsComplex(prhs[1562]) || !(mxGetM(prhs[1562])==1 && mxGetN(prhs[1562])==1) ) { 
      mexErrMsgTxt("Input 1562 must be a noncomplex scalar double.");
    } 
    mexinput1562_temp = mxGetPr(prhs[1562]); 
    double mexinput1562 = *mexinput1562_temp; 

    double *mexinput1563_temp = NULL; 
    if( !mxIsDouble(prhs[1563]) || mxIsComplex(prhs[1563]) || !(mxGetM(prhs[1563])==1 && mxGetN(prhs[1563])==1) ) { 
      mexErrMsgTxt("Input 1563 must be a noncomplex scalar double.");
    } 
    mexinput1563_temp = mxGetPr(prhs[1563]); 
    double mexinput1563 = *mexinput1563_temp; 

    double *mexinput1564_temp = NULL; 
    if( !mxIsDouble(prhs[1564]) || mxIsComplex(prhs[1564]) || !(mxGetM(prhs[1564])==1 && mxGetN(prhs[1564])==1) ) { 
      mexErrMsgTxt("Input 1564 must be a noncomplex scalar double.");
    } 
    mexinput1564_temp = mxGetPr(prhs[1564]); 
    double mexinput1564 = *mexinput1564_temp; 

    double *mexinput1565_temp = NULL; 
    if( !mxIsDouble(prhs[1565]) || mxIsComplex(prhs[1565]) || !(mxGetM(prhs[1565])==1 && mxGetN(prhs[1565])==1) ) { 
      mexErrMsgTxt("Input 1565 must be a noncomplex scalar double.");
    } 
    mexinput1565_temp = mxGetPr(prhs[1565]); 
    double mexinput1565 = *mexinput1565_temp; 

    double *mexinput1566_temp = NULL; 
    if( !mxIsDouble(prhs[1566]) || mxIsComplex(prhs[1566]) || !(mxGetM(prhs[1566])==1 && mxGetN(prhs[1566])==1) ) { 
      mexErrMsgTxt("Input 1566 must be a noncomplex scalar double.");
    } 
    mexinput1566_temp = mxGetPr(prhs[1566]); 
    double mexinput1566 = *mexinput1566_temp; 

    double *mexinput1567_temp = NULL; 
    if( !mxIsDouble(prhs[1567]) || mxIsComplex(prhs[1567]) || !(mxGetM(prhs[1567])==1 && mxGetN(prhs[1567])==1) ) { 
      mexErrMsgTxt("Input 1567 must be a noncomplex scalar double.");
    } 
    mexinput1567_temp = mxGetPr(prhs[1567]); 
    double mexinput1567 = *mexinput1567_temp; 

    double *mexinput1568_temp = NULL; 
    if( !mxIsDouble(prhs[1568]) || mxIsComplex(prhs[1568]) || !(mxGetM(prhs[1568])==1 && mxGetN(prhs[1568])==1) ) { 
      mexErrMsgTxt("Input 1568 must be a noncomplex scalar double.");
    } 
    mexinput1568_temp = mxGetPr(prhs[1568]); 
    double mexinput1568 = *mexinput1568_temp; 

    double *mexinput1569_temp = NULL; 
    if( !mxIsDouble(prhs[1569]) || mxIsComplex(prhs[1569]) || !(mxGetM(prhs[1569])==1 && mxGetN(prhs[1569])==1) ) { 
      mexErrMsgTxt("Input 1569 must be a noncomplex scalar double.");
    } 
    mexinput1569_temp = mxGetPr(prhs[1569]); 
    double mexinput1569 = *mexinput1569_temp; 

    double *mexinput1570_temp = NULL; 
    if( !mxIsDouble(prhs[1570]) || mxIsComplex(prhs[1570]) || !(mxGetM(prhs[1570])==1 && mxGetN(prhs[1570])==1) ) { 
      mexErrMsgTxt("Input 1570 must be a noncomplex scalar double.");
    } 
    mexinput1570_temp = mxGetPr(prhs[1570]); 
    double mexinput1570 = *mexinput1570_temp; 

    double *mexinput1571_temp = NULL; 
    if( !mxIsDouble(prhs[1571]) || mxIsComplex(prhs[1571]) || !(mxGetM(prhs[1571])==1 && mxGetN(prhs[1571])==1) ) { 
      mexErrMsgTxt("Input 1571 must be a noncomplex scalar double.");
    } 
    mexinput1571_temp = mxGetPr(prhs[1571]); 
    double mexinput1571 = *mexinput1571_temp; 

    double *mexinput1572_temp = NULL; 
    if( !mxIsDouble(prhs[1572]) || mxIsComplex(prhs[1572]) || !(mxGetM(prhs[1572])==1 && mxGetN(prhs[1572])==1) ) { 
      mexErrMsgTxt("Input 1572 must be a noncomplex scalar double.");
    } 
    mexinput1572_temp = mxGetPr(prhs[1572]); 
    double mexinput1572 = *mexinput1572_temp; 

    double *mexinput1573_temp = NULL; 
    if( !mxIsDouble(prhs[1573]) || mxIsComplex(prhs[1573]) || !(mxGetM(prhs[1573])==1 && mxGetN(prhs[1573])==1) ) { 
      mexErrMsgTxt("Input 1573 must be a noncomplex scalar double.");
    } 
    mexinput1573_temp = mxGetPr(prhs[1573]); 
    double mexinput1573 = *mexinput1573_temp; 

    double *mexinput1574_temp = NULL; 
    if( !mxIsDouble(prhs[1574]) || mxIsComplex(prhs[1574]) || !(mxGetM(prhs[1574])==1 && mxGetN(prhs[1574])==1) ) { 
      mexErrMsgTxt("Input 1574 must be a noncomplex scalar double.");
    } 
    mexinput1574_temp = mxGetPr(prhs[1574]); 
    double mexinput1574 = *mexinput1574_temp; 

    double *mexinput1575_temp = NULL; 
    if( !mxIsDouble(prhs[1575]) || mxIsComplex(prhs[1575]) || !(mxGetM(prhs[1575])==1 && mxGetN(prhs[1575])==1) ) { 
      mexErrMsgTxt("Input 1575 must be a noncomplex scalar double.");
    } 
    mexinput1575_temp = mxGetPr(prhs[1575]); 
    double mexinput1575 = *mexinput1575_temp; 

    double *mexinput1576_temp = NULL; 
    if( !mxIsDouble(prhs[1576]) || mxIsComplex(prhs[1576]) || !(mxGetM(prhs[1576])==1 && mxGetN(prhs[1576])==1) ) { 
      mexErrMsgTxt("Input 1576 must be a noncomplex scalar double.");
    } 
    mexinput1576_temp = mxGetPr(prhs[1576]); 
    double mexinput1576 = *mexinput1576_temp; 

    double *mexinput1577_temp = NULL; 
    if( !mxIsDouble(prhs[1577]) || mxIsComplex(prhs[1577]) || !(mxGetM(prhs[1577])==1 && mxGetN(prhs[1577])==1) ) { 
      mexErrMsgTxt("Input 1577 must be a noncomplex scalar double.");
    } 
    mexinput1577_temp = mxGetPr(prhs[1577]); 
    double mexinput1577 = *mexinput1577_temp; 

    double *mexinput1578_temp = NULL; 
    if( !mxIsDouble(prhs[1578]) || mxIsComplex(prhs[1578]) || !(mxGetM(prhs[1578])==1 && mxGetN(prhs[1578])==1) ) { 
      mexErrMsgTxt("Input 1578 must be a noncomplex scalar double.");
    } 
    mexinput1578_temp = mxGetPr(prhs[1578]); 
    double mexinput1578 = *mexinput1578_temp; 

    double *mexinput1579_temp = NULL; 
    if( !mxIsDouble(prhs[1579]) || mxIsComplex(prhs[1579]) || !(mxGetM(prhs[1579])==1 && mxGetN(prhs[1579])==1) ) { 
      mexErrMsgTxt("Input 1579 must be a noncomplex scalar double.");
    } 
    mexinput1579_temp = mxGetPr(prhs[1579]); 
    double mexinput1579 = *mexinput1579_temp; 

    double *mexinput1580_temp = NULL; 
    if( !mxIsDouble(prhs[1580]) || mxIsComplex(prhs[1580]) || !(mxGetM(prhs[1580])==1 && mxGetN(prhs[1580])==1) ) { 
      mexErrMsgTxt("Input 1580 must be a noncomplex scalar double.");
    } 
    mexinput1580_temp = mxGetPr(prhs[1580]); 
    double mexinput1580 = *mexinput1580_temp; 

    double *mexinput1581_temp = NULL; 
    if( !mxIsDouble(prhs[1581]) || mxIsComplex(prhs[1581]) || !(mxGetM(prhs[1581])==1 && mxGetN(prhs[1581])==1) ) { 
      mexErrMsgTxt("Input 1581 must be a noncomplex scalar double.");
    } 
    mexinput1581_temp = mxGetPr(prhs[1581]); 
    double mexinput1581 = *mexinput1581_temp; 

    double *mexinput1582_temp = NULL; 
    if( !mxIsDouble(prhs[1582]) || mxIsComplex(prhs[1582]) || !(mxGetM(prhs[1582])==1 && mxGetN(prhs[1582])==1) ) { 
      mexErrMsgTxt("Input 1582 must be a noncomplex scalar double.");
    } 
    mexinput1582_temp = mxGetPr(prhs[1582]); 
    double mexinput1582 = *mexinput1582_temp; 

    double *mexinput1583_temp = NULL; 
    if( !mxIsDouble(prhs[1583]) || mxIsComplex(prhs[1583]) || !(mxGetM(prhs[1583])==1 && mxGetN(prhs[1583])==1) ) { 
      mexErrMsgTxt("Input 1583 must be a noncomplex scalar double.");
    } 
    mexinput1583_temp = mxGetPr(prhs[1583]); 
    double mexinput1583 = *mexinput1583_temp; 

    double *mexinput1584_temp = NULL; 
    if( !mxIsDouble(prhs[1584]) || mxIsComplex(prhs[1584]) || !(mxGetM(prhs[1584])==1 && mxGetN(prhs[1584])==1) ) { 
      mexErrMsgTxt("Input 1584 must be a noncomplex scalar double.");
    } 
    mexinput1584_temp = mxGetPr(prhs[1584]); 
    double mexinput1584 = *mexinput1584_temp; 

    double *mexinput1585_temp = NULL; 
    if( !mxIsDouble(prhs[1585]) || mxIsComplex(prhs[1585]) || !(mxGetM(prhs[1585])==1 && mxGetN(prhs[1585])==1) ) { 
      mexErrMsgTxt("Input 1585 must be a noncomplex scalar double.");
    } 
    mexinput1585_temp = mxGetPr(prhs[1585]); 
    double mexinput1585 = *mexinput1585_temp; 

    double *mexinput1586_temp = NULL; 
    if( !mxIsDouble(prhs[1586]) || mxIsComplex(prhs[1586]) || !(mxGetM(prhs[1586])==1 && mxGetN(prhs[1586])==1) ) { 
      mexErrMsgTxt("Input 1586 must be a noncomplex scalar double.");
    } 
    mexinput1586_temp = mxGetPr(prhs[1586]); 
    double mexinput1586 = *mexinput1586_temp; 

    double *mexinput1587_temp = NULL; 
    if( !mxIsDouble(prhs[1587]) || mxIsComplex(prhs[1587]) || !(mxGetM(prhs[1587])==1 && mxGetN(prhs[1587])==1) ) { 
      mexErrMsgTxt("Input 1587 must be a noncomplex scalar double.");
    } 
    mexinput1587_temp = mxGetPr(prhs[1587]); 
    double mexinput1587 = *mexinput1587_temp; 

    double *mexinput1588_temp = NULL; 
    if( !mxIsDouble(prhs[1588]) || mxIsComplex(prhs[1588]) || !(mxGetM(prhs[1588])==1 && mxGetN(prhs[1588])==1) ) { 
      mexErrMsgTxt("Input 1588 must be a noncomplex scalar double.");
    } 
    mexinput1588_temp = mxGetPr(prhs[1588]); 
    double mexinput1588 = *mexinput1588_temp; 

    double *mexinput1589_temp = NULL; 
    if( !mxIsDouble(prhs[1589]) || mxIsComplex(prhs[1589]) || !(mxGetM(prhs[1589])==1 && mxGetN(prhs[1589])==1) ) { 
      mexErrMsgTxt("Input 1589 must be a noncomplex scalar double.");
    } 
    mexinput1589_temp = mxGetPr(prhs[1589]); 
    double mexinput1589 = *mexinput1589_temp; 

    double *mexinput1590_temp = NULL; 
    if( !mxIsDouble(prhs[1590]) || mxIsComplex(prhs[1590]) || !(mxGetM(prhs[1590])==1 && mxGetN(prhs[1590])==1) ) { 
      mexErrMsgTxt("Input 1590 must be a noncomplex scalar double.");
    } 
    mexinput1590_temp = mxGetPr(prhs[1590]); 
    double mexinput1590 = *mexinput1590_temp; 

    double *mexinput1591_temp = NULL; 
    if( !mxIsDouble(prhs[1591]) || mxIsComplex(prhs[1591]) || !(mxGetM(prhs[1591])==1 && mxGetN(prhs[1591])==1) ) { 
      mexErrMsgTxt("Input 1591 must be a noncomplex scalar double.");
    } 
    mexinput1591_temp = mxGetPr(prhs[1591]); 
    double mexinput1591 = *mexinput1591_temp; 

    double *mexinput1592_temp = NULL; 
    if( !mxIsDouble(prhs[1592]) || mxIsComplex(prhs[1592]) || !(mxGetM(prhs[1592])==1 && mxGetN(prhs[1592])==1) ) { 
      mexErrMsgTxt("Input 1592 must be a noncomplex scalar double.");
    } 
    mexinput1592_temp = mxGetPr(prhs[1592]); 
    double mexinput1592 = *mexinput1592_temp; 

    double *mexinput1593_temp = NULL; 
    if( !mxIsDouble(prhs[1593]) || mxIsComplex(prhs[1593]) || !(mxGetM(prhs[1593])==1 && mxGetN(prhs[1593])==1) ) { 
      mexErrMsgTxt("Input 1593 must be a noncomplex scalar double.");
    } 
    mexinput1593_temp = mxGetPr(prhs[1593]); 
    double mexinput1593 = *mexinput1593_temp; 

    double *mexinput1594_temp = NULL; 
    if( !mxIsDouble(prhs[1594]) || mxIsComplex(prhs[1594]) || !(mxGetM(prhs[1594])==1 && mxGetN(prhs[1594])==1) ) { 
      mexErrMsgTxt("Input 1594 must be a noncomplex scalar double.");
    } 
    mexinput1594_temp = mxGetPr(prhs[1594]); 
    double mexinput1594 = *mexinput1594_temp; 

    double *mexinput1595_temp = NULL; 
    if( !mxIsDouble(prhs[1595]) || mxIsComplex(prhs[1595]) || !(mxGetM(prhs[1595])==1 && mxGetN(prhs[1595])==1) ) { 
      mexErrMsgTxt("Input 1595 must be a noncomplex scalar double.");
    } 
    mexinput1595_temp = mxGetPr(prhs[1595]); 
    double mexinput1595 = *mexinput1595_temp; 

    double *mexinput1596_temp = NULL; 
    if( !mxIsDouble(prhs[1596]) || mxIsComplex(prhs[1596]) || !(mxGetM(prhs[1596])==1 && mxGetN(prhs[1596])==1) ) { 
      mexErrMsgTxt("Input 1596 must be a noncomplex scalar double.");
    } 
    mexinput1596_temp = mxGetPr(prhs[1596]); 
    double mexinput1596 = *mexinput1596_temp; 

    double *mexinput1597_temp = NULL; 
    if( !mxIsDouble(prhs[1597]) || mxIsComplex(prhs[1597]) || !(mxGetM(prhs[1597])==1 && mxGetN(prhs[1597])==1) ) { 
      mexErrMsgTxt("Input 1597 must be a noncomplex scalar double.");
    } 
    mexinput1597_temp = mxGetPr(prhs[1597]); 
    double mexinput1597 = *mexinput1597_temp; 

    double *mexinput1598_temp = NULL; 
    if( !mxIsDouble(prhs[1598]) || mxIsComplex(prhs[1598]) || !(mxGetM(prhs[1598])==1 && mxGetN(prhs[1598])==1) ) { 
      mexErrMsgTxt("Input 1598 must be a noncomplex scalar double.");
    } 
    mexinput1598_temp = mxGetPr(prhs[1598]); 
    double mexinput1598 = *mexinput1598_temp; 

    double *mexinput1599_temp = NULL; 
    if( !mxIsDouble(prhs[1599]) || mxIsComplex(prhs[1599]) || !(mxGetM(prhs[1599])==1 && mxGetN(prhs[1599])==1) ) { 
      mexErrMsgTxt("Input 1599 must be a noncomplex scalar double.");
    } 
    mexinput1599_temp = mxGetPr(prhs[1599]); 
    double mexinput1599 = *mexinput1599_temp; 

    double *mexinput1600_temp = NULL; 
    if( !mxIsDouble(prhs[1600]) || mxIsComplex(prhs[1600]) || !(mxGetM(prhs[1600])==1 && mxGetN(prhs[1600])==1) ) { 
      mexErrMsgTxt("Input 1600 must be a noncomplex scalar double.");
    } 
    mexinput1600_temp = mxGetPr(prhs[1600]); 
    double mexinput1600 = *mexinput1600_temp; 

    double *mexinput1601_temp = NULL; 
    if( !mxIsDouble(prhs[1601]) || mxIsComplex(prhs[1601]) || !(mxGetM(prhs[1601])==1 && mxGetN(prhs[1601])==1) ) { 
      mexErrMsgTxt("Input 1601 must be a noncomplex scalar double.");
    } 
    mexinput1601_temp = mxGetPr(prhs[1601]); 
    double mexinput1601 = *mexinput1601_temp; 

    double *mexinput1602_temp = NULL; 
    if( !mxIsDouble(prhs[1602]) || mxIsComplex(prhs[1602]) || !(mxGetM(prhs[1602])==1 && mxGetN(prhs[1602])==1) ) { 
      mexErrMsgTxt("Input 1602 must be a noncomplex scalar double.");
    } 
    mexinput1602_temp = mxGetPr(prhs[1602]); 
    double mexinput1602 = *mexinput1602_temp; 

    double *mexinput1603_temp = NULL; 
    if( !mxIsDouble(prhs[1603]) || mxIsComplex(prhs[1603]) || !(mxGetM(prhs[1603])==1 && mxGetN(prhs[1603])==1) ) { 
      mexErrMsgTxt("Input 1603 must be a noncomplex scalar double.");
    } 
    mexinput1603_temp = mxGetPr(prhs[1603]); 
    double mexinput1603 = *mexinput1603_temp; 

    double *mexinput1604_temp = NULL; 
    if( !mxIsDouble(prhs[1604]) || mxIsComplex(prhs[1604]) || !(mxGetM(prhs[1604])==1 && mxGetN(prhs[1604])==1) ) { 
      mexErrMsgTxt("Input 1604 must be a noncomplex scalar double.");
    } 
    mexinput1604_temp = mxGetPr(prhs[1604]); 
    double mexinput1604 = *mexinput1604_temp; 

    double *mexinput1605_temp = NULL; 
    if( !mxIsDouble(prhs[1605]) || mxIsComplex(prhs[1605]) || !(mxGetM(prhs[1605])==1 && mxGetN(prhs[1605])==1) ) { 
      mexErrMsgTxt("Input 1605 must be a noncomplex scalar double.");
    } 
    mexinput1605_temp = mxGetPr(prhs[1605]); 
    double mexinput1605 = *mexinput1605_temp; 

    double *mexinput1606_temp = NULL; 
    if( !mxIsDouble(prhs[1606]) || mxIsComplex(prhs[1606]) || !(mxGetM(prhs[1606])==1 && mxGetN(prhs[1606])==1) ) { 
      mexErrMsgTxt("Input 1606 must be a noncomplex scalar double.");
    } 
    mexinput1606_temp = mxGetPr(prhs[1606]); 
    double mexinput1606 = *mexinput1606_temp; 

    double *mexinput1607_temp = NULL; 
    if( !mxIsDouble(prhs[1607]) || mxIsComplex(prhs[1607]) || !(mxGetM(prhs[1607])==1 && mxGetN(prhs[1607])==1) ) { 
      mexErrMsgTxt("Input 1607 must be a noncomplex scalar double.");
    } 
    mexinput1607_temp = mxGetPr(prhs[1607]); 
    double mexinput1607 = *mexinput1607_temp; 

    double *mexinput1608_temp = NULL; 
    if( !mxIsDouble(prhs[1608]) || mxIsComplex(prhs[1608]) || !(mxGetM(prhs[1608])==1 && mxGetN(prhs[1608])==1) ) { 
      mexErrMsgTxt("Input 1608 must be a noncomplex scalar double.");
    } 
    mexinput1608_temp = mxGetPr(prhs[1608]); 
    double mexinput1608 = *mexinput1608_temp; 

    double *mexinput1609_temp = NULL; 
    if( !mxIsDouble(prhs[1609]) || mxIsComplex(prhs[1609]) || !(mxGetM(prhs[1609])==1 && mxGetN(prhs[1609])==1) ) { 
      mexErrMsgTxt("Input 1609 must be a noncomplex scalar double.");
    } 
    mexinput1609_temp = mxGetPr(prhs[1609]); 
    double mexinput1609 = *mexinput1609_temp; 

    double *mexinput1610_temp = NULL; 
    if( !mxIsDouble(prhs[1610]) || mxIsComplex(prhs[1610]) || !(mxGetM(prhs[1610])==1 && mxGetN(prhs[1610])==1) ) { 
      mexErrMsgTxt("Input 1610 must be a noncomplex scalar double.");
    } 
    mexinput1610_temp = mxGetPr(prhs[1610]); 
    double mexinput1610 = *mexinput1610_temp; 

    double *mexinput1611_temp = NULL; 
    if( !mxIsDouble(prhs[1611]) || mxIsComplex(prhs[1611]) || !(mxGetM(prhs[1611])==1 && mxGetN(prhs[1611])==1) ) { 
      mexErrMsgTxt("Input 1611 must be a noncomplex scalar double.");
    } 
    mexinput1611_temp = mxGetPr(prhs[1611]); 
    double mexinput1611 = *mexinput1611_temp; 

    double *mexinput1612_temp = NULL; 
    if( !mxIsDouble(prhs[1612]) || mxIsComplex(prhs[1612]) || !(mxGetM(prhs[1612])==1 && mxGetN(prhs[1612])==1) ) { 
      mexErrMsgTxt("Input 1612 must be a noncomplex scalar double.");
    } 
    mexinput1612_temp = mxGetPr(prhs[1612]); 
    double mexinput1612 = *mexinput1612_temp; 

    double *mexinput1613_temp = NULL; 
    if( !mxIsDouble(prhs[1613]) || mxIsComplex(prhs[1613]) || !(mxGetM(prhs[1613])==1 && mxGetN(prhs[1613])==1) ) { 
      mexErrMsgTxt("Input 1613 must be a noncomplex scalar double.");
    } 
    mexinput1613_temp = mxGetPr(prhs[1613]); 
    double mexinput1613 = *mexinput1613_temp; 

    double *mexinput1614_temp = NULL; 
    if( !mxIsDouble(prhs[1614]) || mxIsComplex(prhs[1614]) || !(mxGetM(prhs[1614])==1 && mxGetN(prhs[1614])==1) ) { 
      mexErrMsgTxt("Input 1614 must be a noncomplex scalar double.");
    } 
    mexinput1614_temp = mxGetPr(prhs[1614]); 
    double mexinput1614 = *mexinput1614_temp; 

    double *mexinput1615_temp = NULL; 
    if( !mxIsDouble(prhs[1615]) || mxIsComplex(prhs[1615]) || !(mxGetM(prhs[1615])==1 && mxGetN(prhs[1615])==1) ) { 
      mexErrMsgTxt("Input 1615 must be a noncomplex scalar double.");
    } 
    mexinput1615_temp = mxGetPr(prhs[1615]); 
    double mexinput1615 = *mexinput1615_temp; 

    double *mexinput1616_temp = NULL; 
    if( !mxIsDouble(prhs[1616]) || mxIsComplex(prhs[1616]) || !(mxGetM(prhs[1616])==1 && mxGetN(prhs[1616])==1) ) { 
      mexErrMsgTxt("Input 1616 must be a noncomplex scalar double.");
    } 
    mexinput1616_temp = mxGetPr(prhs[1616]); 
    double mexinput1616 = *mexinput1616_temp; 

    double *mexinput1617_temp = NULL; 
    if( !mxIsDouble(prhs[1617]) || mxIsComplex(prhs[1617]) || !(mxGetM(prhs[1617])==1 && mxGetN(prhs[1617])==1) ) { 
      mexErrMsgTxt("Input 1617 must be a noncomplex scalar double.");
    } 
    mexinput1617_temp = mxGetPr(prhs[1617]); 
    double mexinput1617 = *mexinput1617_temp; 

    double *mexinput1618_temp = NULL; 
    if( !mxIsDouble(prhs[1618]) || mxIsComplex(prhs[1618]) || !(mxGetM(prhs[1618])==1 && mxGetN(prhs[1618])==1) ) { 
      mexErrMsgTxt("Input 1618 must be a noncomplex scalar double.");
    } 
    mexinput1618_temp = mxGetPr(prhs[1618]); 
    double mexinput1618 = *mexinput1618_temp; 

    double *mexinput1619_temp = NULL; 
    if( !mxIsDouble(prhs[1619]) || mxIsComplex(prhs[1619]) || !(mxGetM(prhs[1619])==1 && mxGetN(prhs[1619])==1) ) { 
      mexErrMsgTxt("Input 1619 must be a noncomplex scalar double.");
    } 
    mexinput1619_temp = mxGetPr(prhs[1619]); 
    double mexinput1619 = *mexinput1619_temp; 

    double *mexinput1620_temp = NULL; 
    if( !mxIsDouble(prhs[1620]) || mxIsComplex(prhs[1620]) || !(mxGetM(prhs[1620])==1 && mxGetN(prhs[1620])==1) ) { 
      mexErrMsgTxt("Input 1620 must be a noncomplex scalar double.");
    } 
    mexinput1620_temp = mxGetPr(prhs[1620]); 
    double mexinput1620 = *mexinput1620_temp; 

    double *mexinput1621_temp = NULL; 
    if( !mxIsDouble(prhs[1621]) || mxIsComplex(prhs[1621]) || !(mxGetM(prhs[1621])==1 && mxGetN(prhs[1621])==1) ) { 
      mexErrMsgTxt("Input 1621 must be a noncomplex scalar double.");
    } 
    mexinput1621_temp = mxGetPr(prhs[1621]); 
    double mexinput1621 = *mexinput1621_temp; 

    double *mexinput1622_temp = NULL; 
    if( !mxIsDouble(prhs[1622]) || mxIsComplex(prhs[1622]) || !(mxGetM(prhs[1622])==1 && mxGetN(prhs[1622])==1) ) { 
      mexErrMsgTxt("Input 1622 must be a noncomplex scalar double.");
    } 
    mexinput1622_temp = mxGetPr(prhs[1622]); 
    double mexinput1622 = *mexinput1622_temp; 

    double *mexinput1623_temp = NULL; 
    if( !mxIsDouble(prhs[1623]) || mxIsComplex(prhs[1623]) || !(mxGetM(prhs[1623])==1 && mxGetN(prhs[1623])==1) ) { 
      mexErrMsgTxt("Input 1623 must be a noncomplex scalar double.");
    } 
    mexinput1623_temp = mxGetPr(prhs[1623]); 
    double mexinput1623 = *mexinput1623_temp; 

    double *mexinput1624_temp = NULL; 
    if( !mxIsDouble(prhs[1624]) || mxIsComplex(prhs[1624]) || !(mxGetM(prhs[1624])==1 && mxGetN(prhs[1624])==1) ) { 
      mexErrMsgTxt("Input 1624 must be a noncomplex scalar double.");
    } 
    mexinput1624_temp = mxGetPr(prhs[1624]); 
    double mexinput1624 = *mexinput1624_temp; 

    double *mexinput1625_temp = NULL; 
    if( !mxIsDouble(prhs[1625]) || mxIsComplex(prhs[1625]) || !(mxGetM(prhs[1625])==1 && mxGetN(prhs[1625])==1) ) { 
      mexErrMsgTxt("Input 1625 must be a noncomplex scalar double.");
    } 
    mexinput1625_temp = mxGetPr(prhs[1625]); 
    double mexinput1625 = *mexinput1625_temp; 

    double *mexinput1626_temp = NULL; 
    if( !mxIsDouble(prhs[1626]) || mxIsComplex(prhs[1626]) || !(mxGetM(prhs[1626])==1 && mxGetN(prhs[1626])==1) ) { 
      mexErrMsgTxt("Input 1626 must be a noncomplex scalar double.");
    } 
    mexinput1626_temp = mxGetPr(prhs[1626]); 
    double mexinput1626 = *mexinput1626_temp; 

    double *mexinput1627_temp = NULL; 
    if( !mxIsDouble(prhs[1627]) || mxIsComplex(prhs[1627]) || !(mxGetM(prhs[1627])==1 && mxGetN(prhs[1627])==1) ) { 
      mexErrMsgTxt("Input 1627 must be a noncomplex scalar double.");
    } 
    mexinput1627_temp = mxGetPr(prhs[1627]); 
    double mexinput1627 = *mexinput1627_temp; 

    double *mexinput1628_temp = NULL; 
    if( !mxIsDouble(prhs[1628]) || mxIsComplex(prhs[1628]) || !(mxGetM(prhs[1628])==1 && mxGetN(prhs[1628])==1) ) { 
      mexErrMsgTxt("Input 1628 must be a noncomplex scalar double.");
    } 
    mexinput1628_temp = mxGetPr(prhs[1628]); 
    double mexinput1628 = *mexinput1628_temp; 

    double *mexinput1629_temp = NULL; 
    if( !mxIsDouble(prhs[1629]) || mxIsComplex(prhs[1629]) || !(mxGetM(prhs[1629])==1 && mxGetN(prhs[1629])==1) ) { 
      mexErrMsgTxt("Input 1629 must be a noncomplex scalar double.");
    } 
    mexinput1629_temp = mxGetPr(prhs[1629]); 
    double mexinput1629 = *mexinput1629_temp; 

    double *mexinput1630_temp = NULL; 
    if( !mxIsDouble(prhs[1630]) || mxIsComplex(prhs[1630]) || !(mxGetM(prhs[1630])==1 && mxGetN(prhs[1630])==1) ) { 
      mexErrMsgTxt("Input 1630 must be a noncomplex scalar double.");
    } 
    mexinput1630_temp = mxGetPr(prhs[1630]); 
    double mexinput1630 = *mexinput1630_temp; 

    double *mexinput1631_temp = NULL; 
    if( !mxIsDouble(prhs[1631]) || mxIsComplex(prhs[1631]) || !(mxGetM(prhs[1631])==1 && mxGetN(prhs[1631])==1) ) { 
      mexErrMsgTxt("Input 1631 must be a noncomplex scalar double.");
    } 
    mexinput1631_temp = mxGetPr(prhs[1631]); 
    double mexinput1631 = *mexinput1631_temp; 

    double *mexinput1632_temp = NULL; 
    if( !mxIsDouble(prhs[1632]) || mxIsComplex(prhs[1632]) || !(mxGetM(prhs[1632])==1 && mxGetN(prhs[1632])==1) ) { 
      mexErrMsgTxt("Input 1632 must be a noncomplex scalar double.");
    } 
    mexinput1632_temp = mxGetPr(prhs[1632]); 
    double mexinput1632 = *mexinput1632_temp; 

    double *mexinput1633_temp = NULL; 
    if( !mxIsDouble(prhs[1633]) || mxIsComplex(prhs[1633]) || !(mxGetM(prhs[1633])==1 && mxGetN(prhs[1633])==1) ) { 
      mexErrMsgTxt("Input 1633 must be a noncomplex scalar double.");
    } 
    mexinput1633_temp = mxGetPr(prhs[1633]); 
    double mexinput1633 = *mexinput1633_temp; 

    double *mexinput1634_temp = NULL; 
    if( !mxIsDouble(prhs[1634]) || mxIsComplex(prhs[1634]) || !(mxGetM(prhs[1634])==1 && mxGetN(prhs[1634])==1) ) { 
      mexErrMsgTxt("Input 1634 must be a noncomplex scalar double.");
    } 
    mexinput1634_temp = mxGetPr(prhs[1634]); 
    double mexinput1634 = *mexinput1634_temp; 

    double *mexinput1635_temp = NULL; 
    if( !mxIsDouble(prhs[1635]) || mxIsComplex(prhs[1635]) || !(mxGetM(prhs[1635])==1 && mxGetN(prhs[1635])==1) ) { 
      mexErrMsgTxt("Input 1635 must be a noncomplex scalar double.");
    } 
    mexinput1635_temp = mxGetPr(prhs[1635]); 
    double mexinput1635 = *mexinput1635_temp; 

    double *mexinput1636_temp = NULL; 
    if( !mxIsDouble(prhs[1636]) || mxIsComplex(prhs[1636]) || !(mxGetM(prhs[1636])==1 && mxGetN(prhs[1636])==1) ) { 
      mexErrMsgTxt("Input 1636 must be a noncomplex scalar double.");
    } 
    mexinput1636_temp = mxGetPr(prhs[1636]); 
    double mexinput1636 = *mexinput1636_temp; 

    double *mexinput1637_temp = NULL; 
    if( !mxIsDouble(prhs[1637]) || mxIsComplex(prhs[1637]) || !(mxGetM(prhs[1637])==1 && mxGetN(prhs[1637])==1) ) { 
      mexErrMsgTxt("Input 1637 must be a noncomplex scalar double.");
    } 
    mexinput1637_temp = mxGetPr(prhs[1637]); 
    double mexinput1637 = *mexinput1637_temp; 

    double *mexinput1638_temp = NULL; 
    if( !mxIsDouble(prhs[1638]) || mxIsComplex(prhs[1638]) || !(mxGetM(prhs[1638])==1 && mxGetN(prhs[1638])==1) ) { 
      mexErrMsgTxt("Input 1638 must be a noncomplex scalar double.");
    } 
    mexinput1638_temp = mxGetPr(prhs[1638]); 
    double mexinput1638 = *mexinput1638_temp; 

    double *mexinput1639_temp = NULL; 
    if( !mxIsDouble(prhs[1639]) || mxIsComplex(prhs[1639]) || !(mxGetM(prhs[1639])==1 && mxGetN(prhs[1639])==1) ) { 
      mexErrMsgTxt("Input 1639 must be a noncomplex scalar double.");
    } 
    mexinput1639_temp = mxGetPr(prhs[1639]); 
    double mexinput1639 = *mexinput1639_temp; 

    double *mexinput1640_temp = NULL; 
    if( !mxIsDouble(prhs[1640]) || mxIsComplex(prhs[1640]) || !(mxGetM(prhs[1640])==1 && mxGetN(prhs[1640])==1) ) { 
      mexErrMsgTxt("Input 1640 must be a noncomplex scalar double.");
    } 
    mexinput1640_temp = mxGetPr(prhs[1640]); 
    double mexinput1640 = *mexinput1640_temp; 

    double *mexinput1641_temp = NULL; 
    if( !mxIsDouble(prhs[1641]) || mxIsComplex(prhs[1641]) || !(mxGetM(prhs[1641])==1 && mxGetN(prhs[1641])==1) ) { 
      mexErrMsgTxt("Input 1641 must be a noncomplex scalar double.");
    } 
    mexinput1641_temp = mxGetPr(prhs[1641]); 
    double mexinput1641 = *mexinput1641_temp; 

    double *mexinput1642_temp = NULL; 
    if( !mxIsDouble(prhs[1642]) || mxIsComplex(prhs[1642]) || !(mxGetM(prhs[1642])==1 && mxGetN(prhs[1642])==1) ) { 
      mexErrMsgTxt("Input 1642 must be a noncomplex scalar double.");
    } 
    mexinput1642_temp = mxGetPr(prhs[1642]); 
    double mexinput1642 = *mexinput1642_temp; 

    double *mexinput1643_temp = NULL; 
    if( !mxIsDouble(prhs[1643]) || mxIsComplex(prhs[1643]) || !(mxGetM(prhs[1643])==1 && mxGetN(prhs[1643])==1) ) { 
      mexErrMsgTxt("Input 1643 must be a noncomplex scalar double.");
    } 
    mexinput1643_temp = mxGetPr(prhs[1643]); 
    double mexinput1643 = *mexinput1643_temp; 

    double *mexinput1644_temp = NULL; 
    if( !mxIsDouble(prhs[1644]) || mxIsComplex(prhs[1644]) || !(mxGetM(prhs[1644])==1 && mxGetN(prhs[1644])==1) ) { 
      mexErrMsgTxt("Input 1644 must be a noncomplex scalar double.");
    } 
    mexinput1644_temp = mxGetPr(prhs[1644]); 
    double mexinput1644 = *mexinput1644_temp; 

    double *mexinput1645_temp = NULL; 
    if( !mxIsDouble(prhs[1645]) || mxIsComplex(prhs[1645]) || !(mxGetM(prhs[1645])==1 && mxGetN(prhs[1645])==1) ) { 
      mexErrMsgTxt("Input 1645 must be a noncomplex scalar double.");
    } 
    mexinput1645_temp = mxGetPr(prhs[1645]); 
    double mexinput1645 = *mexinput1645_temp; 

    double *mexinput1646_temp = NULL; 
    if( !mxIsDouble(prhs[1646]) || mxIsComplex(prhs[1646]) || !(mxGetM(prhs[1646])==1 && mxGetN(prhs[1646])==1) ) { 
      mexErrMsgTxt("Input 1646 must be a noncomplex scalar double.");
    } 
    mexinput1646_temp = mxGetPr(prhs[1646]); 
    double mexinput1646 = *mexinput1646_temp; 

    double *mexinput1647_temp = NULL; 
    if( !mxIsDouble(prhs[1647]) || mxIsComplex(prhs[1647]) || !(mxGetM(prhs[1647])==1 && mxGetN(prhs[1647])==1) ) { 
      mexErrMsgTxt("Input 1647 must be a noncomplex scalar double.");
    } 
    mexinput1647_temp = mxGetPr(prhs[1647]); 
    double mexinput1647 = *mexinput1647_temp; 

    double *mexinput1648_temp = NULL; 
    if( !mxIsDouble(prhs[1648]) || mxIsComplex(prhs[1648]) || !(mxGetM(prhs[1648])==1 && mxGetN(prhs[1648])==1) ) { 
      mexErrMsgTxt("Input 1648 must be a noncomplex scalar double.");
    } 
    mexinput1648_temp = mxGetPr(prhs[1648]); 
    double mexinput1648 = *mexinput1648_temp; 

    double *mexinput1649_temp = NULL; 
    if( !mxIsDouble(prhs[1649]) || mxIsComplex(prhs[1649]) || !(mxGetM(prhs[1649])==1 && mxGetN(prhs[1649])==1) ) { 
      mexErrMsgTxt("Input 1649 must be a noncomplex scalar double.");
    } 
    mexinput1649_temp = mxGetPr(prhs[1649]); 
    double mexinput1649 = *mexinput1649_temp; 

    double *mexinput1650_temp = NULL; 
    if( !mxIsDouble(prhs[1650]) || mxIsComplex(prhs[1650]) || !(mxGetM(prhs[1650])==1 && mxGetN(prhs[1650])==1) ) { 
      mexErrMsgTxt("Input 1650 must be a noncomplex scalar double.");
    } 
    mexinput1650_temp = mxGetPr(prhs[1650]); 
    double mexinput1650 = *mexinput1650_temp; 

    double *mexinput1651_temp = NULL; 
    if( !mxIsDouble(prhs[1651]) || mxIsComplex(prhs[1651]) || !(mxGetM(prhs[1651])==1 && mxGetN(prhs[1651])==1) ) { 
      mexErrMsgTxt("Input 1651 must be a noncomplex scalar double.");
    } 
    mexinput1651_temp = mxGetPr(prhs[1651]); 
    double mexinput1651 = *mexinput1651_temp; 

    double *mexinput1652_temp = NULL; 
    if( !mxIsDouble(prhs[1652]) || mxIsComplex(prhs[1652]) || !(mxGetM(prhs[1652])==1 && mxGetN(prhs[1652])==1) ) { 
      mexErrMsgTxt("Input 1652 must be a noncomplex scalar double.");
    } 
    mexinput1652_temp = mxGetPr(prhs[1652]); 
    double mexinput1652 = *mexinput1652_temp; 

    double *mexinput1653_temp = NULL; 
    if( !mxIsDouble(prhs[1653]) || mxIsComplex(prhs[1653]) || !(mxGetM(prhs[1653])==1 && mxGetN(prhs[1653])==1) ) { 
      mexErrMsgTxt("Input 1653 must be a noncomplex scalar double.");
    } 
    mexinput1653_temp = mxGetPr(prhs[1653]); 
    double mexinput1653 = *mexinput1653_temp; 

    double *mexinput1654_temp = NULL; 
    if( !mxIsDouble(prhs[1654]) || mxIsComplex(prhs[1654]) || !(mxGetM(prhs[1654])==1 && mxGetN(prhs[1654])==1) ) { 
      mexErrMsgTxt("Input 1654 must be a noncomplex scalar double.");
    } 
    mexinput1654_temp = mxGetPr(prhs[1654]); 
    double mexinput1654 = *mexinput1654_temp; 

    double *mexinput1655_temp = NULL; 
    if( !mxIsDouble(prhs[1655]) || mxIsComplex(prhs[1655]) || !(mxGetM(prhs[1655])==1 && mxGetN(prhs[1655])==1) ) { 
      mexErrMsgTxt("Input 1655 must be a noncomplex scalar double.");
    } 
    mexinput1655_temp = mxGetPr(prhs[1655]); 
    double mexinput1655 = *mexinput1655_temp; 

    double *mexinput1656_temp = NULL; 
    if( !mxIsDouble(prhs[1656]) || mxIsComplex(prhs[1656]) || !(mxGetM(prhs[1656])==1 && mxGetN(prhs[1656])==1) ) { 
      mexErrMsgTxt("Input 1656 must be a noncomplex scalar double.");
    } 
    mexinput1656_temp = mxGetPr(prhs[1656]); 
    double mexinput1656 = *mexinput1656_temp; 

    double *mexinput1657_temp = NULL; 
    if( !mxIsDouble(prhs[1657]) || mxIsComplex(prhs[1657]) || !(mxGetM(prhs[1657])==1 && mxGetN(prhs[1657])==1) ) { 
      mexErrMsgTxt("Input 1657 must be a noncomplex scalar double.");
    } 
    mexinput1657_temp = mxGetPr(prhs[1657]); 
    double mexinput1657 = *mexinput1657_temp; 

    double *mexinput1658_temp = NULL; 
    if( !mxIsDouble(prhs[1658]) || mxIsComplex(prhs[1658]) || !(mxGetM(prhs[1658])==1 && mxGetN(prhs[1658])==1) ) { 
      mexErrMsgTxt("Input 1658 must be a noncomplex scalar double.");
    } 
    mexinput1658_temp = mxGetPr(prhs[1658]); 
    double mexinput1658 = *mexinput1658_temp; 

    double *mexinput1659_temp = NULL; 
    if( !mxIsDouble(prhs[1659]) || mxIsComplex(prhs[1659]) || !(mxGetM(prhs[1659])==1 && mxGetN(prhs[1659])==1) ) { 
      mexErrMsgTxt("Input 1659 must be a noncomplex scalar double.");
    } 
    mexinput1659_temp = mxGetPr(prhs[1659]); 
    double mexinput1659 = *mexinput1659_temp; 

    double *mexinput1660_temp = NULL; 
    if( !mxIsDouble(prhs[1660]) || mxIsComplex(prhs[1660]) || !(mxGetM(prhs[1660])==1 && mxGetN(prhs[1660])==1) ) { 
      mexErrMsgTxt("Input 1660 must be a noncomplex scalar double.");
    } 
    mexinput1660_temp = mxGetPr(prhs[1660]); 
    double mexinput1660 = *mexinput1660_temp; 

    double *mexinput1661_temp = NULL; 
    if( !mxIsDouble(prhs[1661]) || mxIsComplex(prhs[1661]) || !(mxGetM(prhs[1661])==1 && mxGetN(prhs[1661])==1) ) { 
      mexErrMsgTxt("Input 1661 must be a noncomplex scalar double.");
    } 
    mexinput1661_temp = mxGetPr(prhs[1661]); 
    double mexinput1661 = *mexinput1661_temp; 

    double *mexinput1662_temp = NULL; 
    if( !mxIsDouble(prhs[1662]) || mxIsComplex(prhs[1662]) || !(mxGetM(prhs[1662])==1 && mxGetN(prhs[1662])==1) ) { 
      mexErrMsgTxt("Input 1662 must be a noncomplex scalar double.");
    } 
    mexinput1662_temp = mxGetPr(prhs[1662]); 
    double mexinput1662 = *mexinput1662_temp; 

    double *mexinput1663_temp = NULL; 
    if( !mxIsDouble(prhs[1663]) || mxIsComplex(prhs[1663]) || !(mxGetM(prhs[1663])==1 && mxGetN(prhs[1663])==1) ) { 
      mexErrMsgTxt("Input 1663 must be a noncomplex scalar double.");
    } 
    mexinput1663_temp = mxGetPr(prhs[1663]); 
    double mexinput1663 = *mexinput1663_temp; 

    double *mexinput1664_temp = NULL; 
    if( !mxIsDouble(prhs[1664]) || mxIsComplex(prhs[1664]) || !(mxGetM(prhs[1664])==1 && mxGetN(prhs[1664])==1) ) { 
      mexErrMsgTxt("Input 1664 must be a noncomplex scalar double.");
    } 
    mexinput1664_temp = mxGetPr(prhs[1664]); 
    double mexinput1664 = *mexinput1664_temp; 

    double *mexinput1665_temp = NULL; 
    if( !mxIsDouble(prhs[1665]) || mxIsComplex(prhs[1665]) || !(mxGetM(prhs[1665])==1 && mxGetN(prhs[1665])==1) ) { 
      mexErrMsgTxt("Input 1665 must be a noncomplex scalar double.");
    } 
    mexinput1665_temp = mxGetPr(prhs[1665]); 
    double mexinput1665 = *mexinput1665_temp; 

    double *mexinput1666_temp = NULL; 
    if( !mxIsDouble(prhs[1666]) || mxIsComplex(prhs[1666]) || !(mxGetM(prhs[1666])==1 && mxGetN(prhs[1666])==1) ) { 
      mexErrMsgTxt("Input 1666 must be a noncomplex scalar double.");
    } 
    mexinput1666_temp = mxGetPr(prhs[1666]); 
    double mexinput1666 = *mexinput1666_temp; 

    double *mexinput1667_temp = NULL; 
    if( !mxIsDouble(prhs[1667]) || mxIsComplex(prhs[1667]) || !(mxGetM(prhs[1667])==1 && mxGetN(prhs[1667])==1) ) { 
      mexErrMsgTxt("Input 1667 must be a noncomplex scalar double.");
    } 
    mexinput1667_temp = mxGetPr(prhs[1667]); 
    double mexinput1667 = *mexinput1667_temp; 

    double *mexinput1668_temp = NULL; 
    if( !mxIsDouble(prhs[1668]) || mxIsComplex(prhs[1668]) || !(mxGetM(prhs[1668])==1 && mxGetN(prhs[1668])==1) ) { 
      mexErrMsgTxt("Input 1668 must be a noncomplex scalar double.");
    } 
    mexinput1668_temp = mxGetPr(prhs[1668]); 
    double mexinput1668 = *mexinput1668_temp; 

    double *mexinput1669_temp = NULL; 
    if( !mxIsDouble(prhs[1669]) || mxIsComplex(prhs[1669]) || !(mxGetM(prhs[1669])==1 && mxGetN(prhs[1669])==1) ) { 
      mexErrMsgTxt("Input 1669 must be a noncomplex scalar double.");
    } 
    mexinput1669_temp = mxGetPr(prhs[1669]); 
    double mexinput1669 = *mexinput1669_temp; 

    double *mexinput1670_temp = NULL; 
    if( !mxIsDouble(prhs[1670]) || mxIsComplex(prhs[1670]) || !(mxGetM(prhs[1670])==1 && mxGetN(prhs[1670])==1) ) { 
      mexErrMsgTxt("Input 1670 must be a noncomplex scalar double.");
    } 
    mexinput1670_temp = mxGetPr(prhs[1670]); 
    double mexinput1670 = *mexinput1670_temp; 

    double *mexinput1671_temp = NULL; 
    if( !mxIsDouble(prhs[1671]) || mxIsComplex(prhs[1671]) || !(mxGetM(prhs[1671])==1 && mxGetN(prhs[1671])==1) ) { 
      mexErrMsgTxt("Input 1671 must be a noncomplex scalar double.");
    } 
    mexinput1671_temp = mxGetPr(prhs[1671]); 
    double mexinput1671 = *mexinput1671_temp; 

    double *mexinput1672_temp = NULL; 
    if( !mxIsDouble(prhs[1672]) || mxIsComplex(prhs[1672]) || !(mxGetM(prhs[1672])==1 && mxGetN(prhs[1672])==1) ) { 
      mexErrMsgTxt("Input 1672 must be a noncomplex scalar double.");
    } 
    mexinput1672_temp = mxGetPr(prhs[1672]); 
    double mexinput1672 = *mexinput1672_temp; 

    double *mexinput1673_temp = NULL; 
    if( !mxIsDouble(prhs[1673]) || mxIsComplex(prhs[1673]) || !(mxGetM(prhs[1673])==1 && mxGetN(prhs[1673])==1) ) { 
      mexErrMsgTxt("Input 1673 must be a noncomplex scalar double.");
    } 
    mexinput1673_temp = mxGetPr(prhs[1673]); 
    double mexinput1673 = *mexinput1673_temp; 

    double *mexinput1674_temp = NULL; 
    if( !mxIsDouble(prhs[1674]) || mxIsComplex(prhs[1674]) || !(mxGetM(prhs[1674])==1 && mxGetN(prhs[1674])==1) ) { 
      mexErrMsgTxt("Input 1674 must be a noncomplex scalar double.");
    } 
    mexinput1674_temp = mxGetPr(prhs[1674]); 
    double mexinput1674 = *mexinput1674_temp; 

    double *mexinput1675_temp = NULL; 
    if( !mxIsDouble(prhs[1675]) || mxIsComplex(prhs[1675]) || !(mxGetM(prhs[1675])==1 && mxGetN(prhs[1675])==1) ) { 
      mexErrMsgTxt("Input 1675 must be a noncomplex scalar double.");
    } 
    mexinput1675_temp = mxGetPr(prhs[1675]); 
    double mexinput1675 = *mexinput1675_temp; 

    double *mexinput1676_temp = NULL; 
    if( !mxIsDouble(prhs[1676]) || mxIsComplex(prhs[1676]) || !(mxGetM(prhs[1676])==1 && mxGetN(prhs[1676])==1) ) { 
      mexErrMsgTxt("Input 1676 must be a noncomplex scalar double.");
    } 
    mexinput1676_temp = mxGetPr(prhs[1676]); 
    double mexinput1676 = *mexinput1676_temp; 

    double *mexinput1677_temp = NULL; 
    if( !mxIsDouble(prhs[1677]) || mxIsComplex(prhs[1677]) || !(mxGetM(prhs[1677])==1 && mxGetN(prhs[1677])==1) ) { 
      mexErrMsgTxt("Input 1677 must be a noncomplex scalar double.");
    } 
    mexinput1677_temp = mxGetPr(prhs[1677]); 
    double mexinput1677 = *mexinput1677_temp; 

    double *mexinput1678_temp = NULL; 
    if( !mxIsDouble(prhs[1678]) || mxIsComplex(prhs[1678]) || !(mxGetM(prhs[1678])==1 && mxGetN(prhs[1678])==1) ) { 
      mexErrMsgTxt("Input 1678 must be a noncomplex scalar double.");
    } 
    mexinput1678_temp = mxGetPr(prhs[1678]); 
    double mexinput1678 = *mexinput1678_temp; 

    double *mexinput1679_temp = NULL; 
    if( !mxIsDouble(prhs[1679]) || mxIsComplex(prhs[1679]) || !(mxGetM(prhs[1679])==1 && mxGetN(prhs[1679])==1) ) { 
      mexErrMsgTxt("Input 1679 must be a noncomplex scalar double.");
    } 
    mexinput1679_temp = mxGetPr(prhs[1679]); 
    double mexinput1679 = *mexinput1679_temp; 

    double *mexinput1680_temp = NULL; 
    if( !mxIsDouble(prhs[1680]) || mxIsComplex(prhs[1680]) || !(mxGetM(prhs[1680])==1 && mxGetN(prhs[1680])==1) ) { 
      mexErrMsgTxt("Input 1680 must be a noncomplex scalar double.");
    } 
    mexinput1680_temp = mxGetPr(prhs[1680]); 
    double mexinput1680 = *mexinput1680_temp; 

    double *mexinput1681_temp = NULL; 
    if( !mxIsDouble(prhs[1681]) || mxIsComplex(prhs[1681]) || !(mxGetM(prhs[1681])==1 && mxGetN(prhs[1681])==1) ) { 
      mexErrMsgTxt("Input 1681 must be a noncomplex scalar double.");
    } 
    mexinput1681_temp = mxGetPr(prhs[1681]); 
    double mexinput1681 = *mexinput1681_temp; 

    double *mexinput1682_temp = NULL; 
    if( !mxIsDouble(prhs[1682]) || mxIsComplex(prhs[1682]) || !(mxGetM(prhs[1682])==1 && mxGetN(prhs[1682])==1) ) { 
      mexErrMsgTxt("Input 1682 must be a noncomplex scalar double.");
    } 
    mexinput1682_temp = mxGetPr(prhs[1682]); 
    double mexinput1682 = *mexinput1682_temp; 

    double *mexinput1683_temp = NULL; 
    if( !mxIsDouble(prhs[1683]) || mxIsComplex(prhs[1683]) || !(mxGetM(prhs[1683])==1 && mxGetN(prhs[1683])==1) ) { 
      mexErrMsgTxt("Input 1683 must be a noncomplex scalar double.");
    } 
    mexinput1683_temp = mxGetPr(prhs[1683]); 
    double mexinput1683 = *mexinput1683_temp; 

    double *mexinput1684_temp = NULL; 
    if( !mxIsDouble(prhs[1684]) || mxIsComplex(prhs[1684]) || !(mxGetM(prhs[1684])==1 && mxGetN(prhs[1684])==1) ) { 
      mexErrMsgTxt("Input 1684 must be a noncomplex scalar double.");
    } 
    mexinput1684_temp = mxGetPr(prhs[1684]); 
    double mexinput1684 = *mexinput1684_temp; 

    double *mexinput1685_temp = NULL; 
    if( !mxIsDouble(prhs[1685]) || mxIsComplex(prhs[1685]) || !(mxGetM(prhs[1685])==1 && mxGetN(prhs[1685])==1) ) { 
      mexErrMsgTxt("Input 1685 must be a noncomplex scalar double.");
    } 
    mexinput1685_temp = mxGetPr(prhs[1685]); 
    double mexinput1685 = *mexinput1685_temp; 

    double *mexinput1686_temp = NULL; 
    if( !mxIsDouble(prhs[1686]) || mxIsComplex(prhs[1686]) || !(mxGetM(prhs[1686])==1 && mxGetN(prhs[1686])==1) ) { 
      mexErrMsgTxt("Input 1686 must be a noncomplex scalar double.");
    } 
    mexinput1686_temp = mxGetPr(prhs[1686]); 
    double mexinput1686 = *mexinput1686_temp; 

    double *mexinput1687_temp = NULL; 
    if( !mxIsDouble(prhs[1687]) || mxIsComplex(prhs[1687]) || !(mxGetM(prhs[1687])==1 && mxGetN(prhs[1687])==1) ) { 
      mexErrMsgTxt("Input 1687 must be a noncomplex scalar double.");
    } 
    mexinput1687_temp = mxGetPr(prhs[1687]); 
    double mexinput1687 = *mexinput1687_temp; 

    double *mexinput1688_temp = NULL; 
    if( !mxIsDouble(prhs[1688]) || mxIsComplex(prhs[1688]) || !(mxGetM(prhs[1688])==1 && mxGetN(prhs[1688])==1) ) { 
      mexErrMsgTxt("Input 1688 must be a noncomplex scalar double.");
    } 
    mexinput1688_temp = mxGetPr(prhs[1688]); 
    double mexinput1688 = *mexinput1688_temp; 

    double *mexinput1689_temp = NULL; 
    if( !mxIsDouble(prhs[1689]) || mxIsComplex(prhs[1689]) || !(mxGetM(prhs[1689])==1 && mxGetN(prhs[1689])==1) ) { 
      mexErrMsgTxt("Input 1689 must be a noncomplex scalar double.");
    } 
    mexinput1689_temp = mxGetPr(prhs[1689]); 
    double mexinput1689 = *mexinput1689_temp; 

    double *mexinput1690_temp = NULL; 
    if( !mxIsDouble(prhs[1690]) || mxIsComplex(prhs[1690]) || !(mxGetM(prhs[1690])==1 && mxGetN(prhs[1690])==1) ) { 
      mexErrMsgTxt("Input 1690 must be a noncomplex scalar double.");
    } 
    mexinput1690_temp = mxGetPr(prhs[1690]); 
    double mexinput1690 = *mexinput1690_temp; 

    double *mexinput1691_temp = NULL; 
    if( !mxIsDouble(prhs[1691]) || mxIsComplex(prhs[1691]) || !(mxGetM(prhs[1691])==1 && mxGetN(prhs[1691])==1) ) { 
      mexErrMsgTxt("Input 1691 must be a noncomplex scalar double.");
    } 
    mexinput1691_temp = mxGetPr(prhs[1691]); 
    double mexinput1691 = *mexinput1691_temp; 

    double *mexinput1692_temp = NULL; 
    if( !mxIsDouble(prhs[1692]) || mxIsComplex(prhs[1692]) || !(mxGetM(prhs[1692])==1 && mxGetN(prhs[1692])==1) ) { 
      mexErrMsgTxt("Input 1692 must be a noncomplex scalar double.");
    } 
    mexinput1692_temp = mxGetPr(prhs[1692]); 
    double mexinput1692 = *mexinput1692_temp; 

    double *mexinput1693_temp = NULL; 
    if( !mxIsDouble(prhs[1693]) || mxIsComplex(prhs[1693]) || !(mxGetM(prhs[1693])==1 && mxGetN(prhs[1693])==1) ) { 
      mexErrMsgTxt("Input 1693 must be a noncomplex scalar double.");
    } 
    mexinput1693_temp = mxGetPr(prhs[1693]); 
    double mexinput1693 = *mexinput1693_temp; 

    double *mexinput1694_temp = NULL; 
    if( !mxIsDouble(prhs[1694]) || mxIsComplex(prhs[1694]) || !(mxGetM(prhs[1694])==1 && mxGetN(prhs[1694])==1) ) { 
      mexErrMsgTxt("Input 1694 must be a noncomplex scalar double.");
    } 
    mexinput1694_temp = mxGetPr(prhs[1694]); 
    double mexinput1694 = *mexinput1694_temp; 

    double *mexinput1695_temp = NULL; 
    if( !mxIsDouble(prhs[1695]) || mxIsComplex(prhs[1695]) || !(mxGetM(prhs[1695])==1 && mxGetN(prhs[1695])==1) ) { 
      mexErrMsgTxt("Input 1695 must be a noncomplex scalar double.");
    } 
    mexinput1695_temp = mxGetPr(prhs[1695]); 
    double mexinput1695 = *mexinput1695_temp; 

    double *mexinput1696_temp = NULL; 
    if( !mxIsDouble(prhs[1696]) || mxIsComplex(prhs[1696]) || !(mxGetM(prhs[1696])==1 && mxGetN(prhs[1696])==1) ) { 
      mexErrMsgTxt("Input 1696 must be a noncomplex scalar double.");
    } 
    mexinput1696_temp = mxGetPr(prhs[1696]); 
    double mexinput1696 = *mexinput1696_temp; 

    double *mexinput1697_temp = NULL; 
    if( !mxIsDouble(prhs[1697]) || mxIsComplex(prhs[1697]) || !(mxGetM(prhs[1697])==1 && mxGetN(prhs[1697])==1) ) { 
      mexErrMsgTxt("Input 1697 must be a noncomplex scalar double.");
    } 
    mexinput1697_temp = mxGetPr(prhs[1697]); 
    double mexinput1697 = *mexinput1697_temp; 

    double *mexinput1698_temp = NULL; 
    if( !mxIsDouble(prhs[1698]) || mxIsComplex(prhs[1698]) || !(mxGetM(prhs[1698])==1 && mxGetN(prhs[1698])==1) ) { 
      mexErrMsgTxt("Input 1698 must be a noncomplex scalar double.");
    } 
    mexinput1698_temp = mxGetPr(prhs[1698]); 
    double mexinput1698 = *mexinput1698_temp; 

    double *mexinput1699_temp = NULL; 
    if( !mxIsDouble(prhs[1699]) || mxIsComplex(prhs[1699]) || !(mxGetM(prhs[1699])==1 && mxGetN(prhs[1699])==1) ) { 
      mexErrMsgTxt("Input 1699 must be a noncomplex scalar double.");
    } 
    mexinput1699_temp = mxGetPr(prhs[1699]); 
    double mexinput1699 = *mexinput1699_temp; 

    double *mexinput1700_temp = NULL; 
    if( !mxIsDouble(prhs[1700]) || mxIsComplex(prhs[1700]) || !(mxGetM(prhs[1700])==1 && mxGetN(prhs[1700])==1) ) { 
      mexErrMsgTxt("Input 1700 must be a noncomplex scalar double.");
    } 
    mexinput1700_temp = mxGetPr(prhs[1700]); 
    double mexinput1700 = *mexinput1700_temp; 

    double *mexinput1701_temp = NULL; 
    if( !mxIsDouble(prhs[1701]) || mxIsComplex(prhs[1701]) || !(mxGetM(prhs[1701])==1 && mxGetN(prhs[1701])==1) ) { 
      mexErrMsgTxt("Input 1701 must be a noncomplex scalar double.");
    } 
    mexinput1701_temp = mxGetPr(prhs[1701]); 
    double mexinput1701 = *mexinput1701_temp; 

    double *mexinput1702_temp = NULL; 
    if( !mxIsDouble(prhs[1702]) || mxIsComplex(prhs[1702]) || !(mxGetM(prhs[1702])==1 && mxGetN(prhs[1702])==1) ) { 
      mexErrMsgTxt("Input 1702 must be a noncomplex scalar double.");
    } 
    mexinput1702_temp = mxGetPr(prhs[1702]); 
    double mexinput1702 = *mexinput1702_temp; 

    double *mexinput1703_temp = NULL; 
    if( !mxIsDouble(prhs[1703]) || mxIsComplex(prhs[1703]) || !(mxGetM(prhs[1703])==1 && mxGetN(prhs[1703])==1) ) { 
      mexErrMsgTxt("Input 1703 must be a noncomplex scalar double.");
    } 
    mexinput1703_temp = mxGetPr(prhs[1703]); 
    double mexinput1703 = *mexinput1703_temp; 

    double *mexinput1704_temp = NULL; 
    if( !mxIsDouble(prhs[1704]) || mxIsComplex(prhs[1704]) || !(mxGetM(prhs[1704])==1 && mxGetN(prhs[1704])==1) ) { 
      mexErrMsgTxt("Input 1704 must be a noncomplex scalar double.");
    } 
    mexinput1704_temp = mxGetPr(prhs[1704]); 
    double mexinput1704 = *mexinput1704_temp; 

    double *mexinput1705_temp = NULL; 
    if( !mxIsDouble(prhs[1705]) || mxIsComplex(prhs[1705]) || !(mxGetM(prhs[1705])==1 && mxGetN(prhs[1705])==1) ) { 
      mexErrMsgTxt("Input 1705 must be a noncomplex scalar double.");
    } 
    mexinput1705_temp = mxGetPr(prhs[1705]); 
    double mexinput1705 = *mexinput1705_temp; 

    double *mexinput1706_temp = NULL; 
    if( !mxIsDouble(prhs[1706]) || mxIsComplex(prhs[1706]) || !(mxGetM(prhs[1706])==1 && mxGetN(prhs[1706])==1) ) { 
      mexErrMsgTxt("Input 1706 must be a noncomplex scalar double.");
    } 
    mexinput1706_temp = mxGetPr(prhs[1706]); 
    double mexinput1706 = *mexinput1706_temp; 

    double *mexinput1707_temp = NULL; 
    if( !mxIsDouble(prhs[1707]) || mxIsComplex(prhs[1707]) || !(mxGetM(prhs[1707])==1 && mxGetN(prhs[1707])==1) ) { 
      mexErrMsgTxt("Input 1707 must be a noncomplex scalar double.");
    } 
    mexinput1707_temp = mxGetPr(prhs[1707]); 
    double mexinput1707 = *mexinput1707_temp; 

    double *mexinput1708_temp = NULL; 
    if( !mxIsDouble(prhs[1708]) || mxIsComplex(prhs[1708]) || !(mxGetM(prhs[1708])==1 && mxGetN(prhs[1708])==1) ) { 
      mexErrMsgTxt("Input 1708 must be a noncomplex scalar double.");
    } 
    mexinput1708_temp = mxGetPr(prhs[1708]); 
    double mexinput1708 = *mexinput1708_temp; 

    double *mexinput1709_temp = NULL; 
    if( !mxIsDouble(prhs[1709]) || mxIsComplex(prhs[1709]) || !(mxGetM(prhs[1709])==1 && mxGetN(prhs[1709])==1) ) { 
      mexErrMsgTxt("Input 1709 must be a noncomplex scalar double.");
    } 
    mexinput1709_temp = mxGetPr(prhs[1709]); 
    double mexinput1709 = *mexinput1709_temp; 

    double *mexinput1710_temp = NULL; 
    if( !mxIsDouble(prhs[1710]) || mxIsComplex(prhs[1710]) || !(mxGetM(prhs[1710])==1 && mxGetN(prhs[1710])==1) ) { 
      mexErrMsgTxt("Input 1710 must be a noncomplex scalar double.");
    } 
    mexinput1710_temp = mxGetPr(prhs[1710]); 
    double mexinput1710 = *mexinput1710_temp; 

    double *mexinput1711_temp = NULL; 
    if( !mxIsDouble(prhs[1711]) || mxIsComplex(prhs[1711]) || !(mxGetM(prhs[1711])==1 && mxGetN(prhs[1711])==1) ) { 
      mexErrMsgTxt("Input 1711 must be a noncomplex scalar double.");
    } 
    mexinput1711_temp = mxGetPr(prhs[1711]); 
    double mexinput1711 = *mexinput1711_temp; 

    double *mexinput1712_temp = NULL; 
    if( !mxIsDouble(prhs[1712]) || mxIsComplex(prhs[1712]) || !(mxGetM(prhs[1712])==1 && mxGetN(prhs[1712])==1) ) { 
      mexErrMsgTxt("Input 1712 must be a noncomplex scalar double.");
    } 
    mexinput1712_temp = mxGetPr(prhs[1712]); 
    double mexinput1712 = *mexinput1712_temp; 

    double *mexinput1713_temp = NULL; 
    if( !mxIsDouble(prhs[1713]) || mxIsComplex(prhs[1713]) || !(mxGetM(prhs[1713])==1 && mxGetN(prhs[1713])==1) ) { 
      mexErrMsgTxt("Input 1713 must be a noncomplex scalar double.");
    } 
    mexinput1713_temp = mxGetPr(prhs[1713]); 
    double mexinput1713 = *mexinput1713_temp; 

    double *mexinput1714_temp = NULL; 
    if( !mxIsDouble(prhs[1714]) || mxIsComplex(prhs[1714]) || !(mxGetM(prhs[1714])==1 && mxGetN(prhs[1714])==1) ) { 
      mexErrMsgTxt("Input 1714 must be a noncomplex scalar double.");
    } 
    mexinput1714_temp = mxGetPr(prhs[1714]); 
    double mexinput1714 = *mexinput1714_temp; 

    double *mexinput1715_temp = NULL; 
    if( !mxIsDouble(prhs[1715]) || mxIsComplex(prhs[1715]) || !(mxGetM(prhs[1715])==1 && mxGetN(prhs[1715])==1) ) { 
      mexErrMsgTxt("Input 1715 must be a noncomplex scalar double.");
    } 
    mexinput1715_temp = mxGetPr(prhs[1715]); 
    double mexinput1715 = *mexinput1715_temp; 

    double *mexinput1716_temp = NULL; 
    if( !mxIsDouble(prhs[1716]) || mxIsComplex(prhs[1716]) || !(mxGetM(prhs[1716])==1 && mxGetN(prhs[1716])==1) ) { 
      mexErrMsgTxt("Input 1716 must be a noncomplex scalar double.");
    } 
    mexinput1716_temp = mxGetPr(prhs[1716]); 
    double mexinput1716 = *mexinput1716_temp; 

    double *mexinput1717_temp = NULL; 
    if( !mxIsDouble(prhs[1717]) || mxIsComplex(prhs[1717]) || !(mxGetM(prhs[1717])==1 && mxGetN(prhs[1717])==1) ) { 
      mexErrMsgTxt("Input 1717 must be a noncomplex scalar double.");
    } 
    mexinput1717_temp = mxGetPr(prhs[1717]); 
    double mexinput1717 = *mexinput1717_temp; 

    double *mexinput1718_temp = NULL; 
    if( !mxIsDouble(prhs[1718]) || mxIsComplex(prhs[1718]) || !(mxGetM(prhs[1718])==1 && mxGetN(prhs[1718])==1) ) { 
      mexErrMsgTxt("Input 1718 must be a noncomplex scalar double.");
    } 
    mexinput1718_temp = mxGetPr(prhs[1718]); 
    double mexinput1718 = *mexinput1718_temp; 

    double *mexinput1719_temp = NULL; 
    if( !mxIsDouble(prhs[1719]) || mxIsComplex(prhs[1719]) || !(mxGetM(prhs[1719])==1 && mxGetN(prhs[1719])==1) ) { 
      mexErrMsgTxt("Input 1719 must be a noncomplex scalar double.");
    } 
    mexinput1719_temp = mxGetPr(prhs[1719]); 
    double mexinput1719 = *mexinput1719_temp; 

    double *mexinput1720_temp = NULL; 
    if( !mxIsDouble(prhs[1720]) || mxIsComplex(prhs[1720]) || !(mxGetM(prhs[1720])==1 && mxGetN(prhs[1720])==1) ) { 
      mexErrMsgTxt("Input 1720 must be a noncomplex scalar double.");
    } 
    mexinput1720_temp = mxGetPr(prhs[1720]); 
    double mexinput1720 = *mexinput1720_temp; 

    double *mexinput1721_temp = NULL; 
    if( !mxIsDouble(prhs[1721]) || mxIsComplex(prhs[1721]) || !(mxGetM(prhs[1721])==1 && mxGetN(prhs[1721])==1) ) { 
      mexErrMsgTxt("Input 1721 must be a noncomplex scalar double.");
    } 
    mexinput1721_temp = mxGetPr(prhs[1721]); 
    double mexinput1721 = *mexinput1721_temp; 

    double *mexinput1722_temp = NULL; 
    if( !mxIsDouble(prhs[1722]) || mxIsComplex(prhs[1722]) || !(mxGetM(prhs[1722])==1 && mxGetN(prhs[1722])==1) ) { 
      mexErrMsgTxt("Input 1722 must be a noncomplex scalar double.");
    } 
    mexinput1722_temp = mxGetPr(prhs[1722]); 
    double mexinput1722 = *mexinput1722_temp; 

    double *mexinput1723_temp = NULL; 
    if( !mxIsDouble(prhs[1723]) || mxIsComplex(prhs[1723]) || !(mxGetM(prhs[1723])==1 && mxGetN(prhs[1723])==1) ) { 
      mexErrMsgTxt("Input 1723 must be a noncomplex scalar double.");
    } 
    mexinput1723_temp = mxGetPr(prhs[1723]); 
    double mexinput1723 = *mexinput1723_temp; 

    double *mexinput1724_temp = NULL; 
    if( !mxIsDouble(prhs[1724]) || mxIsComplex(prhs[1724]) || !(mxGetM(prhs[1724])==1 && mxGetN(prhs[1724])==1) ) { 
      mexErrMsgTxt("Input 1724 must be a noncomplex scalar double.");
    } 
    mexinput1724_temp = mxGetPr(prhs[1724]); 
    double mexinput1724 = *mexinput1724_temp; 

    double *mexinput1725_temp = NULL; 
    if( !mxIsDouble(prhs[1725]) || mxIsComplex(prhs[1725]) || !(mxGetM(prhs[1725])==1 && mxGetN(prhs[1725])==1) ) { 
      mexErrMsgTxt("Input 1725 must be a noncomplex scalar double.");
    } 
    mexinput1725_temp = mxGetPr(prhs[1725]); 
    double mexinput1725 = *mexinput1725_temp; 

    double *mexinput1726_temp = NULL; 
    if( !mxIsDouble(prhs[1726]) || mxIsComplex(prhs[1726]) || !(mxGetM(prhs[1726])==1 && mxGetN(prhs[1726])==1) ) { 
      mexErrMsgTxt("Input 1726 must be a noncomplex scalar double.");
    } 
    mexinput1726_temp = mxGetPr(prhs[1726]); 
    double mexinput1726 = *mexinput1726_temp; 

    double *mexinput1727_temp = NULL; 
    if( !mxIsDouble(prhs[1727]) || mxIsComplex(prhs[1727]) || !(mxGetM(prhs[1727])==1 && mxGetN(prhs[1727])==1) ) { 
      mexErrMsgTxt("Input 1727 must be a noncomplex scalar double.");
    } 
    mexinput1727_temp = mxGetPr(prhs[1727]); 
    double mexinput1727 = *mexinput1727_temp; 

    double *mexinput1728_temp = NULL; 
    if( !mxIsDouble(prhs[1728]) || mxIsComplex(prhs[1728]) || !(mxGetM(prhs[1728])==1 && mxGetN(prhs[1728])==1) ) { 
      mexErrMsgTxt("Input 1728 must be a noncomplex scalar double.");
    } 
    mexinput1728_temp = mxGetPr(prhs[1728]); 
    double mexinput1728 = *mexinput1728_temp; 

    double *mexinput1729_temp = NULL; 
    if( !mxIsDouble(prhs[1729]) || mxIsComplex(prhs[1729]) || !(mxGetM(prhs[1729])==1 && mxGetN(prhs[1729])==1) ) { 
      mexErrMsgTxt("Input 1729 must be a noncomplex scalar double.");
    } 
    mexinput1729_temp = mxGetPr(prhs[1729]); 
    double mexinput1729 = *mexinput1729_temp; 

    double *mexinput1730_temp = NULL; 
    if( !mxIsDouble(prhs[1730]) || mxIsComplex(prhs[1730]) || !(mxGetM(prhs[1730])==1 && mxGetN(prhs[1730])==1) ) { 
      mexErrMsgTxt("Input 1730 must be a noncomplex scalar double.");
    } 
    mexinput1730_temp = mxGetPr(prhs[1730]); 
    double mexinput1730 = *mexinput1730_temp; 

    double *mexinput1731_temp = NULL; 
    if( !mxIsDouble(prhs[1731]) || mxIsComplex(prhs[1731]) || !(mxGetM(prhs[1731])==1 && mxGetN(prhs[1731])==1) ) { 
      mexErrMsgTxt("Input 1731 must be a noncomplex scalar double.");
    } 
    mexinput1731_temp = mxGetPr(prhs[1731]); 
    double mexinput1731 = *mexinput1731_temp; 

    double *mexinput1732_temp = NULL; 
    if( !mxIsDouble(prhs[1732]) || mxIsComplex(prhs[1732]) || !(mxGetM(prhs[1732])==1 && mxGetN(prhs[1732])==1) ) { 
      mexErrMsgTxt("Input 1732 must be a noncomplex scalar double.");
    } 
    mexinput1732_temp = mxGetPr(prhs[1732]); 
    double mexinput1732 = *mexinput1732_temp; 

    double *mexinput1733_temp = NULL; 
    if( !mxIsDouble(prhs[1733]) || mxIsComplex(prhs[1733]) || !(mxGetM(prhs[1733])==1 && mxGetN(prhs[1733])==1) ) { 
      mexErrMsgTxt("Input 1733 must be a noncomplex scalar double.");
    } 
    mexinput1733_temp = mxGetPr(prhs[1733]); 
    double mexinput1733 = *mexinput1733_temp; 

    double *mexinput1734_temp = NULL; 
    if( !mxIsDouble(prhs[1734]) || mxIsComplex(prhs[1734]) || !(mxGetM(prhs[1734])==1 && mxGetN(prhs[1734])==1) ) { 
      mexErrMsgTxt("Input 1734 must be a noncomplex scalar double.");
    } 
    mexinput1734_temp = mxGetPr(prhs[1734]); 
    double mexinput1734 = *mexinput1734_temp; 

    double *mexinput1735_temp = NULL; 
    if( !mxIsDouble(prhs[1735]) || mxIsComplex(prhs[1735]) || !(mxGetM(prhs[1735])==1 && mxGetN(prhs[1735])==1) ) { 
      mexErrMsgTxt("Input 1735 must be a noncomplex scalar double.");
    } 
    mexinput1735_temp = mxGetPr(prhs[1735]); 
    double mexinput1735 = *mexinput1735_temp; 

    double *mexinput1736_temp = NULL; 
    if( !mxIsDouble(prhs[1736]) || mxIsComplex(prhs[1736]) || !(mxGetM(prhs[1736])==1 && mxGetN(prhs[1736])==1) ) { 
      mexErrMsgTxt("Input 1736 must be a noncomplex scalar double.");
    } 
    mexinput1736_temp = mxGetPr(prhs[1736]); 
    double mexinput1736 = *mexinput1736_temp; 

    double *mexinput1737_temp = NULL; 
    if( !mxIsDouble(prhs[1737]) || mxIsComplex(prhs[1737]) || !(mxGetM(prhs[1737])==1 && mxGetN(prhs[1737])==1) ) { 
      mexErrMsgTxt("Input 1737 must be a noncomplex scalar double.");
    } 
    mexinput1737_temp = mxGetPr(prhs[1737]); 
    double mexinput1737 = *mexinput1737_temp; 

    double *mexinput1738_temp = NULL; 
    if( !mxIsDouble(prhs[1738]) || mxIsComplex(prhs[1738]) || !(mxGetM(prhs[1738])==1 && mxGetN(prhs[1738])==1) ) { 
      mexErrMsgTxt("Input 1738 must be a noncomplex scalar double.");
    } 
    mexinput1738_temp = mxGetPr(prhs[1738]); 
    double mexinput1738 = *mexinput1738_temp; 

    double *mexinput1739_temp = NULL; 
    if( !mxIsDouble(prhs[1739]) || mxIsComplex(prhs[1739]) || !(mxGetM(prhs[1739])==1 && mxGetN(prhs[1739])==1) ) { 
      mexErrMsgTxt("Input 1739 must be a noncomplex scalar double.");
    } 
    mexinput1739_temp = mxGetPr(prhs[1739]); 
    double mexinput1739 = *mexinput1739_temp; 

    double *mexinput1740_temp = NULL; 
    if( !mxIsDouble(prhs[1740]) || mxIsComplex(prhs[1740]) || !(mxGetM(prhs[1740])==1 && mxGetN(prhs[1740])==1) ) { 
      mexErrMsgTxt("Input 1740 must be a noncomplex scalar double.");
    } 
    mexinput1740_temp = mxGetPr(prhs[1740]); 
    double mexinput1740 = *mexinput1740_temp; 

    double *mexinput1741_temp = NULL; 
    if( !mxIsDouble(prhs[1741]) || mxIsComplex(prhs[1741]) || !(mxGetM(prhs[1741])==1 && mxGetN(prhs[1741])==1) ) { 
      mexErrMsgTxt("Input 1741 must be a noncomplex scalar double.");
    } 
    mexinput1741_temp = mxGetPr(prhs[1741]); 
    double mexinput1741 = *mexinput1741_temp; 

    double *mexinput1742_temp = NULL; 
    if( !mxIsDouble(prhs[1742]) || mxIsComplex(prhs[1742]) || !(mxGetM(prhs[1742])==1 && mxGetN(prhs[1742])==1) ) { 
      mexErrMsgTxt("Input 1742 must be a noncomplex scalar double.");
    } 
    mexinput1742_temp = mxGetPr(prhs[1742]); 
    double mexinput1742 = *mexinput1742_temp; 

    double *mexinput1743_temp = NULL; 
    if( !mxIsDouble(prhs[1743]) || mxIsComplex(prhs[1743]) || !(mxGetM(prhs[1743])==1 && mxGetN(prhs[1743])==1) ) { 
      mexErrMsgTxt("Input 1743 must be a noncomplex scalar double.");
    } 
    mexinput1743_temp = mxGetPr(prhs[1743]); 
    double mexinput1743 = *mexinput1743_temp; 

    double *mexinput1744_temp = NULL; 
    if( !mxIsDouble(prhs[1744]) || mxIsComplex(prhs[1744]) || !(mxGetM(prhs[1744])==1 && mxGetN(prhs[1744])==1) ) { 
      mexErrMsgTxt("Input 1744 must be a noncomplex scalar double.");
    } 
    mexinput1744_temp = mxGetPr(prhs[1744]); 
    double mexinput1744 = *mexinput1744_temp; 

    double *mexinput1745_temp = NULL; 
    if( !mxIsDouble(prhs[1745]) || mxIsComplex(prhs[1745]) || !(mxGetM(prhs[1745])==1 && mxGetN(prhs[1745])==1) ) { 
      mexErrMsgTxt("Input 1745 must be a noncomplex scalar double.");
    } 
    mexinput1745_temp = mxGetPr(prhs[1745]); 
    double mexinput1745 = *mexinput1745_temp; 

    double *mexinput1746_temp = NULL; 
    if( !mxIsDouble(prhs[1746]) || mxIsComplex(prhs[1746]) || !(mxGetM(prhs[1746])==1 && mxGetN(prhs[1746])==1) ) { 
      mexErrMsgTxt("Input 1746 must be a noncomplex scalar double.");
    } 
    mexinput1746_temp = mxGetPr(prhs[1746]); 
    double mexinput1746 = *mexinput1746_temp; 

    double *mexinput1747_temp = NULL; 
    if( !mxIsDouble(prhs[1747]) || mxIsComplex(prhs[1747]) || !(mxGetM(prhs[1747])==1 && mxGetN(prhs[1747])==1) ) { 
      mexErrMsgTxt("Input 1747 must be a noncomplex scalar double.");
    } 
    mexinput1747_temp = mxGetPr(prhs[1747]); 
    double mexinput1747 = *mexinput1747_temp; 

    double *mexinput1748_temp = NULL; 
    if( !mxIsDouble(prhs[1748]) || mxIsComplex(prhs[1748]) || !(mxGetM(prhs[1748])==1 && mxGetN(prhs[1748])==1) ) { 
      mexErrMsgTxt("Input 1748 must be a noncomplex scalar double.");
    } 
    mexinput1748_temp = mxGetPr(prhs[1748]); 
    double mexinput1748 = *mexinput1748_temp; 

    double *mexinput1749_temp = NULL; 
    if( !mxIsDouble(prhs[1749]) || mxIsComplex(prhs[1749]) || !(mxGetM(prhs[1749])==1 && mxGetN(prhs[1749])==1) ) { 
      mexErrMsgTxt("Input 1749 must be a noncomplex scalar double.");
    } 
    mexinput1749_temp = mxGetPr(prhs[1749]); 
    double mexinput1749 = *mexinput1749_temp; 

    double *mexinput1750_temp = NULL; 
    if( !mxIsDouble(prhs[1750]) || mxIsComplex(prhs[1750]) || !(mxGetM(prhs[1750])==1 && mxGetN(prhs[1750])==1) ) { 
      mexErrMsgTxt("Input 1750 must be a noncomplex scalar double.");
    } 
    mexinput1750_temp = mxGetPr(prhs[1750]); 
    double mexinput1750 = *mexinput1750_temp; 

    double *mexinput1751_temp = NULL; 
    if( !mxIsDouble(prhs[1751]) || mxIsComplex(prhs[1751]) || !(mxGetM(prhs[1751])==1 && mxGetN(prhs[1751])==1) ) { 
      mexErrMsgTxt("Input 1751 must be a noncomplex scalar double.");
    } 
    mexinput1751_temp = mxGetPr(prhs[1751]); 
    double mexinput1751 = *mexinput1751_temp; 

    double *mexinput1752_temp = NULL; 
    if( !mxIsDouble(prhs[1752]) || mxIsComplex(prhs[1752]) || !(mxGetM(prhs[1752])==1 && mxGetN(prhs[1752])==1) ) { 
      mexErrMsgTxt("Input 1752 must be a noncomplex scalar double.");
    } 
    mexinput1752_temp = mxGetPr(prhs[1752]); 
    double mexinput1752 = *mexinput1752_temp; 

    double *mexinput1753_temp = NULL; 
    if( !mxIsDouble(prhs[1753]) || mxIsComplex(prhs[1753]) || !(mxGetM(prhs[1753])==1 && mxGetN(prhs[1753])==1) ) { 
      mexErrMsgTxt("Input 1753 must be a noncomplex scalar double.");
    } 
    mexinput1753_temp = mxGetPr(prhs[1753]); 
    double mexinput1753 = *mexinput1753_temp; 

    double *mexinput1754_temp = NULL; 
    if( !mxIsDouble(prhs[1754]) || mxIsComplex(prhs[1754]) || !(mxGetM(prhs[1754])==1 && mxGetN(prhs[1754])==1) ) { 
      mexErrMsgTxt("Input 1754 must be a noncomplex scalar double.");
    } 
    mexinput1754_temp = mxGetPr(prhs[1754]); 
    double mexinput1754 = *mexinput1754_temp; 

    double *mexinput1755_temp = NULL; 
    if( !mxIsDouble(prhs[1755]) || mxIsComplex(prhs[1755]) || !(mxGetM(prhs[1755])==1 && mxGetN(prhs[1755])==1) ) { 
      mexErrMsgTxt("Input 1755 must be a noncomplex scalar double.");
    } 
    mexinput1755_temp = mxGetPr(prhs[1755]); 
    double mexinput1755 = *mexinput1755_temp; 

    double *mexinput1756_temp = NULL; 
    if( !mxIsDouble(prhs[1756]) || mxIsComplex(prhs[1756]) || !(mxGetM(prhs[1756])==1 && mxGetN(prhs[1756])==1) ) { 
      mexErrMsgTxt("Input 1756 must be a noncomplex scalar double.");
    } 
    mexinput1756_temp = mxGetPr(prhs[1756]); 
    double mexinput1756 = *mexinput1756_temp; 

    double *mexinput1757_temp = NULL; 
    if( !mxIsDouble(prhs[1757]) || mxIsComplex(prhs[1757]) || !(mxGetM(prhs[1757])==1 && mxGetN(prhs[1757])==1) ) { 
      mexErrMsgTxt("Input 1757 must be a noncomplex scalar double.");
    } 
    mexinput1757_temp = mxGetPr(prhs[1757]); 
    double mexinput1757 = *mexinput1757_temp; 

    double *mexinput1758_temp = NULL; 
    if( !mxIsDouble(prhs[1758]) || mxIsComplex(prhs[1758]) || !(mxGetM(prhs[1758])==1 && mxGetN(prhs[1758])==1) ) { 
      mexErrMsgTxt("Input 1758 must be a noncomplex scalar double.");
    } 
    mexinput1758_temp = mxGetPr(prhs[1758]); 
    double mexinput1758 = *mexinput1758_temp; 

    double *mexinput1759_temp = NULL; 
    if( !mxIsDouble(prhs[1759]) || mxIsComplex(prhs[1759]) || !(mxGetM(prhs[1759])==1 && mxGetN(prhs[1759])==1) ) { 
      mexErrMsgTxt("Input 1759 must be a noncomplex scalar double.");
    } 
    mexinput1759_temp = mxGetPr(prhs[1759]); 
    double mexinput1759 = *mexinput1759_temp; 

    double *mexinput1760_temp = NULL; 
    if( !mxIsDouble(prhs[1760]) || mxIsComplex(prhs[1760]) || !(mxGetM(prhs[1760])==1 && mxGetN(prhs[1760])==1) ) { 
      mexErrMsgTxt("Input 1760 must be a noncomplex scalar double.");
    } 
    mexinput1760_temp = mxGetPr(prhs[1760]); 
    double mexinput1760 = *mexinput1760_temp; 

    double *mexinput1761_temp = NULL; 
    if( !mxIsDouble(prhs[1761]) || mxIsComplex(prhs[1761]) || !(mxGetM(prhs[1761])==1 && mxGetN(prhs[1761])==1) ) { 
      mexErrMsgTxt("Input 1761 must be a noncomplex scalar double.");
    } 
    mexinput1761_temp = mxGetPr(prhs[1761]); 
    double mexinput1761 = *mexinput1761_temp; 

    double *mexinput1762_temp = NULL; 
    if( !mxIsDouble(prhs[1762]) || mxIsComplex(prhs[1762]) || !(mxGetM(prhs[1762])==1 && mxGetN(prhs[1762])==1) ) { 
      mexErrMsgTxt("Input 1762 must be a noncomplex scalar double.");
    } 
    mexinput1762_temp = mxGetPr(prhs[1762]); 
    double mexinput1762 = *mexinput1762_temp; 

    double *mexinput1763_temp = NULL; 
    if( !mxIsDouble(prhs[1763]) || mxIsComplex(prhs[1763]) || !(mxGetM(prhs[1763])==1 && mxGetN(prhs[1763])==1) ) { 
      mexErrMsgTxt("Input 1763 must be a noncomplex scalar double.");
    } 
    mexinput1763_temp = mxGetPr(prhs[1763]); 
    double mexinput1763 = *mexinput1763_temp; 

    double *mexinput1764_temp = NULL; 
    if( !mxIsDouble(prhs[1764]) || mxIsComplex(prhs[1764]) || !(mxGetM(prhs[1764])==1 && mxGetN(prhs[1764])==1) ) { 
      mexErrMsgTxt("Input 1764 must be a noncomplex scalar double.");
    } 
    mexinput1764_temp = mxGetPr(prhs[1764]); 
    double mexinput1764 = *mexinput1764_temp; 

    double *mexinput1765_temp = NULL; 
    if( !mxIsDouble(prhs[1765]) || mxIsComplex(prhs[1765]) || !(mxGetM(prhs[1765])==1 && mxGetN(prhs[1765])==1) ) { 
      mexErrMsgTxt("Input 1765 must be a noncomplex scalar double.");
    } 
    mexinput1765_temp = mxGetPr(prhs[1765]); 
    double mexinput1765 = *mexinput1765_temp; 

    double *mexinput1766_temp = NULL; 
    if( !mxIsDouble(prhs[1766]) || mxIsComplex(prhs[1766]) || !(mxGetM(prhs[1766])==1 && mxGetN(prhs[1766])==1) ) { 
      mexErrMsgTxt("Input 1766 must be a noncomplex scalar double.");
    } 
    mexinput1766_temp = mxGetPr(prhs[1766]); 
    double mexinput1766 = *mexinput1766_temp; 

    double *mexinput1767_temp = NULL; 
    if( !mxIsDouble(prhs[1767]) || mxIsComplex(prhs[1767]) || !(mxGetM(prhs[1767])==1 && mxGetN(prhs[1767])==1) ) { 
      mexErrMsgTxt("Input 1767 must be a noncomplex scalar double.");
    } 
    mexinput1767_temp = mxGetPr(prhs[1767]); 
    double mexinput1767 = *mexinput1767_temp; 

    double *mexinput1768_temp = NULL; 
    if( !mxIsDouble(prhs[1768]) || mxIsComplex(prhs[1768]) || !(mxGetM(prhs[1768])==1 && mxGetN(prhs[1768])==1) ) { 
      mexErrMsgTxt("Input 1768 must be a noncomplex scalar double.");
    } 
    mexinput1768_temp = mxGetPr(prhs[1768]); 
    double mexinput1768 = *mexinput1768_temp; 

    double *mexinput1769_temp = NULL; 
    if( !mxIsDouble(prhs[1769]) || mxIsComplex(prhs[1769]) || !(mxGetM(prhs[1769])==1 && mxGetN(prhs[1769])==1) ) { 
      mexErrMsgTxt("Input 1769 must be a noncomplex scalar double.");
    } 
    mexinput1769_temp = mxGetPr(prhs[1769]); 
    double mexinput1769 = *mexinput1769_temp; 

    double *mexinput1770_temp = NULL; 
    if( !mxIsDouble(prhs[1770]) || mxIsComplex(prhs[1770]) || !(mxGetM(prhs[1770])==1 && mxGetN(prhs[1770])==1) ) { 
      mexErrMsgTxt("Input 1770 must be a noncomplex scalar double.");
    } 
    mexinput1770_temp = mxGetPr(prhs[1770]); 
    double mexinput1770 = *mexinput1770_temp; 

    double *mexinput1771_temp = NULL; 
    if( !mxIsDouble(prhs[1771]) || mxIsComplex(prhs[1771]) || !(mxGetM(prhs[1771])==1 && mxGetN(prhs[1771])==1) ) { 
      mexErrMsgTxt("Input 1771 must be a noncomplex scalar double.");
    } 
    mexinput1771_temp = mxGetPr(prhs[1771]); 
    double mexinput1771 = *mexinput1771_temp; 

    double *mexinput1772_temp = NULL; 
    if( !mxIsDouble(prhs[1772]) || mxIsComplex(prhs[1772]) || !(mxGetM(prhs[1772])==1 && mxGetN(prhs[1772])==1) ) { 
      mexErrMsgTxt("Input 1772 must be a noncomplex scalar double.");
    } 
    mexinput1772_temp = mxGetPr(prhs[1772]); 
    double mexinput1772 = *mexinput1772_temp; 

    double *mexinput1773_temp = NULL; 
    if( !mxIsDouble(prhs[1773]) || mxIsComplex(prhs[1773]) || !(mxGetM(prhs[1773])==1 && mxGetN(prhs[1773])==1) ) { 
      mexErrMsgTxt("Input 1773 must be a noncomplex scalar double.");
    } 
    mexinput1773_temp = mxGetPr(prhs[1773]); 
    double mexinput1773 = *mexinput1773_temp; 

    double *mexinput1774_temp = NULL; 
    if( !mxIsDouble(prhs[1774]) || mxIsComplex(prhs[1774]) || !(mxGetM(prhs[1774])==1 && mxGetN(prhs[1774])==1) ) { 
      mexErrMsgTxt("Input 1774 must be a noncomplex scalar double.");
    } 
    mexinput1774_temp = mxGetPr(prhs[1774]); 
    double mexinput1774 = *mexinput1774_temp; 

    double *mexinput1775_temp = NULL; 
    if( !mxIsDouble(prhs[1775]) || mxIsComplex(prhs[1775]) || !(mxGetM(prhs[1775])==1 && mxGetN(prhs[1775])==1) ) { 
      mexErrMsgTxt("Input 1775 must be a noncomplex scalar double.");
    } 
    mexinput1775_temp = mxGetPr(prhs[1775]); 
    double mexinput1775 = *mexinput1775_temp; 

    double *mexinput1776_temp = NULL; 
    if( !mxIsDouble(prhs[1776]) || mxIsComplex(prhs[1776]) || !(mxGetM(prhs[1776])==1 && mxGetN(prhs[1776])==1) ) { 
      mexErrMsgTxt("Input 1776 must be a noncomplex scalar double.");
    } 
    mexinput1776_temp = mxGetPr(prhs[1776]); 
    double mexinput1776 = *mexinput1776_temp; 

    double *mexinput1777_temp = NULL; 
    if( !mxIsDouble(prhs[1777]) || mxIsComplex(prhs[1777]) || !(mxGetM(prhs[1777])==1 && mxGetN(prhs[1777])==1) ) { 
      mexErrMsgTxt("Input 1777 must be a noncomplex scalar double.");
    } 
    mexinput1777_temp = mxGetPr(prhs[1777]); 
    double mexinput1777 = *mexinput1777_temp; 

    double *mexinput1778_temp = NULL; 
    if( !mxIsDouble(prhs[1778]) || mxIsComplex(prhs[1778]) || !(mxGetM(prhs[1778])==1 && mxGetN(prhs[1778])==1) ) { 
      mexErrMsgTxt("Input 1778 must be a noncomplex scalar double.");
    } 
    mexinput1778_temp = mxGetPr(prhs[1778]); 
    double mexinput1778 = *mexinput1778_temp; 

    double *mexinput1779_temp = NULL; 
    if( !mxIsDouble(prhs[1779]) || mxIsComplex(prhs[1779]) || !(mxGetM(prhs[1779])==1 && mxGetN(prhs[1779])==1) ) { 
      mexErrMsgTxt("Input 1779 must be a noncomplex scalar double.");
    } 
    mexinput1779_temp = mxGetPr(prhs[1779]); 
    double mexinput1779 = *mexinput1779_temp; 

    double *mexinput1780_temp = NULL; 
    if( !mxIsDouble(prhs[1780]) || mxIsComplex(prhs[1780]) || !(mxGetM(prhs[1780])==1 && mxGetN(prhs[1780])==1) ) { 
      mexErrMsgTxt("Input 1780 must be a noncomplex scalar double.");
    } 
    mexinput1780_temp = mxGetPr(prhs[1780]); 
    double mexinput1780 = *mexinput1780_temp; 

    double *mexinput1781_temp = NULL; 
    if( !mxIsDouble(prhs[1781]) || mxIsComplex(prhs[1781]) || !(mxGetM(prhs[1781])==1 && mxGetN(prhs[1781])==1) ) { 
      mexErrMsgTxt("Input 1781 must be a noncomplex scalar double.");
    } 
    mexinput1781_temp = mxGetPr(prhs[1781]); 
    double mexinput1781 = *mexinput1781_temp; 

    double *mexinput1782_temp = NULL; 
    if( !mxIsDouble(prhs[1782]) || mxIsComplex(prhs[1782]) || !(mxGetM(prhs[1782])==1 && mxGetN(prhs[1782])==1) ) { 
      mexErrMsgTxt("Input 1782 must be a noncomplex scalar double.");
    } 
    mexinput1782_temp = mxGetPr(prhs[1782]); 
    double mexinput1782 = *mexinput1782_temp; 

    double *mexinput1783_temp = NULL; 
    if( !mxIsDouble(prhs[1783]) || mxIsComplex(prhs[1783]) || !(mxGetM(prhs[1783])==1 && mxGetN(prhs[1783])==1) ) { 
      mexErrMsgTxt("Input 1783 must be a noncomplex scalar double.");
    } 
    mexinput1783_temp = mxGetPr(prhs[1783]); 
    double mexinput1783 = *mexinput1783_temp; 

    double *mexinput1784_temp = NULL; 
    if( !mxIsDouble(prhs[1784]) || mxIsComplex(prhs[1784]) || !(mxGetM(prhs[1784])==1 && mxGetN(prhs[1784])==1) ) { 
      mexErrMsgTxt("Input 1784 must be a noncomplex scalar double.");
    } 
    mexinput1784_temp = mxGetPr(prhs[1784]); 
    double mexinput1784 = *mexinput1784_temp; 

    double *mexinput1785_temp = NULL; 
    if( !mxIsDouble(prhs[1785]) || mxIsComplex(prhs[1785]) || !(mxGetM(prhs[1785])==1 && mxGetN(prhs[1785])==1) ) { 
      mexErrMsgTxt("Input 1785 must be a noncomplex scalar double.");
    } 
    mexinput1785_temp = mxGetPr(prhs[1785]); 
    double mexinput1785 = *mexinput1785_temp; 

    double *mexinput1786_temp = NULL; 
    if( !mxIsDouble(prhs[1786]) || mxIsComplex(prhs[1786]) || !(mxGetM(prhs[1786])==1 && mxGetN(prhs[1786])==1) ) { 
      mexErrMsgTxt("Input 1786 must be a noncomplex scalar double.");
    } 
    mexinput1786_temp = mxGetPr(prhs[1786]); 
    double mexinput1786 = *mexinput1786_temp; 

    double *mexinput1787_temp = NULL; 
    if( !mxIsDouble(prhs[1787]) || mxIsComplex(prhs[1787]) || !(mxGetM(prhs[1787])==1 && mxGetN(prhs[1787])==1) ) { 
      mexErrMsgTxt("Input 1787 must be a noncomplex scalar double.");
    } 
    mexinput1787_temp = mxGetPr(prhs[1787]); 
    double mexinput1787 = *mexinput1787_temp; 

    double *mexinput1788_temp = NULL; 
    if( !mxIsDouble(prhs[1788]) || mxIsComplex(prhs[1788]) || !(mxGetM(prhs[1788])==1 && mxGetN(prhs[1788])==1) ) { 
      mexErrMsgTxt("Input 1788 must be a noncomplex scalar double.");
    } 
    mexinput1788_temp = mxGetPr(prhs[1788]); 
    double mexinput1788 = *mexinput1788_temp; 

    double *mexinput1789_temp = NULL; 
    if( !mxIsDouble(prhs[1789]) || mxIsComplex(prhs[1789]) || !(mxGetM(prhs[1789])==1 && mxGetN(prhs[1789])==1) ) { 
      mexErrMsgTxt("Input 1789 must be a noncomplex scalar double.");
    } 
    mexinput1789_temp = mxGetPr(prhs[1789]); 
    double mexinput1789 = *mexinput1789_temp; 

    double *mexinput1790_temp = NULL; 
    if( !mxIsDouble(prhs[1790]) || mxIsComplex(prhs[1790]) || !(mxGetM(prhs[1790])==1 && mxGetN(prhs[1790])==1) ) { 
      mexErrMsgTxt("Input 1790 must be a noncomplex scalar double.");
    } 
    mexinput1790_temp = mxGetPr(prhs[1790]); 
    double mexinput1790 = *mexinput1790_temp; 

    double *mexinput1791_temp = NULL; 
    if( !mxIsDouble(prhs[1791]) || mxIsComplex(prhs[1791]) || !(mxGetM(prhs[1791])==1 && mxGetN(prhs[1791])==1) ) { 
      mexErrMsgTxt("Input 1791 must be a noncomplex scalar double.");
    } 
    mexinput1791_temp = mxGetPr(prhs[1791]); 
    double mexinput1791 = *mexinput1791_temp; 

    double *mexinput1792_temp = NULL; 
    if( !mxIsDouble(prhs[1792]) || mxIsComplex(prhs[1792]) || !(mxGetM(prhs[1792])==1 && mxGetN(prhs[1792])==1) ) { 
      mexErrMsgTxt("Input 1792 must be a noncomplex scalar double.");
    } 
    mexinput1792_temp = mxGetPr(prhs[1792]); 
    double mexinput1792 = *mexinput1792_temp; 

    double *mexinput1793_temp = NULL; 
    if( !mxIsDouble(prhs[1793]) || mxIsComplex(prhs[1793]) || !(mxGetM(prhs[1793])==1 && mxGetN(prhs[1793])==1) ) { 
      mexErrMsgTxt("Input 1793 must be a noncomplex scalar double.");
    } 
    mexinput1793_temp = mxGetPr(prhs[1793]); 
    double mexinput1793 = *mexinput1793_temp; 

    double *mexinput1794_temp = NULL; 
    if( !mxIsDouble(prhs[1794]) || mxIsComplex(prhs[1794]) || !(mxGetM(prhs[1794])==1 && mxGetN(prhs[1794])==1) ) { 
      mexErrMsgTxt("Input 1794 must be a noncomplex scalar double.");
    } 
    mexinput1794_temp = mxGetPr(prhs[1794]); 
    double mexinput1794 = *mexinput1794_temp; 

    double *mexinput1795_temp = NULL; 
    if( !mxIsDouble(prhs[1795]) || mxIsComplex(prhs[1795]) || !(mxGetM(prhs[1795])==1 && mxGetN(prhs[1795])==1) ) { 
      mexErrMsgTxt("Input 1795 must be a noncomplex scalar double.");
    } 
    mexinput1795_temp = mxGetPr(prhs[1795]); 
    double mexinput1795 = *mexinput1795_temp; 

    double *mexinput1796_temp = NULL; 
    if( !mxIsDouble(prhs[1796]) || mxIsComplex(prhs[1796]) || !(mxGetM(prhs[1796])==1 && mxGetN(prhs[1796])==1) ) { 
      mexErrMsgTxt("Input 1796 must be a noncomplex scalar double.");
    } 
    mexinput1796_temp = mxGetPr(prhs[1796]); 
    double mexinput1796 = *mexinput1796_temp; 

    double *mexinput1797_temp = NULL; 
    if( !mxIsDouble(prhs[1797]) || mxIsComplex(prhs[1797]) || !(mxGetM(prhs[1797])==1 && mxGetN(prhs[1797])==1) ) { 
      mexErrMsgTxt("Input 1797 must be a noncomplex scalar double.");
    } 
    mexinput1797_temp = mxGetPr(prhs[1797]); 
    double mexinput1797 = *mexinput1797_temp; 

    double *mexinput1798_temp = NULL; 
    if( !mxIsDouble(prhs[1798]) || mxIsComplex(prhs[1798]) || !(mxGetM(prhs[1798])==1 && mxGetN(prhs[1798])==1) ) { 
      mexErrMsgTxt("Input 1798 must be a noncomplex scalar double.");
    } 
    mexinput1798_temp = mxGetPr(prhs[1798]); 
    double mexinput1798 = *mexinput1798_temp; 

    double *mexinput1799_temp = NULL; 
    if( !mxIsDouble(prhs[1799]) || mxIsComplex(prhs[1799]) || !(mxGetM(prhs[1799])==1 && mxGetN(prhs[1799])==1) ) { 
      mexErrMsgTxt("Input 1799 must be a noncomplex scalar double.");
    } 
    mexinput1799_temp = mxGetPr(prhs[1799]); 
    double mexinput1799 = *mexinput1799_temp; 

    double *mexinput1800_temp = NULL; 
    if( !mxIsDouble(prhs[1800]) || mxIsComplex(prhs[1800]) || !(mxGetM(prhs[1800])==1 && mxGetN(prhs[1800])==1) ) { 
      mexErrMsgTxt("Input 1800 must be a noncomplex scalar double.");
    } 
    mexinput1800_temp = mxGetPr(prhs[1800]); 
    double mexinput1800 = *mexinput1800_temp; 

    double *mexinput1801_temp = NULL; 
    if( !mxIsDouble(prhs[1801]) || mxIsComplex(prhs[1801]) || !(mxGetM(prhs[1801])==1 && mxGetN(prhs[1801])==1) ) { 
      mexErrMsgTxt("Input 1801 must be a noncomplex scalar double.");
    } 
    mexinput1801_temp = mxGetPr(prhs[1801]); 
    double mexinput1801 = *mexinput1801_temp; 

    double *mexinput1802_temp = NULL; 
    if( !mxIsDouble(prhs[1802]) || mxIsComplex(prhs[1802]) || !(mxGetM(prhs[1802])==1 && mxGetN(prhs[1802])==1) ) { 
      mexErrMsgTxt("Input 1802 must be a noncomplex scalar double.");
    } 
    mexinput1802_temp = mxGetPr(prhs[1802]); 
    double mexinput1802 = *mexinput1802_temp; 

    double *mexinput1803_temp = NULL; 
    if( !mxIsDouble(prhs[1803]) || mxIsComplex(prhs[1803]) || !(mxGetM(prhs[1803])==1 && mxGetN(prhs[1803])==1) ) { 
      mexErrMsgTxt("Input 1803 must be a noncomplex scalar double.");
    } 
    mexinput1803_temp = mxGetPr(prhs[1803]); 
    double mexinput1803 = *mexinput1803_temp; 

    double *mexinput1804_temp = NULL; 
    if( !mxIsDouble(prhs[1804]) || mxIsComplex(prhs[1804]) || !(mxGetM(prhs[1804])==1 && mxGetN(prhs[1804])==1) ) { 
      mexErrMsgTxt("Input 1804 must be a noncomplex scalar double.");
    } 
    mexinput1804_temp = mxGetPr(prhs[1804]); 
    double mexinput1804 = *mexinput1804_temp; 

    double *mexinput1805_temp = NULL; 
    if( !mxIsDouble(prhs[1805]) || mxIsComplex(prhs[1805]) || !(mxGetM(prhs[1805])==1 && mxGetN(prhs[1805])==1) ) { 
      mexErrMsgTxt("Input 1805 must be a noncomplex scalar double.");
    } 
    mexinput1805_temp = mxGetPr(prhs[1805]); 
    double mexinput1805 = *mexinput1805_temp; 

    double *mexinput1806_temp = NULL; 
    if( !mxIsDouble(prhs[1806]) || mxIsComplex(prhs[1806]) || !(mxGetM(prhs[1806])==1 && mxGetN(prhs[1806])==1) ) { 
      mexErrMsgTxt("Input 1806 must be a noncomplex scalar double.");
    } 
    mexinput1806_temp = mxGetPr(prhs[1806]); 
    double mexinput1806 = *mexinput1806_temp; 

    double *mexinput1807_temp = NULL; 
    if( !mxIsDouble(prhs[1807]) || mxIsComplex(prhs[1807]) || !(mxGetM(prhs[1807])==1 && mxGetN(prhs[1807])==1) ) { 
      mexErrMsgTxt("Input 1807 must be a noncomplex scalar double.");
    } 
    mexinput1807_temp = mxGetPr(prhs[1807]); 
    double mexinput1807 = *mexinput1807_temp; 

    double *mexinput1808_temp = NULL; 
    if( !mxIsDouble(prhs[1808]) || mxIsComplex(prhs[1808]) || !(mxGetM(prhs[1808])==1 && mxGetN(prhs[1808])==1) ) { 
      mexErrMsgTxt("Input 1808 must be a noncomplex scalar double.");
    } 
    mexinput1808_temp = mxGetPr(prhs[1808]); 
    double mexinput1808 = *mexinput1808_temp; 

    double *mexinput1809_temp = NULL; 
    if( !mxIsDouble(prhs[1809]) || mxIsComplex(prhs[1809]) || !(mxGetM(prhs[1809])==1 && mxGetN(prhs[1809])==1) ) { 
      mexErrMsgTxt("Input 1809 must be a noncomplex scalar double.");
    } 
    mexinput1809_temp = mxGetPr(prhs[1809]); 
    double mexinput1809 = *mexinput1809_temp; 

    double *mexinput1810_temp = NULL; 
    if( !mxIsDouble(prhs[1810]) || mxIsComplex(prhs[1810]) || !(mxGetM(prhs[1810])==1 && mxGetN(prhs[1810])==1) ) { 
      mexErrMsgTxt("Input 1810 must be a noncomplex scalar double.");
    } 
    mexinput1810_temp = mxGetPr(prhs[1810]); 
    double mexinput1810 = *mexinput1810_temp; 

    double *mexinput1811_temp = NULL; 
    if( !mxIsDouble(prhs[1811]) || mxIsComplex(prhs[1811]) || !(mxGetM(prhs[1811])==1 && mxGetN(prhs[1811])==1) ) { 
      mexErrMsgTxt("Input 1811 must be a noncomplex scalar double.");
    } 
    mexinput1811_temp = mxGetPr(prhs[1811]); 
    double mexinput1811 = *mexinput1811_temp; 

    double *mexinput1812_temp = NULL; 
    if( !mxIsDouble(prhs[1812]) || mxIsComplex(prhs[1812]) || !(mxGetM(prhs[1812])==1 && mxGetN(prhs[1812])==1) ) { 
      mexErrMsgTxt("Input 1812 must be a noncomplex scalar double.");
    } 
    mexinput1812_temp = mxGetPr(prhs[1812]); 
    double mexinput1812 = *mexinput1812_temp; 

    double *mexinput1813_temp = NULL; 
    if( !mxIsDouble(prhs[1813]) || mxIsComplex(prhs[1813]) || !(mxGetM(prhs[1813])==1 && mxGetN(prhs[1813])==1) ) { 
      mexErrMsgTxt("Input 1813 must be a noncomplex scalar double.");
    } 
    mexinput1813_temp = mxGetPr(prhs[1813]); 
    double mexinput1813 = *mexinput1813_temp; 

    double *mexinput1814_temp = NULL; 
    if( !mxIsDouble(prhs[1814]) || mxIsComplex(prhs[1814]) || !(mxGetM(prhs[1814])==1 && mxGetN(prhs[1814])==1) ) { 
      mexErrMsgTxt("Input 1814 must be a noncomplex scalar double.");
    } 
    mexinput1814_temp = mxGetPr(prhs[1814]); 
    double mexinput1814 = *mexinput1814_temp; 

    double *mexinput1815_temp = NULL; 
    if( !mxIsDouble(prhs[1815]) || mxIsComplex(prhs[1815]) || !(mxGetM(prhs[1815])==1 && mxGetN(prhs[1815])==1) ) { 
      mexErrMsgTxt("Input 1815 must be a noncomplex scalar double.");
    } 
    mexinput1815_temp = mxGetPr(prhs[1815]); 
    double mexinput1815 = *mexinput1815_temp; 

    double *mexinput1816_temp = NULL; 
    if( !mxIsDouble(prhs[1816]) || mxIsComplex(prhs[1816]) || !(mxGetM(prhs[1816])==1 && mxGetN(prhs[1816])==1) ) { 
      mexErrMsgTxt("Input 1816 must be a noncomplex scalar double.");
    } 
    mexinput1816_temp = mxGetPr(prhs[1816]); 
    double mexinput1816 = *mexinput1816_temp; 

    double *mexinput1817_temp = NULL; 
    if( !mxIsDouble(prhs[1817]) || mxIsComplex(prhs[1817]) || !(mxGetM(prhs[1817])==1 && mxGetN(prhs[1817])==1) ) { 
      mexErrMsgTxt("Input 1817 must be a noncomplex scalar double.");
    } 
    mexinput1817_temp = mxGetPr(prhs[1817]); 
    double mexinput1817 = *mexinput1817_temp; 

    double *mexinput1818_temp = NULL; 
    if( !mxIsDouble(prhs[1818]) || mxIsComplex(prhs[1818]) || !(mxGetM(prhs[1818])==1 && mxGetN(prhs[1818])==1) ) { 
      mexErrMsgTxt("Input 1818 must be a noncomplex scalar double.");
    } 
    mexinput1818_temp = mxGetPr(prhs[1818]); 
    double mexinput1818 = *mexinput1818_temp; 

    double *mexinput1819_temp = NULL; 
    if( !mxIsDouble(prhs[1819]) || mxIsComplex(prhs[1819]) || !(mxGetM(prhs[1819])==1 && mxGetN(prhs[1819])==1) ) { 
      mexErrMsgTxt("Input 1819 must be a noncomplex scalar double.");
    } 
    mexinput1819_temp = mxGetPr(prhs[1819]); 
    double mexinput1819 = *mexinput1819_temp; 

    double *mexinput1820_temp = NULL; 
    if( !mxIsDouble(prhs[1820]) || mxIsComplex(prhs[1820]) || !(mxGetM(prhs[1820])==1 && mxGetN(prhs[1820])==1) ) { 
      mexErrMsgTxt("Input 1820 must be a noncomplex scalar double.");
    } 
    mexinput1820_temp = mxGetPr(prhs[1820]); 
    double mexinput1820 = *mexinput1820_temp; 

    double *mexinput1821_temp = NULL; 
    if( !mxIsDouble(prhs[1821]) || mxIsComplex(prhs[1821]) || !(mxGetM(prhs[1821])==1 && mxGetN(prhs[1821])==1) ) { 
      mexErrMsgTxt("Input 1821 must be a noncomplex scalar double.");
    } 
    mexinput1821_temp = mxGetPr(prhs[1821]); 
    double mexinput1821 = *mexinput1821_temp; 

    double *mexinput1822_temp = NULL; 
    if( !mxIsDouble(prhs[1822]) || mxIsComplex(prhs[1822]) || !(mxGetM(prhs[1822])==1 && mxGetN(prhs[1822])==1) ) { 
      mexErrMsgTxt("Input 1822 must be a noncomplex scalar double.");
    } 
    mexinput1822_temp = mxGetPr(prhs[1822]); 
    double mexinput1822 = *mexinput1822_temp; 

    double *mexinput1823_temp = NULL; 
    if( !mxIsDouble(prhs[1823]) || mxIsComplex(prhs[1823]) || !(mxGetM(prhs[1823])==1 && mxGetN(prhs[1823])==1) ) { 
      mexErrMsgTxt("Input 1823 must be a noncomplex scalar double.");
    } 
    mexinput1823_temp = mxGetPr(prhs[1823]); 
    double mexinput1823 = *mexinput1823_temp; 

    double *mexinput1824_temp = NULL; 
    if( !mxIsDouble(prhs[1824]) || mxIsComplex(prhs[1824]) || !(mxGetM(prhs[1824])==1 && mxGetN(prhs[1824])==1) ) { 
      mexErrMsgTxt("Input 1824 must be a noncomplex scalar double.");
    } 
    mexinput1824_temp = mxGetPr(prhs[1824]); 
    double mexinput1824 = *mexinput1824_temp; 

    double *mexinput1825_temp = NULL; 
    if( !mxIsDouble(prhs[1825]) || mxIsComplex(prhs[1825]) || !(mxGetM(prhs[1825])==1 && mxGetN(prhs[1825])==1) ) { 
      mexErrMsgTxt("Input 1825 must be a noncomplex scalar double.");
    } 
    mexinput1825_temp = mxGetPr(prhs[1825]); 
    double mexinput1825 = *mexinput1825_temp; 

    double *mexinput1826_temp = NULL; 
    if( !mxIsDouble(prhs[1826]) || mxIsComplex(prhs[1826]) || !(mxGetM(prhs[1826])==1 && mxGetN(prhs[1826])==1) ) { 
      mexErrMsgTxt("Input 1826 must be a noncomplex scalar double.");
    } 
    mexinput1826_temp = mxGetPr(prhs[1826]); 
    double mexinput1826 = *mexinput1826_temp; 

    double *mexinput1827_temp = NULL; 
    if( !mxIsDouble(prhs[1827]) || mxIsComplex(prhs[1827]) || !(mxGetM(prhs[1827])==1 && mxGetN(prhs[1827])==1) ) { 
      mexErrMsgTxt("Input 1827 must be a noncomplex scalar double.");
    } 
    mexinput1827_temp = mxGetPr(prhs[1827]); 
    double mexinput1827 = *mexinput1827_temp; 

    double *mexinput1828_temp = NULL; 
    if( !mxIsDouble(prhs[1828]) || mxIsComplex(prhs[1828]) || !(mxGetM(prhs[1828])==1 && mxGetN(prhs[1828])==1) ) { 
      mexErrMsgTxt("Input 1828 must be a noncomplex scalar double.");
    } 
    mexinput1828_temp = mxGetPr(prhs[1828]); 
    double mexinput1828 = *mexinput1828_temp; 

    double *mexinput1829_temp = NULL; 
    if( !mxIsDouble(prhs[1829]) || mxIsComplex(prhs[1829]) || !(mxGetM(prhs[1829])==1 && mxGetN(prhs[1829])==1) ) { 
      mexErrMsgTxt("Input 1829 must be a noncomplex scalar double.");
    } 
    mexinput1829_temp = mxGetPr(prhs[1829]); 
    double mexinput1829 = *mexinput1829_temp; 

    double *mexinput1830_temp = NULL; 
    if( !mxIsDouble(prhs[1830]) || mxIsComplex(prhs[1830]) || !(mxGetM(prhs[1830])==1 && mxGetN(prhs[1830])==1) ) { 
      mexErrMsgTxt("Input 1830 must be a noncomplex scalar double.");
    } 
    mexinput1830_temp = mxGetPr(prhs[1830]); 
    double mexinput1830 = *mexinput1830_temp; 

    double *mexinput1831_temp = NULL; 
    if( !mxIsDouble(prhs[1831]) || mxIsComplex(prhs[1831]) || !(mxGetM(prhs[1831])==1 && mxGetN(prhs[1831])==1) ) { 
      mexErrMsgTxt("Input 1831 must be a noncomplex scalar double.");
    } 
    mexinput1831_temp = mxGetPr(prhs[1831]); 
    double mexinput1831 = *mexinput1831_temp; 

    double *mexinput1832_temp = NULL; 
    if( !mxIsDouble(prhs[1832]) || mxIsComplex(prhs[1832]) || !(mxGetM(prhs[1832])==1 && mxGetN(prhs[1832])==1) ) { 
      mexErrMsgTxt("Input 1832 must be a noncomplex scalar double.");
    } 
    mexinput1832_temp = mxGetPr(prhs[1832]); 
    double mexinput1832 = *mexinput1832_temp; 

    double *mexinput1833_temp = NULL; 
    if( !mxIsDouble(prhs[1833]) || mxIsComplex(prhs[1833]) || !(mxGetM(prhs[1833])==1 && mxGetN(prhs[1833])==1) ) { 
      mexErrMsgTxt("Input 1833 must be a noncomplex scalar double.");
    } 
    mexinput1833_temp = mxGetPr(prhs[1833]); 
    double mexinput1833 = *mexinput1833_temp; 

    double *mexinput1834_temp = NULL; 
    if( !mxIsDouble(prhs[1834]) || mxIsComplex(prhs[1834]) || !(mxGetM(prhs[1834])==1 && mxGetN(prhs[1834])==1) ) { 
      mexErrMsgTxt("Input 1834 must be a noncomplex scalar double.");
    } 
    mexinput1834_temp = mxGetPr(prhs[1834]); 
    double mexinput1834 = *mexinput1834_temp; 

    double *mexinput1835_temp = NULL; 
    if( !mxIsDouble(prhs[1835]) || mxIsComplex(prhs[1835]) || !(mxGetM(prhs[1835])==1 && mxGetN(prhs[1835])==1) ) { 
      mexErrMsgTxt("Input 1835 must be a noncomplex scalar double.");
    } 
    mexinput1835_temp = mxGetPr(prhs[1835]); 
    double mexinput1835 = *mexinput1835_temp; 

    double *mexinput1836_temp = NULL; 
    if( !mxIsDouble(prhs[1836]) || mxIsComplex(prhs[1836]) || !(mxGetM(prhs[1836])==1 && mxGetN(prhs[1836])==1) ) { 
      mexErrMsgTxt("Input 1836 must be a noncomplex scalar double.");
    } 
    mexinput1836_temp = mxGetPr(prhs[1836]); 
    double mexinput1836 = *mexinput1836_temp; 

    double *mexinput1837_temp = NULL; 
    if( !mxIsDouble(prhs[1837]) || mxIsComplex(prhs[1837]) || !(mxGetM(prhs[1837])==1 && mxGetN(prhs[1837])==1) ) { 
      mexErrMsgTxt("Input 1837 must be a noncomplex scalar double.");
    } 
    mexinput1837_temp = mxGetPr(prhs[1837]); 
    double mexinput1837 = *mexinput1837_temp; 

    double *mexinput1838_temp = NULL; 
    if( !mxIsDouble(prhs[1838]) || mxIsComplex(prhs[1838]) || !(mxGetM(prhs[1838])==1 && mxGetN(prhs[1838])==1) ) { 
      mexErrMsgTxt("Input 1838 must be a noncomplex scalar double.");
    } 
    mexinput1838_temp = mxGetPr(prhs[1838]); 
    double mexinput1838 = *mexinput1838_temp; 

    double *mexinput1839_temp = NULL; 
    if( !mxIsDouble(prhs[1839]) || mxIsComplex(prhs[1839]) || !(mxGetM(prhs[1839])==1 && mxGetN(prhs[1839])==1) ) { 
      mexErrMsgTxt("Input 1839 must be a noncomplex scalar double.");
    } 
    mexinput1839_temp = mxGetPr(prhs[1839]); 
    double mexinput1839 = *mexinput1839_temp; 

    double *mexinput1840_temp = NULL; 
    if( !mxIsDouble(prhs[1840]) || mxIsComplex(prhs[1840]) || !(mxGetM(prhs[1840])==1 && mxGetN(prhs[1840])==1) ) { 
      mexErrMsgTxt("Input 1840 must be a noncomplex scalar double.");
    } 
    mexinput1840_temp = mxGetPr(prhs[1840]); 
    double mexinput1840 = *mexinput1840_temp; 

    double *mexinput1841_temp = NULL; 
    if( !mxIsDouble(prhs[1841]) || mxIsComplex(prhs[1841]) || !(mxGetM(prhs[1841])==1 && mxGetN(prhs[1841])==1) ) { 
      mexErrMsgTxt("Input 1841 must be a noncomplex scalar double.");
    } 
    mexinput1841_temp = mxGetPr(prhs[1841]); 
    double mexinput1841 = *mexinput1841_temp; 

    double *mexinput1842_temp = NULL; 
    if( !mxIsDouble(prhs[1842]) || mxIsComplex(prhs[1842]) || !(mxGetM(prhs[1842])==1 && mxGetN(prhs[1842])==1) ) { 
      mexErrMsgTxt("Input 1842 must be a noncomplex scalar double.");
    } 
    mexinput1842_temp = mxGetPr(prhs[1842]); 
    double mexinput1842 = *mexinput1842_temp; 

    double *mexinput1843_temp = NULL; 
    if( !mxIsDouble(prhs[1843]) || mxIsComplex(prhs[1843]) || !(mxGetM(prhs[1843])==1 && mxGetN(prhs[1843])==1) ) { 
      mexErrMsgTxt("Input 1843 must be a noncomplex scalar double.");
    } 
    mexinput1843_temp = mxGetPr(prhs[1843]); 
    double mexinput1843 = *mexinput1843_temp; 

    double *mexinput1844_temp = NULL; 
    if( !mxIsDouble(prhs[1844]) || mxIsComplex(prhs[1844]) || !(mxGetM(prhs[1844])==1 && mxGetN(prhs[1844])==1) ) { 
      mexErrMsgTxt("Input 1844 must be a noncomplex scalar double.");
    } 
    mexinput1844_temp = mxGetPr(prhs[1844]); 
    double mexinput1844 = *mexinput1844_temp; 

    double *mexinput1845_temp = NULL; 
    if( !mxIsDouble(prhs[1845]) || mxIsComplex(prhs[1845]) || !(mxGetM(prhs[1845])==1 && mxGetN(prhs[1845])==1) ) { 
      mexErrMsgTxt("Input 1845 must be a noncomplex scalar double.");
    } 
    mexinput1845_temp = mxGetPr(prhs[1845]); 
    double mexinput1845 = *mexinput1845_temp; 

    double *mexinput1846_temp = NULL; 
    if( !mxIsDouble(prhs[1846]) || mxIsComplex(prhs[1846]) || !(mxGetM(prhs[1846])==1 && mxGetN(prhs[1846])==1) ) { 
      mexErrMsgTxt("Input 1846 must be a noncomplex scalar double.");
    } 
    mexinput1846_temp = mxGetPr(prhs[1846]); 
    double mexinput1846 = *mexinput1846_temp; 

    double *mexinput1847_temp = NULL; 
    if( !mxIsDouble(prhs[1847]) || mxIsComplex(prhs[1847]) || !(mxGetM(prhs[1847])==1 && mxGetN(prhs[1847])==1) ) { 
      mexErrMsgTxt("Input 1847 must be a noncomplex scalar double.");
    } 
    mexinput1847_temp = mxGetPr(prhs[1847]); 
    double mexinput1847 = *mexinput1847_temp; 

    double *mexinput1848_temp = NULL; 
    if( !mxIsDouble(prhs[1848]) || mxIsComplex(prhs[1848]) || !(mxGetM(prhs[1848])==1 && mxGetN(prhs[1848])==1) ) { 
      mexErrMsgTxt("Input 1848 must be a noncomplex scalar double.");
    } 
    mexinput1848_temp = mxGetPr(prhs[1848]); 
    double mexinput1848 = *mexinput1848_temp; 

    double *mexinput1849_temp = NULL; 
    if( !mxIsDouble(prhs[1849]) || mxIsComplex(prhs[1849]) || !(mxGetM(prhs[1849])==1 && mxGetN(prhs[1849])==1) ) { 
      mexErrMsgTxt("Input 1849 must be a noncomplex scalar double.");
    } 
    mexinput1849_temp = mxGetPr(prhs[1849]); 
    double mexinput1849 = *mexinput1849_temp; 

    double *mexinput1850_temp = NULL; 
    if( !mxIsDouble(prhs[1850]) || mxIsComplex(prhs[1850]) || !(mxGetM(prhs[1850])==1 && mxGetN(prhs[1850])==1) ) { 
      mexErrMsgTxt("Input 1850 must be a noncomplex scalar double.");
    } 
    mexinput1850_temp = mxGetPr(prhs[1850]); 
    double mexinput1850 = *mexinput1850_temp; 

    double *mexinput1851_temp = NULL; 
    if( !mxIsDouble(prhs[1851]) || mxIsComplex(prhs[1851]) || !(mxGetM(prhs[1851])==1 && mxGetN(prhs[1851])==1) ) { 
      mexErrMsgTxt("Input 1851 must be a noncomplex scalar double.");
    } 
    mexinput1851_temp = mxGetPr(prhs[1851]); 
    double mexinput1851 = *mexinput1851_temp; 

    double *mexinput1852_temp = NULL; 
    if( !mxIsDouble(prhs[1852]) || mxIsComplex(prhs[1852]) || !(mxGetM(prhs[1852])==1 && mxGetN(prhs[1852])==1) ) { 
      mexErrMsgTxt("Input 1852 must be a noncomplex scalar double.");
    } 
    mexinput1852_temp = mxGetPr(prhs[1852]); 
    double mexinput1852 = *mexinput1852_temp; 

    double *mexinput1853_temp = NULL; 
    if( !mxIsDouble(prhs[1853]) || mxIsComplex(prhs[1853]) || !(mxGetM(prhs[1853])==1 && mxGetN(prhs[1853])==1) ) { 
      mexErrMsgTxt("Input 1853 must be a noncomplex scalar double.");
    } 
    mexinput1853_temp = mxGetPr(prhs[1853]); 
    double mexinput1853 = *mexinput1853_temp; 

    double *mexinput1854_temp = NULL; 
    if( !mxIsDouble(prhs[1854]) || mxIsComplex(prhs[1854]) || !(mxGetM(prhs[1854])==1 && mxGetN(prhs[1854])==1) ) { 
      mexErrMsgTxt("Input 1854 must be a noncomplex scalar double.");
    } 
    mexinput1854_temp = mxGetPr(prhs[1854]); 
    double mexinput1854 = *mexinput1854_temp; 

    double *mexinput1855_temp = NULL; 
    if( !mxIsDouble(prhs[1855]) || mxIsComplex(prhs[1855]) || !(mxGetM(prhs[1855])==1 && mxGetN(prhs[1855])==1) ) { 
      mexErrMsgTxt("Input 1855 must be a noncomplex scalar double.");
    } 
    mexinput1855_temp = mxGetPr(prhs[1855]); 
    double mexinput1855 = *mexinput1855_temp; 

    double *mexinput1856_temp = NULL; 
    if( !mxIsDouble(prhs[1856]) || mxIsComplex(prhs[1856]) || !(mxGetM(prhs[1856])==1 && mxGetN(prhs[1856])==1) ) { 
      mexErrMsgTxt("Input 1856 must be a noncomplex scalar double.");
    } 
    mexinput1856_temp = mxGetPr(prhs[1856]); 
    double mexinput1856 = *mexinput1856_temp; 

    double *mexinput1857_temp = NULL; 
    if( !mxIsDouble(prhs[1857]) || mxIsComplex(prhs[1857]) || !(mxGetM(prhs[1857])==1 && mxGetN(prhs[1857])==1) ) { 
      mexErrMsgTxt("Input 1857 must be a noncomplex scalar double.");
    } 
    mexinput1857_temp = mxGetPr(prhs[1857]); 
    double mexinput1857 = *mexinput1857_temp; 

    double *mexinput1858_temp = NULL; 
    if( !mxIsDouble(prhs[1858]) || mxIsComplex(prhs[1858]) || !(mxGetM(prhs[1858])==1 && mxGetN(prhs[1858])==1) ) { 
      mexErrMsgTxt("Input 1858 must be a noncomplex scalar double.");
    } 
    mexinput1858_temp = mxGetPr(prhs[1858]); 
    double mexinput1858 = *mexinput1858_temp; 

    double *mexinput1859_temp = NULL; 
    if( !mxIsDouble(prhs[1859]) || mxIsComplex(prhs[1859]) || !(mxGetM(prhs[1859])==1 && mxGetN(prhs[1859])==1) ) { 
      mexErrMsgTxt("Input 1859 must be a noncomplex scalar double.");
    } 
    mexinput1859_temp = mxGetPr(prhs[1859]); 
    double mexinput1859 = *mexinput1859_temp; 

    double *mexinput1860_temp = NULL; 
    if( !mxIsDouble(prhs[1860]) || mxIsComplex(prhs[1860]) || !(mxGetM(prhs[1860])==1 && mxGetN(prhs[1860])==1) ) { 
      mexErrMsgTxt("Input 1860 must be a noncomplex scalar double.");
    } 
    mexinput1860_temp = mxGetPr(prhs[1860]); 
    double mexinput1860 = *mexinput1860_temp; 

    double *mexinput1861_temp = NULL; 
    if( !mxIsDouble(prhs[1861]) || mxIsComplex(prhs[1861]) || !(mxGetM(prhs[1861])==1 && mxGetN(prhs[1861])==1) ) { 
      mexErrMsgTxt("Input 1861 must be a noncomplex scalar double.");
    } 
    mexinput1861_temp = mxGetPr(prhs[1861]); 
    double mexinput1861 = *mexinput1861_temp; 

    double *mexinput1862_temp = NULL; 
    if( !mxIsDouble(prhs[1862]) || mxIsComplex(prhs[1862]) || !(mxGetM(prhs[1862])==1 && mxGetN(prhs[1862])==1) ) { 
      mexErrMsgTxt("Input 1862 must be a noncomplex scalar double.");
    } 
    mexinput1862_temp = mxGetPr(prhs[1862]); 
    double mexinput1862 = *mexinput1862_temp; 

    double *mexinput1863_temp = NULL; 
    if( !mxIsDouble(prhs[1863]) || mxIsComplex(prhs[1863]) || !(mxGetM(prhs[1863])==1 && mxGetN(prhs[1863])==1) ) { 
      mexErrMsgTxt("Input 1863 must be a noncomplex scalar double.");
    } 
    mexinput1863_temp = mxGetPr(prhs[1863]); 
    double mexinput1863 = *mexinput1863_temp; 

    double *mexinput1864_temp = NULL; 
    if( !mxIsDouble(prhs[1864]) || mxIsComplex(prhs[1864]) || !(mxGetM(prhs[1864])==1 && mxGetN(prhs[1864])==1) ) { 
      mexErrMsgTxt("Input 1864 must be a noncomplex scalar double.");
    } 
    mexinput1864_temp = mxGetPr(prhs[1864]); 
    double mexinput1864 = *mexinput1864_temp; 

    double *mexinput1865_temp = NULL; 
    if( !mxIsDouble(prhs[1865]) || mxIsComplex(prhs[1865]) || !(mxGetM(prhs[1865])==1 && mxGetN(prhs[1865])==1) ) { 
      mexErrMsgTxt("Input 1865 must be a noncomplex scalar double.");
    } 
    mexinput1865_temp = mxGetPr(prhs[1865]); 
    double mexinput1865 = *mexinput1865_temp; 

    double *mexinput1866_temp = NULL; 
    if( !mxIsDouble(prhs[1866]) || mxIsComplex(prhs[1866]) || !(mxGetM(prhs[1866])==1 && mxGetN(prhs[1866])==1) ) { 
      mexErrMsgTxt("Input 1866 must be a noncomplex scalar double.");
    } 
    mexinput1866_temp = mxGetPr(prhs[1866]); 
    double mexinput1866 = *mexinput1866_temp; 

    double *mexinput1867_temp = NULL; 
    if( !mxIsDouble(prhs[1867]) || mxIsComplex(prhs[1867]) || !(mxGetM(prhs[1867])==1 && mxGetN(prhs[1867])==1) ) { 
      mexErrMsgTxt("Input 1867 must be a noncomplex scalar double.");
    } 
    mexinput1867_temp = mxGetPr(prhs[1867]); 
    double mexinput1867 = *mexinput1867_temp; 

    double *mexinput1868_temp = NULL; 
    if( !mxIsDouble(prhs[1868]) || mxIsComplex(prhs[1868]) || !(mxGetM(prhs[1868])==1 && mxGetN(prhs[1868])==1) ) { 
      mexErrMsgTxt("Input 1868 must be a noncomplex scalar double.");
    } 
    mexinput1868_temp = mxGetPr(prhs[1868]); 
    double mexinput1868 = *mexinput1868_temp; 

    double *mexinput1869_temp = NULL; 
    if( !mxIsDouble(prhs[1869]) || mxIsComplex(prhs[1869]) || !(mxGetM(prhs[1869])==1 && mxGetN(prhs[1869])==1) ) { 
      mexErrMsgTxt("Input 1869 must be a noncomplex scalar double.");
    } 
    mexinput1869_temp = mxGetPr(prhs[1869]); 
    double mexinput1869 = *mexinput1869_temp; 

    double *mexinput1870_temp = NULL; 
    if( !mxIsDouble(prhs[1870]) || mxIsComplex(prhs[1870]) || !(mxGetM(prhs[1870])==1 && mxGetN(prhs[1870])==1) ) { 
      mexErrMsgTxt("Input 1870 must be a noncomplex scalar double.");
    } 
    mexinput1870_temp = mxGetPr(prhs[1870]); 
    double mexinput1870 = *mexinput1870_temp; 

    double *mexinput1871_temp = NULL; 
    if( !mxIsDouble(prhs[1871]) || mxIsComplex(prhs[1871]) || !(mxGetM(prhs[1871])==1 && mxGetN(prhs[1871])==1) ) { 
      mexErrMsgTxt("Input 1871 must be a noncomplex scalar double.");
    } 
    mexinput1871_temp = mxGetPr(prhs[1871]); 
    double mexinput1871 = *mexinput1871_temp; 

    double *mexinput1872_temp = NULL; 
    if( !mxIsDouble(prhs[1872]) || mxIsComplex(prhs[1872]) || !(mxGetM(prhs[1872])==1 && mxGetN(prhs[1872])==1) ) { 
      mexErrMsgTxt("Input 1872 must be a noncomplex scalar double.");
    } 
    mexinput1872_temp = mxGetPr(prhs[1872]); 
    double mexinput1872 = *mexinput1872_temp; 

    double *mexinput1873_temp = NULL; 
    if( !mxIsDouble(prhs[1873]) || mxIsComplex(prhs[1873]) || !(mxGetM(prhs[1873])==1 && mxGetN(prhs[1873])==1) ) { 
      mexErrMsgTxt("Input 1873 must be a noncomplex scalar double.");
    } 
    mexinput1873_temp = mxGetPr(prhs[1873]); 
    double mexinput1873 = *mexinput1873_temp; 

    double *mexinput1874_temp = NULL; 
    if( !mxIsDouble(prhs[1874]) || mxIsComplex(prhs[1874]) || !(mxGetM(prhs[1874])==1 && mxGetN(prhs[1874])==1) ) { 
      mexErrMsgTxt("Input 1874 must be a noncomplex scalar double.");
    } 
    mexinput1874_temp = mxGetPr(prhs[1874]); 
    double mexinput1874 = *mexinput1874_temp; 

    double *mexinput1875_temp = NULL; 
    if( !mxIsDouble(prhs[1875]) || mxIsComplex(prhs[1875]) || !(mxGetM(prhs[1875])==1 && mxGetN(prhs[1875])==1) ) { 
      mexErrMsgTxt("Input 1875 must be a noncomplex scalar double.");
    } 
    mexinput1875_temp = mxGetPr(prhs[1875]); 
    double mexinput1875 = *mexinput1875_temp; 

    double *mexinput1876_temp = NULL; 
    if( !mxIsDouble(prhs[1876]) || mxIsComplex(prhs[1876]) || !(mxGetM(prhs[1876])==1 && mxGetN(prhs[1876])==1) ) { 
      mexErrMsgTxt("Input 1876 must be a noncomplex scalar double.");
    } 
    mexinput1876_temp = mxGetPr(prhs[1876]); 
    double mexinput1876 = *mexinput1876_temp; 

    double *mexinput1877_temp = NULL; 
    if( !mxIsDouble(prhs[1877]) || mxIsComplex(prhs[1877]) || !(mxGetM(prhs[1877])==1 && mxGetN(prhs[1877])==1) ) { 
      mexErrMsgTxt("Input 1877 must be a noncomplex scalar double.");
    } 
    mexinput1877_temp = mxGetPr(prhs[1877]); 
    double mexinput1877 = *mexinput1877_temp; 

    double *mexinput1878_temp = NULL; 
    if( !mxIsDouble(prhs[1878]) || mxIsComplex(prhs[1878]) || !(mxGetM(prhs[1878])==1 && mxGetN(prhs[1878])==1) ) { 
      mexErrMsgTxt("Input 1878 must be a noncomplex scalar double.");
    } 
    mexinput1878_temp = mxGetPr(prhs[1878]); 
    double mexinput1878 = *mexinput1878_temp; 

    double *mexinput1879_temp = NULL; 
    if( !mxIsDouble(prhs[1879]) || mxIsComplex(prhs[1879]) || !(mxGetM(prhs[1879])==1 && mxGetN(prhs[1879])==1) ) { 
      mexErrMsgTxt("Input 1879 must be a noncomplex scalar double.");
    } 
    mexinput1879_temp = mxGetPr(prhs[1879]); 
    double mexinput1879 = *mexinput1879_temp; 

    double *mexinput1880_temp = NULL; 
    if( !mxIsDouble(prhs[1880]) || mxIsComplex(prhs[1880]) || !(mxGetM(prhs[1880])==1 && mxGetN(prhs[1880])==1) ) { 
      mexErrMsgTxt("Input 1880 must be a noncomplex scalar double.");
    } 
    mexinput1880_temp = mxGetPr(prhs[1880]); 
    double mexinput1880 = *mexinput1880_temp; 

    double *mexinput1881_temp = NULL; 
    if( !mxIsDouble(prhs[1881]) || mxIsComplex(prhs[1881]) || !(mxGetM(prhs[1881])==1 && mxGetN(prhs[1881])==1) ) { 
      mexErrMsgTxt("Input 1881 must be a noncomplex scalar double.");
    } 
    mexinput1881_temp = mxGetPr(prhs[1881]); 
    double mexinput1881 = *mexinput1881_temp; 

    double *mexinput1882_temp = NULL; 
    if( !mxIsDouble(prhs[1882]) || mxIsComplex(prhs[1882]) || !(mxGetM(prhs[1882])==1 && mxGetN(prhs[1882])==1) ) { 
      mexErrMsgTxt("Input 1882 must be a noncomplex scalar double.");
    } 
    mexinput1882_temp = mxGetPr(prhs[1882]); 
    double mexinput1882 = *mexinput1882_temp; 

    double *mexinput1883_temp = NULL; 
    if( !mxIsDouble(prhs[1883]) || mxIsComplex(prhs[1883]) || !(mxGetM(prhs[1883])==1 && mxGetN(prhs[1883])==1) ) { 
      mexErrMsgTxt("Input 1883 must be a noncomplex scalar double.");
    } 
    mexinput1883_temp = mxGetPr(prhs[1883]); 
    double mexinput1883 = *mexinput1883_temp; 

    double *mexinput1884_temp = NULL; 
    if( !mxIsDouble(prhs[1884]) || mxIsComplex(prhs[1884]) || !(mxGetM(prhs[1884])==1 && mxGetN(prhs[1884])==1) ) { 
      mexErrMsgTxt("Input 1884 must be a noncomplex scalar double.");
    } 
    mexinput1884_temp = mxGetPr(prhs[1884]); 
    double mexinput1884 = *mexinput1884_temp; 

    double *mexinput1885_temp = NULL; 
    if( !mxIsDouble(prhs[1885]) || mxIsComplex(prhs[1885]) || !(mxGetM(prhs[1885])==1 && mxGetN(prhs[1885])==1) ) { 
      mexErrMsgTxt("Input 1885 must be a noncomplex scalar double.");
    } 
    mexinput1885_temp = mxGetPr(prhs[1885]); 
    double mexinput1885 = *mexinput1885_temp; 

    double *mexinput1886_temp = NULL; 
    if( !mxIsDouble(prhs[1886]) || mxIsComplex(prhs[1886]) || !(mxGetM(prhs[1886])==1 && mxGetN(prhs[1886])==1) ) { 
      mexErrMsgTxt("Input 1886 must be a noncomplex scalar double.");
    } 
    mexinput1886_temp = mxGetPr(prhs[1886]); 
    double mexinput1886 = *mexinput1886_temp; 

    double *mexinput1887_temp = NULL; 
    if( !mxIsDouble(prhs[1887]) || mxIsComplex(prhs[1887]) || !(mxGetM(prhs[1887])==1 && mxGetN(prhs[1887])==1) ) { 
      mexErrMsgTxt("Input 1887 must be a noncomplex scalar double.");
    } 
    mexinput1887_temp = mxGetPr(prhs[1887]); 
    double mexinput1887 = *mexinput1887_temp; 

    double *mexinput1888_temp = NULL; 
    if( !mxIsDouble(prhs[1888]) || mxIsComplex(prhs[1888]) || !(mxGetM(prhs[1888])==1 && mxGetN(prhs[1888])==1) ) { 
      mexErrMsgTxt("Input 1888 must be a noncomplex scalar double.");
    } 
    mexinput1888_temp = mxGetPr(prhs[1888]); 
    double mexinput1888 = *mexinput1888_temp; 

    double *mexinput1889_temp = NULL; 
    if( !mxIsDouble(prhs[1889]) || mxIsComplex(prhs[1889]) || !(mxGetM(prhs[1889])==1 && mxGetN(prhs[1889])==1) ) { 
      mexErrMsgTxt("Input 1889 must be a noncomplex scalar double.");
    } 
    mexinput1889_temp = mxGetPr(prhs[1889]); 
    double mexinput1889 = *mexinput1889_temp; 

    double *mexinput1890_temp = NULL; 
    if( !mxIsDouble(prhs[1890]) || mxIsComplex(prhs[1890]) || !(mxGetM(prhs[1890])==1 && mxGetN(prhs[1890])==1) ) { 
      mexErrMsgTxt("Input 1890 must be a noncomplex scalar double.");
    } 
    mexinput1890_temp = mxGetPr(prhs[1890]); 
    double mexinput1890 = *mexinput1890_temp; 

    double *mexinput1891_temp = NULL; 
    if( !mxIsDouble(prhs[1891]) || mxIsComplex(prhs[1891]) || !(mxGetM(prhs[1891])==1 && mxGetN(prhs[1891])==1) ) { 
      mexErrMsgTxt("Input 1891 must be a noncomplex scalar double.");
    } 
    mexinput1891_temp = mxGetPr(prhs[1891]); 
    double mexinput1891 = *mexinput1891_temp; 

    double *mexinput1892_temp = NULL; 
    if( !mxIsDouble(prhs[1892]) || mxIsComplex(prhs[1892]) || !(mxGetM(prhs[1892])==1 && mxGetN(prhs[1892])==1) ) { 
      mexErrMsgTxt("Input 1892 must be a noncomplex scalar double.");
    } 
    mexinput1892_temp = mxGetPr(prhs[1892]); 
    double mexinput1892 = *mexinput1892_temp; 

    double *mexinput1893_temp = NULL; 
    if( !mxIsDouble(prhs[1893]) || mxIsComplex(prhs[1893]) || !(mxGetM(prhs[1893])==1 && mxGetN(prhs[1893])==1) ) { 
      mexErrMsgTxt("Input 1893 must be a noncomplex scalar double.");
    } 
    mexinput1893_temp = mxGetPr(prhs[1893]); 
    double mexinput1893 = *mexinput1893_temp; 

    double *mexinput1894_temp = NULL; 
    if( !mxIsDouble(prhs[1894]) || mxIsComplex(prhs[1894]) || !(mxGetM(prhs[1894])==1 && mxGetN(prhs[1894])==1) ) { 
      mexErrMsgTxt("Input 1894 must be a noncomplex scalar double.");
    } 
    mexinput1894_temp = mxGetPr(prhs[1894]); 
    double mexinput1894 = *mexinput1894_temp; 

    double *mexinput1895_temp = NULL; 
    if( !mxIsDouble(prhs[1895]) || mxIsComplex(prhs[1895]) || !(mxGetM(prhs[1895])==1 && mxGetN(prhs[1895])==1) ) { 
      mexErrMsgTxt("Input 1895 must be a noncomplex scalar double.");
    } 
    mexinput1895_temp = mxGetPr(prhs[1895]); 
    double mexinput1895 = *mexinput1895_temp; 

    double *mexinput1896_temp = NULL; 
    if( !mxIsDouble(prhs[1896]) || mxIsComplex(prhs[1896]) || !(mxGetM(prhs[1896])==1 && mxGetN(prhs[1896])==1) ) { 
      mexErrMsgTxt("Input 1896 must be a noncomplex scalar double.");
    } 
    mexinput1896_temp = mxGetPr(prhs[1896]); 
    double mexinput1896 = *mexinput1896_temp; 

    double *mexinput1897_temp = NULL; 
    if( !mxIsDouble(prhs[1897]) || mxIsComplex(prhs[1897]) || !(mxGetM(prhs[1897])==1 && mxGetN(prhs[1897])==1) ) { 
      mexErrMsgTxt("Input 1897 must be a noncomplex scalar double.");
    } 
    mexinput1897_temp = mxGetPr(prhs[1897]); 
    double mexinput1897 = *mexinput1897_temp; 

    double *mexinput1898_temp = NULL; 
    if( !mxIsDouble(prhs[1898]) || mxIsComplex(prhs[1898]) || !(mxGetM(prhs[1898])==1 && mxGetN(prhs[1898])==1) ) { 
      mexErrMsgTxt("Input 1898 must be a noncomplex scalar double.");
    } 
    mexinput1898_temp = mxGetPr(prhs[1898]); 
    double mexinput1898 = *mexinput1898_temp; 

    double *mexinput1899_temp = NULL; 
    if( !mxIsDouble(prhs[1899]) || mxIsComplex(prhs[1899]) || !(mxGetM(prhs[1899])==1 && mxGetN(prhs[1899])==1) ) { 
      mexErrMsgTxt("Input 1899 must be a noncomplex scalar double.");
    } 
    mexinput1899_temp = mxGetPr(prhs[1899]); 
    double mexinput1899 = *mexinput1899_temp; 

    double *mexinput1900_temp = NULL; 
    if( !mxIsDouble(prhs[1900]) || mxIsComplex(prhs[1900]) || !(mxGetM(prhs[1900])==1 && mxGetN(prhs[1900])==1) ) { 
      mexErrMsgTxt("Input 1900 must be a noncomplex scalar double.");
    } 
    mexinput1900_temp = mxGetPr(prhs[1900]); 
    double mexinput1900 = *mexinput1900_temp; 

    double *mexinput1901_temp = NULL; 
    if( !mxIsDouble(prhs[1901]) || mxIsComplex(prhs[1901]) || !(mxGetM(prhs[1901])==1 && mxGetN(prhs[1901])==1) ) { 
      mexErrMsgTxt("Input 1901 must be a noncomplex scalar double.");
    } 
    mexinput1901_temp = mxGetPr(prhs[1901]); 
    double mexinput1901 = *mexinput1901_temp; 

    double *mexinput1902_temp = NULL; 
    if( !mxIsDouble(prhs[1902]) || mxIsComplex(prhs[1902]) || !(mxGetM(prhs[1902])==1 && mxGetN(prhs[1902])==1) ) { 
      mexErrMsgTxt("Input 1902 must be a noncomplex scalar double.");
    } 
    mexinput1902_temp = mxGetPr(prhs[1902]); 
    double mexinput1902 = *mexinput1902_temp; 

    double *mexinput1903_temp = NULL; 
    if( !mxIsDouble(prhs[1903]) || mxIsComplex(prhs[1903]) || !(mxGetM(prhs[1903])==1 && mxGetN(prhs[1903])==1) ) { 
      mexErrMsgTxt("Input 1903 must be a noncomplex scalar double.");
    } 
    mexinput1903_temp = mxGetPr(prhs[1903]); 
    double mexinput1903 = *mexinput1903_temp; 

    double *mexinput1904_temp = NULL; 
    if( !mxIsDouble(prhs[1904]) || mxIsComplex(prhs[1904]) || !(mxGetM(prhs[1904])==1 && mxGetN(prhs[1904])==1) ) { 
      mexErrMsgTxt("Input 1904 must be a noncomplex scalar double.");
    } 
    mexinput1904_temp = mxGetPr(prhs[1904]); 
    double mexinput1904 = *mexinput1904_temp; 

    double *mexinput1905_temp = NULL; 
    if( !mxIsDouble(prhs[1905]) || mxIsComplex(prhs[1905]) || !(mxGetM(prhs[1905])==1 && mxGetN(prhs[1905])==1) ) { 
      mexErrMsgTxt("Input 1905 must be a noncomplex scalar double.");
    } 
    mexinput1905_temp = mxGetPr(prhs[1905]); 
    double mexinput1905 = *mexinput1905_temp; 

    double *mexinput1906_temp = NULL; 
    if( !mxIsDouble(prhs[1906]) || mxIsComplex(prhs[1906]) || !(mxGetM(prhs[1906])==1 && mxGetN(prhs[1906])==1) ) { 
      mexErrMsgTxt("Input 1906 must be a noncomplex scalar double.");
    } 
    mexinput1906_temp = mxGetPr(prhs[1906]); 
    double mexinput1906 = *mexinput1906_temp; 

    double *mexinput1907_temp = NULL; 
    if( !mxIsDouble(prhs[1907]) || mxIsComplex(prhs[1907]) || !(mxGetM(prhs[1907])==1 && mxGetN(prhs[1907])==1) ) { 
      mexErrMsgTxt("Input 1907 must be a noncomplex scalar double.");
    } 
    mexinput1907_temp = mxGetPr(prhs[1907]); 
    double mexinput1907 = *mexinput1907_temp; 

    double *mexinput1908_temp = NULL; 
    if( !mxIsDouble(prhs[1908]) || mxIsComplex(prhs[1908]) || !(mxGetM(prhs[1908])==1 && mxGetN(prhs[1908])==1) ) { 
      mexErrMsgTxt("Input 1908 must be a noncomplex scalar double.");
    } 
    mexinput1908_temp = mxGetPr(prhs[1908]); 
    double mexinput1908 = *mexinput1908_temp; 

    double *mexinput1909_temp = NULL; 
    if( !mxIsDouble(prhs[1909]) || mxIsComplex(prhs[1909]) || !(mxGetM(prhs[1909])==1 && mxGetN(prhs[1909])==1) ) { 
      mexErrMsgTxt("Input 1909 must be a noncomplex scalar double.");
    } 
    mexinput1909_temp = mxGetPr(prhs[1909]); 
    double mexinput1909 = *mexinput1909_temp; 

    double *mexinput1910_temp = NULL; 
    if( !mxIsDouble(prhs[1910]) || mxIsComplex(prhs[1910]) || !(mxGetM(prhs[1910])==1 && mxGetN(prhs[1910])==1) ) { 
      mexErrMsgTxt("Input 1910 must be a noncomplex scalar double.");
    } 
    mexinput1910_temp = mxGetPr(prhs[1910]); 
    double mexinput1910 = *mexinput1910_temp; 

    double *mexinput1911_temp = NULL; 
    if( !mxIsDouble(prhs[1911]) || mxIsComplex(prhs[1911]) || !(mxGetM(prhs[1911])==1 && mxGetN(prhs[1911])==1) ) { 
      mexErrMsgTxt("Input 1911 must be a noncomplex scalar double.");
    } 
    mexinput1911_temp = mxGetPr(prhs[1911]); 
    double mexinput1911 = *mexinput1911_temp; 

    double *mexinput1912_temp = NULL; 
    if( !mxIsDouble(prhs[1912]) || mxIsComplex(prhs[1912]) || !(mxGetM(prhs[1912])==1 && mxGetN(prhs[1912])==1) ) { 
      mexErrMsgTxt("Input 1912 must be a noncomplex scalar double.");
    } 
    mexinput1912_temp = mxGetPr(prhs[1912]); 
    double mexinput1912 = *mexinput1912_temp; 

    double *mexinput1913_temp = NULL; 
    if( !mxIsDouble(prhs[1913]) || mxIsComplex(prhs[1913]) || !(mxGetM(prhs[1913])==1 && mxGetN(prhs[1913])==1) ) { 
      mexErrMsgTxt("Input 1913 must be a noncomplex scalar double.");
    } 
    mexinput1913_temp = mxGetPr(prhs[1913]); 
    double mexinput1913 = *mexinput1913_temp; 

    double *mexinput1914_temp = NULL; 
    if( !mxIsDouble(prhs[1914]) || mxIsComplex(prhs[1914]) || !(mxGetM(prhs[1914])==1 && mxGetN(prhs[1914])==1) ) { 
      mexErrMsgTxt("Input 1914 must be a noncomplex scalar double.");
    } 
    mexinput1914_temp = mxGetPr(prhs[1914]); 
    double mexinput1914 = *mexinput1914_temp; 

    double *mexinput1915_temp = NULL; 
    if( !mxIsDouble(prhs[1915]) || mxIsComplex(prhs[1915]) || !(mxGetM(prhs[1915])==1 && mxGetN(prhs[1915])==1) ) { 
      mexErrMsgTxt("Input 1915 must be a noncomplex scalar double.");
    } 
    mexinput1915_temp = mxGetPr(prhs[1915]); 
    double mexinput1915 = *mexinput1915_temp; 

    double *mexinput1916_temp = NULL; 
    if( !mxIsDouble(prhs[1916]) || mxIsComplex(prhs[1916]) || !(mxGetM(prhs[1916])==1 && mxGetN(prhs[1916])==1) ) { 
      mexErrMsgTxt("Input 1916 must be a noncomplex scalar double.");
    } 
    mexinput1916_temp = mxGetPr(prhs[1916]); 
    double mexinput1916 = *mexinput1916_temp; 

    double *mexinput1917_temp = NULL; 
    if( !mxIsDouble(prhs[1917]) || mxIsComplex(prhs[1917]) || !(mxGetM(prhs[1917])==1 && mxGetN(prhs[1917])==1) ) { 
      mexErrMsgTxt("Input 1917 must be a noncomplex scalar double.");
    } 
    mexinput1917_temp = mxGetPr(prhs[1917]); 
    double mexinput1917 = *mexinput1917_temp; 

    double *mexinput1918_temp = NULL; 
    if( !mxIsDouble(prhs[1918]) || mxIsComplex(prhs[1918]) || !(mxGetM(prhs[1918])==1 && mxGetN(prhs[1918])==1) ) { 
      mexErrMsgTxt("Input 1918 must be a noncomplex scalar double.");
    } 
    mexinput1918_temp = mxGetPr(prhs[1918]); 
    double mexinput1918 = *mexinput1918_temp; 

    double *mexinput1919_temp = NULL; 
    if( !mxIsDouble(prhs[1919]) || mxIsComplex(prhs[1919]) || !(mxGetM(prhs[1919])==1 && mxGetN(prhs[1919])==1) ) { 
      mexErrMsgTxt("Input 1919 must be a noncomplex scalar double.");
    } 
    mexinput1919_temp = mxGetPr(prhs[1919]); 
    double mexinput1919 = *mexinput1919_temp; 

    double *mexinput1920_temp = NULL; 
    if( !mxIsDouble(prhs[1920]) || mxIsComplex(prhs[1920]) || !(mxGetM(prhs[1920])==1 && mxGetN(prhs[1920])==1) ) { 
      mexErrMsgTxt("Input 1920 must be a noncomplex scalar double.");
    } 
    mexinput1920_temp = mxGetPr(prhs[1920]); 
    double mexinput1920 = *mexinput1920_temp; 

    double *mexinput1921_temp = NULL; 
    if( !mxIsDouble(prhs[1921]) || mxIsComplex(prhs[1921]) || !(mxGetM(prhs[1921])==1 && mxGetN(prhs[1921])==1) ) { 
      mexErrMsgTxt("Input 1921 must be a noncomplex scalar double.");
    } 
    mexinput1921_temp = mxGetPr(prhs[1921]); 
    double mexinput1921 = *mexinput1921_temp; 

    double *mexinput1922_temp = NULL; 
    if( !mxIsDouble(prhs[1922]) || mxIsComplex(prhs[1922]) || !(mxGetM(prhs[1922])==1 && mxGetN(prhs[1922])==1) ) { 
      mexErrMsgTxt("Input 1922 must be a noncomplex scalar double.");
    } 
    mexinput1922_temp = mxGetPr(prhs[1922]); 
    double mexinput1922 = *mexinput1922_temp; 

    double *mexinput1923_temp = NULL; 
    if( !mxIsDouble(prhs[1923]) || mxIsComplex(prhs[1923]) || !(mxGetM(prhs[1923])==1 && mxGetN(prhs[1923])==1) ) { 
      mexErrMsgTxt("Input 1923 must be a noncomplex scalar double.");
    } 
    mexinput1923_temp = mxGetPr(prhs[1923]); 
    double mexinput1923 = *mexinput1923_temp; 

    double *mexinput1924_temp = NULL; 
    if( !mxIsDouble(prhs[1924]) || mxIsComplex(prhs[1924]) || !(mxGetM(prhs[1924])==1 && mxGetN(prhs[1924])==1) ) { 
      mexErrMsgTxt("Input 1924 must be a noncomplex scalar double.");
    } 
    mexinput1924_temp = mxGetPr(prhs[1924]); 
    double mexinput1924 = *mexinput1924_temp; 

    double *mexinput1925_temp = NULL; 
    if( !mxIsDouble(prhs[1925]) || mxIsComplex(prhs[1925]) || !(mxGetM(prhs[1925])==1 && mxGetN(prhs[1925])==1) ) { 
      mexErrMsgTxt("Input 1925 must be a noncomplex scalar double.");
    } 
    mexinput1925_temp = mxGetPr(prhs[1925]); 
    double mexinput1925 = *mexinput1925_temp; 

    double *mexinput1926_temp = NULL; 
    if( !mxIsDouble(prhs[1926]) || mxIsComplex(prhs[1926]) || !(mxGetM(prhs[1926])==1 && mxGetN(prhs[1926])==1) ) { 
      mexErrMsgTxt("Input 1926 must be a noncomplex scalar double.");
    } 
    mexinput1926_temp = mxGetPr(prhs[1926]); 
    double mexinput1926 = *mexinput1926_temp; 

    double *mexinput1927_temp = NULL; 
    if( !mxIsDouble(prhs[1927]) || mxIsComplex(prhs[1927]) || !(mxGetM(prhs[1927])==1 && mxGetN(prhs[1927])==1) ) { 
      mexErrMsgTxt("Input 1927 must be a noncomplex scalar double.");
    } 
    mexinput1927_temp = mxGetPr(prhs[1927]); 
    double mexinput1927 = *mexinput1927_temp; 

    double *mexinput1928_temp = NULL; 
    if( !mxIsDouble(prhs[1928]) || mxIsComplex(prhs[1928]) || !(mxGetM(prhs[1928])==1 && mxGetN(prhs[1928])==1) ) { 
      mexErrMsgTxt("Input 1928 must be a noncomplex scalar double.");
    } 
    mexinput1928_temp = mxGetPr(prhs[1928]); 
    double mexinput1928 = *mexinput1928_temp; 

    double *mexinput1929_temp = NULL; 
    if( !mxIsDouble(prhs[1929]) || mxIsComplex(prhs[1929]) || !(mxGetM(prhs[1929])==1 && mxGetN(prhs[1929])==1) ) { 
      mexErrMsgTxt("Input 1929 must be a noncomplex scalar double.");
    } 
    mexinput1929_temp = mxGetPr(prhs[1929]); 
    double mexinput1929 = *mexinput1929_temp; 

    double *mexinput1930_temp = NULL; 
    if( !mxIsDouble(prhs[1930]) || mxIsComplex(prhs[1930]) || !(mxGetM(prhs[1930])==1 && mxGetN(prhs[1930])==1) ) { 
      mexErrMsgTxt("Input 1930 must be a noncomplex scalar double.");
    } 
    mexinput1930_temp = mxGetPr(prhs[1930]); 
    double mexinput1930 = *mexinput1930_temp; 

    double *mexinput1931_temp = NULL; 
    if( !mxIsDouble(prhs[1931]) || mxIsComplex(prhs[1931]) || !(mxGetM(prhs[1931])==1 && mxGetN(prhs[1931])==1) ) { 
      mexErrMsgTxt("Input 1931 must be a noncomplex scalar double.");
    } 
    mexinput1931_temp = mxGetPr(prhs[1931]); 
    double mexinput1931 = *mexinput1931_temp; 

    double *mexinput1932_temp = NULL; 
    if( !mxIsDouble(prhs[1932]) || mxIsComplex(prhs[1932]) || !(mxGetM(prhs[1932])==1 && mxGetN(prhs[1932])==1) ) { 
      mexErrMsgTxt("Input 1932 must be a noncomplex scalar double.");
    } 
    mexinput1932_temp = mxGetPr(prhs[1932]); 
    double mexinput1932 = *mexinput1932_temp; 

    double *mexinput1933_temp = NULL; 
    if( !mxIsDouble(prhs[1933]) || mxIsComplex(prhs[1933]) || !(mxGetM(prhs[1933])==1 && mxGetN(prhs[1933])==1) ) { 
      mexErrMsgTxt("Input 1933 must be a noncomplex scalar double.");
    } 
    mexinput1933_temp = mxGetPr(prhs[1933]); 
    double mexinput1933 = *mexinput1933_temp; 

    double *mexinput1934_temp = NULL; 
    if( !mxIsDouble(prhs[1934]) || mxIsComplex(prhs[1934]) || !(mxGetM(prhs[1934])==1 && mxGetN(prhs[1934])==1) ) { 
      mexErrMsgTxt("Input 1934 must be a noncomplex scalar double.");
    } 
    mexinput1934_temp = mxGetPr(prhs[1934]); 
    double mexinput1934 = *mexinput1934_temp; 

    double *mexinput1935_temp = NULL; 
    if( !mxIsDouble(prhs[1935]) || mxIsComplex(prhs[1935]) || !(mxGetM(prhs[1935])==1 && mxGetN(prhs[1935])==1) ) { 
      mexErrMsgTxt("Input 1935 must be a noncomplex scalar double.");
    } 
    mexinput1935_temp = mxGetPr(prhs[1935]); 
    double mexinput1935 = *mexinput1935_temp; 

    double *mexinput1936_temp = NULL; 
    if( !mxIsDouble(prhs[1936]) || mxIsComplex(prhs[1936]) || !(mxGetM(prhs[1936])==1 && mxGetN(prhs[1936])==1) ) { 
      mexErrMsgTxt("Input 1936 must be a noncomplex scalar double.");
    } 
    mexinput1936_temp = mxGetPr(prhs[1936]); 
    double mexinput1936 = *mexinput1936_temp; 

    double *mexinput1937_temp = NULL; 
    if( !mxIsDouble(prhs[1937]) || mxIsComplex(prhs[1937]) || !(mxGetM(prhs[1937])==1 && mxGetN(prhs[1937])==1) ) { 
      mexErrMsgTxt("Input 1937 must be a noncomplex scalar double.");
    } 
    mexinput1937_temp = mxGetPr(prhs[1937]); 
    double mexinput1937 = *mexinput1937_temp; 

    double *mexinput1938_temp = NULL; 
    if( !mxIsDouble(prhs[1938]) || mxIsComplex(prhs[1938]) || !(mxGetM(prhs[1938])==1 && mxGetN(prhs[1938])==1) ) { 
      mexErrMsgTxt("Input 1938 must be a noncomplex scalar double.");
    } 
    mexinput1938_temp = mxGetPr(prhs[1938]); 
    double mexinput1938 = *mexinput1938_temp; 

    double *mexinput1939_temp = NULL; 
    if( !mxIsDouble(prhs[1939]) || mxIsComplex(prhs[1939]) || !(mxGetM(prhs[1939])==1 && mxGetN(prhs[1939])==1) ) { 
      mexErrMsgTxt("Input 1939 must be a noncomplex scalar double.");
    } 
    mexinput1939_temp = mxGetPr(prhs[1939]); 
    double mexinput1939 = *mexinput1939_temp; 

    double *mexinput1940_temp = NULL; 
    if( !mxIsDouble(prhs[1940]) || mxIsComplex(prhs[1940]) || !(mxGetM(prhs[1940])==1 && mxGetN(prhs[1940])==1) ) { 
      mexErrMsgTxt("Input 1940 must be a noncomplex scalar double.");
    } 
    mexinput1940_temp = mxGetPr(prhs[1940]); 
    double mexinput1940 = *mexinput1940_temp; 

    double *mexinput1941_temp = NULL; 
    if( !mxIsDouble(prhs[1941]) || mxIsComplex(prhs[1941]) || !(mxGetM(prhs[1941])==1 && mxGetN(prhs[1941])==1) ) { 
      mexErrMsgTxt("Input 1941 must be a noncomplex scalar double.");
    } 
    mexinput1941_temp = mxGetPr(prhs[1941]); 
    double mexinput1941 = *mexinput1941_temp; 

    double *mexinput1942_temp = NULL; 
    if( !mxIsDouble(prhs[1942]) || mxIsComplex(prhs[1942]) || !(mxGetM(prhs[1942])==1 && mxGetN(prhs[1942])==1) ) { 
      mexErrMsgTxt("Input 1942 must be a noncomplex scalar double.");
    } 
    mexinput1942_temp = mxGetPr(prhs[1942]); 
    double mexinput1942 = *mexinput1942_temp; 

    double *mexinput1943_temp = NULL; 
    if( !mxIsDouble(prhs[1943]) || mxIsComplex(prhs[1943]) || !(mxGetM(prhs[1943])==1 && mxGetN(prhs[1943])==1) ) { 
      mexErrMsgTxt("Input 1943 must be a noncomplex scalar double.");
    } 
    mexinput1943_temp = mxGetPr(prhs[1943]); 
    double mexinput1943 = *mexinput1943_temp; 

    double *mexinput1944_temp = NULL; 
    if( !mxIsDouble(prhs[1944]) || mxIsComplex(prhs[1944]) || !(mxGetM(prhs[1944])==1 && mxGetN(prhs[1944])==1) ) { 
      mexErrMsgTxt("Input 1944 must be a noncomplex scalar double.");
    } 
    mexinput1944_temp = mxGetPr(prhs[1944]); 
    double mexinput1944 = *mexinput1944_temp; 

    double *mexinput1945_temp = NULL; 
    if( !mxIsDouble(prhs[1945]) || mxIsComplex(prhs[1945]) || !(mxGetM(prhs[1945])==1 && mxGetN(prhs[1945])==1) ) { 
      mexErrMsgTxt("Input 1945 must be a noncomplex scalar double.");
    } 
    mexinput1945_temp = mxGetPr(prhs[1945]); 
    double mexinput1945 = *mexinput1945_temp; 

    double *mexinput1946_temp = NULL; 
    if( !mxIsDouble(prhs[1946]) || mxIsComplex(prhs[1946]) || !(mxGetM(prhs[1946])==1 && mxGetN(prhs[1946])==1) ) { 
      mexErrMsgTxt("Input 1946 must be a noncomplex scalar double.");
    } 
    mexinput1946_temp = mxGetPr(prhs[1946]); 
    double mexinput1946 = *mexinput1946_temp; 

    double *mexinput1947_temp = NULL; 
    if( !mxIsDouble(prhs[1947]) || mxIsComplex(prhs[1947]) || !(mxGetM(prhs[1947])==1 && mxGetN(prhs[1947])==1) ) { 
      mexErrMsgTxt("Input 1947 must be a noncomplex scalar double.");
    } 
    mexinput1947_temp = mxGetPr(prhs[1947]); 
    double mexinput1947 = *mexinput1947_temp; 

    double *mexinput1948_temp = NULL; 
    if( !mxIsDouble(prhs[1948]) || mxIsComplex(prhs[1948]) || !(mxGetM(prhs[1948])==1 && mxGetN(prhs[1948])==1) ) { 
      mexErrMsgTxt("Input 1948 must be a noncomplex scalar double.");
    } 
    mexinput1948_temp = mxGetPr(prhs[1948]); 
    double mexinput1948 = *mexinput1948_temp; 

    double *mexinput1949_temp = NULL; 
    if( !mxIsDouble(prhs[1949]) || mxIsComplex(prhs[1949]) || !(mxGetM(prhs[1949])==1 && mxGetN(prhs[1949])==1) ) { 
      mexErrMsgTxt("Input 1949 must be a noncomplex scalar double.");
    } 
    mexinput1949_temp = mxGetPr(prhs[1949]); 
    double mexinput1949 = *mexinput1949_temp; 

    double *mexinput1950_temp = NULL; 
    if( !mxIsDouble(prhs[1950]) || mxIsComplex(prhs[1950]) || !(mxGetM(prhs[1950])==1 && mxGetN(prhs[1950])==1) ) { 
      mexErrMsgTxt("Input 1950 must be a noncomplex scalar double.");
    } 
    mexinput1950_temp = mxGetPr(prhs[1950]); 
    double mexinput1950 = *mexinput1950_temp; 

    double *mexinput1951_temp = NULL; 
    if( !mxIsDouble(prhs[1951]) || mxIsComplex(prhs[1951]) || !(mxGetM(prhs[1951])==1 && mxGetN(prhs[1951])==1) ) { 
      mexErrMsgTxt("Input 1951 must be a noncomplex scalar double.");
    } 
    mexinput1951_temp = mxGetPr(prhs[1951]); 
    double mexinput1951 = *mexinput1951_temp; 

    double *mexinput1952_temp = NULL; 
    if( !mxIsDouble(prhs[1952]) || mxIsComplex(prhs[1952]) || !(mxGetM(prhs[1952])==1 && mxGetN(prhs[1952])==1) ) { 
      mexErrMsgTxt("Input 1952 must be a noncomplex scalar double.");
    } 
    mexinput1952_temp = mxGetPr(prhs[1952]); 
    double mexinput1952 = *mexinput1952_temp; 

    double *mexinput1953_temp = NULL; 
    if( !mxIsDouble(prhs[1953]) || mxIsComplex(prhs[1953]) || !(mxGetM(prhs[1953])==1 && mxGetN(prhs[1953])==1) ) { 
      mexErrMsgTxt("Input 1953 must be a noncomplex scalar double.");
    } 
    mexinput1953_temp = mxGetPr(prhs[1953]); 
    double mexinput1953 = *mexinput1953_temp; 

    double *mexinput1954_temp = NULL; 
    if( !mxIsDouble(prhs[1954]) || mxIsComplex(prhs[1954]) || !(mxGetM(prhs[1954])==1 && mxGetN(prhs[1954])==1) ) { 
      mexErrMsgTxt("Input 1954 must be a noncomplex scalar double.");
    } 
    mexinput1954_temp = mxGetPr(prhs[1954]); 
    double mexinput1954 = *mexinput1954_temp; 

    double *mexinput1955_temp = NULL; 
    if( !mxIsDouble(prhs[1955]) || mxIsComplex(prhs[1955]) || !(mxGetM(prhs[1955])==1 && mxGetN(prhs[1955])==1) ) { 
      mexErrMsgTxt("Input 1955 must be a noncomplex scalar double.");
    } 
    mexinput1955_temp = mxGetPr(prhs[1955]); 
    double mexinput1955 = *mexinput1955_temp; 

    double *mexinput1956_temp = NULL; 
    if( !mxIsDouble(prhs[1956]) || mxIsComplex(prhs[1956]) || !(mxGetM(prhs[1956])==1 && mxGetN(prhs[1956])==1) ) { 
      mexErrMsgTxt("Input 1956 must be a noncomplex scalar double.");
    } 
    mexinput1956_temp = mxGetPr(prhs[1956]); 
    double mexinput1956 = *mexinput1956_temp; 

    double *mexinput1957_temp = NULL; 
    if( !mxIsDouble(prhs[1957]) || mxIsComplex(prhs[1957]) || !(mxGetM(prhs[1957])==1 && mxGetN(prhs[1957])==1) ) { 
      mexErrMsgTxt("Input 1957 must be a noncomplex scalar double.");
    } 
    mexinput1957_temp = mxGetPr(prhs[1957]); 
    double mexinput1957 = *mexinput1957_temp; 

    double *mexinput1958_temp = NULL; 
    if( !mxIsDouble(prhs[1958]) || mxIsComplex(prhs[1958]) || !(mxGetM(prhs[1958])==1 && mxGetN(prhs[1958])==1) ) { 
      mexErrMsgTxt("Input 1958 must be a noncomplex scalar double.");
    } 
    mexinput1958_temp = mxGetPr(prhs[1958]); 
    double mexinput1958 = *mexinput1958_temp; 

    double *mexinput1959_temp = NULL; 
    if( !mxIsDouble(prhs[1959]) || mxIsComplex(prhs[1959]) || !(mxGetM(prhs[1959])==1 && mxGetN(prhs[1959])==1) ) { 
      mexErrMsgTxt("Input 1959 must be a noncomplex scalar double.");
    } 
    mexinput1959_temp = mxGetPr(prhs[1959]); 
    double mexinput1959 = *mexinput1959_temp; 

    double *mexinput1960_temp = NULL; 
    if( !mxIsDouble(prhs[1960]) || mxIsComplex(prhs[1960]) || !(mxGetM(prhs[1960])==1 && mxGetN(prhs[1960])==1) ) { 
      mexErrMsgTxt("Input 1960 must be a noncomplex scalar double.");
    } 
    mexinput1960_temp = mxGetPr(prhs[1960]); 
    double mexinput1960 = *mexinput1960_temp; 

    double *mexinput1961_temp = NULL; 
    if( !mxIsDouble(prhs[1961]) || mxIsComplex(prhs[1961]) || !(mxGetM(prhs[1961])==1 && mxGetN(prhs[1961])==1) ) { 
      mexErrMsgTxt("Input 1961 must be a noncomplex scalar double.");
    } 
    mexinput1961_temp = mxGetPr(prhs[1961]); 
    double mexinput1961 = *mexinput1961_temp; 

    double *mexinput1962_temp = NULL; 
    if( !mxIsDouble(prhs[1962]) || mxIsComplex(prhs[1962]) || !(mxGetM(prhs[1962])==1 && mxGetN(prhs[1962])==1) ) { 
      mexErrMsgTxt("Input 1962 must be a noncomplex scalar double.");
    } 
    mexinput1962_temp = mxGetPr(prhs[1962]); 
    double mexinput1962 = *mexinput1962_temp; 

    double *mexinput1963_temp = NULL; 
    if( !mxIsDouble(prhs[1963]) || mxIsComplex(prhs[1963]) || !(mxGetM(prhs[1963])==1 && mxGetN(prhs[1963])==1) ) { 
      mexErrMsgTxt("Input 1963 must be a noncomplex scalar double.");
    } 
    mexinput1963_temp = mxGetPr(prhs[1963]); 
    double mexinput1963 = *mexinput1963_temp; 

    double *mexinput1964_temp = NULL; 
    if( !mxIsDouble(prhs[1964]) || mxIsComplex(prhs[1964]) || !(mxGetM(prhs[1964])==1 && mxGetN(prhs[1964])==1) ) { 
      mexErrMsgTxt("Input 1964 must be a noncomplex scalar double.");
    } 
    mexinput1964_temp = mxGetPr(prhs[1964]); 
    double mexinput1964 = *mexinput1964_temp; 

    double *mexinput1965_temp = NULL; 
    if( !mxIsDouble(prhs[1965]) || mxIsComplex(prhs[1965]) || !(mxGetM(prhs[1965])==1 && mxGetN(prhs[1965])==1) ) { 
      mexErrMsgTxt("Input 1965 must be a noncomplex scalar double.");
    } 
    mexinput1965_temp = mxGetPr(prhs[1965]); 
    double mexinput1965 = *mexinput1965_temp; 

    double *mexinput1966_temp = NULL; 
    if( !mxIsDouble(prhs[1966]) || mxIsComplex(prhs[1966]) || !(mxGetM(prhs[1966])==1 && mxGetN(prhs[1966])==1) ) { 
      mexErrMsgTxt("Input 1966 must be a noncomplex scalar double.");
    } 
    mexinput1966_temp = mxGetPr(prhs[1966]); 
    double mexinput1966 = *mexinput1966_temp; 

    double *mexinput1967_temp = NULL; 
    if( !mxIsDouble(prhs[1967]) || mxIsComplex(prhs[1967]) || !(mxGetM(prhs[1967])==1 && mxGetN(prhs[1967])==1) ) { 
      mexErrMsgTxt("Input 1967 must be a noncomplex scalar double.");
    } 
    mexinput1967_temp = mxGetPr(prhs[1967]); 
    double mexinput1967 = *mexinput1967_temp; 

    double *mexinput1968_temp = NULL; 
    if( !mxIsDouble(prhs[1968]) || mxIsComplex(prhs[1968]) || !(mxGetM(prhs[1968])==1 && mxGetN(prhs[1968])==1) ) { 
      mexErrMsgTxt("Input 1968 must be a noncomplex scalar double.");
    } 
    mexinput1968_temp = mxGetPr(prhs[1968]); 
    double mexinput1968 = *mexinput1968_temp; 

    double *mexinput1969_temp = NULL; 
    if( !mxIsDouble(prhs[1969]) || mxIsComplex(prhs[1969]) || !(mxGetM(prhs[1969])==1 && mxGetN(prhs[1969])==1) ) { 
      mexErrMsgTxt("Input 1969 must be a noncomplex scalar double.");
    } 
    mexinput1969_temp = mxGetPr(prhs[1969]); 
    double mexinput1969 = *mexinput1969_temp; 

    double *mexinput1970_temp = NULL; 
    if( !mxIsDouble(prhs[1970]) || mxIsComplex(prhs[1970]) || !(mxGetM(prhs[1970])==1 && mxGetN(prhs[1970])==1) ) { 
      mexErrMsgTxt("Input 1970 must be a noncomplex scalar double.");
    } 
    mexinput1970_temp = mxGetPr(prhs[1970]); 
    double mexinput1970 = *mexinput1970_temp; 

    double *mexinput1971_temp = NULL; 
    if( !mxIsDouble(prhs[1971]) || mxIsComplex(prhs[1971]) || !(mxGetM(prhs[1971])==1 && mxGetN(prhs[1971])==1) ) { 
      mexErrMsgTxt("Input 1971 must be a noncomplex scalar double.");
    } 
    mexinput1971_temp = mxGetPr(prhs[1971]); 
    double mexinput1971 = *mexinput1971_temp; 

    double *mexinput1972_temp = NULL; 
    if( !mxIsDouble(prhs[1972]) || mxIsComplex(prhs[1972]) || !(mxGetM(prhs[1972])==1 && mxGetN(prhs[1972])==1) ) { 
      mexErrMsgTxt("Input 1972 must be a noncomplex scalar double.");
    } 
    mexinput1972_temp = mxGetPr(prhs[1972]); 
    double mexinput1972 = *mexinput1972_temp; 

    double *mexinput1973_temp = NULL; 
    if( !mxIsDouble(prhs[1973]) || mxIsComplex(prhs[1973]) || !(mxGetM(prhs[1973])==1 && mxGetN(prhs[1973])==1) ) { 
      mexErrMsgTxt("Input 1973 must be a noncomplex scalar double.");
    } 
    mexinput1973_temp = mxGetPr(prhs[1973]); 
    double mexinput1973 = *mexinput1973_temp; 

    double *mexinput1974_temp = NULL; 
    if( !mxIsDouble(prhs[1974]) || mxIsComplex(prhs[1974]) || !(mxGetM(prhs[1974])==1 && mxGetN(prhs[1974])==1) ) { 
      mexErrMsgTxt("Input 1974 must be a noncomplex scalar double.");
    } 
    mexinput1974_temp = mxGetPr(prhs[1974]); 
    double mexinput1974 = *mexinput1974_temp; 

    double *mexinput1975_temp = NULL; 
    if( !mxIsDouble(prhs[1975]) || mxIsComplex(prhs[1975]) || !(mxGetM(prhs[1975])==1 && mxGetN(prhs[1975])==1) ) { 
      mexErrMsgTxt("Input 1975 must be a noncomplex scalar double.");
    } 
    mexinput1975_temp = mxGetPr(prhs[1975]); 
    double mexinput1975 = *mexinput1975_temp; 

    double *mexinput1976_temp = NULL; 
    if( !mxIsDouble(prhs[1976]) || mxIsComplex(prhs[1976]) || !(mxGetM(prhs[1976])==1 && mxGetN(prhs[1976])==1) ) { 
      mexErrMsgTxt("Input 1976 must be a noncomplex scalar double.");
    } 
    mexinput1976_temp = mxGetPr(prhs[1976]); 
    double mexinput1976 = *mexinput1976_temp; 

    double *mexinput1977_temp = NULL; 
    if( !mxIsDouble(prhs[1977]) || mxIsComplex(prhs[1977]) || !(mxGetM(prhs[1977])==1 && mxGetN(prhs[1977])==1) ) { 
      mexErrMsgTxt("Input 1977 must be a noncomplex scalar double.");
    } 
    mexinput1977_temp = mxGetPr(prhs[1977]); 
    double mexinput1977 = *mexinput1977_temp; 

    double *mexinput1978_temp = NULL; 
    if( !mxIsDouble(prhs[1978]) || mxIsComplex(prhs[1978]) || !(mxGetM(prhs[1978])==1 && mxGetN(prhs[1978])==1) ) { 
      mexErrMsgTxt("Input 1978 must be a noncomplex scalar double.");
    } 
    mexinput1978_temp = mxGetPr(prhs[1978]); 
    double mexinput1978 = *mexinput1978_temp; 

    double *mexinput1979_temp = NULL; 
    if( !mxIsDouble(prhs[1979]) || mxIsComplex(prhs[1979]) || !(mxGetM(prhs[1979])==1 && mxGetN(prhs[1979])==1) ) { 
      mexErrMsgTxt("Input 1979 must be a noncomplex scalar double.");
    } 
    mexinput1979_temp = mxGetPr(prhs[1979]); 
    double mexinput1979 = *mexinput1979_temp; 

    double *mexinput1980_temp = NULL; 
    if( !mxIsDouble(prhs[1980]) || mxIsComplex(prhs[1980]) || !(mxGetM(prhs[1980])==1 && mxGetN(prhs[1980])==1) ) { 
      mexErrMsgTxt("Input 1980 must be a noncomplex scalar double.");
    } 
    mexinput1980_temp = mxGetPr(prhs[1980]); 
    double mexinput1980 = *mexinput1980_temp; 

    double *mexinput1981_temp = NULL; 
    if( !mxIsDouble(prhs[1981]) || mxIsComplex(prhs[1981]) || !(mxGetM(prhs[1981])==1 && mxGetN(prhs[1981])==1) ) { 
      mexErrMsgTxt("Input 1981 must be a noncomplex scalar double.");
    } 
    mexinput1981_temp = mxGetPr(prhs[1981]); 
    double mexinput1981 = *mexinput1981_temp; 

    double *mexinput1982_temp = NULL; 
    if( !mxIsDouble(prhs[1982]) || mxIsComplex(prhs[1982]) || !(mxGetM(prhs[1982])==1 && mxGetN(prhs[1982])==1) ) { 
      mexErrMsgTxt("Input 1982 must be a noncomplex scalar double.");
    } 
    mexinput1982_temp = mxGetPr(prhs[1982]); 
    double mexinput1982 = *mexinput1982_temp; 

    double *mexinput1983_temp = NULL; 
    if( !mxIsDouble(prhs[1983]) || mxIsComplex(prhs[1983]) || !(mxGetM(prhs[1983])==1 && mxGetN(prhs[1983])==1) ) { 
      mexErrMsgTxt("Input 1983 must be a noncomplex scalar double.");
    } 
    mexinput1983_temp = mxGetPr(prhs[1983]); 
    double mexinput1983 = *mexinput1983_temp; 

    double *mexinput1984_temp = NULL; 
    if( !mxIsDouble(prhs[1984]) || mxIsComplex(prhs[1984]) || !(mxGetM(prhs[1984])==1 && mxGetN(prhs[1984])==1) ) { 
      mexErrMsgTxt("Input 1984 must be a noncomplex scalar double.");
    } 
    mexinput1984_temp = mxGetPr(prhs[1984]); 
    double mexinput1984 = *mexinput1984_temp; 

    double *mexinput1985_temp = NULL; 
    if( !mxIsDouble(prhs[1985]) || mxIsComplex(prhs[1985]) || !(mxGetM(prhs[1985])==1 && mxGetN(prhs[1985])==1) ) { 
      mexErrMsgTxt("Input 1985 must be a noncomplex scalar double.");
    } 
    mexinput1985_temp = mxGetPr(prhs[1985]); 
    double mexinput1985 = *mexinput1985_temp; 

    double *mexinput1986_temp = NULL; 
    if( !mxIsDouble(prhs[1986]) || mxIsComplex(prhs[1986]) || !(mxGetM(prhs[1986])==1 && mxGetN(prhs[1986])==1) ) { 
      mexErrMsgTxt("Input 1986 must be a noncomplex scalar double.");
    } 
    mexinput1986_temp = mxGetPr(prhs[1986]); 
    double mexinput1986 = *mexinput1986_temp; 

    double *mexinput1987_temp = NULL; 
    if( !mxIsDouble(prhs[1987]) || mxIsComplex(prhs[1987]) || !(mxGetM(prhs[1987])==1 && mxGetN(prhs[1987])==1) ) { 
      mexErrMsgTxt("Input 1987 must be a noncomplex scalar double.");
    } 
    mexinput1987_temp = mxGetPr(prhs[1987]); 
    double mexinput1987 = *mexinput1987_temp; 

    double *mexinput1988_temp = NULL; 
    if( !mxIsDouble(prhs[1988]) || mxIsComplex(prhs[1988]) || !(mxGetM(prhs[1988])==1 && mxGetN(prhs[1988])==1) ) { 
      mexErrMsgTxt("Input 1988 must be a noncomplex scalar double.");
    } 
    mexinput1988_temp = mxGetPr(prhs[1988]); 
    double mexinput1988 = *mexinput1988_temp; 

    double *mexinput1989_temp = NULL; 
    if( !mxIsDouble(prhs[1989]) || mxIsComplex(prhs[1989]) || !(mxGetM(prhs[1989])==1 && mxGetN(prhs[1989])==1) ) { 
      mexErrMsgTxt("Input 1989 must be a noncomplex scalar double.");
    } 
    mexinput1989_temp = mxGetPr(prhs[1989]); 
    double mexinput1989 = *mexinput1989_temp; 

    double *mexinput1990_temp = NULL; 
    if( !mxIsDouble(prhs[1990]) || mxIsComplex(prhs[1990]) || !(mxGetM(prhs[1990])==1 && mxGetN(prhs[1990])==1) ) { 
      mexErrMsgTxt("Input 1990 must be a noncomplex scalar double.");
    } 
    mexinput1990_temp = mxGetPr(prhs[1990]); 
    double mexinput1990 = *mexinput1990_temp; 

    double *mexinput1991_temp = NULL; 
    if( !mxIsDouble(prhs[1991]) || mxIsComplex(prhs[1991]) || !(mxGetM(prhs[1991])==1 && mxGetN(prhs[1991])==1) ) { 
      mexErrMsgTxt("Input 1991 must be a noncomplex scalar double.");
    } 
    mexinput1991_temp = mxGetPr(prhs[1991]); 
    double mexinput1991 = *mexinput1991_temp; 

    double *mexinput1992_temp = NULL; 
    if( !mxIsDouble(prhs[1992]) || mxIsComplex(prhs[1992]) || !(mxGetM(prhs[1992])==1 && mxGetN(prhs[1992])==1) ) { 
      mexErrMsgTxt("Input 1992 must be a noncomplex scalar double.");
    } 
    mexinput1992_temp = mxGetPr(prhs[1992]); 
    double mexinput1992 = *mexinput1992_temp; 

    double *mexinput1993_temp = NULL; 
    if( !mxIsDouble(prhs[1993]) || mxIsComplex(prhs[1993]) || !(mxGetM(prhs[1993])==1 && mxGetN(prhs[1993])==1) ) { 
      mexErrMsgTxt("Input 1993 must be a noncomplex scalar double.");
    } 
    mexinput1993_temp = mxGetPr(prhs[1993]); 
    double mexinput1993 = *mexinput1993_temp; 

    double *mexinput1994_temp = NULL; 
    if( !mxIsDouble(prhs[1994]) || mxIsComplex(prhs[1994]) || !(mxGetM(prhs[1994])==1 && mxGetN(prhs[1994])==1) ) { 
      mexErrMsgTxt("Input 1994 must be a noncomplex scalar double.");
    } 
    mexinput1994_temp = mxGetPr(prhs[1994]); 
    double mexinput1994 = *mexinput1994_temp; 

    double *mexinput1995_temp = NULL; 
    if( !mxIsDouble(prhs[1995]) || mxIsComplex(prhs[1995]) || !(mxGetM(prhs[1995])==1 && mxGetN(prhs[1995])==1) ) { 
      mexErrMsgTxt("Input 1995 must be a noncomplex scalar double.");
    } 
    mexinput1995_temp = mxGetPr(prhs[1995]); 
    double mexinput1995 = *mexinput1995_temp; 

    double *mexinput1996_temp = NULL; 
    if( !mxIsDouble(prhs[1996]) || mxIsComplex(prhs[1996]) || !(mxGetM(prhs[1996])==1 && mxGetN(prhs[1996])==1) ) { 
      mexErrMsgTxt("Input 1996 must be a noncomplex scalar double.");
    } 
    mexinput1996_temp = mxGetPr(prhs[1996]); 
    double mexinput1996 = *mexinput1996_temp; 

    double *mexinput1997_temp = NULL; 
    if( !mxIsDouble(prhs[1997]) || mxIsComplex(prhs[1997]) || !(mxGetM(prhs[1997])==1 && mxGetN(prhs[1997])==1) ) { 
      mexErrMsgTxt("Input 1997 must be a noncomplex scalar double.");
    } 
    mexinput1997_temp = mxGetPr(prhs[1997]); 
    double mexinput1997 = *mexinput1997_temp; 

    double *mexinput1998_temp = NULL; 
    if( !mxIsDouble(prhs[1998]) || mxIsComplex(prhs[1998]) || !(mxGetM(prhs[1998])==1 && mxGetN(prhs[1998])==1) ) { 
      mexErrMsgTxt("Input 1998 must be a noncomplex scalar double.");
    } 
    mexinput1998_temp = mxGetPr(prhs[1998]); 
    double mexinput1998 = *mexinput1998_temp; 

    double *mexinput1999_temp = NULL; 
    if( !mxIsDouble(prhs[1999]) || mxIsComplex(prhs[1999]) || !(mxGetM(prhs[1999])==1 && mxGetN(prhs[1999])==1) ) { 
      mexErrMsgTxt("Input 1999 must be a noncomplex scalar double.");
    } 
    mexinput1999_temp = mxGetPr(prhs[1999]); 
    double mexinput1999 = *mexinput1999_temp; 

    double *mexinput2000_temp = NULL; 
    if( !mxIsDouble(prhs[2000]) || mxIsComplex(prhs[2000]) || !(mxGetM(prhs[2000])==1 && mxGetN(prhs[2000])==1) ) { 
      mexErrMsgTxt("Input 2000 must be a noncomplex scalar double.");
    } 
    mexinput2000_temp = mxGetPr(prhs[2000]); 
    double mexinput2000 = *mexinput2000_temp; 

    double *mexinput2001_temp = NULL; 
    if( !mxIsDouble(prhs[2001]) || mxIsComplex(prhs[2001]) || !(mxGetM(prhs[2001])==1 && mxGetN(prhs[2001])==1) ) { 
      mexErrMsgTxt("Input 2001 must be a noncomplex scalar double.");
    } 
    mexinput2001_temp = mxGetPr(prhs[2001]); 
    double mexinput2001 = *mexinput2001_temp; 

    double *mexinput2002_temp = NULL; 
    if( !mxIsDouble(prhs[2002]) || mxIsComplex(prhs[2002]) || !(mxGetM(prhs[2002])==1 && mxGetN(prhs[2002])==1) ) { 
      mexErrMsgTxt("Input 2002 must be a noncomplex scalar double.");
    } 
    mexinput2002_temp = mxGetPr(prhs[2002]); 
    double mexinput2002 = *mexinput2002_temp; 

    double *mexinput2003_temp = NULL; 
    if( !mxIsDouble(prhs[2003]) || mxIsComplex(prhs[2003]) || !(mxGetM(prhs[2003])==1 && mxGetN(prhs[2003])==1) ) { 
      mexErrMsgTxt("Input 2003 must be a noncomplex scalar double.");
    } 
    mexinput2003_temp = mxGetPr(prhs[2003]); 
    double mexinput2003 = *mexinput2003_temp; 

    double *mexinput2004_temp = NULL; 
    if( !mxIsDouble(prhs[2004]) || mxIsComplex(prhs[2004]) || !(mxGetM(prhs[2004])==1 && mxGetN(prhs[2004])==1) ) { 
      mexErrMsgTxt("Input 2004 must be a noncomplex scalar double.");
    } 
    mexinput2004_temp = mxGetPr(prhs[2004]); 
    double mexinput2004 = *mexinput2004_temp; 

    double *mexinput2005_temp = NULL; 
    if( !mxIsDouble(prhs[2005]) || mxIsComplex(prhs[2005]) || !(mxGetM(prhs[2005])==1 && mxGetN(prhs[2005])==1) ) { 
      mexErrMsgTxt("Input 2005 must be a noncomplex scalar double.");
    } 
    mexinput2005_temp = mxGetPr(prhs[2005]); 
    double mexinput2005 = *mexinput2005_temp; 

    double *mexinput2006_temp = NULL; 
    if( !mxIsDouble(prhs[2006]) || mxIsComplex(prhs[2006]) || !(mxGetM(prhs[2006])==1 && mxGetN(prhs[2006])==1) ) { 
      mexErrMsgTxt("Input 2006 must be a noncomplex scalar double.");
    } 
    mexinput2006_temp = mxGetPr(prhs[2006]); 
    double mexinput2006 = *mexinput2006_temp; 

    double *mexinput2007_temp = NULL; 
    if( !mxIsDouble(prhs[2007]) || mxIsComplex(prhs[2007]) || !(mxGetM(prhs[2007])==1 && mxGetN(prhs[2007])==1) ) { 
      mexErrMsgTxt("Input 2007 must be a noncomplex scalar double.");
    } 
    mexinput2007_temp = mxGetPr(prhs[2007]); 
    double mexinput2007 = *mexinput2007_temp; 

    double *mexinput2008_temp = NULL; 
    if( !mxIsDouble(prhs[2008]) || mxIsComplex(prhs[2008]) || !(mxGetM(prhs[2008])==1 && mxGetN(prhs[2008])==1) ) { 
      mexErrMsgTxt("Input 2008 must be a noncomplex scalar double.");
    } 
    mexinput2008_temp = mxGetPr(prhs[2008]); 
    double mexinput2008 = *mexinput2008_temp; 

    double *mexinput2009_temp = NULL; 
    if( !mxIsDouble(prhs[2009]) || mxIsComplex(prhs[2009]) || !(mxGetM(prhs[2009])==1 && mxGetN(prhs[2009])==1) ) { 
      mexErrMsgTxt("Input 2009 must be a noncomplex scalar double.");
    } 
    mexinput2009_temp = mxGetPr(prhs[2009]); 
    double mexinput2009 = *mexinput2009_temp; 

    double *mexinput2010_temp = NULL; 
    if( !mxIsDouble(prhs[2010]) || mxIsComplex(prhs[2010]) || !(mxGetM(prhs[2010])==1 && mxGetN(prhs[2010])==1) ) { 
      mexErrMsgTxt("Input 2010 must be a noncomplex scalar double.");
    } 
    mexinput2010_temp = mxGetPr(prhs[2010]); 
    double mexinput2010 = *mexinput2010_temp; 

    double *mexinput2011_temp = NULL; 
    if( !mxIsDouble(prhs[2011]) || mxIsComplex(prhs[2011]) || !(mxGetM(prhs[2011])==1 && mxGetN(prhs[2011])==1) ) { 
      mexErrMsgTxt("Input 2011 must be a noncomplex scalar double.");
    } 
    mexinput2011_temp = mxGetPr(prhs[2011]); 
    double mexinput2011 = *mexinput2011_temp; 

    double *mexinput2012_temp = NULL; 
    if( !mxIsDouble(prhs[2012]) || mxIsComplex(prhs[2012]) || !(mxGetM(prhs[2012])==1 && mxGetN(prhs[2012])==1) ) { 
      mexErrMsgTxt("Input 2012 must be a noncomplex scalar double.");
    } 
    mexinput2012_temp = mxGetPr(prhs[2012]); 
    double mexinput2012 = *mexinput2012_temp; 

    double *mexinput2013_temp = NULL; 
    if( !mxIsDouble(prhs[2013]) || mxIsComplex(prhs[2013]) || !(mxGetM(prhs[2013])==1 && mxGetN(prhs[2013])==1) ) { 
      mexErrMsgTxt("Input 2013 must be a noncomplex scalar double.");
    } 
    mexinput2013_temp = mxGetPr(prhs[2013]); 
    double mexinput2013 = *mexinput2013_temp; 

    double *mexinput2014_temp = NULL; 
    if( !mxIsDouble(prhs[2014]) || mxIsComplex(prhs[2014]) || !(mxGetM(prhs[2014])==1 && mxGetN(prhs[2014])==1) ) { 
      mexErrMsgTxt("Input 2014 must be a noncomplex scalar double.");
    } 
    mexinput2014_temp = mxGetPr(prhs[2014]); 
    double mexinput2014 = *mexinput2014_temp; 

    DifferentialEquation acadodata_f1;
    acadodata_f1 << dot(x1) == (u1-x1);
    acadodata_f1 << dot(x2) == (u2-x2);
    acadodata_f1 << dot(x3) == (u3-x3);
    acadodata_f1 << dot(x4) == (u4-x4);
    acadodata_f1 << dot(x5) == (u5-x5);
    acadodata_f1 << dot(x6) == ((1/1.44115188075855872000e+17*8.52729567844839100000e+15*sin((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x12))+1/2.88230376151711744000e+17*5.58590468982017300000e+15*cos((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x12))+2.00896572177743100000e+15/9.00719925474099200000e+15*sin((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x17))+3.89327180586924700000e+15/7.20575940379279360000e+16*cos((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x17))-4.46400452526453037083e-02)*4.71238898038468931873e+01-(1/2.50000000000000000000e+01*x6+x1)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x7) == ((1/1.44115188075855872000e+17*6.77197268768446700000e+15*cos((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x13))-1/1.44115188075855872000e+17*8.52729567844839100000e+15*sin((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x12))+1/1.80143985094819840000e+16*3.13234361282872700000e+15*sin((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x17))+1/2.25179981368524800000e+15*3.97037343148983000000e+14*sin((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x16))+1/2.88230376151711744000e+17*5.58590468982017300000e+15*cos((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x12))+1/3.60287970189639680000e+16*7.13262094584429700000e+15*sin((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x13))-2.04035713500249765717e-01+4.10367998045999500000e+15/7.20575940379279360000e+16*cos((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x17))+4.18726678954399300000e+15/7.20575940379279360000e+16*cos((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x16)))*4.71238898038468931873e+01-(1/2.50000000000000000000e+01*x7+x2)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x8) == ((1/1.44115188075855872000e+17*6.77197268768446700000e+15*cos((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x13))+1/3.60287970189639680000e+16*6.16200515415340700000e+15*sin((1/1.00000000000000000000e+02*x13-1/1.00000000000000000000e+02*x16))-1/3.60287970189639680000e+16*7.13262094584429700000e+15*sin((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x13))+4.82857937648155100000e+15/7.20575940379279360000e+16*cos((1/1.00000000000000000000e+02*x13-1/1.00000000000000000000e+02*x16))-6.22712567296050123478e-02)*4.71238898038468931873e+01-(1/2.50000000000000000000e+01*x8+x3)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x9) == ((1.17336784691510900000e+15/9.00719925474099200000e+15*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x23))-1.24542513459210024696e-01+1/1.38549460216053760000e+16*3.49172349636498700000e+15*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x17))+1/3.60287970189639680000e+16*7.16612772707193300000e+15*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x21))+1/7.20575940379279360000e+16*8.85659888320172300000e+15*cos((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x22))+2.30413164135529300000e+15/9.00719925474099200000e+15*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x22))+4.76660984560893300000e+15/7.20575940379279360000e+16*cos((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x23))+6.84403028172239500000e+15/7.20575940379279360000e+16*cos((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x21)))*4.71238898038468931873e+01-(1/2.50000000000000000000e+01*x9+x4)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x10) == (-(1/2.50000000000000000000e+01*x10+x5)*4.71238898038468931873e+01+(1/3.09886357172387840000e+16*5.45864818159161300000e+15*sin((1/1.00000000000000000000e+02*x15-1/1.00000000000000000000e+02*x18))-3.11356283648025061739e-02)*4.71238898038468931873e+01);
    acadodata_f1 << dot(x11) == 1.00000000000000000000e+02*x6;
    acadodata_f1 << dot(x12) == 1.00000000000000000000e+02*x7;
    acadodata_f1 << dot(x13) == 1.00000000000000000000e+02*x8;
    acadodata_f1 << dot(x14) == 1.00000000000000000000e+02*x9;
    acadodata_f1 << dot(x15) == 1.00000000000000000000e+02*x10;
    acadodata_f1 << dot(x16) == (1.46737471768494100000e+15/2.80676112793600000000e+12*sin((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x18))+1/1.75921860444160000000e+13*2.55570482760253500000e+15*cos((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x16))-1/1.75921860444160000000e+13*7.52197894794117100000e+15*sin((1/1.00000000000000000000e+02*x13-1/1.00000000000000000000e+02*x16))+1/1.86623039897600000000e+12*2.59490005825617900000e+15*sin((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x19))+1/3.51843720888320000000e+13*5.89426193418158100000e+15*cos((1/1.00000000000000000000e+02*x13-1/1.00000000000000000000e+02*x16))+1/7.03687441776640000000e+13*7.40806954330357700000e+15*sin((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x17))+2.67000000000000000000e+02/8.00000000000000000000e+00*cos((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x17))-3.87731780418928700000e+15/8.79609302220800000000e+12*sin((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x16))-8.30943000825552985589e+02);
    acadodata_f1 << dot(x17) == (-1/1.75921860444160000000e+13*7.64732327350763500000e+15*sin((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x17))+1/3.51843720888320000000e+13*4.75252905989898300000e+15*cos((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x17))+1/3.51843720888320000000e+13*5.00937497614745500000e+15*cos((1/1.00000000000000000000e+02*x12-1/1.00000000000000000000e+02*x17))-1/7.03687441776640000000e+13*7.40806954330357700000e+15*sin((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x17))-2.13117889182433300000e+15/3.38255518105600000000e+12*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x17))+2.67000000000000000000e+02/8.00000000000000000000e+00*cos((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x17))-2.80911908360715301569e+02-4.90470146918318100000e+15/8.79609302220800000000e+12*sin((1/1.00000000000000000000e+02*x11-1/1.00000000000000000000e+02*x17)));
    acadodata_f1 << dot(x18) == (1.08288653414891500000e+15/3.93741126860800000000e+12*sin((1/1.00000000000000000000e+02*x18-1/1.00000000000000000000e+02*x19))-1.46737471768494100000e+15/2.80676112793600000000e+12*sin((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x18))-1/1.51311697838080000000e+13*6.66338889354444900000e+15*sin((1/1.00000000000000000000e+02*x15-1/1.00000000000000000000e+02*x18)));
    acadodata_f1 << dot(x19) == (-1.08288653414891500000e+15/3.93741126860800000000e+12*sin((1/1.00000000000000000000e+02*x18-1/1.00000000000000000000e+02*x19))-1/1.86623039897600000000e+12*2.59490005825617900000e+15*sin((1/1.00000000000000000000e+02*x16-1/1.00000000000000000000e+02*x19))+1/4.00000000000000000000e+00*8.45000000000000000000e+02*sin((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x20))+2.79517846013214700000e+15/8.79609302220800000000e+12*cos((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x24))+2.97285953918074900000e+15/4.39804651110400000000e+12*sin((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x24))+5.59607438072872900000e+15/7.03687441776640000000e+13*cos((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x20)));
    acadodata_f1 << dot(x20) == (1.64100000000000000000e+03/8.00000000000000000000e+00*cos((1/1.00000000000000000000e+02*x20-1/1.00000000000000000000e+02*x21))-1/4.00000000000000000000e+00*8.45000000000000000000e+02*sin((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x20))+2.11183198346936300000e+15/4.39804651110400000000e+12*sin((1/1.00000000000000000000e+02*x20-1/1.00000000000000000000e+02*x21))+5.59607438072872900000e+15/7.03687441776640000000e+13*cos((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x20)));
    acadodata_f1 << dot(x21) == (1.64100000000000000000e+03/8.00000000000000000000e+00*cos((1/1.00000000000000000000e+02*x20-1/1.00000000000000000000e+02*x21))-1.98900000000000000000e+03/4.00000000000000000000e+00*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x21))+1/1.75921860444160000000e+13*4.17726457624657900000e+15*cos((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x21))-2.11183198346936300000e+15/4.39804651110400000000e+12*sin((1/1.00000000000000000000e+02*x20-1/1.00000000000000000000e+02*x21))-4.67258290935283810086e+02);
    acadodata_f1 << dot(x22) == (1/1.75921860444160000000e+13*5.40563896679792700000e+15*cos((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x22))+1/1.75921860444160000000e+13*8.79081536639467500000e+15*sin((1/1.00000000000000000000e+02*x22-1/1.00000000000000000000e+02*x23))-2.81266069501378500000e+15/4.39804651110400000000e+12*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x22))+4.85808217616547900000e+15/8.79609302220800000000e+12*cos((1/1.00000000000000000000e+02*x22-1/1.00000000000000000000e+02*x23))-6.00250687200051970649e+02);
    acadodata_f1 << dot(x23) == (1.32300000000000000000e+03/8.00000000000000000000e+00*cos((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x23))-1.43233379750379500000e+15/4.39804651110400000000e+12*sin((1/1.00000000000000000000e+02*x14-1/1.00000000000000000000e+02*x23))-1/1.75921860444160000000e+13*8.79081536639467500000e+15*sin((1/1.00000000000000000000e+02*x22-1/1.00000000000000000000e+02*x23))+3.75879045071503300000e+15/8.79609302220800000000e+12*cos((1/1.00000000000000000000e+02*x23-1/1.00000000000000000000e+02*x24))-4.83500114324542664690e+02+4.85808217616547900000e+15/8.79609302220800000000e+12*cos((1/1.00000000000000000000e+02*x22-1/1.00000000000000000000e+02*x23))+7.65304073397206900000e+15/8.79609302220800000000e+12*sin((1/1.00000000000000000000e+02*x23-1/1.00000000000000000000e+02*x24)));
    acadodata_f1 << dot(x24) == (2.79517846013214700000e+15/8.79609302220800000000e+12*cos((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x24))-2.97285953918074900000e+15/4.39804651110400000000e+12*sin((1/1.00000000000000000000e+02*x19-1/1.00000000000000000000e+02*x24))-3.22333409549695147689e+02+3.75879045071503300000e+15/8.79609302220800000000e+12*cos((1/1.00000000000000000000e+02*x23-1/1.00000000000000000000e+02*x24))-7.65304073397206900000e+15/8.79609302220800000000e+12*sin((1/1.00000000000000000000e+02*x23-1/1.00000000000000000000e+02*x24)));
    acadodata_f1 << dot(x25) == (1/1.00000000000000000000e+04*pow(x11,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x12,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x13,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x14,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x15,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x16,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x17,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x18,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x19,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x20,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x21,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x22,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x23,2.00000000000000000000e+00)+1/1.00000000000000000000e+04*pow(x24,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x1,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x2,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x3,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x4,2.00000000000000000000e+00)+1/2.00000000000000000000e+00*pow(x5,2.00000000000000000000e+00)+2.00000000000000000000e+02*pow(x10,2.00000000000000000000e+00)+2.00000000000000000000e+02*pow(x6,2.00000000000000000000e+00)+2.00000000000000000000e+02*pow(x7,2.00000000000000000000e+00)+2.00000000000000000000e+02*pow(x8,2.00000000000000000000e+00)+2.00000000000000000000e+02*pow(x9,2.00000000000000000000e+00));
    acadodata_f1 << dot(inputcost) == ((mexinput675*u1+mexinput680*u2+mexinput685*u3+mexinput690*u4+mexinput695*u5)*u1+(mexinput676*u1+mexinput681*u2+mexinput686*u3+mexinput691*u4+mexinput696*u5)*u2+(mexinput677*u1+mexinput682*u2+mexinput687*u3+mexinput692*u4+mexinput697*u5)*u3+(mexinput678*u1+mexinput683*u2+mexinput688*u3+mexinput693*u4+mexinput698*u5)*u4+(mexinput679*u1+mexinput684*u2+mexinput689*u3+mexinput694*u4+mexinput699*u5)*u5);

    OCP ocp1(0, mexinput701, mexinput700);
    ocp1.minimizeMayerTerm((((-mexinput25+x1)*mexinput300+(-mexinput26+x2)*mexinput550+(-mexinput27+x3)*mexinput110+(-mexinput28+x4)*mexinput135+(-mexinput29+x5)*mexinput160+(-mexinput30+x6)*mexinput185+(-mexinput31+x7)*mexinput210+(-mexinput32+x8)*mexinput235+(-mexinput33+x9)*mexinput260+(-mexinput34+x10)*mexinput285+(-mexinput35+x11)*mexinput310+(-mexinput36+x12)*mexinput335+(-mexinput37+x13)*mexinput360+(-mexinput38+x14)*mexinput385+(-mexinput39+x15)*mexinput410+(-mexinput40+x16)*mexinput435+(-mexinput41+x17)*mexinput460+(-mexinput42+x18)*mexinput485+(-mexinput43+x19)*mexinput510+(-mexinput44+x20)*mexinput535+(-mexinput45+x21)*mexinput560+(-mexinput46+x22)*mexinput585+(-mexinput47+x23)*mexinput610+(-mexinput48+x24)*mexinput635+(-mexinput49+x25)*mexinput660)*(-mexinput35+x11)+((-mexinput25+x1)*mexinput301+(-mexinput26+x2)*mexinput551+(-mexinput27+x3)*mexinput111+(-mexinput28+x4)*mexinput136+(-mexinput29+x5)*mexinput161+(-mexinput30+x6)*mexinput186+(-mexinput31+x7)*mexinput211+(-mexinput32+x8)*mexinput236+(-mexinput33+x9)*mexinput261+(-mexinput34+x10)*mexinput286+(-mexinput35+x11)*mexinput311+(-mexinput36+x12)*mexinput336+(-mexinput37+x13)*mexinput361+(-mexinput38+x14)*mexinput386+(-mexinput39+x15)*mexinput411+(-mexinput40+x16)*mexinput436+(-mexinput41+x17)*mexinput461+(-mexinput42+x18)*mexinput486+(-mexinput43+x19)*mexinput511+(-mexinput44+x20)*mexinput536+(-mexinput45+x21)*mexinput561+(-mexinput46+x22)*mexinput586+(-mexinput47+x23)*mexinput611+(-mexinput48+x24)*mexinput636+(-mexinput49+x25)*mexinput661)*(-mexinput36+x12)+((-mexinput25+x1)*mexinput302+(-mexinput26+x2)*mexinput552+(-mexinput27+x3)*mexinput112+(-mexinput28+x4)*mexinput137+(-mexinput29+x5)*mexinput162+(-mexinput30+x6)*mexinput187+(-mexinput31+x7)*mexinput212+(-mexinput32+x8)*mexinput237+(-mexinput33+x9)*mexinput262+(-mexinput34+x10)*mexinput287+(-mexinput35+x11)*mexinput312+(-mexinput36+x12)*mexinput337+(-mexinput37+x13)*mexinput362+(-mexinput38+x14)*mexinput387+(-mexinput39+x15)*mexinput412+(-mexinput40+x16)*mexinput437+(-mexinput41+x17)*mexinput462+(-mexinput42+x18)*mexinput487+(-mexinput43+x19)*mexinput512+(-mexinput44+x20)*mexinput537+(-mexinput45+x21)*mexinput562+(-mexinput46+x22)*mexinput587+(-mexinput47+x23)*mexinput612+(-mexinput48+x24)*mexinput637+(-mexinput49+x25)*mexinput662)*(-mexinput37+x13)+((-mexinput25+x1)*mexinput303+(-mexinput26+x2)*mexinput553+(-mexinput27+x3)*mexinput113+(-mexinput28+x4)*mexinput138+(-mexinput29+x5)*mexinput163+(-mexinput30+x6)*mexinput188+(-mexinput31+x7)*mexinput213+(-mexinput32+x8)*mexinput238+(-mexinput33+x9)*mexinput263+(-mexinput34+x10)*mexinput288+(-mexinput35+x11)*mexinput313+(-mexinput36+x12)*mexinput338+(-mexinput37+x13)*mexinput363+(-mexinput38+x14)*mexinput388+(-mexinput39+x15)*mexinput413+(-mexinput40+x16)*mexinput438+(-mexinput41+x17)*mexinput463+(-mexinput42+x18)*mexinput488+(-mexinput43+x19)*mexinput513+(-mexinput44+x20)*mexinput538+(-mexinput45+x21)*mexinput563+(-mexinput46+x22)*mexinput588+(-mexinput47+x23)*mexinput613+(-mexinput48+x24)*mexinput638+(-mexinput49+x25)*mexinput663)*(-mexinput38+x14)+((-mexinput25+x1)*mexinput304+(-mexinput26+x2)*mexinput554+(-mexinput27+x3)*mexinput114+(-mexinput28+x4)*mexinput139+(-mexinput29+x5)*mexinput164+(-mexinput30+x6)*mexinput189+(-mexinput31+x7)*mexinput214+(-mexinput32+x8)*mexinput239+(-mexinput33+x9)*mexinput264+(-mexinput34+x10)*mexinput289+(-mexinput35+x11)*mexinput314+(-mexinput36+x12)*mexinput339+(-mexinput37+x13)*mexinput364+(-mexinput38+x14)*mexinput389+(-mexinput39+x15)*mexinput414+(-mexinput40+x16)*mexinput439+(-mexinput41+x17)*mexinput464+(-mexinput42+x18)*mexinput489+(-mexinput43+x19)*mexinput514+(-mexinput44+x20)*mexinput539+(-mexinput45+x21)*mexinput564+(-mexinput46+x22)*mexinput589+(-mexinput47+x23)*mexinput614+(-mexinput48+x24)*mexinput639+(-mexinput49+x25)*mexinput664)*(-mexinput39+x15)+((-mexinput25+x1)*mexinput305+(-mexinput26+x2)*mexinput555+(-mexinput27+x3)*mexinput115+(-mexinput28+x4)*mexinput140+(-mexinput29+x5)*mexinput165+(-mexinput30+x6)*mexinput190+(-mexinput31+x7)*mexinput215+(-mexinput32+x8)*mexinput240+(-mexinput33+x9)*mexinput265+(-mexinput34+x10)*mexinput290+(-mexinput35+x11)*mexinput315+(-mexinput36+x12)*mexinput340+(-mexinput37+x13)*mexinput365+(-mexinput38+x14)*mexinput390+(-mexinput39+x15)*mexinput415+(-mexinput40+x16)*mexinput440+(-mexinput41+x17)*mexinput465+(-mexinput42+x18)*mexinput490+(-mexinput43+x19)*mexinput515+(-mexinput44+x20)*mexinput540+(-mexinput45+x21)*mexinput565+(-mexinput46+x22)*mexinput590+(-mexinput47+x23)*mexinput615+(-mexinput48+x24)*mexinput640+(-mexinput49+x25)*mexinput665)*(-mexinput40+x16)+((-mexinput25+x1)*mexinput306+(-mexinput26+x2)*mexinput556+(-mexinput27+x3)*mexinput116+(-mexinput28+x4)*mexinput141+(-mexinput29+x5)*mexinput166+(-mexinput30+x6)*mexinput191+(-mexinput31+x7)*mexinput216+(-mexinput32+x8)*mexinput241+(-mexinput33+x9)*mexinput266+(-mexinput34+x10)*mexinput291+(-mexinput35+x11)*mexinput316+(-mexinput36+x12)*mexinput341+(-mexinput37+x13)*mexinput366+(-mexinput38+x14)*mexinput391+(-mexinput39+x15)*mexinput416+(-mexinput40+x16)*mexinput441+(-mexinput41+x17)*mexinput466+(-mexinput42+x18)*mexinput491+(-mexinput43+x19)*mexinput516+(-mexinput44+x20)*mexinput541+(-mexinput45+x21)*mexinput566+(-mexinput46+x22)*mexinput591+(-mexinput47+x23)*mexinput616+(-mexinput48+x24)*mexinput641+(-mexinput49+x25)*mexinput666)*(-mexinput41+x17)+((-mexinput25+x1)*mexinput307+(-mexinput26+x2)*mexinput557+(-mexinput27+x3)*mexinput117+(-mexinput28+x4)*mexinput142+(-mexinput29+x5)*mexinput167+(-mexinput30+x6)*mexinput192+(-mexinput31+x7)*mexinput217+(-mexinput32+x8)*mexinput242+(-mexinput33+x9)*mexinput267+(-mexinput34+x10)*mexinput292+(-mexinput35+x11)*mexinput317+(-mexinput36+x12)*mexinput342+(-mexinput37+x13)*mexinput367+(-mexinput38+x14)*mexinput392+(-mexinput39+x15)*mexinput417+(-mexinput40+x16)*mexinput442+(-mexinput41+x17)*mexinput467+(-mexinput42+x18)*mexinput492+(-mexinput43+x19)*mexinput517+(-mexinput44+x20)*mexinput542+(-mexinput45+x21)*mexinput567+(-mexinput46+x22)*mexinput592+(-mexinput47+x23)*mexinput617+(-mexinput48+x24)*mexinput642+(-mexinput49+x25)*mexinput667)*(-mexinput42+x18)+((-mexinput25+x1)*mexinput308+(-mexinput26+x2)*mexinput558+(-mexinput27+x3)*mexinput118+(-mexinput28+x4)*mexinput143+(-mexinput29+x5)*mexinput168+(-mexinput30+x6)*mexinput193+(-mexinput31+x7)*mexinput218+(-mexinput32+x8)*mexinput243+(-mexinput33+x9)*mexinput268+(-mexinput34+x10)*mexinput293+(-mexinput35+x11)*mexinput318+(-mexinput36+x12)*mexinput343+(-mexinput37+x13)*mexinput368+(-mexinput38+x14)*mexinput393+(-mexinput39+x15)*mexinput418+(-mexinput40+x16)*mexinput443+(-mexinput41+x17)*mexinput468+(-mexinput42+x18)*mexinput493+(-mexinput43+x19)*mexinput518+(-mexinput44+x20)*mexinput543+(-mexinput45+x21)*mexinput568+(-mexinput46+x22)*mexinput593+(-mexinput47+x23)*mexinput618+(-mexinput48+x24)*mexinput643+(-mexinput49+x25)*mexinput668)*(-mexinput43+x19)+((-mexinput25+x1)*mexinput325+(-mexinput26+x2)*mexinput575+(-mexinput27+x3)*mexinput120+(-mexinput28+x4)*mexinput145+(-mexinput29+x5)*mexinput170+(-mexinput30+x6)*mexinput195+(-mexinput31+x7)*mexinput220+(-mexinput32+x8)*mexinput245+(-mexinput33+x9)*mexinput270+(-mexinput34+x10)*mexinput295+(-mexinput35+x11)*mexinput320+(-mexinput36+x12)*mexinput345+(-mexinput37+x13)*mexinput370+(-mexinput38+x14)*mexinput395+(-mexinput39+x15)*mexinput420+(-mexinput40+x16)*mexinput445+(-mexinput41+x17)*mexinput470+(-mexinput42+x18)*mexinput495+(-mexinput43+x19)*mexinput520+(-mexinput44+x20)*mexinput545+(-mexinput45+x21)*mexinput570+(-mexinput46+x22)*mexinput595+(-mexinput47+x23)*mexinput620+(-mexinput48+x24)*mexinput645+(-mexinput49+x25)*mexinput670)*(-mexinput45+x21)+((-mexinput25+x1)*mexinput326+(-mexinput26+x2)*mexinput576+(-mexinput27+x3)*mexinput121+(-mexinput28+x4)*mexinput146+(-mexinput29+x5)*mexinput171+(-mexinput30+x6)*mexinput196+(-mexinput31+x7)*mexinput221+(-mexinput32+x8)*mexinput246+(-mexinput33+x9)*mexinput271+(-mexinput34+x10)*mexinput296+(-mexinput35+x11)*mexinput321+(-mexinput36+x12)*mexinput346+(-mexinput37+x13)*mexinput371+(-mexinput38+x14)*mexinput396+(-mexinput39+x15)*mexinput421+(-mexinput40+x16)*mexinput446+(-mexinput41+x17)*mexinput471+(-mexinput42+x18)*mexinput496+(-mexinput43+x19)*mexinput521+(-mexinput44+x20)*mexinput546+(-mexinput45+x21)*mexinput571+(-mexinput46+x22)*mexinput596+(-mexinput47+x23)*mexinput621+(-mexinput48+x24)*mexinput646+(-mexinput49+x25)*mexinput671)*(-mexinput46+x22)+((-mexinput25+x1)*mexinput327+(-mexinput26+x2)*mexinput577+(-mexinput27+x3)*mexinput122+(-mexinput28+x4)*mexinput147+(-mexinput29+x5)*mexinput172+(-mexinput30+x6)*mexinput197+(-mexinput31+x7)*mexinput222+(-mexinput32+x8)*mexinput247+(-mexinput33+x9)*mexinput272+(-mexinput34+x10)*mexinput297+(-mexinput35+x11)*mexinput322+(-mexinput36+x12)*mexinput347+(-mexinput37+x13)*mexinput372+(-mexinput38+x14)*mexinput397+(-mexinput39+x15)*mexinput422+(-mexinput40+x16)*mexinput447+(-mexinput41+x17)*mexinput472+(-mexinput42+x18)*mexinput497+(-mexinput43+x19)*mexinput522+(-mexinput44+x20)*mexinput547+(-mexinput45+x21)*mexinput572+(-mexinput46+x22)*mexinput597+(-mexinput47+x23)*mexinput622+(-mexinput48+x24)*mexinput647+(-mexinput49+x25)*mexinput672)*(-mexinput47+x23)+((-mexinput25+x1)*mexinput328+(-mexinput26+x2)*mexinput578+(-mexinput27+x3)*mexinput123+(-mexinput28+x4)*mexinput148+(-mexinput29+x5)*mexinput173+(-mexinput30+x6)*mexinput198+(-mexinput31+x7)*mexinput223+(-mexinput32+x8)*mexinput248+(-mexinput33+x9)*mexinput273+(-mexinput34+x10)*mexinput298+(-mexinput35+x11)*mexinput323+(-mexinput36+x12)*mexinput348+(-mexinput37+x13)*mexinput373+(-mexinput38+x14)*mexinput398+(-mexinput39+x15)*mexinput423+(-mexinput40+x16)*mexinput448+(-mexinput41+x17)*mexinput473+(-mexinput42+x18)*mexinput498+(-mexinput43+x19)*mexinput523+(-mexinput44+x20)*mexinput548+(-mexinput45+x21)*mexinput573+(-mexinput46+x22)*mexinput598+(-mexinput47+x23)*mexinput623+(-mexinput48+x24)*mexinput648+(-mexinput49+x25)*mexinput673)*(-mexinput48+x24)+((-mexinput25+x1)*mexinput329+(-mexinput26+x2)*mexinput579+(-mexinput27+x3)*mexinput124+(-mexinput28+x4)*mexinput149+(-mexinput29+x5)*mexinput174+(-mexinput30+x6)*mexinput199+(-mexinput31+x7)*mexinput224+(-mexinput32+x8)*mexinput249+(-mexinput33+x9)*mexinput274+(-mexinput34+x10)*mexinput299+(-mexinput35+x11)*mexinput324+(-mexinput36+x12)*mexinput349+(-mexinput37+x13)*mexinput374+(-mexinput38+x14)*mexinput399+(-mexinput39+x15)*mexinput424+(-mexinput40+x16)*mexinput449+(-mexinput41+x17)*mexinput474+(-mexinput42+x18)*mexinput499+(-mexinput43+x19)*mexinput524+(-mexinput44+x20)*mexinput549+(-mexinput45+x21)*mexinput574+(-mexinput46+x22)*mexinput599+(-mexinput47+x23)*mexinput624+(-mexinput48+x24)*mexinput649+(-mexinput49+x25)*mexinput674)*(-mexinput49+x25)+((-mexinput25+x1)*mexinput50+(-mexinput26+x2)*mexinput75+(-mexinput27+x3)*mexinput100+(-mexinput28+x4)*mexinput125+(-mexinput29+x5)*mexinput150+(-mexinput30+x6)*mexinput175+(-mexinput31+x7)*mexinput200+(-mexinput32+x8)*mexinput225+(-mexinput33+x9)*mexinput250+(-mexinput34+x10)*mexinput275+(-mexinput35+x11)*mexinput300+(-mexinput36+x12)*mexinput325+(-mexinput37+x13)*mexinput350+(-mexinput38+x14)*mexinput375+(-mexinput39+x15)*mexinput400+(-mexinput40+x16)*mexinput425+(-mexinput41+x17)*mexinput450+(-mexinput42+x18)*mexinput475+(-mexinput43+x19)*mexinput500+(-mexinput44+x20)*mexinput525+(-mexinput45+x21)*mexinput550+(-mexinput46+x22)*mexinput575+(-mexinput47+x23)*mexinput600+(-mexinput48+x24)*mexinput625+(-mexinput49+x25)*mexinput650)*(-mexinput25+x1)+((-mexinput25+x1)*mexinput51+(-mexinput26+x2)*mexinput76+(-mexinput27+x3)*mexinput101+(-mexinput28+x4)*mexinput126+(-mexinput29+x5)*mexinput151+(-mexinput30+x6)*mexinput176+(-mexinput31+x7)*mexinput201+(-mexinput32+x8)*mexinput226+(-mexinput33+x9)*mexinput251+(-mexinput34+x10)*mexinput276+(-mexinput35+x11)*mexinput301+(-mexinput36+x12)*mexinput326+(-mexinput37+x13)*mexinput351+(-mexinput38+x14)*mexinput376+(-mexinput39+x15)*mexinput401+(-mexinput40+x16)*mexinput426+(-mexinput41+x17)*mexinput451+(-mexinput42+x18)*mexinput476+(-mexinput43+x19)*mexinput501+(-mexinput44+x20)*mexinput526+(-mexinput45+x21)*mexinput551+(-mexinput46+x22)*mexinput576+(-mexinput47+x23)*mexinput601+(-mexinput48+x24)*mexinput626+(-mexinput49+x25)*mexinput651)*(-mexinput26+x2)+((-mexinput25+x1)*mexinput52+(-mexinput26+x2)*mexinput77+(-mexinput27+x3)*mexinput102+(-mexinput28+x4)*mexinput127+(-mexinput29+x5)*mexinput152+(-mexinput30+x6)*mexinput177+(-mexinput31+x7)*mexinput202+(-mexinput32+x8)*mexinput227+(-mexinput33+x9)*mexinput252+(-mexinput34+x10)*mexinput277+(-mexinput35+x11)*mexinput302+(-mexinput36+x12)*mexinput327+(-mexinput37+x13)*mexinput352+(-mexinput38+x14)*mexinput377+(-mexinput39+x15)*mexinput402+(-mexinput40+x16)*mexinput427+(-mexinput41+x17)*mexinput452+(-mexinput42+x18)*mexinput477+(-mexinput43+x19)*mexinput502+(-mexinput44+x20)*mexinput527+(-mexinput45+x21)*mexinput552+(-mexinput46+x22)*mexinput577+(-mexinput47+x23)*mexinput602+(-mexinput48+x24)*mexinput627+(-mexinput49+x25)*mexinput652)*(-mexinput27+x3)+((-mexinput25+x1)*mexinput53+(-mexinput26+x2)*mexinput78+(-mexinput27+x3)*mexinput103+(-mexinput28+x4)*mexinput128+(-mexinput29+x5)*mexinput153+(-mexinput30+x6)*mexinput178+(-mexinput31+x7)*mexinput203+(-mexinput32+x8)*mexinput228+(-mexinput33+x9)*mexinput253+(-mexinput34+x10)*mexinput278+(-mexinput35+x11)*mexinput303+(-mexinput36+x12)*mexinput328+(-mexinput37+x13)*mexinput353+(-mexinput38+x14)*mexinput378+(-mexinput39+x15)*mexinput403+(-mexinput40+x16)*mexinput428+(-mexinput41+x17)*mexinput453+(-mexinput42+x18)*mexinput478+(-mexinput43+x19)*mexinput503+(-mexinput44+x20)*mexinput528+(-mexinput45+x21)*mexinput553+(-mexinput46+x22)*mexinput578+(-mexinput47+x23)*mexinput603+(-mexinput48+x24)*mexinput628+(-mexinput49+x25)*mexinput653)*(-mexinput28+x4)+((-mexinput25+x1)*mexinput54+(-mexinput26+x2)*mexinput79+(-mexinput27+x3)*mexinput104+(-mexinput28+x4)*mexinput129+(-mexinput29+x5)*mexinput154+(-mexinput30+x6)*mexinput179+(-mexinput31+x7)*mexinput204+(-mexinput32+x8)*mexinput229+(-mexinput33+x9)*mexinput254+(-mexinput34+x10)*mexinput279+(-mexinput35+x11)*mexinput304+(-mexinput36+x12)*mexinput329+(-mexinput37+x13)*mexinput354+(-mexinput38+x14)*mexinput379+(-mexinput39+x15)*mexinput404+(-mexinput40+x16)*mexinput429+(-mexinput41+x17)*mexinput454+(-mexinput42+x18)*mexinput479+(-mexinput43+x19)*mexinput504+(-mexinput44+x20)*mexinput529+(-mexinput45+x21)*mexinput554+(-mexinput46+x22)*mexinput579+(-mexinput47+x23)*mexinput604+(-mexinput48+x24)*mexinput629+(-mexinput49+x25)*mexinput654)*(-mexinput29+x5)+((-mexinput25+x1)*mexinput55+(-mexinput26+x2)*mexinput80+(-mexinput27+x3)*mexinput105+(-mexinput28+x4)*mexinput130+(-mexinput29+x5)*mexinput155+(-mexinput30+x6)*mexinput180+(-mexinput31+x7)*mexinput205+(-mexinput32+x8)*mexinput230+(-mexinput33+x9)*mexinput255+(-mexinput34+x10)*mexinput280+(-mexinput35+x11)*mexinput305+(-mexinput36+x12)*mexinput330+(-mexinput37+x13)*mexinput355+(-mexinput38+x14)*mexinput380+(-mexinput39+x15)*mexinput405+(-mexinput40+x16)*mexinput430+(-mexinput41+x17)*mexinput455+(-mexinput42+x18)*mexinput480+(-mexinput43+x19)*mexinput505+(-mexinput44+x20)*mexinput530+(-mexinput45+x21)*mexinput555+(-mexinput46+x22)*mexinput580+(-mexinput47+x23)*mexinput605+(-mexinput48+x24)*mexinput630+(-mexinput49+x25)*mexinput655)*(-mexinput30+x6)+((-mexinput25+x1)*mexinput56+(-mexinput26+x2)*mexinput81+(-mexinput27+x3)*mexinput106+(-mexinput28+x4)*mexinput131+(-mexinput29+x5)*mexinput156+(-mexinput30+x6)*mexinput181+(-mexinput31+x7)*mexinput206+(-mexinput32+x8)*mexinput231+(-mexinput33+x9)*mexinput256+(-mexinput34+x10)*mexinput281+(-mexinput35+x11)*mexinput306+(-mexinput36+x12)*mexinput331+(-mexinput37+x13)*mexinput356+(-mexinput38+x14)*mexinput381+(-mexinput39+x15)*mexinput406+(-mexinput40+x16)*mexinput431+(-mexinput41+x17)*mexinput456+(-mexinput42+x18)*mexinput481+(-mexinput43+x19)*mexinput506+(-mexinput44+x20)*mexinput531+(-mexinput45+x21)*mexinput556+(-mexinput46+x22)*mexinput581+(-mexinput47+x23)*mexinput606+(-mexinput48+x24)*mexinput631+(-mexinput49+x25)*mexinput656)*(-mexinput31+x7)+((-mexinput25+x1)*mexinput57+(-mexinput26+x2)*mexinput82+(-mexinput27+x3)*mexinput107+(-mexinput28+x4)*mexinput132+(-mexinput29+x5)*mexinput157+(-mexinput30+x6)*mexinput182+(-mexinput31+x7)*mexinput207+(-mexinput32+x8)*mexinput232+(-mexinput33+x9)*mexinput257+(-mexinput34+x10)*mexinput282+(-mexinput35+x11)*mexinput307+(-mexinput36+x12)*mexinput332+(-mexinput37+x13)*mexinput357+(-mexinput38+x14)*mexinput382+(-mexinput39+x15)*mexinput407+(-mexinput40+x16)*mexinput432+(-mexinput41+x17)*mexinput457+(-mexinput42+x18)*mexinput482+(-mexinput43+x19)*mexinput507+(-mexinput44+x20)*mexinput532+(-mexinput45+x21)*mexinput557+(-mexinput46+x22)*mexinput582+(-mexinput47+x23)*mexinput607+(-mexinput48+x24)*mexinput632+(-mexinput49+x25)*mexinput657)*(-mexinput32+x8)+((-mexinput25+x1)*mexinput58+(-mexinput26+x2)*mexinput83+(-mexinput27+x3)*mexinput108+(-mexinput28+x4)*mexinput133+(-mexinput29+x5)*mexinput158+(-mexinput30+x6)*mexinput183+(-mexinput31+x7)*mexinput208+(-mexinput32+x8)*mexinput233+(-mexinput33+x9)*mexinput258+(-mexinput34+x10)*mexinput283+(-mexinput35+x11)*mexinput308+(-mexinput36+x12)*mexinput333+(-mexinput37+x13)*mexinput358+(-mexinput38+x14)*mexinput383+(-mexinput39+x15)*mexinput408+(-mexinput40+x16)*mexinput433+(-mexinput41+x17)*mexinput458+(-mexinput42+x18)*mexinput483+(-mexinput43+x19)*mexinput508+(-mexinput44+x20)*mexinput533+(-mexinput45+x21)*mexinput558+(-mexinput46+x22)*mexinput583+(-mexinput47+x23)*mexinput608+(-mexinput48+x24)*mexinput633+(-mexinput49+x25)*mexinput658)*(-mexinput33+x9)+((-mexinput25+x1)*mexinput59+(-mexinput26+x2)*mexinput84+(-mexinput27+x3)*mexinput109+(-mexinput28+x4)*mexinput134+(-mexinput29+x5)*mexinput159+(-mexinput30+x6)*mexinput184+(-mexinput31+x7)*mexinput209+(-mexinput32+x8)*mexinput234+(-mexinput33+x9)*mexinput259+(-mexinput34+x10)*mexinput284+(-mexinput35+x11)*mexinput309+(-mexinput36+x12)*mexinput334+(-mexinput37+x13)*mexinput359+(-mexinput38+x14)*mexinput384+(-mexinput39+x15)*mexinput409+(-mexinput40+x16)*mexinput434+(-mexinput41+x17)*mexinput459+(-mexinput42+x18)*mexinput484+(-mexinput43+x19)*mexinput509+(-mexinput44+x20)*mexinput534+(-mexinput45+x21)*mexinput559+(-mexinput46+x22)*mexinput584+(-mexinput47+x23)*mexinput609+(-mexinput48+x24)*mexinput634+(-mexinput49+x25)*mexinput659)*(-mexinput34+x10)+((-mexinput25+x1)*mexinput69+(-mexinput26+x2)*mexinput94+(-mexinput27+x3)*mexinput119+(-mexinput28+x4)*mexinput144+(-mexinput29+x5)*mexinput169+(-mexinput30+x6)*mexinput194+(-mexinput31+x7)*mexinput219+(-mexinput32+x8)*mexinput244+(-mexinput33+x9)*mexinput269+(-mexinput34+x10)*mexinput294+(-mexinput35+x11)*mexinput319+(-mexinput36+x12)*mexinput344+(-mexinput37+x13)*mexinput369+(-mexinput38+x14)*mexinput394+(-mexinput39+x15)*mexinput419+(-mexinput40+x16)*mexinput444+(-mexinput41+x17)*mexinput469+(-mexinput42+x18)*mexinput494+(-mexinput43+x19)*mexinput519+(-mexinput44+x20)*mexinput544+(-mexinput45+x21)*mexinput569+(-mexinput46+x22)*mexinput594+(-mexinput47+x23)*mexinput619+(-mexinput48+x24)*mexinput644+(-mexinput49+x25)*mexinput669)*(-mexinput44+x20)+9.99999999999999954748e-07*ps1+inputcost));
    ocp1.subjectTo(acadodata_f1);
    ocp1.subjectTo(AT_START, x1 == mexinput0);
    ocp1.subjectTo(AT_START, x2 == mexinput1);
    ocp1.subjectTo(AT_START, x3 == mexinput2);
    ocp1.subjectTo(AT_START, x4 == mexinput3);
    ocp1.subjectTo(AT_START, x5 == mexinput4);
    ocp1.subjectTo(AT_START, x6 == mexinput5);
    ocp1.subjectTo(AT_START, x7 == mexinput6);
    ocp1.subjectTo(AT_START, x8 == mexinput7);
    ocp1.subjectTo(AT_START, x9 == mexinput8);
    ocp1.subjectTo(AT_START, x10 == mexinput9);
    ocp1.subjectTo(AT_START, x11 == mexinput10);
    ocp1.subjectTo(AT_START, x12 == mexinput11);
    ocp1.subjectTo(AT_START, x13 == mexinput12);
    ocp1.subjectTo(AT_START, x14 == mexinput13);
    ocp1.subjectTo(AT_START, x15 == mexinput14);
    ocp1.subjectTo(AT_START, x16 == mexinput15);
    ocp1.subjectTo(AT_START, x17 == mexinput16);
    ocp1.subjectTo(AT_START, x18 == mexinput17);
    ocp1.subjectTo(AT_START, x19 == mexinput18);
    ocp1.subjectTo(AT_START, x20 == mexinput19);
    ocp1.subjectTo(AT_START, x21 == mexinput20);
    ocp1.subjectTo(AT_START, x22 == mexinput21);
    ocp1.subjectTo(AT_START, x23 == mexinput22);
    ocp1.subjectTo(AT_START, x24 == mexinput23);
    ocp1.subjectTo(AT_START, x25 == mexinput24);
    ocp1.subjectTo(AT_START, inputcost == 0.00000000000000000000e+00);
    ocp1.subjectTo(mexinput707 <= u1 <= mexinput702);
    ocp1.subjectTo(mexinput708 <= u2 <= mexinput703);
    ocp1.subjectTo(mexinput709 <= u3 <= mexinput704);
    ocp1.subjectTo(mexinput710 <= u4 <= mexinput705);
    ocp1.subjectTo(mexinput711 <= u5 <= mexinput706);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x1 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x1 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x1 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x2 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x2 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x2 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x3 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x3 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x3 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x4 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x4 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x4 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x5 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x5 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(0.00000000000000000000e+00 <= x5 <= 2.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1962*mexinput2012+mexinput712*x1+mexinput713*x2+mexinput714*x3+mexinput715*x4+mexinput716*x5+mexinput717*x6+mexinput718*x7+mexinput719*x8+mexinput720*x9+mexinput721*x10+mexinput731*x20+mexinput962*x11+mexinput963*x12+mexinput964*x13+mexinput965*x14+mexinput966*x15+mexinput967*x16+mexinput968*x17+mexinput969*x18+mexinput970*x19+mexinput987*x21+mexinput988*x22+mexinput989*x23+mexinput990*x24+mexinput991*x25)/mexinput1962/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1212*x11+mexinput1213*x12+mexinput1214*x13+mexinput1215*x14+mexinput1216*x15+mexinput1217*x16+mexinput1218*x17+mexinput1219*x18+mexinput1220*x19+mexinput1237*x21+mexinput1238*x22+mexinput1239*x23+mexinput1240*x24+mexinput1241*x25-mexinput1963*mexinput2012+mexinput737*x1+mexinput738*x2+mexinput739*x3+mexinput740*x4+mexinput741*x5+mexinput742*x6+mexinput743*x7+mexinput744*x8+mexinput745*x9+mexinput746*x10+mexinput756*x20)/mexinput1963/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1462*x11+mexinput1463*x12+mexinput1464*x13+mexinput1465*x14+mexinput1466*x15+mexinput1467*x16+mexinput1468*x17+mexinput1469*x18+mexinput1470*x19+mexinput1487*x21+mexinput1488*x22+mexinput1489*x23+mexinput1490*x24+mexinput1491*x25-mexinput1964*mexinput2012+mexinput762*x1+mexinput763*x2+mexinput764*x3+mexinput765*x4+mexinput766*x5+mexinput767*x6+mexinput768*x7+mexinput769*x8+mexinput770*x9+mexinput771*x10+mexinput781*x20)/mexinput1964/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1712*x11+mexinput1713*x12+mexinput1714*x13+mexinput1715*x14+mexinput1716*x15+mexinput1717*x16+mexinput1718*x17+mexinput1719*x18+mexinput1720*x19+mexinput1737*x21+mexinput1738*x22+mexinput1739*x23+mexinput1740*x24+mexinput1741*x25-mexinput1965*mexinput2012+mexinput787*x1+mexinput788*x2+mexinput789*x3+mexinput790*x4+mexinput791*x5+mexinput792*x6+mexinput793*x7+mexinput794*x8+mexinput795*x9+mexinput796*x10+mexinput806*x20)/mexinput1965/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1966*mexinput2012+mexinput812*x1+mexinput813*x2+mexinput814*x3+mexinput815*x4+mexinput816*x5+mexinput817*x6+mexinput818*x7+mexinput819*x8+mexinput820*x9+mexinput821*x10+mexinput822*x11+mexinput823*x12+mexinput824*x13+mexinput825*x14+mexinput826*x15+mexinput827*x16+mexinput828*x17+mexinput829*x18+mexinput830*x19+mexinput831*x20+mexinput832*x21+mexinput833*x22+mexinput834*x23+mexinput835*x24+mexinput836*x25)/mexinput1966/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1967*mexinput2012+mexinput837*x1+mexinput838*x2+mexinput839*x3+mexinput840*x4+mexinput841*x5+mexinput842*x6+mexinput843*x7+mexinput844*x8+mexinput845*x9+mexinput846*x10+mexinput847*x11+mexinput848*x12+mexinput849*x13+mexinput850*x14+mexinput851*x15+mexinput852*x16+mexinput853*x17+mexinput854*x18+mexinput855*x19+mexinput856*x20+mexinput857*x21+mexinput858*x22+mexinput859*x23+mexinput860*x24+mexinput861*x25)/mexinput1967/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1968*mexinput2012+mexinput862*x1+mexinput863*x2+mexinput864*x3+mexinput865*x4+mexinput866*x5+mexinput867*x6+mexinput868*x7+mexinput869*x8+mexinput870*x9+mexinput871*x10+mexinput872*x11+mexinput873*x12+mexinput874*x13+mexinput875*x14+mexinput876*x15+mexinput877*x16+mexinput878*x17+mexinput879*x18+mexinput880*x19+mexinput881*x20+mexinput882*x21+mexinput883*x22+mexinput884*x23+mexinput885*x24+mexinput886*x25)/mexinput1968/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1969*mexinput2012+mexinput887*x1+mexinput888*x2+mexinput889*x3+mexinput890*x4+mexinput891*x5+mexinput892*x6+mexinput893*x7+mexinput894*x8+mexinput895*x9+mexinput896*x10+mexinput897*x11+mexinput898*x12+mexinput899*x13+mexinput900*x14+mexinput901*x15+mexinput902*x16+mexinput903*x17+mexinput904*x18+mexinput905*x19+mexinput906*x20+mexinput907*x21+mexinput908*x22+mexinput909*x23+mexinput910*x24+mexinput911*x25)/mexinput1969/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1970*mexinput2012+mexinput912*x1+mexinput913*x2+mexinput914*x3+mexinput915*x4+mexinput916*x5+mexinput917*x6+mexinput918*x7+mexinput919*x8+mexinput920*x9+mexinput921*x10+mexinput922*x11+mexinput923*x12+mexinput924*x13+mexinput925*x14+mexinput926*x15+mexinput927*x16+mexinput928*x17+mexinput929*x18+mexinput930*x19+mexinput931*x20+mexinput932*x21+mexinput933*x22+mexinput934*x23+mexinput935*x24+mexinput936*x25)/mexinput1970/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1971*mexinput2012+mexinput937*x1+mexinput938*x2+mexinput939*x3+mexinput940*x4+mexinput941*x5+mexinput942*x6+mexinput943*x7+mexinput944*x8+mexinput945*x9+mexinput946*x10+mexinput947*x11+mexinput948*x12+mexinput949*x13+mexinput950*x14+mexinput951*x15+mexinput952*x16+mexinput953*x17+mexinput954*x18+mexinput955*x19+mexinput956*x20+mexinput957*x21+mexinput958*x22+mexinput959*x23+mexinput960*x24+mexinput961*x25)/mexinput1971/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((-mexinput1972*mexinput2012+mexinput962*x1+mexinput963*x2+mexinput964*x3+mexinput965*x4+mexinput966*x5+mexinput967*x6+mexinput968*x7+mexinput969*x8+mexinput970*x9+mexinput971*x10+mexinput972*x11+mexinput973*x12+mexinput974*x13+mexinput975*x14+mexinput976*x15+mexinput977*x16+mexinput978*x17+mexinput979*x18+mexinput980*x19+mexinput981*x20+mexinput982*x21+mexinput983*x22+mexinput984*x23+mexinput985*x24+mexinput986*x25)/mexinput1972/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1000*x14+mexinput1001*x15+mexinput1002*x16+mexinput1003*x17+mexinput1004*x18+mexinput1005*x19+mexinput1006*x20+mexinput1007*x21+mexinput1008*x22+mexinput1009*x23+mexinput1010*x24+mexinput1011*x25-mexinput1973*mexinput2012+mexinput987*x1+mexinput988*x2+mexinput989*x3+mexinput990*x4+mexinput991*x5+mexinput992*x6+mexinput993*x7+mexinput994*x8+mexinput995*x9+mexinput996*x10+mexinput997*x11+mexinput998*x12+mexinput999*x13)/mexinput1973/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1012*x1+mexinput1013*x2+mexinput1014*x3+mexinput1015*x4+mexinput1016*x5+mexinput1017*x6+mexinput1018*x7+mexinput1019*x8+mexinput1020*x9+mexinput1021*x10+mexinput1022*x11+mexinput1023*x12+mexinput1024*x13+mexinput1025*x14+mexinput1026*x15+mexinput1027*x16+mexinput1028*x17+mexinput1029*x18+mexinput1030*x19+mexinput1031*x20+mexinput1032*x21+mexinput1033*x22+mexinput1034*x23+mexinput1035*x24+mexinput1036*x25-mexinput1974*mexinput2012)/mexinput1974/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1037*x1+mexinput1038*x2+mexinput1039*x3+mexinput1040*x4+mexinput1041*x5+mexinput1042*x6+mexinput1043*x7+mexinput1044*x8+mexinput1045*x9+mexinput1046*x10+mexinput1047*x11+mexinput1048*x12+mexinput1049*x13+mexinput1050*x14+mexinput1051*x15+mexinput1052*x16+mexinput1053*x17+mexinput1054*x18+mexinput1055*x19+mexinput1056*x20+mexinput1057*x21+mexinput1058*x22+mexinput1059*x23+mexinput1060*x24+mexinput1061*x25-mexinput1975*mexinput2012)/mexinput1975/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1062*x1+mexinput1063*x2+mexinput1064*x3+mexinput1065*x4+mexinput1066*x5+mexinput1067*x6+mexinput1068*x7+mexinput1069*x8+mexinput1070*x9+mexinput1071*x10+mexinput1072*x11+mexinput1073*x12+mexinput1074*x13+mexinput1075*x14+mexinput1076*x15+mexinput1077*x16+mexinput1078*x17+mexinput1079*x18+mexinput1080*x19+mexinput1081*x20+mexinput1082*x21+mexinput1083*x22+mexinput1084*x23+mexinput1085*x24+mexinput1086*x25-mexinput1976*mexinput2012)/mexinput1976/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1087*x1+mexinput1088*x2+mexinput1089*x3+mexinput1090*x4+mexinput1091*x5+mexinput1092*x6+mexinput1093*x7+mexinput1094*x8+mexinput1095*x9+mexinput1096*x10+mexinput1097*x11+mexinput1098*x12+mexinput1099*x13+mexinput1100*x14+mexinput1101*x15+mexinput1102*x16+mexinput1103*x17+mexinput1104*x18+mexinput1105*x19+mexinput1106*x20+mexinput1107*x21+mexinput1108*x22+mexinput1109*x23+mexinput1110*x24+mexinput1111*x25-mexinput1977*mexinput2012)/mexinput1977/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1112*x1+mexinput1113*x2+mexinput1114*x3+mexinput1115*x4+mexinput1116*x5+mexinput1117*x6+mexinput1118*x7+mexinput1119*x8+mexinput1120*x9+mexinput1121*x10+mexinput1122*x11+mexinput1123*x12+mexinput1124*x13+mexinput1125*x14+mexinput1126*x15+mexinput1127*x16+mexinput1128*x17+mexinput1129*x18+mexinput1130*x19+mexinput1131*x20+mexinput1132*x21+mexinput1133*x22+mexinput1134*x23+mexinput1135*x24+mexinput1136*x25-mexinput1978*mexinput2012)/mexinput1978/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1137*x1+mexinput1138*x2+mexinput1139*x3+mexinput1140*x4+mexinput1141*x5+mexinput1142*x6+mexinput1143*x7+mexinput1144*x8+mexinput1145*x9+mexinput1146*x10+mexinput1147*x11+mexinput1148*x12+mexinput1149*x13+mexinput1150*x14+mexinput1151*x15+mexinput1152*x16+mexinput1153*x17+mexinput1154*x18+mexinput1155*x19+mexinput1156*x20+mexinput1157*x21+mexinput1158*x22+mexinput1159*x23+mexinput1160*x24+mexinput1161*x25-mexinput1979*mexinput2012)/mexinput1979/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1162*x1+mexinput1163*x2+mexinput1164*x3+mexinput1165*x4+mexinput1166*x5+mexinput1167*x6+mexinput1168*x7+mexinput1169*x8+mexinput1170*x9+mexinput1171*x10+mexinput1172*x11+mexinput1173*x12+mexinput1174*x13+mexinput1175*x14+mexinput1176*x15+mexinput1177*x16+mexinput1178*x17+mexinput1179*x18+mexinput1180*x19+mexinput1181*x20+mexinput1182*x21+mexinput1183*x22+mexinput1184*x23+mexinput1185*x24+mexinput1186*x25-mexinput1980*mexinput2012)/mexinput1980/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1187*x1+mexinput1188*x2+mexinput1189*x3+mexinput1190*x4+mexinput1191*x5+mexinput1192*x6+mexinput1193*x7+mexinput1194*x8+mexinput1195*x9+mexinput1196*x10+mexinput1197*x11+mexinput1198*x12+mexinput1199*x13+mexinput1200*x14+mexinput1201*x15+mexinput1202*x16+mexinput1203*x17+mexinput1204*x18+mexinput1205*x19+mexinput1206*x20+mexinput1207*x21+mexinput1208*x22+mexinput1209*x23+mexinput1210*x24+mexinput1211*x25-mexinput1981*mexinput2012)/mexinput1981/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1212*x1+mexinput1213*x2+mexinput1214*x3+mexinput1215*x4+mexinput1216*x5+mexinput1217*x6+mexinput1218*x7+mexinput1219*x8+mexinput1220*x9+mexinput1221*x10+mexinput1222*x11+mexinput1223*x12+mexinput1224*x13+mexinput1225*x14+mexinput1226*x15+mexinput1227*x16+mexinput1228*x17+mexinput1229*x18+mexinput1230*x19+mexinput1231*x20+mexinput1232*x21+mexinput1233*x22+mexinput1234*x23+mexinput1235*x24+mexinput1236*x25-mexinput1982*mexinput2012)/mexinput1982/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1237*x1+mexinput1238*x2+mexinput1239*x3+mexinput1240*x4+mexinput1241*x5+mexinput1242*x6+mexinput1243*x7+mexinput1244*x8+mexinput1245*x9+mexinput1246*x10+mexinput1247*x11+mexinput1248*x12+mexinput1249*x13+mexinput1250*x14+mexinput1251*x15+mexinput1252*x16+mexinput1253*x17+mexinput1254*x18+mexinput1255*x19+mexinput1256*x20+mexinput1257*x21+mexinput1258*x22+mexinput1259*x23+mexinput1260*x24+mexinput1261*x25-mexinput1983*mexinput2012)/mexinput1983/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1262*x1+mexinput1263*x2+mexinput1264*x3+mexinput1265*x4+mexinput1266*x5+mexinput1267*x6+mexinput1268*x7+mexinput1269*x8+mexinput1270*x9+mexinput1271*x10+mexinput1272*x11+mexinput1273*x12+mexinput1274*x13+mexinput1275*x14+mexinput1276*x15+mexinput1277*x16+mexinput1278*x17+mexinput1279*x18+mexinput1280*x19+mexinput1281*x20+mexinput1282*x21+mexinput1283*x22+mexinput1284*x23+mexinput1285*x24+mexinput1286*x25-mexinput1984*mexinput2012)/mexinput1984/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1287*x1+mexinput1288*x2+mexinput1289*x3+mexinput1290*x4+mexinput1291*x5+mexinput1292*x6+mexinput1293*x7+mexinput1294*x8+mexinput1295*x9+mexinput1296*x10+mexinput1297*x11+mexinput1298*x12+mexinput1299*x13+mexinput1300*x14+mexinput1301*x15+mexinput1302*x16+mexinput1303*x17+mexinput1304*x18+mexinput1305*x19+mexinput1306*x20+mexinput1307*x21+mexinput1308*x22+mexinput1309*x23+mexinput1310*x24+mexinput1311*x25-mexinput1985*mexinput2012)/mexinput1985/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1312*x1+mexinput1313*x2+mexinput1314*x3+mexinput1315*x4+mexinput1316*x5+mexinput1317*x6+mexinput1318*x7+mexinput1319*x8+mexinput1320*x9+mexinput1321*x10+mexinput1322*x11+mexinput1323*x12+mexinput1324*x13+mexinput1325*x14+mexinput1326*x15+mexinput1327*x16+mexinput1328*x17+mexinput1329*x18+mexinput1330*x19+mexinput1331*x20+mexinput1332*x21+mexinput1333*x22+mexinput1334*x23+mexinput1335*x24+mexinput1336*x25-mexinput1986*mexinput2012)/mexinput1986/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1337*x1+mexinput1338*x2+mexinput1339*x3+mexinput1340*x4+mexinput1341*x5+mexinput1342*x6+mexinput1343*x7+mexinput1344*x8+mexinput1345*x9+mexinput1346*x10+mexinput1347*x11+mexinput1348*x12+mexinput1349*x13+mexinput1350*x14+mexinput1351*x15+mexinput1352*x16+mexinput1353*x17+mexinput1354*x18+mexinput1355*x19+mexinput1356*x20+mexinput1357*x21+mexinput1358*x22+mexinput1359*x23+mexinput1360*x24+mexinput1361*x25-mexinput1987*mexinput2012)/mexinput1987/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1362*x1+mexinput1363*x2+mexinput1364*x3+mexinput1365*x4+mexinput1366*x5+mexinput1367*x6+mexinput1368*x7+mexinput1369*x8+mexinput1370*x9+mexinput1371*x10+mexinput1372*x11+mexinput1373*x12+mexinput1374*x13+mexinput1375*x14+mexinput1376*x15+mexinput1377*x16+mexinput1378*x17+mexinput1379*x18+mexinput1380*x19+mexinput1381*x20+mexinput1382*x21+mexinput1383*x22+mexinput1384*x23+mexinput1385*x24+mexinput1386*x25-mexinput1988*mexinput2012)/mexinput1988/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1387*x1+mexinput1388*x2+mexinput1389*x3+mexinput1390*x4+mexinput1391*x5+mexinput1392*x6+mexinput1393*x7+mexinput1394*x8+mexinput1395*x9+mexinput1396*x10+mexinput1397*x11+mexinput1398*x12+mexinput1399*x13+mexinput1400*x14+mexinput1401*x15+mexinput1402*x16+mexinput1403*x17+mexinput1404*x18+mexinput1405*x19+mexinput1406*x20+mexinput1407*x21+mexinput1408*x22+mexinput1409*x23+mexinput1410*x24+mexinput1411*x25-mexinput1989*mexinput2012)/mexinput1989/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1412*x1+mexinput1413*x2+mexinput1414*x3+mexinput1415*x4+mexinput1416*x5+mexinput1417*x6+mexinput1418*x7+mexinput1419*x8+mexinput1420*x9+mexinput1421*x10+mexinput1422*x11+mexinput1423*x12+mexinput1424*x13+mexinput1425*x14+mexinput1426*x15+mexinput1427*x16+mexinput1428*x17+mexinput1429*x18+mexinput1430*x19+mexinput1431*x20+mexinput1432*x21+mexinput1433*x22+mexinput1434*x23+mexinput1435*x24+mexinput1436*x25-mexinput1990*mexinput2012)/mexinput1990/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1437*x1+mexinput1438*x2+mexinput1439*x3+mexinput1440*x4+mexinput1441*x5+mexinput1442*x6+mexinput1443*x7+mexinput1444*x8+mexinput1445*x9+mexinput1446*x10+mexinput1447*x11+mexinput1448*x12+mexinput1449*x13+mexinput1450*x14+mexinput1451*x15+mexinput1452*x16+mexinput1453*x17+mexinput1454*x18+mexinput1455*x19+mexinput1456*x20+mexinput1457*x21+mexinput1458*x22+mexinput1459*x23+mexinput1460*x24+mexinput1461*x25-mexinput1991*mexinput2012)/mexinput1991/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1462*x1+mexinput1463*x2+mexinput1464*x3+mexinput1465*x4+mexinput1466*x5+mexinput1467*x6+mexinput1468*x7+mexinput1469*x8+mexinput1470*x9+mexinput1471*x10+mexinput1472*x11+mexinput1473*x12+mexinput1474*x13+mexinput1475*x14+mexinput1476*x15+mexinput1477*x16+mexinput1478*x17+mexinput1479*x18+mexinput1480*x19+mexinput1481*x20+mexinput1482*x21+mexinput1483*x22+mexinput1484*x23+mexinput1485*x24+mexinput1486*x25-mexinput1992*mexinput2012)/mexinput1992/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1487*x1+mexinput1488*x2+mexinput1489*x3+mexinput1490*x4+mexinput1491*x5+mexinput1492*x6+mexinput1493*x7+mexinput1494*x8+mexinput1495*x9+mexinput1496*x10+mexinput1497*x11+mexinput1498*x12+mexinput1499*x13+mexinput1500*x14+mexinput1501*x15+mexinput1502*x16+mexinput1503*x17+mexinput1504*x18+mexinput1505*x19+mexinput1506*x20+mexinput1507*x21+mexinput1508*x22+mexinput1509*x23+mexinput1510*x24+mexinput1511*x25-mexinput1993*mexinput2012)/mexinput1993/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1512*x1+mexinput1513*x2+mexinput1514*x3+mexinput1515*x4+mexinput1516*x5+mexinput1517*x6+mexinput1518*x7+mexinput1519*x8+mexinput1520*x9+mexinput1521*x10+mexinput1522*x11+mexinput1523*x12+mexinput1524*x13+mexinput1525*x14+mexinput1526*x15+mexinput1527*x16+mexinput1528*x17+mexinput1529*x18+mexinput1530*x19+mexinput1531*x20+mexinput1532*x21+mexinput1533*x22+mexinput1534*x23+mexinput1535*x24+mexinput1536*x25-mexinput1994*mexinput2012)/mexinput1994/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1537*x1+mexinput1538*x2+mexinput1539*x3+mexinput1540*x4+mexinput1541*x5+mexinput1542*x6+mexinput1543*x7+mexinput1544*x8+mexinput1545*x9+mexinput1546*x10+mexinput1547*x11+mexinput1548*x12+mexinput1549*x13+mexinput1550*x14+mexinput1551*x15+mexinput1552*x16+mexinput1553*x17+mexinput1554*x18+mexinput1555*x19+mexinput1556*x20+mexinput1557*x21+mexinput1558*x22+mexinput1559*x23+mexinput1560*x24+mexinput1561*x25-mexinput1995*mexinput2012)/mexinput1995/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1562*x1+mexinput1563*x2+mexinput1564*x3+mexinput1565*x4+mexinput1566*x5+mexinput1567*x6+mexinput1568*x7+mexinput1569*x8+mexinput1570*x9+mexinput1571*x10+mexinput1572*x11+mexinput1573*x12+mexinput1574*x13+mexinput1575*x14+mexinput1576*x15+mexinput1577*x16+mexinput1578*x17+mexinput1579*x18+mexinput1580*x19+mexinput1581*x20+mexinput1582*x21+mexinput1583*x22+mexinput1584*x23+mexinput1585*x24+mexinput1586*x25-mexinput1996*mexinput2012)/mexinput1996/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1587*x1+mexinput1588*x2+mexinput1589*x3+mexinput1590*x4+mexinput1591*x5+mexinput1592*x6+mexinput1593*x7+mexinput1594*x8+mexinput1595*x9+mexinput1596*x10+mexinput1597*x11+mexinput1598*x12+mexinput1599*x13+mexinput1600*x14+mexinput1601*x15+mexinput1602*x16+mexinput1603*x17+mexinput1604*x18+mexinput1605*x19+mexinput1606*x20+mexinput1607*x21+mexinput1608*x22+mexinput1609*x23+mexinput1610*x24+mexinput1611*x25-mexinput1997*mexinput2012)/mexinput1997/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1612*x1+mexinput1613*x2+mexinput1614*x3+mexinput1615*x4+mexinput1616*x5+mexinput1617*x6+mexinput1618*x7+mexinput1619*x8+mexinput1620*x9+mexinput1621*x10+mexinput1622*x11+mexinput1623*x12+mexinput1624*x13+mexinput1625*x14+mexinput1626*x15+mexinput1627*x16+mexinput1628*x17+mexinput1629*x18+mexinput1630*x19+mexinput1631*x20+mexinput1632*x21+mexinput1633*x22+mexinput1634*x23+mexinput1635*x24+mexinput1636*x25-mexinput1998*mexinput2012)/mexinput1998/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1637*x1+mexinput1638*x2+mexinput1639*x3+mexinput1640*x4+mexinput1641*x5+mexinput1642*x6+mexinput1643*x7+mexinput1644*x8+mexinput1645*x9+mexinput1646*x10+mexinput1647*x11+mexinput1648*x12+mexinput1649*x13+mexinput1650*x14+mexinput1651*x15+mexinput1652*x16+mexinput1653*x17+mexinput1654*x18+mexinput1655*x19+mexinput1656*x20+mexinput1657*x21+mexinput1658*x22+mexinput1659*x23+mexinput1660*x24+mexinput1661*x25-mexinput1999*mexinput2012)/mexinput1999/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1662*x1+mexinput1663*x2+mexinput1664*x3+mexinput1665*x4+mexinput1666*x5+mexinput1667*x6+mexinput1668*x7+mexinput1669*x8+mexinput1670*x9+mexinput1671*x10+mexinput1672*x11+mexinput1673*x12+mexinput1674*x13+mexinput1675*x14+mexinput1676*x15+mexinput1677*x16+mexinput1678*x17+mexinput1679*x18+mexinput1680*x19+mexinput1681*x20+mexinput1682*x21+mexinput1683*x22+mexinput1684*x23+mexinput1685*x24+mexinput1686*x25-mexinput2000*mexinput2012)/mexinput2000/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1687*x1+mexinput1688*x2+mexinput1689*x3+mexinput1690*x4+mexinput1691*x5+mexinput1692*x6+mexinput1693*x7+mexinput1694*x8+mexinput1695*x9+mexinput1696*x10+mexinput1697*x11+mexinput1698*x12+mexinput1699*x13+mexinput1700*x14+mexinput1701*x15+mexinput1702*x16+mexinput1703*x17+mexinput1704*x18+mexinput1705*x19+mexinput1706*x20+mexinput1707*x21+mexinput1708*x22+mexinput1709*x23+mexinput1710*x24+mexinput1711*x25-mexinput2001*mexinput2012)/mexinput2001/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1712*x1+mexinput1713*x2+mexinput1714*x3+mexinput1715*x4+mexinput1716*x5+mexinput1717*x6+mexinput1718*x7+mexinput1719*x8+mexinput1720*x9+mexinput1721*x10+mexinput1722*x11+mexinput1723*x12+mexinput1724*x13+mexinput1725*x14+mexinput1726*x15+mexinput1727*x16+mexinput1728*x17+mexinput1729*x18+mexinput1730*x19+mexinput1731*x20+mexinput1732*x21+mexinput1733*x22+mexinput1734*x23+mexinput1735*x24+mexinput1736*x25-mexinput2002*mexinput2012)/mexinput2002/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1737*x1+mexinput1738*x2+mexinput1739*x3+mexinput1740*x4+mexinput1741*x5+mexinput1742*x6+mexinput1743*x7+mexinput1744*x8+mexinput1745*x9+mexinput1746*x10+mexinput1747*x11+mexinput1748*x12+mexinput1749*x13+mexinput1750*x14+mexinput1751*x15+mexinput1752*x16+mexinput1753*x17+mexinput1754*x18+mexinput1755*x19+mexinput1756*x20+mexinput1757*x21+mexinput1758*x22+mexinput1759*x23+mexinput1760*x24+mexinput1761*x25-mexinput2003*mexinput2012)/mexinput2003/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1762*x1+mexinput1763*x2+mexinput1764*x3+mexinput1765*x4+mexinput1766*x5+mexinput1767*x6+mexinput1768*x7+mexinput1769*x8+mexinput1770*x9+mexinput1771*x10+mexinput1772*x11+mexinput1773*x12+mexinput1774*x13+mexinput1775*x14+mexinput1776*x15+mexinput1777*x16+mexinput1778*x17+mexinput1779*x18+mexinput1780*x19+mexinput1781*x20+mexinput1782*x21+mexinput1783*x22+mexinput1784*x23+mexinput1785*x24+mexinput1786*x25-mexinput2004*mexinput2012)/mexinput2004/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1787*x1+mexinput1788*x2+mexinput1789*x3+mexinput1790*x4+mexinput1791*x5+mexinput1792*x6+mexinput1793*x7+mexinput1794*x8+mexinput1795*x9+mexinput1796*x10+mexinput1797*x11+mexinput1798*x12+mexinput1799*x13+mexinput1800*x14+mexinput1801*x15+mexinput1802*x16+mexinput1803*x17+mexinput1804*x18+mexinput1805*x19+mexinput1806*x20+mexinput1807*x21+mexinput1808*x22+mexinput1809*x23+mexinput1810*x24+mexinput1811*x25-mexinput2005*mexinput2012)/mexinput2005/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1812*x1+mexinput1813*x2+mexinput1814*x3+mexinput1815*x4+mexinput1816*x5+mexinput1817*x6+mexinput1818*x7+mexinput1819*x8+mexinput1820*x9+mexinput1821*x10+mexinput1822*x11+mexinput1823*x12+mexinput1824*x13+mexinput1825*x14+mexinput1826*x15+mexinput1827*x16+mexinput1828*x17+mexinput1829*x18+mexinput1830*x19+mexinput1831*x20+mexinput1832*x21+mexinput1833*x22+mexinput1834*x23+mexinput1835*x24+mexinput1836*x25-mexinput2006*mexinput2012)/mexinput2006/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1837*x1+mexinput1838*x2+mexinput1839*x3+mexinput1840*x4+mexinput1841*x5+mexinput1842*x6+mexinput1843*x7+mexinput1844*x8+mexinput1845*x9+mexinput1846*x10+mexinput1847*x11+mexinput1848*x12+mexinput1849*x13+mexinput1850*x14+mexinput1851*x15+mexinput1852*x16+mexinput1853*x17+mexinput1854*x18+mexinput1855*x19+mexinput1856*x20+mexinput1857*x21+mexinput1858*x22+mexinput1859*x23+mexinput1860*x24+mexinput1861*x25-mexinput2007*mexinput2012)/mexinput2007/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1862*x1+mexinput1863*x2+mexinput1864*x3+mexinput1865*x4+mexinput1866*x5+mexinput1867*x6+mexinput1868*x7+mexinput1869*x8+mexinput1870*x9+mexinput1871*x10+mexinput1872*x11+mexinput1873*x12+mexinput1874*x13+mexinput1875*x14+mexinput1876*x15+mexinput1877*x16+mexinput1878*x17+mexinput1879*x18+mexinput1880*x19+mexinput1881*x20+mexinput1882*x21+mexinput1883*x22+mexinput1884*x23+mexinput1885*x24+mexinput1886*x25-mexinput2008*mexinput2012)/mexinput2008/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1887*x1+mexinput1888*x2+mexinput1889*x3+mexinput1890*x4+mexinput1891*x5+mexinput1892*x6+mexinput1893*x7+mexinput1894*x8+mexinput1895*x9+mexinput1896*x10+mexinput1897*x11+mexinput1898*x12+mexinput1899*x13+mexinput1900*x14+mexinput1901*x15+mexinput1902*x16+mexinput1903*x17+mexinput1904*x18+mexinput1905*x19+mexinput1906*x20+mexinput1907*x21+mexinput1908*x22+mexinput1909*x23+mexinput1910*x24+mexinput1911*x25-mexinput2009*mexinput2012)/mexinput2009/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1912*x1+mexinput1913*x2+mexinput1914*x3+mexinput1915*x4+mexinput1916*x5+mexinput1917*x6+mexinput1918*x7+mexinput1919*x8+mexinput1920*x9+mexinput1921*x10+mexinput1922*x11+mexinput1923*x12+mexinput1924*x13+mexinput1925*x14+mexinput1926*x15+mexinput1927*x16+mexinput1928*x17+mexinput1929*x18+mexinput1930*x19+mexinput1931*x20+mexinput1932*x21+mexinput1933*x22+mexinput1934*x23+mexinput1935*x24+mexinput1936*x25-mexinput2010*mexinput2012)/mexinput2010/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ((mexinput1937*x1+mexinput1938*x2+mexinput1939*x3+mexinput1940*x4+mexinput1941*x5+mexinput1942*x6+mexinput1943*x7+mexinput1944*x8+mexinput1945*x9+mexinput1946*x10+mexinput1947*x11+mexinput1948*x12+mexinput1949*x13+mexinput1950*x14+mexinput1951*x15+mexinput1952*x16+mexinput1953*x17+mexinput1954*x18+mexinput1955*x19+mexinput1956*x20+mexinput1957*x21+mexinput1958*x22+mexinput1959*x23+mexinput1960*x24+mexinput1961*x25-mexinput2011*mexinput2012)/mexinput2011/mexinput2012-ps1) <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, ps1 >= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1962*mexinput2012+mexinput712*x1+mexinput713*x2+mexinput714*x3+mexinput715*x4+mexinput716*x5+mexinput717*x6+mexinput718*x7+mexinput719*x8+mexinput720*x9+mexinput721*x10+mexinput731*x20+mexinput962*x11+mexinput963*x12+mexinput964*x13+mexinput965*x14+mexinput966*x15+mexinput967*x16+mexinput968*x17+mexinput969*x18+mexinput970*x19+mexinput987*x21+mexinput988*x22+mexinput989*x23+mexinput990*x24+mexinput991*x25)/mexinput1962/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1212*x11+mexinput1213*x12+mexinput1214*x13+mexinput1215*x14+mexinput1216*x15+mexinput1217*x16+mexinput1218*x17+mexinput1219*x18+mexinput1220*x19+mexinput1237*x21+mexinput1238*x22+mexinput1239*x23+mexinput1240*x24+mexinput1241*x25-mexinput1963*mexinput2012+mexinput737*x1+mexinput738*x2+mexinput739*x3+mexinput740*x4+mexinput741*x5+mexinput742*x6+mexinput743*x7+mexinput744*x8+mexinput745*x9+mexinput746*x10+mexinput756*x20)/mexinput1963/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1462*x11+mexinput1463*x12+mexinput1464*x13+mexinput1465*x14+mexinput1466*x15+mexinput1467*x16+mexinput1468*x17+mexinput1469*x18+mexinput1470*x19+mexinput1487*x21+mexinput1488*x22+mexinput1489*x23+mexinput1490*x24+mexinput1491*x25-mexinput1964*mexinput2012+mexinput762*x1+mexinput763*x2+mexinput764*x3+mexinput765*x4+mexinput766*x5+mexinput767*x6+mexinput768*x7+mexinput769*x8+mexinput770*x9+mexinput771*x10+mexinput781*x20)/mexinput1964/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1712*x11+mexinput1713*x12+mexinput1714*x13+mexinput1715*x14+mexinput1716*x15+mexinput1717*x16+mexinput1718*x17+mexinput1719*x18+mexinput1720*x19+mexinput1737*x21+mexinput1738*x22+mexinput1739*x23+mexinput1740*x24+mexinput1741*x25-mexinput1965*mexinput2012+mexinput787*x1+mexinput788*x2+mexinput789*x3+mexinput790*x4+mexinput791*x5+mexinput792*x6+mexinput793*x7+mexinput794*x8+mexinput795*x9+mexinput796*x10+mexinput806*x20)/mexinput1965/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1966*mexinput2012+mexinput812*x1+mexinput813*x2+mexinput814*x3+mexinput815*x4+mexinput816*x5+mexinput817*x6+mexinput818*x7+mexinput819*x8+mexinput820*x9+mexinput821*x10+mexinput822*x11+mexinput823*x12+mexinput824*x13+mexinput825*x14+mexinput826*x15+mexinput827*x16+mexinput828*x17+mexinput829*x18+mexinput830*x19+mexinput831*x20+mexinput832*x21+mexinput833*x22+mexinput834*x23+mexinput835*x24+mexinput836*x25)/mexinput1966/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1967*mexinput2012+mexinput837*x1+mexinput838*x2+mexinput839*x3+mexinput840*x4+mexinput841*x5+mexinput842*x6+mexinput843*x7+mexinput844*x8+mexinput845*x9+mexinput846*x10+mexinput847*x11+mexinput848*x12+mexinput849*x13+mexinput850*x14+mexinput851*x15+mexinput852*x16+mexinput853*x17+mexinput854*x18+mexinput855*x19+mexinput856*x20+mexinput857*x21+mexinput858*x22+mexinput859*x23+mexinput860*x24+mexinput861*x25)/mexinput1967/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1968*mexinput2012+mexinput862*x1+mexinput863*x2+mexinput864*x3+mexinput865*x4+mexinput866*x5+mexinput867*x6+mexinput868*x7+mexinput869*x8+mexinput870*x9+mexinput871*x10+mexinput872*x11+mexinput873*x12+mexinput874*x13+mexinput875*x14+mexinput876*x15+mexinput877*x16+mexinput878*x17+mexinput879*x18+mexinput880*x19+mexinput881*x20+mexinput882*x21+mexinput883*x22+mexinput884*x23+mexinput885*x24+mexinput886*x25)/mexinput1968/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1969*mexinput2012+mexinput887*x1+mexinput888*x2+mexinput889*x3+mexinput890*x4+mexinput891*x5+mexinput892*x6+mexinput893*x7+mexinput894*x8+mexinput895*x9+mexinput896*x10+mexinput897*x11+mexinput898*x12+mexinput899*x13+mexinput900*x14+mexinput901*x15+mexinput902*x16+mexinput903*x17+mexinput904*x18+mexinput905*x19+mexinput906*x20+mexinput907*x21+mexinput908*x22+mexinput909*x23+mexinput910*x24+mexinput911*x25)/mexinput1969/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1970*mexinput2012+mexinput912*x1+mexinput913*x2+mexinput914*x3+mexinput915*x4+mexinput916*x5+mexinput917*x6+mexinput918*x7+mexinput919*x8+mexinput920*x9+mexinput921*x10+mexinput922*x11+mexinput923*x12+mexinput924*x13+mexinput925*x14+mexinput926*x15+mexinput927*x16+mexinput928*x17+mexinput929*x18+mexinput930*x19+mexinput931*x20+mexinput932*x21+mexinput933*x22+mexinput934*x23+mexinput935*x24+mexinput936*x25)/mexinput1970/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1971*mexinput2012+mexinput937*x1+mexinput938*x2+mexinput939*x3+mexinput940*x4+mexinput941*x5+mexinput942*x6+mexinput943*x7+mexinput944*x8+mexinput945*x9+mexinput946*x10+mexinput947*x11+mexinput948*x12+mexinput949*x13+mexinput950*x14+mexinput951*x15+mexinput952*x16+mexinput953*x17+mexinput954*x18+mexinput955*x19+mexinput956*x20+mexinput957*x21+mexinput958*x22+mexinput959*x23+mexinput960*x24+mexinput961*x25)/mexinput1971/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (-mexinput1972*mexinput2012+mexinput962*x1+mexinput963*x2+mexinput964*x3+mexinput965*x4+mexinput966*x5+mexinput967*x6+mexinput968*x7+mexinput969*x8+mexinput970*x9+mexinput971*x10+mexinput972*x11+mexinput973*x12+mexinput974*x13+mexinput975*x14+mexinput976*x15+mexinput977*x16+mexinput978*x17+mexinput979*x18+mexinput980*x19+mexinput981*x20+mexinput982*x21+mexinput983*x22+mexinput984*x23+mexinput985*x24+mexinput986*x25)/mexinput1972/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1000*x14+mexinput1001*x15+mexinput1002*x16+mexinput1003*x17+mexinput1004*x18+mexinput1005*x19+mexinput1006*x20+mexinput1007*x21+mexinput1008*x22+mexinput1009*x23+mexinput1010*x24+mexinput1011*x25-mexinput1973*mexinput2012+mexinput987*x1+mexinput988*x2+mexinput989*x3+mexinput990*x4+mexinput991*x5+mexinput992*x6+mexinput993*x7+mexinput994*x8+mexinput995*x9+mexinput996*x10+mexinput997*x11+mexinput998*x12+mexinput999*x13)/mexinput1973/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1012*x1+mexinput1013*x2+mexinput1014*x3+mexinput1015*x4+mexinput1016*x5+mexinput1017*x6+mexinput1018*x7+mexinput1019*x8+mexinput1020*x9+mexinput1021*x10+mexinput1022*x11+mexinput1023*x12+mexinput1024*x13+mexinput1025*x14+mexinput1026*x15+mexinput1027*x16+mexinput1028*x17+mexinput1029*x18+mexinput1030*x19+mexinput1031*x20+mexinput1032*x21+mexinput1033*x22+mexinput1034*x23+mexinput1035*x24+mexinput1036*x25-mexinput1974*mexinput2012)/mexinput1974/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1037*x1+mexinput1038*x2+mexinput1039*x3+mexinput1040*x4+mexinput1041*x5+mexinput1042*x6+mexinput1043*x7+mexinput1044*x8+mexinput1045*x9+mexinput1046*x10+mexinput1047*x11+mexinput1048*x12+mexinput1049*x13+mexinput1050*x14+mexinput1051*x15+mexinput1052*x16+mexinput1053*x17+mexinput1054*x18+mexinput1055*x19+mexinput1056*x20+mexinput1057*x21+mexinput1058*x22+mexinput1059*x23+mexinput1060*x24+mexinput1061*x25-mexinput1975*mexinput2012)/mexinput1975/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1062*x1+mexinput1063*x2+mexinput1064*x3+mexinput1065*x4+mexinput1066*x5+mexinput1067*x6+mexinput1068*x7+mexinput1069*x8+mexinput1070*x9+mexinput1071*x10+mexinput1072*x11+mexinput1073*x12+mexinput1074*x13+mexinput1075*x14+mexinput1076*x15+mexinput1077*x16+mexinput1078*x17+mexinput1079*x18+mexinput1080*x19+mexinput1081*x20+mexinput1082*x21+mexinput1083*x22+mexinput1084*x23+mexinput1085*x24+mexinput1086*x25-mexinput1976*mexinput2012)/mexinput1976/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1087*x1+mexinput1088*x2+mexinput1089*x3+mexinput1090*x4+mexinput1091*x5+mexinput1092*x6+mexinput1093*x7+mexinput1094*x8+mexinput1095*x9+mexinput1096*x10+mexinput1097*x11+mexinput1098*x12+mexinput1099*x13+mexinput1100*x14+mexinput1101*x15+mexinput1102*x16+mexinput1103*x17+mexinput1104*x18+mexinput1105*x19+mexinput1106*x20+mexinput1107*x21+mexinput1108*x22+mexinput1109*x23+mexinput1110*x24+mexinput1111*x25-mexinput1977*mexinput2012)/mexinput1977/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1112*x1+mexinput1113*x2+mexinput1114*x3+mexinput1115*x4+mexinput1116*x5+mexinput1117*x6+mexinput1118*x7+mexinput1119*x8+mexinput1120*x9+mexinput1121*x10+mexinput1122*x11+mexinput1123*x12+mexinput1124*x13+mexinput1125*x14+mexinput1126*x15+mexinput1127*x16+mexinput1128*x17+mexinput1129*x18+mexinput1130*x19+mexinput1131*x20+mexinput1132*x21+mexinput1133*x22+mexinput1134*x23+mexinput1135*x24+mexinput1136*x25-mexinput1978*mexinput2012)/mexinput1978/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1137*x1+mexinput1138*x2+mexinput1139*x3+mexinput1140*x4+mexinput1141*x5+mexinput1142*x6+mexinput1143*x7+mexinput1144*x8+mexinput1145*x9+mexinput1146*x10+mexinput1147*x11+mexinput1148*x12+mexinput1149*x13+mexinput1150*x14+mexinput1151*x15+mexinput1152*x16+mexinput1153*x17+mexinput1154*x18+mexinput1155*x19+mexinput1156*x20+mexinput1157*x21+mexinput1158*x22+mexinput1159*x23+mexinput1160*x24+mexinput1161*x25-mexinput1979*mexinput2012)/mexinput1979/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1162*x1+mexinput1163*x2+mexinput1164*x3+mexinput1165*x4+mexinput1166*x5+mexinput1167*x6+mexinput1168*x7+mexinput1169*x8+mexinput1170*x9+mexinput1171*x10+mexinput1172*x11+mexinput1173*x12+mexinput1174*x13+mexinput1175*x14+mexinput1176*x15+mexinput1177*x16+mexinput1178*x17+mexinput1179*x18+mexinput1180*x19+mexinput1181*x20+mexinput1182*x21+mexinput1183*x22+mexinput1184*x23+mexinput1185*x24+mexinput1186*x25-mexinput1980*mexinput2012)/mexinput1980/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1187*x1+mexinput1188*x2+mexinput1189*x3+mexinput1190*x4+mexinput1191*x5+mexinput1192*x6+mexinput1193*x7+mexinput1194*x8+mexinput1195*x9+mexinput1196*x10+mexinput1197*x11+mexinput1198*x12+mexinput1199*x13+mexinput1200*x14+mexinput1201*x15+mexinput1202*x16+mexinput1203*x17+mexinput1204*x18+mexinput1205*x19+mexinput1206*x20+mexinput1207*x21+mexinput1208*x22+mexinput1209*x23+mexinput1210*x24+mexinput1211*x25-mexinput1981*mexinput2012)/mexinput1981/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1212*x1+mexinput1213*x2+mexinput1214*x3+mexinput1215*x4+mexinput1216*x5+mexinput1217*x6+mexinput1218*x7+mexinput1219*x8+mexinput1220*x9+mexinput1221*x10+mexinput1222*x11+mexinput1223*x12+mexinput1224*x13+mexinput1225*x14+mexinput1226*x15+mexinput1227*x16+mexinput1228*x17+mexinput1229*x18+mexinput1230*x19+mexinput1231*x20+mexinput1232*x21+mexinput1233*x22+mexinput1234*x23+mexinput1235*x24+mexinput1236*x25-mexinput1982*mexinput2012)/mexinput1982/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1237*x1+mexinput1238*x2+mexinput1239*x3+mexinput1240*x4+mexinput1241*x5+mexinput1242*x6+mexinput1243*x7+mexinput1244*x8+mexinput1245*x9+mexinput1246*x10+mexinput1247*x11+mexinput1248*x12+mexinput1249*x13+mexinput1250*x14+mexinput1251*x15+mexinput1252*x16+mexinput1253*x17+mexinput1254*x18+mexinput1255*x19+mexinput1256*x20+mexinput1257*x21+mexinput1258*x22+mexinput1259*x23+mexinput1260*x24+mexinput1261*x25-mexinput1983*mexinput2012)/mexinput1983/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1262*x1+mexinput1263*x2+mexinput1264*x3+mexinput1265*x4+mexinput1266*x5+mexinput1267*x6+mexinput1268*x7+mexinput1269*x8+mexinput1270*x9+mexinput1271*x10+mexinput1272*x11+mexinput1273*x12+mexinput1274*x13+mexinput1275*x14+mexinput1276*x15+mexinput1277*x16+mexinput1278*x17+mexinput1279*x18+mexinput1280*x19+mexinput1281*x20+mexinput1282*x21+mexinput1283*x22+mexinput1284*x23+mexinput1285*x24+mexinput1286*x25-mexinput1984*mexinput2012)/mexinput1984/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1287*x1+mexinput1288*x2+mexinput1289*x3+mexinput1290*x4+mexinput1291*x5+mexinput1292*x6+mexinput1293*x7+mexinput1294*x8+mexinput1295*x9+mexinput1296*x10+mexinput1297*x11+mexinput1298*x12+mexinput1299*x13+mexinput1300*x14+mexinput1301*x15+mexinput1302*x16+mexinput1303*x17+mexinput1304*x18+mexinput1305*x19+mexinput1306*x20+mexinput1307*x21+mexinput1308*x22+mexinput1309*x23+mexinput1310*x24+mexinput1311*x25-mexinput1985*mexinput2012)/mexinput1985/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1312*x1+mexinput1313*x2+mexinput1314*x3+mexinput1315*x4+mexinput1316*x5+mexinput1317*x6+mexinput1318*x7+mexinput1319*x8+mexinput1320*x9+mexinput1321*x10+mexinput1322*x11+mexinput1323*x12+mexinput1324*x13+mexinput1325*x14+mexinput1326*x15+mexinput1327*x16+mexinput1328*x17+mexinput1329*x18+mexinput1330*x19+mexinput1331*x20+mexinput1332*x21+mexinput1333*x22+mexinput1334*x23+mexinput1335*x24+mexinput1336*x25-mexinput1986*mexinput2012)/mexinput1986/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1337*x1+mexinput1338*x2+mexinput1339*x3+mexinput1340*x4+mexinput1341*x5+mexinput1342*x6+mexinput1343*x7+mexinput1344*x8+mexinput1345*x9+mexinput1346*x10+mexinput1347*x11+mexinput1348*x12+mexinput1349*x13+mexinput1350*x14+mexinput1351*x15+mexinput1352*x16+mexinput1353*x17+mexinput1354*x18+mexinput1355*x19+mexinput1356*x20+mexinput1357*x21+mexinput1358*x22+mexinput1359*x23+mexinput1360*x24+mexinput1361*x25-mexinput1987*mexinput2012)/mexinput1987/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1362*x1+mexinput1363*x2+mexinput1364*x3+mexinput1365*x4+mexinput1366*x5+mexinput1367*x6+mexinput1368*x7+mexinput1369*x8+mexinput1370*x9+mexinput1371*x10+mexinput1372*x11+mexinput1373*x12+mexinput1374*x13+mexinput1375*x14+mexinput1376*x15+mexinput1377*x16+mexinput1378*x17+mexinput1379*x18+mexinput1380*x19+mexinput1381*x20+mexinput1382*x21+mexinput1383*x22+mexinput1384*x23+mexinput1385*x24+mexinput1386*x25-mexinput1988*mexinput2012)/mexinput1988/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1387*x1+mexinput1388*x2+mexinput1389*x3+mexinput1390*x4+mexinput1391*x5+mexinput1392*x6+mexinput1393*x7+mexinput1394*x8+mexinput1395*x9+mexinput1396*x10+mexinput1397*x11+mexinput1398*x12+mexinput1399*x13+mexinput1400*x14+mexinput1401*x15+mexinput1402*x16+mexinput1403*x17+mexinput1404*x18+mexinput1405*x19+mexinput1406*x20+mexinput1407*x21+mexinput1408*x22+mexinput1409*x23+mexinput1410*x24+mexinput1411*x25-mexinput1989*mexinput2012)/mexinput1989/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1412*x1+mexinput1413*x2+mexinput1414*x3+mexinput1415*x4+mexinput1416*x5+mexinput1417*x6+mexinput1418*x7+mexinput1419*x8+mexinput1420*x9+mexinput1421*x10+mexinput1422*x11+mexinput1423*x12+mexinput1424*x13+mexinput1425*x14+mexinput1426*x15+mexinput1427*x16+mexinput1428*x17+mexinput1429*x18+mexinput1430*x19+mexinput1431*x20+mexinput1432*x21+mexinput1433*x22+mexinput1434*x23+mexinput1435*x24+mexinput1436*x25-mexinput1990*mexinput2012)/mexinput1990/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1437*x1+mexinput1438*x2+mexinput1439*x3+mexinput1440*x4+mexinput1441*x5+mexinput1442*x6+mexinput1443*x7+mexinput1444*x8+mexinput1445*x9+mexinput1446*x10+mexinput1447*x11+mexinput1448*x12+mexinput1449*x13+mexinput1450*x14+mexinput1451*x15+mexinput1452*x16+mexinput1453*x17+mexinput1454*x18+mexinput1455*x19+mexinput1456*x20+mexinput1457*x21+mexinput1458*x22+mexinput1459*x23+mexinput1460*x24+mexinput1461*x25-mexinput1991*mexinput2012)/mexinput1991/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1462*x1+mexinput1463*x2+mexinput1464*x3+mexinput1465*x4+mexinput1466*x5+mexinput1467*x6+mexinput1468*x7+mexinput1469*x8+mexinput1470*x9+mexinput1471*x10+mexinput1472*x11+mexinput1473*x12+mexinput1474*x13+mexinput1475*x14+mexinput1476*x15+mexinput1477*x16+mexinput1478*x17+mexinput1479*x18+mexinput1480*x19+mexinput1481*x20+mexinput1482*x21+mexinput1483*x22+mexinput1484*x23+mexinput1485*x24+mexinput1486*x25-mexinput1992*mexinput2012)/mexinput1992/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1487*x1+mexinput1488*x2+mexinput1489*x3+mexinput1490*x4+mexinput1491*x5+mexinput1492*x6+mexinput1493*x7+mexinput1494*x8+mexinput1495*x9+mexinput1496*x10+mexinput1497*x11+mexinput1498*x12+mexinput1499*x13+mexinput1500*x14+mexinput1501*x15+mexinput1502*x16+mexinput1503*x17+mexinput1504*x18+mexinput1505*x19+mexinput1506*x20+mexinput1507*x21+mexinput1508*x22+mexinput1509*x23+mexinput1510*x24+mexinput1511*x25-mexinput1993*mexinput2012)/mexinput1993/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1512*x1+mexinput1513*x2+mexinput1514*x3+mexinput1515*x4+mexinput1516*x5+mexinput1517*x6+mexinput1518*x7+mexinput1519*x8+mexinput1520*x9+mexinput1521*x10+mexinput1522*x11+mexinput1523*x12+mexinput1524*x13+mexinput1525*x14+mexinput1526*x15+mexinput1527*x16+mexinput1528*x17+mexinput1529*x18+mexinput1530*x19+mexinput1531*x20+mexinput1532*x21+mexinput1533*x22+mexinput1534*x23+mexinput1535*x24+mexinput1536*x25-mexinput1994*mexinput2012)/mexinput1994/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1537*x1+mexinput1538*x2+mexinput1539*x3+mexinput1540*x4+mexinput1541*x5+mexinput1542*x6+mexinput1543*x7+mexinput1544*x8+mexinput1545*x9+mexinput1546*x10+mexinput1547*x11+mexinput1548*x12+mexinput1549*x13+mexinput1550*x14+mexinput1551*x15+mexinput1552*x16+mexinput1553*x17+mexinput1554*x18+mexinput1555*x19+mexinput1556*x20+mexinput1557*x21+mexinput1558*x22+mexinput1559*x23+mexinput1560*x24+mexinput1561*x25-mexinput1995*mexinput2012)/mexinput1995/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1562*x1+mexinput1563*x2+mexinput1564*x3+mexinput1565*x4+mexinput1566*x5+mexinput1567*x6+mexinput1568*x7+mexinput1569*x8+mexinput1570*x9+mexinput1571*x10+mexinput1572*x11+mexinput1573*x12+mexinput1574*x13+mexinput1575*x14+mexinput1576*x15+mexinput1577*x16+mexinput1578*x17+mexinput1579*x18+mexinput1580*x19+mexinput1581*x20+mexinput1582*x21+mexinput1583*x22+mexinput1584*x23+mexinput1585*x24+mexinput1586*x25-mexinput1996*mexinput2012)/mexinput1996/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1587*x1+mexinput1588*x2+mexinput1589*x3+mexinput1590*x4+mexinput1591*x5+mexinput1592*x6+mexinput1593*x7+mexinput1594*x8+mexinput1595*x9+mexinput1596*x10+mexinput1597*x11+mexinput1598*x12+mexinput1599*x13+mexinput1600*x14+mexinput1601*x15+mexinput1602*x16+mexinput1603*x17+mexinput1604*x18+mexinput1605*x19+mexinput1606*x20+mexinput1607*x21+mexinput1608*x22+mexinput1609*x23+mexinput1610*x24+mexinput1611*x25-mexinput1997*mexinput2012)/mexinput1997/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1612*x1+mexinput1613*x2+mexinput1614*x3+mexinput1615*x4+mexinput1616*x5+mexinput1617*x6+mexinput1618*x7+mexinput1619*x8+mexinput1620*x9+mexinput1621*x10+mexinput1622*x11+mexinput1623*x12+mexinput1624*x13+mexinput1625*x14+mexinput1626*x15+mexinput1627*x16+mexinput1628*x17+mexinput1629*x18+mexinput1630*x19+mexinput1631*x20+mexinput1632*x21+mexinput1633*x22+mexinput1634*x23+mexinput1635*x24+mexinput1636*x25-mexinput1998*mexinput2012)/mexinput1998/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1637*x1+mexinput1638*x2+mexinput1639*x3+mexinput1640*x4+mexinput1641*x5+mexinput1642*x6+mexinput1643*x7+mexinput1644*x8+mexinput1645*x9+mexinput1646*x10+mexinput1647*x11+mexinput1648*x12+mexinput1649*x13+mexinput1650*x14+mexinput1651*x15+mexinput1652*x16+mexinput1653*x17+mexinput1654*x18+mexinput1655*x19+mexinput1656*x20+mexinput1657*x21+mexinput1658*x22+mexinput1659*x23+mexinput1660*x24+mexinput1661*x25-mexinput1999*mexinput2012)/mexinput1999/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1662*x1+mexinput1663*x2+mexinput1664*x3+mexinput1665*x4+mexinput1666*x5+mexinput1667*x6+mexinput1668*x7+mexinput1669*x8+mexinput1670*x9+mexinput1671*x10+mexinput1672*x11+mexinput1673*x12+mexinput1674*x13+mexinput1675*x14+mexinput1676*x15+mexinput1677*x16+mexinput1678*x17+mexinput1679*x18+mexinput1680*x19+mexinput1681*x20+mexinput1682*x21+mexinput1683*x22+mexinput1684*x23+mexinput1685*x24+mexinput1686*x25-mexinput2000*mexinput2012)/mexinput2000/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1687*x1+mexinput1688*x2+mexinput1689*x3+mexinput1690*x4+mexinput1691*x5+mexinput1692*x6+mexinput1693*x7+mexinput1694*x8+mexinput1695*x9+mexinput1696*x10+mexinput1697*x11+mexinput1698*x12+mexinput1699*x13+mexinput1700*x14+mexinput1701*x15+mexinput1702*x16+mexinput1703*x17+mexinput1704*x18+mexinput1705*x19+mexinput1706*x20+mexinput1707*x21+mexinput1708*x22+mexinput1709*x23+mexinput1710*x24+mexinput1711*x25-mexinput2001*mexinput2012)/mexinput2001/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1712*x1+mexinput1713*x2+mexinput1714*x3+mexinput1715*x4+mexinput1716*x5+mexinput1717*x6+mexinput1718*x7+mexinput1719*x8+mexinput1720*x9+mexinput1721*x10+mexinput1722*x11+mexinput1723*x12+mexinput1724*x13+mexinput1725*x14+mexinput1726*x15+mexinput1727*x16+mexinput1728*x17+mexinput1729*x18+mexinput1730*x19+mexinput1731*x20+mexinput1732*x21+mexinput1733*x22+mexinput1734*x23+mexinput1735*x24+mexinput1736*x25-mexinput2002*mexinput2012)/mexinput2002/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1737*x1+mexinput1738*x2+mexinput1739*x3+mexinput1740*x4+mexinput1741*x5+mexinput1742*x6+mexinput1743*x7+mexinput1744*x8+mexinput1745*x9+mexinput1746*x10+mexinput1747*x11+mexinput1748*x12+mexinput1749*x13+mexinput1750*x14+mexinput1751*x15+mexinput1752*x16+mexinput1753*x17+mexinput1754*x18+mexinput1755*x19+mexinput1756*x20+mexinput1757*x21+mexinput1758*x22+mexinput1759*x23+mexinput1760*x24+mexinput1761*x25-mexinput2003*mexinput2012)/mexinput2003/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1762*x1+mexinput1763*x2+mexinput1764*x3+mexinput1765*x4+mexinput1766*x5+mexinput1767*x6+mexinput1768*x7+mexinput1769*x8+mexinput1770*x9+mexinput1771*x10+mexinput1772*x11+mexinput1773*x12+mexinput1774*x13+mexinput1775*x14+mexinput1776*x15+mexinput1777*x16+mexinput1778*x17+mexinput1779*x18+mexinput1780*x19+mexinput1781*x20+mexinput1782*x21+mexinput1783*x22+mexinput1784*x23+mexinput1785*x24+mexinput1786*x25-mexinput2004*mexinput2012)/mexinput2004/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1787*x1+mexinput1788*x2+mexinput1789*x3+mexinput1790*x4+mexinput1791*x5+mexinput1792*x6+mexinput1793*x7+mexinput1794*x8+mexinput1795*x9+mexinput1796*x10+mexinput1797*x11+mexinput1798*x12+mexinput1799*x13+mexinput1800*x14+mexinput1801*x15+mexinput1802*x16+mexinput1803*x17+mexinput1804*x18+mexinput1805*x19+mexinput1806*x20+mexinput1807*x21+mexinput1808*x22+mexinput1809*x23+mexinput1810*x24+mexinput1811*x25-mexinput2005*mexinput2012)/mexinput2005/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1812*x1+mexinput1813*x2+mexinput1814*x3+mexinput1815*x4+mexinput1816*x5+mexinput1817*x6+mexinput1818*x7+mexinput1819*x8+mexinput1820*x9+mexinput1821*x10+mexinput1822*x11+mexinput1823*x12+mexinput1824*x13+mexinput1825*x14+mexinput1826*x15+mexinput1827*x16+mexinput1828*x17+mexinput1829*x18+mexinput1830*x19+mexinput1831*x20+mexinput1832*x21+mexinput1833*x22+mexinput1834*x23+mexinput1835*x24+mexinput1836*x25-mexinput2006*mexinput2012)/mexinput2006/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1837*x1+mexinput1838*x2+mexinput1839*x3+mexinput1840*x4+mexinput1841*x5+mexinput1842*x6+mexinput1843*x7+mexinput1844*x8+mexinput1845*x9+mexinput1846*x10+mexinput1847*x11+mexinput1848*x12+mexinput1849*x13+mexinput1850*x14+mexinput1851*x15+mexinput1852*x16+mexinput1853*x17+mexinput1854*x18+mexinput1855*x19+mexinput1856*x20+mexinput1857*x21+mexinput1858*x22+mexinput1859*x23+mexinput1860*x24+mexinput1861*x25-mexinput2007*mexinput2012)/mexinput2007/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1862*x1+mexinput1863*x2+mexinput1864*x3+mexinput1865*x4+mexinput1866*x5+mexinput1867*x6+mexinput1868*x7+mexinput1869*x8+mexinput1870*x9+mexinput1871*x10+mexinput1872*x11+mexinput1873*x12+mexinput1874*x13+mexinput1875*x14+mexinput1876*x15+mexinput1877*x16+mexinput1878*x17+mexinput1879*x18+mexinput1880*x19+mexinput1881*x20+mexinput1882*x21+mexinput1883*x22+mexinput1884*x23+mexinput1885*x24+mexinput1886*x25-mexinput2008*mexinput2012)/mexinput2008/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1887*x1+mexinput1888*x2+mexinput1889*x3+mexinput1890*x4+mexinput1891*x5+mexinput1892*x6+mexinput1893*x7+mexinput1894*x8+mexinput1895*x9+mexinput1896*x10+mexinput1897*x11+mexinput1898*x12+mexinput1899*x13+mexinput1900*x14+mexinput1901*x15+mexinput1902*x16+mexinput1903*x17+mexinput1904*x18+mexinput1905*x19+mexinput1906*x20+mexinput1907*x21+mexinput1908*x22+mexinput1909*x23+mexinput1910*x24+mexinput1911*x25-mexinput2009*mexinput2012)/mexinput2009/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1912*x1+mexinput1913*x2+mexinput1914*x3+mexinput1915*x4+mexinput1916*x5+mexinput1917*x6+mexinput1918*x7+mexinput1919*x8+mexinput1920*x9+mexinput1921*x10+mexinput1922*x11+mexinput1923*x12+mexinput1924*x13+mexinput1925*x14+mexinput1926*x15+mexinput1927*x16+mexinput1928*x17+mexinput1929*x18+mexinput1930*x19+mexinput1931*x20+mexinput1932*x21+mexinput1933*x22+mexinput1934*x23+mexinput1935*x24+mexinput1936*x25-mexinput2010*mexinput2012)/mexinput2010/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_END, (mexinput1937*x1+mexinput1938*x2+mexinput1939*x3+mexinput1940*x4+mexinput1941*x5+mexinput1942*x6+mexinput1943*x7+mexinput1944*x8+mexinput1945*x9+mexinput1946*x10+mexinput1947*x11+mexinput1948*x12+mexinput1949*x13+mexinput1950*x14+mexinput1951*x15+mexinput1952*x16+mexinput1953*x17+mexinput1954*x18+mexinput1955*x19+mexinput1956*x20+mexinput1957*x21+mexinput1958*x22+mexinput1959*x23+mexinput1960*x24+mexinput1961*x25-mexinput2011*mexinput2012)/mexinput2011/mexinput2012 <= 0.00000000000000000000e+00);
    ocp1.subjectTo(AT_START, (-mexinput2013+ps1) <= (-mexinput2014));


    OptimizationAlgorithm algo1(ocp1);
    algo1.set( HESSIAN_APPROXIMATION, EXACT_HESSIAN );
    algo1.set( KKT_TOLERANCE, 1.000000E-12 );
    algo1.set( INTEGRATOR_TOLERANCE, 1.000000E-06 );
    algo1.set( INTEGRATOR_TYPE, INT_RK45 );
    algo1.set( DISCRETIZATION_TYPE, MULTIPLE_SHOOTING );
    algo1.set( ABSOLUTE_TOLERANCE, 1.000000E-06 );
    algo1.set( MAX_NUM_ITERATIONS, 1000 );
    returnValue returnvalue = algo1.solve();

    VariablesGrid out_states; 
    VariablesGrid out_parameters; 
    VariablesGrid out_controls; 
    VariablesGrid out_disturbances; 
    VariablesGrid out_algstates; 
    algo1.getDifferentialStates(out_states);
    algo1.getControls(out_controls);
    algo1.getParameters(out_parameters);
    const char* outputFieldNames[] = {"STATES", "CONTROLS", "PARAMETERS", "DISTURBANCES", "ALGEBRAICSTATES", "CONVERGENCE_ACHIEVED"}; 
    plhs[0] = mxCreateStructMatrix( 1,1,6,outputFieldNames ); 
    mxArray *OutS = NULL;
    double  *outS = NULL;
    OutS = mxCreateDoubleMatrix( out_states.getNumPoints(),1+out_states.getNumValues(),mxREAL ); 
    outS = mxGetPr( OutS );
    for( int i=0; i<out_states.getNumPoints(); ++i ){ 
      outS[0*out_states.getNumPoints() + i] = out_states.getTime(i); 
      for( int j=0; j<out_states.getNumValues(); ++j ){ 
        outS[(1+j)*out_states.getNumPoints() + i] = out_states(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"STATES",OutS );
    mxArray *OutC = NULL;
    double  *outC = NULL;
    OutC = mxCreateDoubleMatrix( out_controls.getNumPoints(),1+out_controls.getNumValues(),mxREAL ); 
    outC = mxGetPr( OutC );
    for( int i=0; i<out_controls.getNumPoints(); ++i ){ 
      outC[0*out_controls.getNumPoints() + i] = out_controls.getTime(i); 
      for( int j=0; j<out_controls.getNumValues(); ++j ){ 
        outC[(1+j)*out_controls.getNumPoints() + i] = out_controls(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"CONTROLS",OutC );
    mxArray *OutP = NULL;
    double  *outP = NULL;
    OutP = mxCreateDoubleMatrix( out_parameters.getNumPoints(),1+out_parameters.getNumValues(),mxREAL ); 
    outP = mxGetPr( OutP );
    for( int i=0; i<out_parameters.getNumPoints(); ++i ){ 
      outP[0*out_parameters.getNumPoints() + i] = out_parameters.getTime(i); 
      for( int j=0; j<out_parameters.getNumValues(); ++j ){ 
        outP[(1+j)*out_parameters.getNumPoints() + i] = out_parameters(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"PARAMETERS",OutP );
    mxArray *OutW = NULL;
    double  *outW = NULL;
    OutW = mxCreateDoubleMatrix( out_disturbances.getNumPoints(),1+out_disturbances.getNumValues(),mxREAL ); 
    outW = mxGetPr( OutW );
    for( int i=0; i<out_disturbances.getNumPoints(); ++i ){ 
      outW[0*out_disturbances.getNumPoints() + i] = out_disturbances.getTime(i); 
      for( int j=0; j<out_disturbances.getNumValues(); ++j ){ 
        outW[(1+j)*out_disturbances.getNumPoints() + i] = out_disturbances(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"DISTURBANCES",OutW );
    mxArray *OutZ = NULL;
    double  *outZ = NULL;
    OutZ = mxCreateDoubleMatrix( out_algstates.getNumPoints(),1+out_algstates.getNumValues(),mxREAL ); 
    outZ = mxGetPr( OutZ );
    for( int i=0; i<out_algstates.getNumPoints(); ++i ){ 
      outZ[0*out_algstates.getNumPoints() + i] = out_algstates.getTime(i); 
      for( int j=0; j<out_algstates.getNumValues(); ++j ){ 
        outZ[(1+j)*out_algstates.getNumPoints() + i] = out_algstates(i, j); 
       } 
    } 

    mxSetField( plhs[0],0,"ALGEBRAICSTATES",OutZ );
    mxArray *OutConv = NULL;
    if ( returnvalue == SUCCESSFUL_RETURN ) { OutConv = mxCreateDoubleScalar( 1 ); }else{ OutConv = mxCreateDoubleScalar( 0 ); } 
    mxSetField( plhs[0],0,"CONVERGENCE_ACHIEVED",OutConv );


    clearAllStaticCounters( ); 
 
} 

