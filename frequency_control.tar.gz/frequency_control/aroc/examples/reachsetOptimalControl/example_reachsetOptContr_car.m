% This script demonstrates the Reachset Optimal Control Algorithm on the 
% turn right maneuver of a car

%% EXACT CONTROLLER

% load benchmark parameter
Param = param_car_turnRight();

% define algorithm options
Opts = settings_reachsetOptContr_car();

% offline phase computations
[objContr,res] = reachsetOptimalControl('car',Param,Opts);

% simulation 
[res,~,~] = simulateRandom(objContr,res,10,0.5,0.6,2);

% visualization
figure
hold on
box on
plotReach(res,[1,2],[.7 .7 .7]);
plotReachTimePoint(res,[1,2],'b');
plotSimulation(res,[1,2],'k');
xlabel('v');
ylabel('\phi');

figure
hold on
box on
plotReach(res,[3,4],[.7 .7 .7]);
plotReachTimePoint(res,[3,4],'b');
plotSimulation(res,[3,4],'k');
xlabel('x');
ylabel('y');
