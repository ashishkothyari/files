% This script demonstrates frequency control for IEEE 14 bus benchmark 
% model using model predictive control

% load benchmark parameter
Param = param_powDyn1();

% define algorithm options
Opts = settings_reachsetMPC_powDyn(Param);

[u,x] = reachsetMPC('powDyn_algCompDCFlow',Param,Opts);




