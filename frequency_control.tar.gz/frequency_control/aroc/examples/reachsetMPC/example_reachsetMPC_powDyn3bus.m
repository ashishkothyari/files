Param = param_powDyn3bus1();

% define algorithm options
Opts = settings_reachsetMPC_powDyn3bus(Param);

% offline phase computations
[u,x] = reachsetMPC('powDyn_algCompDCFlow3bus',Param,Opts);

% visualization
%figure; hold on; box on
%plot(Opts.termReg,[1,2],'g','EdgeColor','none','FaceAlpha',0.5,'Filled',true);
%plotReach(res,[1,2],[.7 .7 .7]);
%plotReachTimePoint(res,[1,2],'b');
%plotSimulation(res,[1,2],'r');
%xlabel('C_A');
%ylabel('T');
%xlim([-0.2,0.15]);
%ylim([-50,5]);
