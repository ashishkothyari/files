% This script demonstrates the performance of the Safety Net Controller on
% the example of a turn-right maneuver of the car benchmark

% load benchmark parameter
Param = param_car_turnRight();


%% LQR COMFORT CONTROLLER

% define algorithm options
Opts = settings_safetyNetContr_car();

% offline phase computations
[objContr,res] = safetyNetControl('car',Param,Opts);

% simulation
[res,~,~] = simulateRandom(objContr,res,10,0.5,0.6,2);

% visualization
figure
hold on
box on
plotReach(res,[1,2],[.7 .7 .7]);
plotReachTimePoint(res,[1,2],'b');
plotSimulation(res,[1,2],'k');
xlabel('v');
ylabel('\phi');
title('LQR comfort controller');

figure
hold on
box on
plotReach(res,[3,4],[.7 .7 .7]);
plotReachTimePoint(res,[3,4],'b');
plotSimulation(res,[3,4],'k');
xlabel('x');
ylabel('y');
title('LQR comfort controller');


%% MPC COMFORT CONTROLLER

% define algorithm options
Opts = settings_safetyNetContr_car();

Opts.controller = 'MPC';
contrOpts.Q = diag([12 10 60 35]);
contrOpts.R = diag([0.1 1]);
contrOpts.horizon = 12;
Opts.contrOpts = contrOpts;

% offline phase computations
[objContr,res] = safetyNetControl('car',Param,Opts);

% simulation
[res,~,~] = simulateRandom(objContr,res,10,0.5,0.6,2);

% visualization
figure
hold on
box on
plotReach(res,[1,2],[.7 .7 .7]);
plotReachTimePoint(res,[1,2],'b');
plotSimulation(res,[1,2],'k');
xlabel('v');
ylabel('\phi');
title('MPC comfort controller');

figure
hold on
box on
plotReach(res,[3,4],[.7 .7 .7]);
plotReachTimePoint(res,[3,4],'b');
plotSimulation(res,[3,4],'k');
xlabel('x');
ylabel('y');
title('MPC comfort controller');