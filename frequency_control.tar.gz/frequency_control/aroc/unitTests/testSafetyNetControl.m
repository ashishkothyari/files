%% Test LQR Comfort Controller

% load benchmark parameter
Param = param_car_turnRight();

% define algorithm options
Opts = settings_safetyNetContr_car();

% offline phase computations
[obj,result] = safetyNetControl('car',Param,Opts);

% simulation
[result,~,~] = simulateRandom(obj,result,10,0.5,0.6,2);

% check if the input constraints are satisfied
res = checkSimInputs(result,Param.U);
assert(res == 1);

% check if the end point of the simulation are located inside the final 
% reachable set
res = checkFinalSimPoints(result);
assert(res == 1);

% check if the final reachable set is contained in the shifted initial set
res = checkFinalInInitSet(result,result.reachSetTimePoint{1});
assert(res == 1);

% check if the inital reachable set is identical to the stored result
I = interval( ...
[12.0003795165043279; -0.1169492324475189; -4.0149744555772422; -1.3109692176323655], ...
[27.9993705093748595; 0.1131919212068887; 4.0231516728795373; 1.3854760669553605]);

res = checkInitialSet(result,I);
assert(res == 1);


%% Test MPC Comfort Controller

% load benchmark parameter
Param = param_car_turnRight();

% define algorithm options
Opts = settings_safetyNetContr_car();

Opts.controller = 'MPC';
contrOpts.Q = 2*diag([12 10 60 35]);
contrOpts.R = 2*diag([1 1.5]);
contrOpts.horizon = 12;
Opts.contrOpts = contrOpts;

% offline phase computations
[obj,result] = safetyNetControl('car',Param,Opts);

% simulation 
[result,~,~] = simulateRandom(obj,result,10,0.5,0.6,2);

% check if the input constraints are satisfied
res = checkSimInputs(result,Param.U);
assert(res == 1);

% check if the end point of the simulation are located inside the final 
% reachable set
res = checkFinalSimPoints(result);
assert(res == 1);

% check if the final reachable set is contained in the shifted initial set
res = checkFinalInInitSet(result,result.reachSetTimePoint{1});
assert(res == 1);

% check if the initial reachable set is identical to the stored result
I = interval( ...
[12.0003795165043279; -0.1169492324475189; -4.0149744555772422; -1.3109692176323655], ...
[27.9993705093748595; 0.1131919212068887; 4.0231516728795373; 1.3854760669553605]);

res = checkInitialSet(result,I);
assert(res == 1);