%% Test Linear System

% get benchmark parameter
Param = param_platoon();

% define algorithm options
Opts = settings_optBasedContr_platoon();

% offline phase computations
[objContr,res] = optimizationBasedControl('platoon',Param,Opts);

% simulation 
[result,~,~] = simulateRandom(objContr,res,10,0.5,0.6,2);

% check if the input constraints are satisfied
res = checkSimInputs(result,Param.U);
assert(res == 1);

% check if the end point of the simulation are located inside the final 
% reachable set
res = checkFinalSimPoints(result);
assert(res == 1);

% check if the final reachable set is contained in the shifted initial set
res = checkFinalInInitSet(result,Param.R0);
assert(res == 1);

% check if the final reachable set is identical to the stored result
I = interval( ...
[20.7729248142885154; 21.7336198555074951; 0.8642301225774796; -0.0124750099493406; 0.8410928589181423; -0.0699043173605096; 0.8170244000401192; -0.1656332926558900], ...
[21.1519940224786254; 22.0200024296014156; 1.1988241171024898; 0.1897937409151929; 1.2035331757578998; 0.1849110797454573; 1.2059540930029193; 0.2222378900221844]);

res = checkFinalSet(result,I);
assert(res == 1);


%% Test Nonlinear System

% get benchmark parameter
Param = param_car_turnRight();

% define algorithm options
Opts = settings_optBasedContr_car();

% offline phase computations
[objContr,res] = optimizationBasedControl('car',Param,Opts);

% simulation 
[result,~,~] = simulateRandom(objContr,res,10,0.5,0.6,2);

% check if the input constraints are satisfied
res = checkSimInputs(result,Param.U);
assert(res == 1);

% check if the end point of the simulation are located inside the final 
% reachable set
res = checkFinalSimPoints(result);
assert(res == 1);

% check if the final reachable set is contained in the shifted initial set
res = checkFinalInInitSet(result,Param.R0);
assert(res == 1);

% check if the final reachable set is identical to the stored result
I = interval( ...
[19.9706695059227428; -0.2032829568454538; 19.7775031633612812; -2.0245164857636526], ...
[20.0295074113861489; -0.1927385149220238; 19.9621420474746998; -1.9554380233745596]);

res = checkFinalSet(result,I);
assert(res == 1);