%% Test Generator Space Control

% get benchmark parameter
Param = param_car_turnRight();

% define algorithm options
Opts = settings_genSpaceContr_car();
Opts = rmfield(Opts,'extHorizon');

% offline phase computations
[obj,result] = generatorSpaceControl('car',Param,Opts);

% simulation 
[result,~,~] = simulateRandom(obj,result,10,0.5,0.6,2);

% check if the input constraints are satisfied
res = checkSimInputs(result,Param.U);
assert(res == 1);

% check if the end point of the simulation are located inside the final 
% reachable set
res = checkFinalSimPoints(result);
assert(res == 1);

% check if the final reachable set is contained in the shifted initial set
res = checkFinalInInitSet(result,Param.R0);
assert(res == 1);

% check if the final reachable set is identical to the stored result
I = interval( ...
[19.9498970693088822; -0.2020041757825786; 19.8420229844045899; -2.1884976584574924], ...
[20.0501029306911178; -0.1979958242174105; 19.8979774297836407; -1.7915023831906454]);

res = checkFinalSet(result,I);
assert(res == 1);


%% Test Extendet Optimization Horizon

% get benchmark parameter
Param = param_car_turnRight();

% define algorithm options
Opts = settings_genSpaceContr_car();

Opts.extHorizon.active = 1;
Opts.extHorizon.horizon = 3;
Opts.extHorizon.decay = 'fall';

% offline phase computations
[obj,result] = generatorSpaceControl('car',Param,Opts);

% simulation 
[result,~,~] = simulateRandom(obj,result,10,0.5,0.6,2);

% check if the input constraints are satisfied
res = checkSimInputs(result,Param.U);
assert(res == 1);

% check if the end point of the simulation are located inside the final 
% reachable set
res = checkFinalSimPoints(result);
assert(res == 1);

% check if the final reachable set is contained in the shifted initial set
res = checkFinalInInitSet(result,Param.R0);
assert(res == 1);

% check if the final reachable set is identical to the stored result
I = interval( ...
[19.9499594990694433; -0.2020034889977863; 19.8156256499724641; -1.9968112289210753], ...
[20.0500405009305567; -0.1979965110022028; 19.9243747642157665; -1.9831888127270625]);

res = checkFinalSet(result,I);
assert(res == 1);